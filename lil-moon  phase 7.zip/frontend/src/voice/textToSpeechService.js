// Text-to-speech through the system's installed voices (Chromium speechSynthesis -> Windows voices). Local: no audio is sent anywhere.
const synth = () => (typeof window !== 'undefined' && window.speechSynthesis) || null;

export const ttsAvailable = () => !!synth() && typeof window.SpeechSynthesisUtterance === 'function';

// Voices can load late; wait briefly for them.
export function listVoices() {
  const s = synth();
  if (!s) return Promise.resolve([]);
  const now = s.getVoices();
  if (now.length) return Promise.resolve(now);
  return new Promise((resolve) => {
    const done = () => { s.removeEventListener?.('voiceschanged', done); resolve(s.getVoices()); };
    s.addEventListener?.('voiceschanged', done);
    setTimeout(done, 1500);
  });
}

// Resolves with how it ended: 'spoken' | 'muted' | 'cancelled' | 'unavailable'.
export function speak(text, { voiceName = null, rate = 1, volume = 1, muted = false } = {}) {
  const s = synth();
  if (muted || !text) return Promise.resolve('muted');
  if (!ttsAvailable()) return Promise.resolve('unavailable');
  return new Promise((resolve) => {
    try {
      s.cancel(); // never talk over ourselves
      const u = new window.SpeechSynthesisUtterance(String(text).slice(0, 600));
      u.rate = Math.min(2, Math.max(0.5, rate));
      u.volume = Math.min(1, Math.max(0, volume));
      const v = voiceName ? s.getVoices().find((x) => x.name === voiceName) : null;
      if (v) u.voice = v;
      u.onend = () => resolve('spoken');
      u.onerror = (e) => resolve(e && (e.error === 'canceled' || e.error === 'interrupted') ? 'cancelled' : 'unavailable');
      s.speak(u);
    } catch { resolve('unavailable'); }
  });
}

// Immediate: speech stops now.
export const stopSpeaking = () => { try { synth()?.cancel(); } catch { /* nothing to stop */ } };
