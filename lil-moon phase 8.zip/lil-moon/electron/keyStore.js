// Holds the AI provider API key. Lives ONLY in the main process; the dashboard can set or clear it but never read it.
// Stored encrypted with the operating system's secure storage (Windows DPAPI via Electron safeStorage).
// LILMOON_AI_API_KEY, if set in the environment, takes precedence and nothing is written to disk.
const { app, safeStorage } = require('electron');
const fs = require('fs');
const path = require('path');

function createKeyStore() {
  const file = () => path.join(app.getPath('userData'), 'ai-key.bin');
  let cache;
  const env = () => process.env.LILMOON_AI_API_KEY || null;
  const stored = () => {
    if (cache !== undefined) return cache;
    try { cache = safeStorage.decryptString(fs.readFileSync(file())); } catch { cache = null; }
    return cache;
  };
  return {
    has: () => !!(env() || stored()),
    get: () => env() || stored(),
    source: () => (env() ? 'environment' : stored() ? 'stored' : null),
    set(key) {
      if (!safeStorage.isEncryptionAvailable()) {
        throw Object.assign(new Error('Secure storage is not available on this computer, so the key was not saved. Set the LILMOON_AI_API_KEY environment variable instead.'), { httpStatus: 503, code: 'encryption_unavailable' });
      }
      fs.writeFileSync(file(), safeStorage.encryptString(key), { mode: 0o600 });
      cache = key;
    },
    clear() { cache = null; try { fs.unlinkSync(file()); } catch { /* nothing stored */ } },
  };
}

module.exports = { createKeyStore };
