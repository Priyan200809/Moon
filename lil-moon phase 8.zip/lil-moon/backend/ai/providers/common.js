// Shared provider plumbing. A provider is: async function* stream({ settings, apiKey, system, messages, tools, signal })
// yielding { type: 'text', text } and { type: 'tool_call', id, name, args }.
// Neutral messages: { role: 'user'|'assistant'|'tool', content, toolCalls?: [{id,name,args}], toolCallId? }.
class ProviderError extends Error {
  constructor(kind, message, extra = {}) { super(message); this.kind = kind; Object.assign(this, extra); }
}

const scrub = (text, key) => (key ? String(text).split(key).join('***') : String(text));

async function classify(res, apiKey) {
  let detail = '';
  try { const j = JSON.parse(await res.text()); detail = j?.error?.message ?? j?.message ?? ''; } catch { /* not JSON */ }
  detail = scrub(detail, apiKey).slice(0, 200);
  const s = res.status;
  if (s === 401 || s === 403) return new ProviderError('auth', 'The AI provider rejected the API key. Check it in the AI setup.', { status: s });
  if (s === 404) return new ProviderError('bad_request', `The AI provider could not find that model or address.${detail ? ` (${detail})` : ''}`, { status: s });
  if (s === 429) return new ProviderError('rate_limit', 'The AI provider is rate limiting requests. Wait a moment and try again.', { status: s, retryAfter: Number(res.headers.get('retry-after')) || null });
  if (s >= 500) return new ProviderError('server', 'The AI provider had a problem. Try again shortly.', { status: s });
  return new ProviderError('bad_request', `The AI provider refused the request.${detail ? ` (${detail})` : ''}`, { status: s });
}

// POST JSON and return the Response, with one polite retry for 429/503 before any output was produced.
async function post(url, { headers, body, signal, apiKey }) {
  const attempt = async () => {
    try {
      return await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body), signal: AbortSignal.any([signal, AbortSignal.timeout(180000)].filter(Boolean)) });
    } catch (err) {
      if (signal?.aborted) throw new ProviderError('aborted', 'Stopped.');
      throw new ProviderError('network', 'Could not reach the AI provider. Check your internet connection and the provider address.');
    }
  };
  let res = await attempt();
  if ((res.status === 429 || res.status === 503) && !signal?.aborted) {
    const wait = Math.min(3000, (Number(res.headers.get('retry-after')) || 1) * 1000);
    await res.arrayBuffer().catch(() => {});
    await new Promise((r) => setTimeout(r, wait));
    res = await attempt();
  }
  if (!res.ok) throw await classify(res, apiKey);
  return res;
}

// Parse a Server-Sent-Events body into { event, data } objects.
async function* sse(res, signal) {
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  try {
    for (;;) {
      let chunk;
      try { chunk = await reader.read(); } catch { throw new ProviderError(signal?.aborted ? 'aborted' : 'network', signal?.aborted ? 'Stopped.' : 'The connection to the AI provider was interrupted.'); }
      if (chunk.done) break;
      buf += dec.decode(chunk.value, { stream: true });
      let i;
      while ((i = buf.search(/\r?\n\r?\n/)) >= 0) {
        const raw = buf.slice(0, i);
        buf = buf.slice(i).replace(/^\r?\n\r?\n/, '');
        let event = 'message', data = '';
        for (const line of raw.split(/\r?\n/)) {
          if (line.startsWith('event:')) event = line.slice(6).trim();
          else if (line.startsWith('data:')) data += line.slice(5).trim();
        }
        if (data) yield { event, data };
      }
    }
  } finally { reader.cancel().catch(() => {}); }
}

const safeJson = (s) => { try { return JSON.parse(s); } catch { return null; } };

module.exports = { ProviderError, post, sse, safeJson, scrub };
