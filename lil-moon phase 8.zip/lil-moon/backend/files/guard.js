// What the indexer may never touch. Applied when a folder is added AND while walking it.
const path = require('path');

const DENIED_DIRS = new Set([
  'node_modules', '.git', '.svn', '.hg', '__pycache__', '.venv', 'venv', '.tox', '.idea', '.vs',
  '$recycle.bin', 'system volume information', 'appdata', 'application data', 'windows', 'program files', 'program files (x86)', 'programdata',
  '.ssh', '.gnupg', '.aws', '.azure', '.kube', '.docker', '.config', '.cache', '.mozilla', '.thunderbird', 'user data',
]);
const DENIED_FILE = [
  /^\.env(\..*)?$/i, /^id_(rsa|dsa|ecdsa|ed25519)/i, /\.(pem|key|pfx|p12|kdbx|keystore|jks|ppk|gpg|asc)$/i,
  /^(credentials|secrets?|passwords?|tokens?)\b/i, /^(known_hosts|authorized_keys|\.netrc|\.npmrc|\.pypirc|\.git-credentials)$/i,
  /^(cookies|login data|web data|history|key[34]\.db|logins\.json)$/i,
];

const isDeniedDirName = (name) => DENIED_DIRS.has(name.toLowerCase());
const isDeniedFileName = (name) => DENIED_FILE.some((re) => re.test(name));

const PROTECTED_POSIX = ['/etc', '/usr', '/bin', '/sbin', '/lib', '/var', '/sys', '/proc', '/dev', '/boot', '/root', '/opt', '/private'];
const PROTECTED_WIN = ['windows', 'program files', 'program files (x86)', 'programdata', '$recycle.bin', 'system volume information'];

// Returns a human reason if the folder must not be indexed, otherwise null.
function protectedFolderReason(folder, { userData = null } = {}) {
  const abs = path.resolve(folder);
  const parsed = path.parse(abs);
  if (abs === parsed.root) return 'A whole drive or the filesystem root cannot be indexed. Pick a specific folder.';
  const rel = abs.slice(parsed.root.length).split(/[\\/]+/).filter(Boolean).map((s) => s.toLowerCase());
  if (path.sep === '\\') {
    if (PROTECTED_WIN.includes(rel[0])) return 'System folders cannot be indexed.';
    if (rel.some((seg) => ['appdata', 'user data'].includes(seg))) return 'Application data and browser profile folders cannot be indexed.';
  } else if (PROTECTED_POSIX.some((p) => abs === p || abs.startsWith(p + '/'))) return 'System folders cannot be indexed.';
  if (rel.some((seg) => ['.ssh', '.gnupg', '.aws', '.azure', '.kube'].includes(seg))) return 'Credential folders cannot be indexed.';
  if (userData) {
    const ud = path.resolve(userData);
    if (abs === ud || abs.startsWith(ud + path.sep)) return "Lil Moon's own data folder cannot be indexed.";
  }
  return null;
}

module.exports = { isDeniedDirName, isDeniedFileName, protectedFolderReason };
