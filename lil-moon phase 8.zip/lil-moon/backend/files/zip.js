// Minimal, defensive ZIP reader (enough for .docx). Reads ONE named entry; never extracts to disk.
const zlib = require('zlib');

function readEntry(buf, wanted, { maxBytes = 50 * 1024 * 1024 } = {}) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Not a valid ZIP file.');
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Corrupt ZIP directory.');
    const flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10);
    const csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nameLen = buf.readUInt16LE(p + 28), extraLen = buf.readUInt16LE(p + 30), commentLen = buf.readUInt16LE(p + 32);
    const offset = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen);
    p += 46 + nameLen + extraLen + commentLen;
    if (name !== wanted) continue;
    if (flags & 1) throw new Error('Encrypted documents are not supported.');
    if (csize === 0xffffffff || usize === 0xffffffff) throw new Error('ZIP64 files are not supported.');
    if (usize > maxBytes) throw new Error('Document is too large to read safely.');
    if (buf.readUInt32LE(offset) !== 0x04034b50) throw new Error('Corrupt ZIP entry.');
    const start = offset + 30 + buf.readUInt16LE(offset + 26) + buf.readUInt16LE(offset + 28);
    const data = buf.subarray(start, start + csize);
    if (method === 0) return data;
    if (method === 8) return zlib.inflateRawSync(data, { maxOutputLength: maxBytes }); // bounded: zip-bomb safe
    throw new Error('Unsupported ZIP compression.');
  }
  return null;
}

module.exports = { readEntry };
