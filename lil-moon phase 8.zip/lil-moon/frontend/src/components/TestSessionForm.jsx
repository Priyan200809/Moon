import { useState } from 'react';
import { api } from '../lib/api.js';

// Manual entry so the database can be exercised before automatic tracking exists (a later phase).
export default function TestSessionForm({ category, noun, onAdded }) {
  const [name, setName] = useState('');
  const [minutes, setMinutes] = useState(10);
  const [msg, setMsg] = useState({ text: '', error: false });
  const [busy, setBusy] = useState(false);
  const valid = name.trim() && Number.isInteger(minutes) && minutes >= 1 && minutes <= 600;

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const end = new Date();
      await api('POST', '/api/usage/sessions', { category, itemName: name.trim(), startedAt: new Date(end - minutes * 60000).toISOString(), endedAt: end.toISOString() });
      setMsg({ text: 'Session added.', error: false });
      setName('');
      onAdded();
    } catch (err) {
      setMsg({ text: err.message, error: true });
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="test-form" onSubmit={submit}>
      <label className="field">Name of the {noun}
        <input value={name} maxLength={200} onChange={(e) => setName(e.target.value)} placeholder={category === 'application' ? 'Notepad' : 'example.com'} />
      </label>
      <label className="field">Minutes used
        <input type="number" min="1" max="600" value={Number.isNaN(minutes) ? '' : minutes} onChange={(e) => setMinutes(e.target.valueAsNumber)} />
      </label>
      <button className="btn" type="submit" disabled={!valid || busy}>Add test session</button>
      <span role="status" className={msg.error ? 'msg-error' : ''}>{msg.text}</span>
    </form>
  );
}
