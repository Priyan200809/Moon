# Lil Moon (Phase 1)

A floating, moon-shaped desktop companion for Windows. Neobrutalism look, built with Electron + React.

## Setup (Windows 10/11)
1. Install Node.js 20 or newer (LTS) from https://nodejs.org (includes npm).
2. Open PowerShell in this folder and run:
```
npm install
```

## Run
- Normal run (builds the UI, then launches): `npm start`
- Development (Vite dev server, UI reloads on save): `npm run dev`
- Build the UI only: `npm run build`
- Automated smoke test: `npm run smoke` (Linux/CI with a display; see "Testing")

## Use
- Drag the moon anywhere. A short click opens the dashboard; a drag never does.
- Clicking again focuses (or restores) the same dashboard window.
- Dashboard buttons: Minimize, Close (moon stays), Exit Lil Moon (quits everything).
- Right-click the moon for Open dashboard / Exit Lil Moon.
- The moon's position is saved to `%APPDATA%\lil-moon\settings.json` and restored on launch.

## Dashboard (Phase 2)
Sections: Home, Application usage, Website usage, Voice assistant, Settings (left sidebar, top tabs when narrow).
- **Works:** navigation, progress bars and remaining-time maths, default daily limit (saved, validated in the main process, drives the sample data), theme (Sunny yellow / Cream / Lilac, saved and applied on launch).
- **Placeholder:** all usage numbers (labelled "Sample data"), microphone button, command history, example commands, "Start with Windows" (saved but not applied).
Settings are stored under `preferences` in `%APPDATA%\lil-moon\settings.json`, next to the moon position.

## Layout
```
electron/   main.js (lifecycle + IPC validation), windowManager.js (windows, drag), settingsStore.js (settings file), preload.js (bridge)
frontend/   React UI (one bundle, routes #/moon and #/dashboard): pages/, components/, hooks/, data/sampleData.js
scripts/    dev.js (Vite + Electron), smoke.js (automated test)
```

## Security
contextIsolation on, nodeIntegration off, sandbox on, preload exposes only fixed no-argument commands, main checks that each command comes from the correct window's top frame, navigation and new windows are blocked, production CSP is set in index.html. No filesystem or shell access is exposed.

## Troubleshooting
- Blank or missing moon: run `npm run build` first, or use `npm start`.
- Electron download failed during install: re-run `npm install`, or `node node_modules/electron/install.js`.
- Port 5173 busy in dev: close the other Vite process.
- Moon hidden behind a full-screen exclusive game: expected; borderless/windowed games are fine.
- Reset the moon's position: delete `%APPDATA%\lil-moon\settings.json`.

## Implemented
Floating frameless transparent always-on-top moon, drag vs click detection, dashboard with sample-data cards, single dashboard instance, minimize/close/exit, edge clamping, multi-monitor and display-change handling, saved position.

## Known limitations
- Application/website usage, voice assistant and settings are visual placeholders; sample data is labelled.
- No tray icon or app icon yet (the moon's right-click menu is the way out without opening the dashboard).
- Windows-specific behaviour (DPI scaling, always-on-top over other topmost windows) was not tested on real Windows.

## Testing
`npm run smoke` runs two phases (set `SMOKE_PHASE=1` then `2` with the same `SMOKE_DIR`) to check restart persistence. Under Linux use `xvfb-run -a npx electron --no-sandbox scripts/smoke.js`.
