// Pairing code: the user-visible secret that lets one browser extension talk to /ext. Only its SHA-256 is stored.
const crypto = require('crypto');
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I

function generateCode() {
  const bytes = crypto.randomBytes(24);
  let raw = '';
  for (let i = 0; i < 24; i++) raw += ALPHABET[bytes[i] % ALPHABET.length]; // ~120 bits
  return raw.match(/.{4}/g).join('-');
}
const normalize = (code) => String(code).toUpperCase().replace(/[^A-Z0-9]/g, '');
const hashCode = (code) => crypto.createHash('sha256').update(normalize(code)).digest('hex');
const verifyCode = (code, hash) => {
  const a = Buffer.from(hashCode(code), 'hex'), b = Buffer.from(hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};

module.exports = { generateCode, hashCode, verifyCode };
