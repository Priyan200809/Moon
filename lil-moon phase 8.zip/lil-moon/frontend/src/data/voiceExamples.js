// Display-only examples for the Voice assistant page. Voice commands are not implemented yet.
export const exampleCommands = [
  'Open Notepad',
  'How long have I used my browser today?',
  'Set my daily limit to 4 hours',
  'Hide the moon for 10 minutes',
];
