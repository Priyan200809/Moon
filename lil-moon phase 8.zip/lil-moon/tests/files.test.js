const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { openDatabase } = require('../backend/database');
const { createAiRepository } = require('../backend/aiRepo');
const { createIndexer } = require('../backend/files/indexer');
const { searchFiles, searchChunks } = require('../backend/files/search');
const { protectedFolderReason } = require('../backend/files/guard');
const { chunkSections, SIZE } = require('../backend/files/chunk');
const { redactSecrets } = require('../backend/safety');
const { makePdf, makeDocx } = require('./fixtures');

const w = (root, rel, data) => { const f = path.join(root, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, data); return f; };

function setup() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'lm-files-'));
  const outside = fs.mkdtempSync(path.join(os.tmpdir(), 'lm-outside-'));
  w(root, 'notes/dbms_notes.txt', 'Database management systems cover normalization, ACID transactions and SQL joins.\n\nThe zebra crossing example explains deadlocks.');
  w(root, 'notes/testing.docx', makeDocx([{ heading: 'Software Testing' }, 'Black box testing ignores internals while white box testing inspects them.', 'Mutation score measures test quality.']));
  w(root, 'notes/networks.pdf', makePdf(['Computer networks overview', 'The quantum entanglement handshake is fictional.']));
  w(root, 'README.md', '# Project\n\nIntro.\n\n## SQLite storage\n\nWe store data in SQLite with FTS5 search.');
  w(root, 'code/gcd.py', 'def gcd(a, b):\n    # Euclid algorithm\n    while b:\n        a, b = b, a % b\n    return a\n');
  w(root, 'code/config.py', 'api_key = "sk-abcdefghijklmnopqrstuvwxyz123456"\nTIMEOUT = 30\npassword = hunter2hunter2\n');
  w(root, 'data/people.csv', 'name,city\nAsha,Chennai\nRavi,Madurai\n');
  w(root, 'data/settings.json', '{"theme":"dark","lang":"en"}');
  w(root, 'web/page.html', '<h1>Hello hypertext</h1>');
  w(root, 'web/style.css', 'body { color: purple; }');
  w(root, 'db/schema.sql', 'CREATE TABLE widgets (id INTEGER PRIMARY KEY);');
  // things that must never be indexed
  w(root, '.env', 'SECRET_TOKEN=supersecretvalue');
  w(root, 'ssh/id_rsa', '-----BEGIN OPENSSH PRIVATE KEY-----\nAAAA\n-----END OPENSSH PRIVATE KEY-----');
  w(root, 'credentials.json', '{"token":"leakedtokenvalue"}');
  w(root, 'certs/server.pem', 'pemcontentxyz');
  w(root, 'node_modules/lib/index.js', 'var neverindexedmodule = 1;');
  w(root, 'AppData/Local/x.txt', 'appdatasecretcontent');
  w(root, 'notes/key.txt', '-----BEGIN RSA PRIVATE KEY-----\nMIIEow\n-----END RSA PRIVATE KEY-----');
  w(root, 'bin/blob.txt', Buffer.from([0x41, 0x00, 0x42, 0x00]));
  w(root, 'big/huge.txt', 'x'.repeat(3 * 1024 * 1024));
  w(root, 'notes/broken.pdf', 'this is not a pdf');
  w(outside, 'outside_secret.txt', 'outsidesymlinktarget');
  try { fs.symlinkSync(path.join(outside, 'outside_secret.txt'), path.join(root, 'link.txt')); fs.symlinkSync(outside, path.join(root, 'linkdir')); } catch { /* symlinks unavailable */ }
  const db = openDatabase(':memory:');
  const aiRepo = createAiRepository(db);
  const indexer = createIndexer({ aiRepo });
  const folder = aiRepo.addFolder(root);
  return { root, db, aiRepo, indexer, folder };
}
const files = (t) => t.db.prepare('SELECT rel_path, status, note FROM indexed_files ORDER BY rel_path').all();
const hit = (t, q) => searchFiles(t.db, q).map((h) => h.relPath);

test('indexes every supported type and ignores secrets, system folders, links, binaries and huge files', async () => {
  const t = setup();
  await t.indexer.index(t.folder.id);
  const rows = files(t);
  const indexed = rows.filter((r) => r.status === 'indexed').map((r) => r.rel_path);
  assert.deepEqual(indexed, ['README.md', 'code/config.py', 'code/gcd.py', 'data/people.csv', 'data/settings.json', 'db/schema.sql', 'notes/dbms_notes.txt', 'notes/networks.pdf', 'notes/testing.docx', 'web/page.html', 'web/style.css']);
  const all = rows.map((r) => r.rel_path).join(' ');
  for (const never of ['.env', 'id_rsa', 'credentials.json', 'server.pem', 'node_modules', 'AppData', 'link.txt', 'linkdir', 'outside_secret']) assert.ok(!all.includes(never), never);
  assert.equal(rows.find((r) => r.rel_path === 'notes/key.txt').status, 'skipped');   // private key content
  assert.equal(rows.find((r) => r.rel_path === 'bin/blob.txt').status, 'skipped');    // binary
  assert.equal(rows.find((r) => r.rel_path === 'big/huge.txt').status, 'skipped');    // too large
  assert.equal(rows.find((r) => r.rel_path === 'notes/broken.pdf').status, 'error');  // unreadable PDF reported, not fatal
  assert.equal(t.aiRepo.getFolder(t.folder.id).status, 'idle');
  assert.ok(t.aiRepo.getFolder(t.folder.id).lastIndexedAt);
  const f = t.aiRepo.listFolders()[0];
  assert.equal(f.indexedFiles, 11);
  assert.equal(t.db.prepare("SELECT COUNT(*) n FROM file_chunks WHERE text LIKE '%sk-abcdef%' OR text LIKE '%hunter2%'").get().n, 0); // secrets redacted in the index
});

test('keyword search finds known phrases across TXT, PDF, DOCX, MD, CSV, code', async () => {
  const t = setup();
  await t.indexer.index(t.folder.id);
  assert.equal(hit(t, 'normalization')[0], 'notes/dbms_notes.txt');
  assert.equal(hit(t, 'quantum entanglement')[0], 'notes/networks.pdf');
  assert.equal(hit(t, 'white box testing')[0], 'notes/testing.docx');
  assert.equal(hit(t, 'SQLite FTS5')[0], 'README.md');
  assert.equal(hit(t, 'Madurai')[0], 'data/people.csv');
  assert.equal(hit(t, 'euclid')[0], 'code/gcd.py');
  assert.equal(hit(t, 'widgets')[0], 'db/schema.sql');
  assert.equal(hit(t, 'Find my DBMS notes')[0], 'notes/dbms_notes.txt');           // natural language + file-name match
  assert.equal(hit(t, 'Find the file containing the GCD program')[0], 'code/gcd.py');
  const pdf = searchChunks(t.db, 'handshake')[0];
  assert.equal(pdf.heading, 'Page 2');
  assert.match(pdf.snippet, /\[handshake\]/i);
  assert.equal(searchChunks(t.db, 'Software Testing')[0].heading, 'Software Testing');
  assert.deepEqual(hit(t, 'abcdefghijklmnopqrstuvwxyz123456'), []);                // redacted secret is not searchable
  assert.deepEqual(hit(t, 'supersecretvalue'), []);
  assert.deepEqual(hit(t, 'leakedtokenvalue'), []);
  assert.deepEqual(hit(t, 'outsidesymlinktarget'), []);
  assert.deepEqual(hit(t, 'xyzzyplughnothing'), []);
});

test('hostile search text never breaks or alters the query', async () => {
  const t = setup();
  await t.indexer.index(t.folder.id);
  for (const q of ['"', '*', 'AND OR NOT', 'NEAR(a b)', 'foo)', '" OR 1=1 --', "'; DROP TABLE file_chunks; --", 'text:normalization', '{x}', 'a'.repeat(5000), '', '   ', '%_\\']) {
    assert.doesNotThrow(() => searchFiles(t.db, q), q.slice(0, 20));
  }
  assert.equal(t.db.prepare('SELECT COUNT(*) n FROM file_chunks').get().n > 0, true);
});

test('unchanged files are not re-indexed or duplicated; edits, deletions and renames are picked up', async () => {
  const t = setup();
  await t.indexer.index(t.folder.id);
  const before = t.db.prepare('SELECT COUNT(*) n, MIN(id) a, MAX(id) b FROM file_chunks').get();
  await t.indexer.index(t.folder.id);
  assert.deepEqual({ ...t.db.prepare('SELECT COUNT(*) n, MIN(id) a, MAX(id) b FROM file_chunks').get() }, { ...before });
  assert.equal(t.indexer.progress(t.folder.id).indexed, 0);
  assert.ok(t.indexer.progress(t.folder.id).unchanged >= 11);

  const f = path.join(t.root, 'notes/dbms_notes.txt');
  fs.writeFileSync(f, 'Now this file talks about quaternion rotations only.');
  fs.utimesSync(f, new Date(), new Date(Date.now() + 5000));
  await t.indexer.index(t.folder.id);
  assert.equal(t.indexer.progress(t.folder.id).indexed, 1);
  assert.equal(hit(t, 'quaternion')[0], 'notes/dbms_notes.txt');
  assert.ok(!hit(t, 'normalization').includes('notes/dbms_notes.txt'));          // old text is gone from the index

  fs.writeFileSync(f, 'Now this file talks about quaternion rotations only.');   // same text, new mtime: hash match, no rewrite
  fs.utimesSync(f, new Date(), new Date(Date.now() + 9000));
  const ids = t.db.prepare('SELECT id FROM file_chunks WHERE file_id = (SELECT id FROM indexed_files WHERE rel_path = ?)').all('notes/dbms_notes.txt').map((r) => r.id);
  await t.indexer.index(t.folder.id);
  assert.deepEqual(t.db.prepare('SELECT id FROM file_chunks WHERE file_id = (SELECT id FROM indexed_files WHERE rel_path = ?)').all('notes/dbms_notes.txt').map((r) => r.id), ids);

  fs.renameSync(path.join(t.root, 'data/people.csv'), path.join(t.root, 'data/staff.csv'));
  fs.unlinkSync(path.join(t.root, 'README.md'));
  await t.indexer.index(t.folder.id);
  assert.equal(hit(t, 'Madurai')[0], 'data/staff.csv');
  assert.deepEqual(hit(t, 'SQLite FTS5'), []);
  assert.equal(t.db.prepare("SELECT COUNT(*) n FROM indexed_files WHERE rel_path IN ('README.md','data/people.csv')").get().n, 0);
  // the FTS index stays in step with the table (no orphans after the deletes above)
  assert.equal(t.db.prepare('SELECT COUNT(*) n FROM file_chunks').get().n, t.db.prepare("SELECT COUNT(*) n FROM file_chunks_fts WHERE file_chunks_fts MATCH 'the OR a OR is OR we OR file OR this OR now'").get().n >= 0 ? t.db.prepare('SELECT COUNT(*) n FROM file_chunks').get().n : -1);
});

test('removing a folder deletes its files, chunks and search entries; the original files are untouched', async () => {
  const t = setup();
  await t.indexer.index(t.folder.id);
  const snapshot = fs.readdirSync(t.root, { recursive: true }).sort();
  const mtime = fs.statSync(path.join(t.root, 'notes/dbms_notes.txt')).mtimeMs;
  assert.equal(t.aiRepo.removeFolder(t.folder.id), true);
  assert.equal(t.db.prepare('SELECT COUNT(*) n FROM indexed_files').get().n, 0);
  assert.equal(t.db.prepare('SELECT COUNT(*) n FROM file_chunks').get().n, 0);
  assert.deepEqual(hit(t, 'normalization'), []);
  assert.deepEqual(fs.readdirSync(t.root, { recursive: true }).sort(), snapshot);
  assert.equal(fs.statSync(path.join(t.root, 'notes/dbms_notes.txt')).mtimeMs, mtime);
});

test('protected folders are refused; a missing folder reports an error instead of crashing', async () => {
  const ud = '/tmp/lil-moon-userdata';
  for (const p of ['/', '/etc', '/usr/lib', '/proc/self', path.join(os.homedir(), '.ssh'), ud, path.join(ud, 'sub')]) assert.ok(protectedFolderReason(p, { userData: ud }), p);
  for (const p of ['/tmp', '/tmp/my-notes', '/home/someone/Documents']) assert.equal(protectedFolderReason(p, { userData: ud }), null, p);
  assert.ok(protectedFolderReason('C:\\', {}) === null || path.sep === '/'); // platform-specific rules are unit-tested on Windows paths below
  const t = setup();
  const ghost = t.aiRepo.addFolder(path.join(os.tmpdir(), 'lm-does-not-exist-' + Date.now()));
  await t.indexer.index(ghost.id);
  assert.equal(t.aiRepo.getFolder(ghost.id).status, 'error');
  assert.match(t.aiRepo.getFolder(ghost.id).lastError, /not found/i);
});

test('chunking keeps chunks bounded and redaction handles tokens, keys and card numbers', () => {
  const long = Array.from({ length: 400 }, (_, i) => `line ${i} ${'word '.repeat(10)}`).join('\n');
  const chunks = chunkSections([{ heading: 'H', text: long }, { heading: null, text: 'y'.repeat(5000) }]);
  assert.ok(chunks.length > 5);
  assert.ok(chunks.every((c) => c.text.length <= SIZE + 5));
  const r = redactSecrets('token=abc12345 key sk-1234567890abcdefghij ghp_' + 'a'.repeat(36) + ' card 4111 1111 1111 1111 order 1234 5678 ok Bearer ' + 'x'.repeat(30));
  assert.ok(!/abc12345|sk-1234|ghp_|4111|xxxxxxxxxx/.test(r));
  assert.ok(r.includes('1234 5678 ok'));
});
