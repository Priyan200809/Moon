# Voice assistant (Phase 7)

Built on this copy of the project: Phases 1-3, 5 and 6 are present and working. **Phase 4 (Windows application tracking) is still missing** (its upload was empty). Effect on voice: launching apps works independently of it; answers about application usage ("How much time did I spend on Chrome?", "Show app usage") read whatever application rows exist in `usage_sessions`, and honestly say "I don't have any recorded time" / "I haven't recorded any application usage today" when there are none. Nothing is invented.

## Speech recognition: what was chosen and why
**Windows' built-in offline recogniser (System.Speech / SAPI), driven by one fixed PowerShell script.** It is **local**: the microphone audio goes to Windows' recogniser on this computer; Lil Moon never receives audio, only recognised text; nothing is sent to any service. No new dependency and no model download.
Options considered:
- *Chromium Web Speech API (`webkitSpeechRecognition`)*: sends audio to Google's servers, and in Electron it needs API keys and commonly fails. Rejected (cloud, unreliable).
- *Local Whisper/Vosk models*: better accuracy and more languages, but need a 40-150 MB model download plus a WASM/native dependency, which could not be verified in this environment. The engine sits behind a small interface (`electron/voice/speechRecognitionService.js`: `start`/`stop`/text events), so one can replace it later.
Trade-offs: SAPI dictation accuracy is modest (a quiet room and clear speech help); English (US) ships with Windows; Tamil works only if a Tamil recogniser is installed (otherwise the app says so and you switch back to English); it always uses the default microphone.
**Listening is push-to-talk only: one utterance per press, then the microphone is released.** It starts only from the microphone/Start button or the moon menu's "Talk to Lil Moon", shows a "Microphone ON" bar, stops immediately on Stop, ends by itself after ~8 s of silence, and has a hard 20 s safety limit. Wake-word listening is **not implemented** (the setting is shown disabled; the API and the database both refuse it).

## Pipeline and modules
```
Speech Input -> Speech-to-Text -> Command Normalization -> Intent Detection -> Command Validation -> Permission/Confirmation -> Approved Action -> Response
```
| Spec module | File |
|---|---|
| speechRecognitionService | `electron/voice/speechRecognitionService.js` (+ `sapiScript.js`), renderer wrapper `frontend/src/voice/speechRecognitionService.js` |
| commandParser | `backend/voice/commandParser.js` |
| intentDetector | `backend/voice/intentDetector.js` (fixed rules, no model, no eval) |
| applicationRegistry | `backend/voice/applicationRegistry.js` (+ `appLauncher.js`) |
| websiteRegistry | `backend/voice/websiteRegistry.js` |
| commandExecutor | `backend/voice/commandExecutor.js` |
| textToSpeechService | `frontend/src/voice/textToSpeechService.js` |
| voiceHistoryService | `backend/voice/voiceHistoryService.js`; orchestration in `backend/voice/voiceService.js` |

## Commands
Open apps: Chrome, Edge, Firefox, VS Code, Visual Studio, Notepad, Calculator, File Explorer, Paint ("open Chrome", "launch notepad", "open vs code"). Open websites: YouTube, Instagram, Google, GitHub, Reddit, LinkedIn, Gmail, Wikipedia, Stack Overflow, Facebook, Netflix, Spotify web, plus any site on your tracked list by name. Information: "what time is it", "what's today's date", "how much time did I spend on Chrome / YouTube", "how much time is left on YouTube", "show my daily limits", "show my website usage / app usage". Dashboard: "open home / settings / voice assistant / usage limits", "show app usage", "show website usage". Assistant: "stop listening", "start listening", "repeat that", "clear conversation", "stop talking", "clear voice history" (asks to confirm). Polite words ("please", "hey Lil Moon") are ignored.

## Safety model
- **Phrases only select an intent.** A name is only ever looked up in the allowlists; no part of speech becomes a path, argument, URL scheme, SQL or script.
- **Applications:** a fixed id -> list of absolute `.exe` locations built from four trusted environment variables (`ProgramFiles`, `ProgramFiles(x86)`, `LOCALAPPDATA`, `SystemRoot`); launched with `spawn(exe, [], {shell:false, detached:true})` in the main process only, no arguments. Not found -> "I couldn't find that application. Please check whether it is installed." Fuzzy matching tolerates small slips ("notepat"); partial names that match several apps ("open visual") ask which one; an exact name beats a partial one ("open google" opens the website, not Chrome). Command lines and admin tools (cmd, PowerShell, terminals, regedit, ...) are not in the registry and are refused by name.
- **Websites:** fixed https URLs or `https://<validated host>/`; anything with another scheme, a port, credentials, an IP address, `localhost` or a path is rejected. A valid hostname that is not in the registry (e.g. "open example.com") is read back and needs "yes". Opened with the system default browser via `shell.openExternal`, re-validated there. If the site's limit is reached the reply says it may be blocked.
- **Confirmation and display-before-acting:** every command is shown as text. A recognition with confidence below 0.6 that would *do* something (open/launch) is read back first ("I heard ... Should I do that?"). Ambiguous matches, unknown sites and "clear voice history" need an explicit yes/choice, which can be spoken or clicked (single-use ids, 60 s expiry).
- **Never by voice:** turning off restrictions/warnings/privacy/tracking, deleting usage data, running commands/scripts/SQL. These are refused with an explanation. The renderer cannot start processes, read files, query the database or run shell commands; the bridge exposes seven fixed operations (`start(language)`, `stop`, `permission`, `openMicrophoneSettings`, `takeActivation`, `onEvent`, `onActivate`), IPC is accepted only from the dashboard window's top frame, the language is checked against an allowlist.
- **PowerShell:** the only script is fixed, started with `-EncodedCommand` (no script file, no execution-policy override), reads only `LILMOON_LANG` and `LILMOON_TIMEOUT`, contains no network or execution calls (a test asserts this), and outputs JSON lines of text that are re-validated and length-limited.
- **Privacy:** no audio stored anywhere; the history table has no audio column; unmatched speech is saved only as "(not understood)"; history can be switched off or cleared; text-to-speech never reads app/site lists aloud by default (a spoken summary says the details are on screen).

## Text-to-speech
Chromium `speechSynthesis` with the installed Windows voices (local). Settings: voice, speed 0.5-2, volume 0-1, mute, test voice; **Stop speaking** cancels immediately; the assistant never listens while speaking; replies are always shown as text too. If no voice is available the app says "text only". Sensitive lists are summarised, not read.

## Database (schema v4; migration keeps all data)
`voice_settings` (one row: enabled, language `en-US|ta-IN`, voice_name, speech_rate, speech_volume, muted, wake_word_enabled pinned to 0, push_to_talk pinned to 1, history_enabled) and `voice_history` (id, recognized_text, intent, status, response_text, source `voice|typed`, created_at; index on created_at). Parameterised queries throughout.

## API (dashboard token)
`GET|PUT /api/voice/settings`, `GET /api/voice/capabilities`, `GET|DELETE /api/voice/history`, `POST /api/voice/command {text, source, confidence}`, `POST /api/voice/confirm {id, choice}`. The extension's pairing code cannot reach any of them.

## Errors handled with friendly messages
Permission denied (with a button to open Windows microphone settings), no microphone, timeout, background noise / empty result, unsupported language, unknown command, ambiguous application, application not installed, invalid website, backend unavailable, text-to-speech unavailable, non-Windows platform.

## What was actually run (Linux, Node 22 + Electron 45 under Xvfb)
| Area | Result |
|---|---|
| Voice pipeline (20): the fifteen scenarios from the spec (open Chrome/Notepad/Calculator/YouTube/GitHub, app and website usage, "how much time on Chrome", "time left on YouTube", daily limits, open settings, stop listening, unknown command, ambiguous name), plus typo matching, unsafe requests (shells, scripts, SQL, `;`/`&&` injection, `javascript:`/`file:`/`http:`/IP/localhost/port/credential URLs), low-confidence read-back, confirmations, history on/off/clear, voice disabled, database failure | Passed (real SQLite and limits engine; the launcher is driven with a fake process and fake file system, so no real app was started) |
| Speech service (7): refusals before any process, fixed command line, partial -> final flow, immediate stop, timeout/noise/empty/hung, error mapping, garbage ignored, text limits, script content checks | Passed with a **fake PowerShell process** |
| Voice API over HTTP (5): validation, single-use confirmations, settings (wake word refused), history, token separation | Passed |
| Whole suite (`npm test`) | 113 of 113 passed |
| Electron smoke (real windows, preload bridge, UI, pipeline): voice page content, bridge keys, defaults, microphone press without Windows (friendly message), typed commands answered/refused, listening indicator + live transcript + recognised command + navigation (events delivered the way the real engine would), permission-denied and no-microphone messages, low-confidence navigation, history saved, wake word refused, "Talk to Lil Moon" activation, persistence across restart | 72 of 73 passed in phase 1 and 13 of 13 in the restart phase; the one failure is **dashboard minimize** (no window manager under bare Xvfb), unchanged since Phase 1 |
Phases 1-3, 5 and 6 checks all still pass.

## NOT verified (needs Windows)
- **The real recogniser:** the PowerShell/System.Speech script, microphone capture, recognition accuracy, `RecognizeAsync` events, and the real permission-denied path (`getMediaAccessStatus` and the way Windows reports a blocked microphone). It could not be run here; only its JSON protocol is tested.
- Real app launches (paths, `calc.exe`/Explorer behaviour), real browser opening, the toast/dialog from Phase 6 unaffected.
- Real speaking: this environment has no voices, so the text-only path was exercised; `speechSynthesis` voice selection, speed, volume, mute and immediate stop are not verified with a real voice.
- The moon's right-click "Talk to Lil Moon" item itself (native menu); the activation it triggers was tested.
- Tamil (needs an installed recogniser), and noisy-room behaviour.

## Manual test checklist (Windows)
1. `npm start`, open the dashboard -> **Voice assistant**. The badge says "Microphone off".
2. Press the microphone. The "Microphone ON" bar and "Listening" pill appear; Windows may ask for microphone access (allow it). Say "Open Notepad": the text appears under "What I heard" while you speak, then the reply "Opening Notepad." appears and is spoken, and Notepad opens. The microphone closes by itself.
3. Repeat for "Open Chrome", "Open Calculator", "Open YouTube", "Open GitHub" (browser opens the site), "Show app usage", "Show website usage", "How much time did I spend on Chrome", "How much time is left on YouTube", "Show my daily limits", "Open settings", "Stop listening" (press the mic first, say it; the session ends).
4. Say "open banana": nothing opens, the reply says it didn't understand. Say "open visual": it asks which one; say "the second one" or press a button.
5. Say "open example dot com": it asks before opening. Say "turn off all restrictions" or "run powershell": refused.
6. Block the microphone in Windows Settings > Privacy & security > Microphone (desktop apps), press the mic: the permission card says what to do. Unplug the microphone: "No microphone was found".
7. Press the mic and stay silent for 8 s: "I didn't hear anything". Press Stop while listening: it stops at once. Press "Stop speaking" during a reply: speech stops at once.
8. Settings: change voice, speed, volume, mute; "Test voice". Switch history off and run a command: nothing new in history. Clear history.
9. Right-click the moon -> **Talk to Lil Moon**: the dashboard opens on the Voice page and starts one listening session.
10. Typed commands (the box) go through exactly the same checks.

## Known limitations
- Accuracy depends on Windows' SAPI recogniser; expect to retry. One command per press. No wake word, no continuous listening, no microphone choice, no global hotkey.
- Application list is fixed in code (`applicationRegistry.js`); apps in non-standard locations will report "couldn't find that application". Store/UWP apps other than those listed are not supported.
- Application usage answers depend on Phase 4's record names (matching is by name with common aliases such as `chrome.exe` and "Google Chrome").
- "Repeat that" repeats the last answer text; "start listening" by voice opens one more session only after the reply has finished.
