# Website usage tracking (Phase 5)

## What it does
A Chrome/Edge extension tells the Lil Moon desktop app **which listed website is in front**. The desktop app measures the time, combines it with whether you are present, and stores it in the existing SQLite database. The dashboard's **Website usage** page reads those rows.

Time counts only while ALL of these hold: the extension is alive and not paused, the browser window is focused and not minimised, the active tab is on a listed site (not a private window), and you are not idle / locked / asleep.

## Architecture
```
Chrome/Edge extension (MV3 service worker)         Lil Moon (Electron main process)
  events: tab / window / focus / navigation  --->   Express API  127.0.0.1 only, ports 47615-47624 then random
  30 s alarm heartbeat (state assertion)             /ext/*  pairing-code auth + extension-origin check
  reports {domain|null, paused, seq, at}             websiteTracker.js  (owns all durations)
                                                     idleMonitor.js     (owns idle / lock / sleep)  <- powerMonitor
                                                     SQLite  usage_sessions (category = 'website')
```
- **Why the desktop app measures time:** timers in a Manifest V3 service worker are unreliable (it is stopped after ~30 s idle). The extension only reports changes plus a 30 s heartbeat; every duration is computed from timestamps in the desktop app. A late or missing timer cannot distort totals.
- **One idle detector:** `backend/idleMonitor.js` (Electron `powerMonitor`: seconds since last input, `lock-screen`, `unlock-screen`, `suspend`, `resume`). Phase 4's own idle service was not available when this was built; when Phase 4 is merged, make it feed `tracker.onPresence(state, atMs)` instead of adding a second detector.
- **Storage model:** one row per uninterrupted run on one site. It is created once the run lasts >= 1 s and extended at every heartbeat/refresh. A crash loses at most one heartbeat; "today" is live; rows never overlap (a new run cannot start before the last stored one ended); a unique index on `(item_name, started_at)` for website rows blocks exact duplicates; runs are split at local midnight so each row belongs to one calendar day (`session_date` is the local day, timestamps are UTC ISO-8601 as in Phase 3).
- **Browser closed / extension dead:** no heartbeat for 100 s -> the run is closed at the last heartbeat (under-counts by at most ~30 s, never over-counts).
- **Idle:** when idleness is detected (default 60 s without input) the run is ended at the moment of the last input, not at detection. Passive watching (a video with no mouse/keyboard) therefore stops counting after the threshold; raise the threshold on the page if you want that to count.
- **Several browsers/profiles:** each install reports separately. An unfocused browser reporting "nothing" does not cancel the focused one.
- **Backend offline:** the extension queues messages in `chrome.storage.local` (max 50, only the newest heartbeat kept), retries on the next event/heartbeat, and each message has a per-install sequence number so retries and re-ordered deliveries are ignored. A delayed message cannot be back-dated before the last stored run or the latest presence change. The desktop app being closed means nothing is counted (it cannot observe idle/lock).

### Pairing and local security
- The extension needs a **pairing code** (48 hex chars, shown only in the dashboard, rotatable). It is separate from the dashboard's per-launch token: the code opens only `/ext/*`; the dashboard token does not open `/ext/*`; neither works on the other's routes.
- `/ext` requires an extension origin (`chrome-extension://<32 letters a-p>`); ordinary web pages are refused. The Host allow-list (DNS-rebinding defence), 16 kB body limit, JSON-only and strict field validation from Phase 3 still apply. The server listens on 127.0.0.1 only.
- The extension can do five things: read the site list/idle setting, send its state, read today's totals, ask the app to open the dashboard, and ping. No SQL, files or shell. The server re-checks every reported domain against the enabled list; anything else is stored as nothing.
- Limit: another program running as you could read the pairing code from the database file. A local app cannot prevent that.

## Permissions (and why)
| Permission | Why |
|---|---|
| `tabs` | Read the active tab's address to learn its domain, and receive tab events. Chrome words this as "read your browsing history"; the extension reads only the active tab, keeps only the domain, and discards everything else in memory. |
| `alarms` | The 30 s heartbeat that survives service-worker restarts. |
| `storage` | Pairing code, pause flag, site list, and the small offline queue. |
| host `http://127.0.0.1/*` | Talk to the desktop app on this computer. No other host. |
| `incognito: not_allowed` | The extension cannot be enabled in private windows (and ignores them if it were). |

## Privacy
Collected: the domain of sites on your list and how long it was in front while you were active. Never collected: page content, full URLs, paths, query strings, titles, passwords, form input, keystrokes, screenshots, private-window activity. Nothing is sent anywhere except to the Lil Moon app on this computer; nothing goes to an AI service. Controls: Pause in the popup; edit the list; remove a single session; **Delete website history** (website rows only). Idle detection reads only "seconds since last input" as one number.
Icons on the page are drawn locally (a coloured letter) because fetching favicons would tell a third party which sites you use.

## Install on Windows
1. `npm install`, then `npm start`.
2. Dashboard -> **Website usage** -> copy the pairing code.
3. `chrome://extensions` -> Developer mode -> **Load unpacked** -> the project's `extension` folder (Edge: `edge://extensions`).
4. Toolbar icon -> paste the code -> **Connect**.

If port 47615-47624 are all taken by other programs the page shows a warning; close them and restart Lil Moon.

## API added (all on the dashboard token unless marked ext)
`GET /api/websites/overview`, `POST /api/websites`, `PUT|DELETE /api/websites/:id`, `GET|POST /api/websites/aliases`, `DELETE /api/websites/aliases/:alias`, `GET /api/websites/extension`, `POST /api/websites/extension/rotate`, `DELETE /api/websites/history`; `PUT /api/settings` accepts `idleThresholdSeconds` (10-3600). ext (pairing code): `GET /ext/ping`, `GET /ext/config`, `POST /ext/activity`, `GET /ext/summary`, `POST /ext/open-dashboard`.
Schema v2 (migration is transactional and keeps existing data): `user_settings.idle_threshold_seconds`, `user_settings.extension_token`, table `domain_aliases`, unique index `ux_usage_website_start`, default sites and aliases.

## Domain normalisation
`extension/lib/domain.js` (shared by the extension and the backend). Lower-case, drop `www`/`m`/`mobile`/`touch` prefixes, apply configurable aliases (`youtu.be -> youtube.com`, editable via the aliases API), then match by whole DNS labels: a host matches a listed domain only if it equals it or is a true subdomain (`music.youtube.com` -> `youtube.com`; `notyoutube.com` and `youtube.com.evil.example` do not match). Non-http(s) pages (chrome://, file://, about:, extension pages), IP addresses and unlisted sites report "nothing".

## Test results (what was actually run, Linux, Node 22 + Electron 45 under Xvfb)
| Check | How | Result |
|---|---|---|
| Phase 3 API/database tests (13) | `npm test`, three assertions updated for schema v2 and the five default sites | Passed |
| Website tracker + idle monitor (16): YouTube 10 min; YouTube -> Instagram; untracked tab; another app / minimise (focus lost); idle backdating; lock and sleep; pause/resume; browser closed; worker-restart duplicates; delayed message clamp; restart without overlap; midnight split; single row per run; sub-second; two browsers | fake clock + real SQLite | Passed |
| Extension API (10): pairing, origin, token separation, validation, domain re-check, end-to-end rows, silence, backend restart, list/alias management, history delete, port fallback | real HTTP server | Passed |
| Extension logic (9): pairing, scenarios 1-5 and 8, background tabs, incognito/internal pages, worker restart, offline queue and reconnect, privacy of every outgoing message, port discovery, look-alike domains | extension `core.js` + `domain.js` against the real backend; **only the `chrome` object is simulated** | Passed |
| Electron smoke (phase 1 + 2 restart) | real windows, IPC, dashboard UI, real `powerMonitor` events, HTTP "extension" | All Phase 1/2/3 checks and all new Phase 5 checks passed, **except** "dashboard minimize" (no window manager under bare Xvfb; same limitation as before) |

## NOT verified (needs your Windows machine)
- The real extension inside Chrome/Edge: install, popup rendering, `windows.getLastFocused` focus/minimise behaviour, `tabs.onUpdated` for single-page-app navigation (YouTube), alarm cadence, service-worker restart, browser startup/shutdown.
- Real Windows idle (`GetLastInputInfo` via `powerMonitor.getSystemIdleTime`), real lock/sleep/resume events.
- Dashboard minimize; always-on-top; DPI/multi-monitor (from earlier phases).
- Phase 4 application tracking and the "no double counting with applications" check (item 17): Phase 4 was not available. Website rows use `category = 'website'` and are summed separately from `category = 'application'`; the browser's own process time belongs to Phase 4 and is not subtracted anywhere.
- Windows checklist: (1) YouTube in front ~2 min, popup and dashboard time rises; (2) switch to Instagram tab, then to a non-listed tab; (3) click VS Code, wait 1 min, dashboard stays flat; (4) minimise Chrome, same; (5) stop touching the PC 70 s, time stops; move the mouse, it resumes; (6) Win+L, unlock; (7) Pause in popup, 1 min flat, Resume; (8) close Chrome, reopen; (9) `chrome://extensions` -> service worker "Stop", then switch tabs; (10) quit Lil Moon, switch tabs, restart Lil Moon, popup shows reconnect; (11) private window never counts.

## Known limitations
- Needs the `tabs` permission (see above). Chrome shows a broad warning for it.
- Counting granularity: the heartbeat is 30 s; a browser crash or force-quit can under-count up to about 30 s.
- Passive viewing beyond the idle threshold is not counted (by design).
- Messages queued while the desktop app is closed are replayed on reconnect, but time while the app was closed is not counted.
- Minimising is detected by the `minimized` window state / focus loss; if Chrome reports neither for some window type, it is caught at the next 30 s heartbeat.
- Sessions shorter than 1 s are dropped.
- No website blocking, restrictions, voice or AI memory (later phases).
