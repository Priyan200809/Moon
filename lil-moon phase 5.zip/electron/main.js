const { app, ipcMain, powerMonitor } = require('electron');
const wm = require('./windowManager');
const path = require('path');
const store = require('./settingsStore');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer, EXT_PORTS } = require('../backend/server');
const { createTracker } = require('../backend/websiteTracker');
const { createIdleMonitor } = require('../backend/idleMonitor');

// The API accepts requests only from our own pages: file:// (Origin "null") in production, the Vite origin in dev.
const allowedOrigins = process.env.LILMOON_DEV_URL ? [new URL(process.env.LILMOON_DEV_URL).origin] : ['null'];
let backend = null;
let backendError = '';

// Phase 5: website tracking. One presence detector (idleMonitor) feeds one tracker; the extension only says which site is in front.
function startTracking(repo) {
  const tracker = createTracker({ repo });
  let threshold = { at: 0, seconds: 60 };
  const idle = createIdleMonitor({
    getIdleSeconds: () => powerMonitor.getSystemIdleTime(),
    getThresholdSeconds: () => { // re-read the saved threshold at most every 5 s
      if (Date.now() - threshold.at > 5000) threshold = { at: Date.now(), seconds: repo.getSettings().idleThresholdSeconds };
      return threshold.seconds;
    },
    onChange: (state, atMs) => tracker.onPresence(state, atMs),
  });
  const detach = idle.attach(powerMonitor); // lock-screen, unlock-screen, suspend, resume
  idle.start();
  const reconcile = setInterval(() => tracker.reconcile(), 15000); // also called on every read; this covers an unwatched dashboard
  return { tracker, idle, stop: () => { clearInterval(reconcile); idle.stop(); detach(); tracker.shutdown(); } };
}

async function startBackend() {
  try {
    const db = openDatabase(path.join(app.getPath('userData'), 'lil-moon.db'), { legacyPreferences: store.getLegacyPreferences() });
    try {
      const repo = createRepository(db);
      const tracking = startTracking(repo);
      try {
        const api = await startServer({
          repo, allowedOrigins, tracker: tracking.tracker, ports: [...EXT_PORTS, 0],
          hooks: { openDashboard: () => wm.openDashboard() },
        });
        backend = { db, api, tracking };
      } catch (err) { tracking.stop(); throw err; }
    } catch (err) { db.close(); throw err; }
  } catch (err) {
    console.error('[lil-moon] backend failed to start:', err);
    backendError = 'Lil Moon could not open its local database. Your data was not changed.';
  }
}

// Accept a command only from the exact window (top frame) that is allowed to send it.
function windowFor(who, event) {
  const win = who === 'moon' ? wm.getMoon() : wm.getDashboard();
  const ok = win && !win.isDestroyed() && event.sender === win.webContents && event.senderFrame === event.sender.mainFrame;
  return ok ? win : null;
}
function on(channel, who, handler) {
  ipcMain.on(channel, (event) => { const win = windowFor(who, event); if (win) handler(win); });
}
function handle(channel, who, handler) {
  ipcMain.handle(channel, (event, payload) => {
    if (!windowFor(who, event)) throw new Error('Rejected');
    return handler(payload);
  });
}

function registerIpc() {
  on('moon:drag-start', 'moon', wm.dragStart);
  on('moon:drag-move', 'moon', wm.dragMove);
  on('moon:drag-end', 'moon', wm.dragEnd);
  on('moon:menu', 'moon', wm.showMoonMenu);
  on('dashboard:open', 'moon', wm.openDashboard);
  on('dashboard:minimize', 'dashboard', (w) => w.minimize());
  on('dashboard:close', 'dashboard', (w) => w.close());
  on('dashboard:toggle-maximize', 'dashboard', (w) => (w.isMaximized() ? w.unmaximize() : w.maximize()));
  on('app:exit', 'dashboard', wm.quit);
  // Only the dashboard window may learn the API address and its per-launch token.
  handle('api:config', 'dashboard', () => (backend ? { baseUrl: backend.api.baseUrl, token: backend.api.token } : { error: backendError }));
  ipcMain.handle('app:version', () => app.getVersion());
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => wm.openDashboard());
  app.whenReady().then(async () => {
    registerIpc();
    await startBackend(); // the moon still appears if the database fails
    wm.createMoon();
  });
  app.on('will-quit', () => {
    if (!backend) return;
    const { api, db, tracking } = backend;
    backend = null;
    try { tracking.stop(); } catch (err) { console.error('[lil-moon] could not store the open website run:', err); } // before the database closes
    api.close(); // stops listening and drops connections synchronously
    try { db.close(); } catch { /* ignore */ }
  });
  // The moon keeps the app alive; closing the dashboard never quits.
  app.on('window-all-closed', () => {});
  app.on('before-quit', wm.prepareQuit);
}

// Exposed for the automated smoke test only (it is not reachable from any renderer).
module.exports = { __services: () => backend };
