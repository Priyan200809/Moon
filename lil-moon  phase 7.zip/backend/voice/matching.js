// Small, dependency-free fuzzy matching used for spoken application and website names.
const squash = (s) => String(s).toLowerCase().replace(/\.exe$/, '').replace(/[^a-z0-9]/g, '');
const words = (s) => String(s).toLowerCase().replace(/\s+/g, ' ').trim();

function levenshtein(a, b) {
  if (a === b) return 0;
  const prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let diag = prev[0];
    prev[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = prev[j];
      prev[j] = Math.min(prev[j] + 1, prev[j - 1] + 1, diag + (a[i - 1] === b[j - 1] ? 0 : 1));
      diag = tmp;
    }
  }
  return prev[b.length];
}

// 1 = same name; 0.8 = every spoken word appears in a longer name ("visual" in "visual studio"); ~0.75-0.9 = a small spelling slip; 0 = no match.
function scoreName(query, aliases) {
  const q = words(query);
  const sq = squash(q);
  if (!sq) return 0;
  let best = 0;
  for (const alias of aliases) {
    const a = words(alias);
    const sa = squash(a);
    if (!sa) continue;
    if (a === q || sa === sq) return 1;
    const qt = q.split(' '), at = a.split(' ');
    if (qt.length < at.length && qt.every((t) => t.length >= 3 && at.includes(t))) best = Math.max(best, 0.8);
    const maxLen = Math.max(sa.length, sq.length);
    const allowed = maxLen >= 7 ? 2 : maxLen >= 5 ? 1 : 0; // very short names must match exactly
    const d = levenshtein(sa, sq);
    if (d <= allowed) best = Math.max(best, 0.9 * (1 - d / maxLen));
  }
  return best >= 0.74 ? best : 0;
}

// Pick one candidate, or report that the choice is ambiguous. An exact name always beats a partial one.
function decide(cands) {
  const c = cands.filter((x) => x.score > 0).sort((a, b) => b.score - a.score);
  if (!c.length) return { kind: 'none' };
  const [top, second] = c;
  if (!second) return { kind: 'one', pick: top };
  if (top.score === 1 && second.score < 1) return { kind: 'one', pick: top };
  if (top.score - second.score >= 0.1) return { kind: 'one', pick: top };
  return { kind: 'ambiguous', options: c.filter((x) => top.score - x.score < 0.1).slice(0, 4) };
}

module.exports = { squash, words, levenshtein, scoreName, decide };
