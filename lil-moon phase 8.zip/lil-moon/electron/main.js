const { app, ipcMain, powerMonitor, dialog, shell } = require('electron');
const wm = require('./windowManager');
const path = require('path');
const store = require('./settingsStore');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer } = require('../backend/server');
const { createIdleMonitor } = require('../backend/idleMonitor');
const { createServices } = require('../backend/services');
const { createKeyStore } = require('./keyStore');

// The API accepts requests only from our own pages: file:// (Origin "null") in production, the Vite origin in dev.
const allowedOrigins = process.env.LILMOON_DEV_URL ? [new URL(process.env.LILMOON_DEV_URL).origin] : ['null'];
// The pinned ID of the bundled extension (derived from the public key in extension/manifest.json).
// Add other IDs (for example an Edge install) with LILMOON_EXTENSION_IDS=id1,id2.
const EXTENSION_IDS = ['ioijpdmcecfedcpbfgabfmabpoccjcej', ...(process.env.LILMOON_EXTENSION_IDS || '').split(',').filter((i) => /^[a-p]{32}$/.test(i))];
const extensionOrigins = EXTENSION_IDS.map((id) => `chrome-extension://${id}`);
let backend = null;
let idleTimer = null;
let backendError = '';

async function startBackend() {
  try {
    const db = openDatabase(path.join(app.getPath('userData'), 'lil-moon.db'), { legacyPreferences: store.getLegacyPreferences() });
    try {
      const repo = createRepository(db);
      const activity = createIdleMonitor({
        getIdleSeconds: () => powerMonitor.getSystemIdleTime(),
        getThresholdSeconds: () => repo.getSettings().idleThresholdSeconds,
      });
      // Single idle/lock/sleep detector for the whole app. Errors here must never take the app down.
      const safe = (fn) => () => { try { fn(); } catch (e) { console.error('[lil-moon] idle monitor:', e.message); } };
      idleTimer = setInterval(safe(() => activity.tick()), 1000);
      idleTimer.unref();
      powerMonitor.on('lock-screen', safe(activity.lock));
      powerMonitor.on('unlock-screen', safe(activity.unlock));
      powerMonitor.on('suspend', safe(activity.suspend));
      powerMonitor.on('resume', safe(activity.resume));
      // Trusted actions the assistant may request. Each is narrow; none accepts a path or command from the page or the model.
      const actions = {
        openDashboard: () => wm.openDashboard(),
        pickFolder: async () => {
          const r = await dialog.showOpenDialog(wm.getDashboard() ?? undefined, { title: 'Choose a folder to index', properties: ['openDirectory'] });
          return r.canceled ? null : r.filePaths[0];
        },
        openPath: (p) => { shell.openPath(p); },          // only called for document/data types
        revealPath: (p) => { shell.showItemInFolder(p); }, // scripts and web files are revealed, never launched
        openExternal: (url) => { if (/^https:\/\/[a-z0-9.-]+(\/|$)/i.test(url)) shell.openExternal(url); },
      };
      const services = createServices({ db, repo, keyStore: createKeyStore(), actions, userData: app.getPath('userData') });
      backend = { db, services, api: await startServer({ repo, allowedOrigins, extensionOrigins, activity, actions, services }) };
      setTimeout(() => { try { services.files.reindexAll(); } catch (e) { console.error('[lil-moon] reindex:', e.message); } }, 5000).unref(); // pick up file changes made while closed
    } catch (err) { db.close(); throw err; }
  } catch (err) {
    console.error('[lil-moon] backend failed to start:', err);
    backendError = 'Lil Moon could not open its local database. Your data was not changed.';
  }
}

// Accept a command only from the exact window (top frame) that is allowed to send it.
function windowFor(who, event) {
  const win = who === 'moon' ? wm.getMoon() : wm.getDashboard();
  const ok = win && !win.isDestroyed() && event.sender === win.webContents && event.senderFrame === event.sender.mainFrame;
  return ok ? win : null;
}
function on(channel, who, handler) {
  ipcMain.on(channel, (event) => { const win = windowFor(who, event); if (win) handler(win); });
}
function handle(channel, who, handler) {
  ipcMain.handle(channel, (event, payload) => {
    if (!windowFor(who, event)) throw new Error('Rejected');
    return handler(payload);
  });
}

function registerIpc() {
  on('moon:drag-start', 'moon', wm.dragStart);
  on('moon:drag-move', 'moon', wm.dragMove);
  on('moon:drag-end', 'moon', wm.dragEnd);
  on('moon:menu', 'moon', wm.showMoonMenu);
  on('dashboard:open', 'moon', wm.openDashboard);
  on('dashboard:minimize', 'dashboard', (w) => w.minimize());
  on('dashboard:close', 'dashboard', (w) => w.close());
  on('dashboard:toggle-maximize', 'dashboard', (w) => (w.isMaximized() ? w.unmaximize() : w.maximize()));
  on('app:exit', 'dashboard', wm.quit);
  // Only the dashboard window may learn the API address and its per-launch token.
  handle('api:config', 'dashboard', () => (backend ? { baseUrl: backend.api.baseUrl, token: backend.api.token } : { error: backendError }));
  ipcMain.handle('app:version', () => app.getVersion());
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => wm.openDashboard());
  app.whenReady().then(async () => {
    registerIpc();
    await startBackend(); // the moon still appears if the database fails
    wm.createMoon();
  });
  app.on('will-quit', () => {
    if (!backend) return;
    const { api, db } = backend;
    backend = null;
    clearInterval(idleTimer);
    api.close(); // stops listening and drops connections synchronously
    try { db.close(); } catch { /* ignore */ }
  });
  // The moon keeps the app alive; closing the dashboard never quits.
  app.on('window-all-closed', () => {});
  app.on('before-quit', wm.prepareQuit);
}
