// Phase 7 voice pipeline: parser -> intent -> validation -> confirmation -> approved action -> response, against the real database.
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDatabase, createRepository, localDate } = require('../backend/database');
const { createTracker } = require('../backend/websiteTracker');
const { createLimitEngine } = require('../backend/limits');
const { createAppLauncher } = require('../backend/voice/appLauncher');
const { createCommandExecutor } = require('../backend/voice/commandExecutor');
const { createVoiceService } = require('../backend/voice/voiceService');
const { normalize } = require('../backend/voice/commandParser');
const { detect } = require('../backend/voice/intentDetector');
const Sites = require('../backend/voice/websiteRegistry');
const Apps = require('../backend/voice/applicationRegistry');
const { scoreName } = require('../backend/voice/matching');
const { EventEmitter } = require('events');

const NOON = new Date(2026, 9, 31, 15, 42, 0).getTime();
const WIN_ENV = { SystemRoot: 'C:\\Windows', ProgramFiles: 'C:\\Program Files', 'ProgramFiles(x86)': 'C:\\Program Files (x86)', LOCALAPPDATA: 'C:\\Users\\u\\AppData\\Local' };
const INSTALLED = new Set([
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Windows\\System32\\notepad.exe', 'C:\\Windows\\System32\\calc.exe', 'C:\\Windows\\explorer.exe',
  'C:\\Users\\u\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe', 'C:\\Program Files\\Microsoft Visual Studio\\2022\\Community\\Common7\\IDE\\devenv.exe',
]);

function rig({ platform = 'win32', installed = INSTALLED, spawnFails = false } = {}) {
  const clock = { t: NOON };
  const db = openDatabase(':memory:');
  const repo = createRepository(db);
  const tracker = createTracker({ repo, now: () => clock.t });
  const limits = createLimitEngine({ repo, tracker, now: () => clock.t });
  const spawned = []; const opened = [];
  const spawn = (exe, args, opts) => {
    spawned.push({ exe, args, opts });
    const e = new EventEmitter(); e.unref = () => {};
    setImmediate(() => e.emit(spawnFails ? 'error' : 'spawn', new Error('boom')));
    return e;
  };
  const launcher = createAppLauncher({ platform, env: WIN_ENV, existsSync: (p) => installed.has(p), spawn });
  const opener = { open: async (u) => { opened.push(u); } };
  const executor = createCommandExecutor({ repo, tracker, limits, launcher, opener, now: () => clock.t });
  const logs = [];
  const service = createVoiceService({ repo, executor, now: () => clock.t, log: { error: (...a) => logs.push(a.join(' ')) } });
  const use = (category, name, secs) => repo.insertSession({ category, itemName: name, startedAt: new Date(clock.t - secs * 1000 - Math.random() * 900).toISOString(), endedAt: new Date(clock.t).toISOString(), durationSeconds: secs });
  return { clock, db, repo, tracker, limits, service, spawned, opened, use, logs, say: (t, o) => service.run(t, o) };
}

// ---- 12: the spec's fifteen scenarios ----
test('1-5. open Chrome / Notepad / Calculator launch the allowlisted executable; YouTube / GitHub open the https site', async () => {
  const r = rig();
  let x = await r.say('Open Chrome.'); assert.deepEqual([x.status, x.text], ['executed', 'Opening Google Chrome.']);
  x = await r.say('Open Notepad.'); assert.equal(x.text, 'Opening Notepad.');
  x = await r.say('Open Calculator.'); assert.equal(x.text, 'Opening Calculator.');
  assert.deepEqual(r.spawned.map((s) => s.exe), ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Windows\\System32\\notepad.exe', 'C:\\Windows\\System32\\calc.exe']);
  for (const s of r.spawned) { assert.deepEqual(s.args, []); assert.equal(s.opts.shell, false); assert.equal(s.opts.detached, true); }
  x = await r.say('Open YouTube.'); assert.equal(x.text, 'Opening YouTube.');
  x = await r.say('Open GitHub.'); assert.equal(x.text, 'Opening GitHub.');
  assert.deepEqual(r.opened, ['https://www.youtube.com/', 'https://github.com/']);
  x = await r.say('open file explorer'); assert.equal(x.text, 'Opening File Explorer.');
  x = await r.say('open vs code'); assert.equal(x.text, 'Opening Visual Studio Code.');
});

test('6/7/11. dashboard navigation: app usage, website usage, settings, home, voice assistant', async () => {
  const r = rig();
  assert.equal((await r.say('Show app usage.')).ui.navigate, 'apps');
  assert.equal((await r.say('Show website usage.')).ui.navigate, 'sites');
  const s = await r.say('Open settings.'); assert.deepEqual([s.ui.navigate, s.text], ['settings', 'Opening Settings.']);
  assert.equal((await r.say('open home')).ui.navigate, 'home');
  assert.equal((await r.say('open voice assistant')).ui.navigate, 'voice');
  assert.equal((await r.say('open usage limits')).ui.navigate, 'limits');
  assert.equal(r.spawned.length + r.opened.length, 0, 'navigation never launches anything');
});

test('8. "How much time did I spend on Chrome?" comes from stored application records, never invented', async () => {
  const r = rig();
  let x = await r.say('How much time did I spend on Chrome?');
  assert.equal(x.text, "I don't have any recorded time for Google Chrome today.");
  r.use('application', 'chrome.exe', 35 * 60); r.use('application', 'Google Chrome', 10 * 60); r.use('application', 'Notepad', 7 * 60);
  x = await r.say('How much time did I spend on Chrome?');
  assert.equal(x.text, 'You have spent 45 minutes on Google Chrome today.');
  assert.equal((await r.say('how long have i used notepad today')).text, 'You have spent 7 minutes on Notepad today.');
  r.use('application', 'Notepad', 3600 - 7 * 60 + 5 * 60);
  assert.equal((await r.say('how much time did i spend on notepad')).text, 'You have spent 1 hour 5 minutes on Notepad today.');
});

test('website usage answers use real rows, the tracked list, and the live run', async () => {
  const r = rig();
  assert.equal((await r.say('how much time did i spend on youtube')).text, "You haven't spent any time on YouTube today.");
  r.use('website', 'youtube.com', 35 * 60);
  assert.equal((await r.say('How much time did I spend on YouTube?')).text, 'You have spent 35 minutes on YouTube today.');
  assert.equal((await r.say('how much time on netflix today')).text, "Netflix isn't on your tracked websites list, so I have no usage for it.");
  const send = (domain, seq, kind = 'change') => r.tracker.onBrowser({ installId: 'install-voice-01', seq, kind, domain, paused: false, at: new Date(r.clock.t).toISOString() });
  send('github.com', 0); for (let i = 1; i <= 4; i++) { r.clock.t += 30000; send('github.com', i, 'heartbeat'); }
  assert.equal((await r.say('how much time did i spend on github')).text, 'You have spent 2 minutes on GitHub today.');   // the run that is open right now
});

test('9/10. limits: time left, reached, no limit, disabled, master off; "show my daily limits" summarises without reading names aloud', async () => {
  const r = rig();
  assert.equal((await r.say('How much time is left on YouTube?')).text, "You haven't set a daily limit for YouTube.");
  const l = r.limits.create({ targetType: 'website', target: 'youtube.com', dailyLimitSeconds: 3600, mode: 'warn', warningPercent: 80, extensionMinutes: 10, isEnabled: true });
  r.limits.create({ targetType: 'application', target: 'Notepad', dailyLimitSeconds: 1800, mode: 'confirm', warningPercent: 80, extensionMinutes: 10, isEnabled: true });
  r.use('website', 'youtube.com', 35 * 60);
  assert.equal((await r.say('How much time is left on YouTube?')).text, 'You have 25 minutes left on YouTube today.');
  assert.equal((await r.say('how much time do i have left on notepad')).text, 'You have 30 minutes left on Notepad today.');
  const s = await r.say('Show my daily limits.');
  assert.equal(s.ui.navigate, 'limits'); assert.match(s.text, /2 active limits, none reached today/);
  assert.deepEqual(s.details.map((d) => d.label).sort(), ['Notepad', 'youtube.com']);
  assert.doesNotMatch(s.speech, /youtube|notepad/i);
  r.use('website', 'youtube.com', 30 * 60);
  assert.equal((await r.say('how much time is left on youtube')).text, "You've reached today's limit for YouTube.");
  r.limits.setMaster(false);
  assert.match((await r.say('how much time is left on youtube')).text, /restrictions are turned off/);
  r.limits.setMaster(true); r.limits.update(l.id, { isEnabled: false });
  assert.equal((await r.say('how much time is left on youtube')).text, 'The limit for YouTube is turned off.');
});

test('12. "Stop listening" and the other assistant controls return a UI action and change nothing else', async () => {
  const r = rig();
  assert.deepEqual([(await r.say('Stop listening.')).ui.action, (await r.say('start listening')).ui.action, (await r.say('stop talking')).ui.action, (await r.say('clear conversation')).ui.action], ['stop_listening', 'start_listening', 'stop_speaking', 'clear_conversation']);
  assert.equal((await r.say('repeat that')).text, 'Cleared the conversation.');                // repeats the last real answer
  const t = await r.say('What time is it?'); assert.equal(t.text, "It's 3:42 PM.");
  assert.equal((await r.say('say that again')).text, "It's 3:42 PM.");
  assert.equal((await r.say("What's today's date?")).text, 'Today is Saturday, October 31, 2026.');
});

test('13. an unknown command executes nothing and is not kept in history', async () => {
  const r = rig();
  const x = await r.say('banana smoothie with extra password hunter2');
  assert.equal(x.status, 'unknown'); assert.match(x.text, /didn't understand/);
  assert.equal(r.spawned.length + r.opened.length, 0);
  assert.deepEqual(r.repo.listVoiceHistory({ limit: 5, offset: 0 }).records.map((h) => [h.recognizedText, h.status]), [['(not understood)', 'unknown']]);
  assert.equal((await r.say('')).status, 'unknown');
  assert.equal((await r.say('   ?!  ')).status, 'unknown');
  assert.equal((await r.say('x'.repeat(500))).status, 'unknown');
});

test('14. an ambiguous application name asks which one; the answer is used; saying no does nothing', async () => {
  const r = rig();
  let x = await r.say('open visual');
  assert.equal(x.status, 'needs_confirmation'); assert.deepEqual(x.confirmation.options.sort(), ['Visual Studio', 'Visual Studio Code']);
  assert.equal(r.spawned.length, 0);
  x = await r.say('the second one');                                          // options are ordered by score then registry order
  assert.equal(x.status, 'executed'); assert.match(x.text, /^Opening Visual Studio/);
  assert.equal(r.spawned.length, 1);
  x = await r.say('open visual'); x = await r.say('no');
  assert.deepEqual([x.status, r.spawned.length], ['cancelled', 1]);
  x = await r.say('open visual'); x = await r.say('open notepad');             // a new request abandons the question
  assert.equal(r.spawned.length, 2); assert.equal(r.service.pendingQuestion(), null);
  x = await r.say('open visual'); const id = x.confirmation.id;
  assert.equal((await r.service.confirm({ id: 'not-the-id-1234', choice: 0 })).status, 'rejected');
  assert.equal((await r.service.confirm({ id, choice: 9 })).status, 'rejected');
  const ok = await r.service.confirm({ id: x.confirmation.id, choice: 0 });
  assert.equal(ok.status === 'rejected', true);                                // the first confirm attempt consumed the question
});

test('exact names beat partial matches; typos are forgiven; unrelated words are not matched', () => {
  assert.equal(scoreName('visual studio', Apps.byId('visualstudio').aliases), 1);
  assert.equal(scoreName('visual', Apps.byId('vscode').aliases), 0.8);
  assert.ok(scoreName('notepat', Apps.byId('notepad').aliases) >= 0.74);
  assert.ok(scoreName('calculater', Apps.byId('calculator').aliases) >= 0.74);
  assert.equal(scoreName('paint', Apps.byId('notepad').aliases), 0);
  assert.equal(scoreName('point', Apps.byId('paint').aliases), 0);
  assert.equal(scoreName('google', Apps.byId('chrome').aliases), 0.8);
});

test('a misspelled name still resolves to one app; a site name wins over a partial app match', async () => {
  const r = rig();
  assert.equal((await r.say('open notepat')).text, 'Opening Notepad.');
  assert.equal((await r.say('open google')).text, 'Opening Google.');            // the site (exact) beats "Google Chrome" (partial)
  assert.deepEqual(r.opened, ['https://www.google.com/']);
  assert.equal((await r.say('open chrome browser')).text, 'Opening Google Chrome.');
});

test('application not installed / unknown / non-Windows give the friendly message and launch nothing', async () => {
  const r = rig({ installed: new Set() });
  for (const t of ['open chrome', 'open banana']) { const x = await r.say(t); assert.deepEqual([x.status, x.text], ['error', "I couldn't find that application. Please check whether it is installed."]); }
  assert.equal(r.spawned.length, 0);
  const linux = rig({ platform: 'linux' });
  assert.match((await linux.say('open notepad')).text, /only works on Windows/);
  const broken = rig({ spawnFails: true });
  assert.match((await broken.say('open notepad')).text, /couldn't open Notepad/);
});

test('unsafe requests are refused or never reach a process: shells, scripts, SQL, protection settings, data deletion', async () => {
  const r = rig();
  for (const t of ['open cmd', 'open command prompt', 'launch powershell', 'open windows terminal', 'open registry editor', 'open cmd.exe /c calc', 'open task scheduler', 'open command prompt; rm -rf /', 'open notepad && del *.*']) {
    const x = await r.say(t);
    assert.notEqual(x.status, 'executed', t);
  }
  for (const t of ['run powershell Get-Process', 'execute the command format c', 'type a script', 'run sql drop table usage_sessions']) {
    const x = await r.say(t); assert.equal(x.status, 'rejected', t); assert.match(x.text, /can't run commands/);
  }
  for (const t of ['turn off all restrictions', 'disable the limits', 'stop tracking', 'turn off privacy']) { const x = await r.say(t); assert.equal(x.status, 'rejected', t); assert.match(x.text, /protection setting/); }
  const del = await r.say('delete my usage history'); assert.equal(del.status, 'rejected');
  assert.equal(r.spawned.length, 0); assert.equal(r.opened.length, 0);
  assert.equal(r.repo.restrictionsEnabled(), true);
});

test('website safety: registry sites open directly; an unknown valid host asks first; schemes, IPs, paths and ports are refused', async () => {
  const r = rig();
  let x = await r.say('open example.com'); assert.equal(x.status, 'needs_confirmation'); assert.equal(r.opened.length, 0);
  x = await r.say('yes'); assert.deepEqual([x.status, x.text, r.opened], ['executed', 'Opening example.com.', ['https://example.com/']]);
  for (const t of ['open javascript:alert(1)', 'open http://evil.test', 'open file:///c:/windows', 'open 127.0.0.1', 'open localhost', 'open user@evil.test', 'open example.com/path?x=1']) {
    const before = r.opened.length;
    const y = await r.say(t); assert.notEqual(y.status, 'executed', t); assert.equal(r.opened.length, before, t);
  }
  assert.equal(Sites.validateUrl('javascript:alert(1)'), null);
  for (const bad of ['http://example.com/', 'ftp://example.com/', 'data:text/html,hi', 'https://user:pw@example.com/', 'https://example.com:8443/', 'https://127.0.0.1/', 'https://localhost/', 'file:///c:/x', 'not a url']) assert.equal(Sites.validateUrl(bad), null, bad);
  assert.equal(Sites.validateUrl('https://example.com/'), 'https://example.com/');
  assert.equal(Sites.urlFromSpokenHost('github.com'), 'https://github.com/');
  assert.equal(Sites.urlFromSpokenHost('github'), null);
  assert.equal(Sites.urlFromSpokenHost('a.b c'), null);
});

test('opening a site whose limit is reached adds a note (it may be blocked)', async () => {
  const r = rig();
  r.limits.create({ targetType: 'website', target: 'youtube.com', dailyLimitSeconds: 600, mode: 'enforce', warningPercent: 80, extensionMinutes: 5, isEnabled: true });
  r.use('website', 'youtube.com', 700);
  const x = await r.say('open youtube');
  assert.match(x.text, /Opening YouTube\. Note: youtube\.com has reached its daily limit and may be blocked\./);
});

test('tracked websites are openable by their own name', async () => {
  const r = rig();
  r.repo.addWebsite({ domain: 'example.org', displayName: 'My Example' });
  const x = await r.say('open my example');
  assert.deepEqual([x.text, r.opened], ['Opening My Example.', ['https://example.org/']]);
});

test('low recognition confidence: actions are read back first; answers and navigation are not delayed', async () => {
  const r = rig();
  let x = await r.say('open notepad', { source: 'voice', confidence: 0.4 });
  assert.equal(x.status, 'needs_confirmation'); assert.match(x.text, /I heard "open notepad"/); assert.equal(r.spawned.length, 0);
  x = await r.say('yes'); assert.deepEqual([x.status, r.spawned.length], ['executed', 1]);
  x = await r.say('open notepad', { source: 'voice', confidence: 0.4 }); x = await r.say('no'); assert.equal(r.spawned.length, 1);
  assert.equal((await r.say('what time is it', { source: 'voice', confidence: 0.3 })).status, 'executed');
  assert.equal((await r.say('open settings', { source: 'voice', confidence: 0.3 })).ui.navigate, 'settings');
  x = await r.say('open notepad', { source: 'voice', confidence: 0.4 });
  const ok = await r.service.confirm({ id: x.confirmation.id, choice: 'yes' }); assert.equal(ok.text, 'Opening Notepad.');
});

test('voice history: saved as text only, respects the setting, can be cleared (by confirmation when spoken)', async () => {
  const r = rig();
  await r.say('open notepad'); await r.say('what time is it', { source: 'voice' });
  const h = r.repo.listVoiceHistory({ limit: 10, offset: 0 }).records;
  assert.deepEqual(h.map((x) => [x.recognizedText, x.intent, x.status, x.source]), [['what time is it', 'time', 'executed', 'voice'], ['open notepad', 'open_target', 'executed', 'typed']]);
  assert.ok(h.every((x) => x.responseText.length > 0 && x.createdAt));
  assert.deepEqual(Object.keys(r.db.prepare('PRAGMA table_info(voice_history)').all().reduce((o, c) => ({ ...o, [c.name]: 1 }), {})).sort(), ['created_at', 'id', 'intent', 'recognized_text', 'response_text', 'source', 'status']); // no audio column
  r.repo.updateVoiceSettings({ historyEnabled: false });
  await r.say('open settings');
  assert.equal(r.repo.listVoiceHistory({ limit: 10, offset: 0 }).total, 2);
  r.repo.updateVoiceSettings({ historyEnabled: true });
  const q = await r.say('clear voice history'); assert.equal(q.status, 'needs_confirmation');
  assert.equal(r.repo.listVoiceHistory({ limit: 10, offset: 0 }).total, 3);       // nothing deleted until confirmed
  const c = await r.say('yes'); assert.match(c.text, /^Cleared \d+ saved voice commands?\.$/);
  assert.equal(r.repo.listVoiceHistory({ limit: 10, offset: 0 }).records.length, 1); // only the confirmation itself remains
});

test('voice disabled in settings: nothing runs, nothing is saved', async () => {
  const r = rig(); r.repo.updateVoiceSettings({ enabled: false });
  const x = await r.say('open notepad'); assert.deepEqual([x.status, r.spawned.length, r.repo.listVoiceHistory({ limit: 5, offset: 0 }).total], ['rejected', 0, 0]);
});

test('backend trouble becomes a friendly answer, not a crash', async () => {
  const r = rig();
  r.db.exec('DROP TABLE usage_sessions');
  const x = await r.say('how much time did i spend on chrome');
  assert.equal(x.status, 'error'); assert.match(x.text, /Something went wrong/);
  assert.ok(r.logs.length >= 1);
});

test('parser and intents: the spec examples and look-alike phrasings', () => {
  const cases = [['Open Chrome.', 'open_target', 'chrome'], ['please open vs code for me', 'open_target', 'vs code'], ['Hey Lil Moon, open Notepad', 'open_target', 'notepad'],
    ['How much time is left on YouTube?', 'limit_remaining', 'youtube'], ['how much time do i have left on youtube', 'limit_remaining', 'youtube'], ['how much have I used chrome', 'usage_target', 'chrome'],
    ['How long did I spend on GitHub today', 'usage_target', 'github']];
  for (const [said, intent, name] of cases) { const n = normalize(said); const d = detect(n.text); assert.deepEqual([d.name, d.slots.name], [intent, name], said); }
  assert.equal(normalize('Open YouTube; DROP TABLE x --').text.includes(';'), false);
  assert.equal(normalize('open\u0000chrome').text, 'open chrome');
  assert.equal(normalize('open example dot com').text, 'open example.com');
});
