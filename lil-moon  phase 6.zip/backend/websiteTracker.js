// Website session tracker. The desktop app is the single authority on time: the browser extension only reports WHICH tracked
// website is in front (or none); the idle monitor reports whether the person is present. A run of usage is open only while
//   extension live  AND  tracking not paused  AND  a tracked site is the focused tab  AND  presence is "active".
// Several browsers/profiles may report at once; any live, unpaused one that reports a site justifies counting it.
// Timestamps (not timers) decide every duration, so a late timer or a sleeping service worker cannot distort totals.
//
// Storage model: ONE database row per uninterrupted run. The row is created once it lasts >= 1 s, then extended at each
// checkpoint (every heartbeat / dashboard refresh). Consequences: a crash loses at most one checkpoint, "today" is live,
// retries cannot create duplicates (runs only move forward from `floor`), and runs never overlap.
const { localDate } = require('./database');

const iso = (ms) => new Date(ms).toISOString();
const nextLocalMidnight = (ms) => { const d = new Date(ms); return new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).getTime(); };

function createTracker({ repo, now = Date.now, staleMs = 100000, minRunMs = 1000 }) {
  const startMs = now();
  let floorMs = Math.max(startMs, repo.lastWebsiteEndMs()); // no run may begin before this
  let presence = { state: 'active', sinceMs: startMs };
  // One entry per extension install (Chrome and Edge, or two profiles, can report at once). Only one browser window is in
  // front at a time, so at most one live install reports a site; the others report null and must not cancel it.
  const installs = new Map(); // installId -> { domain, paused, lastSeenMs, changedMs, lastSeq, browserName }
  let run = null; // { id, domain, startedMs, endedMs }

  const isLive = (i, t) => t - i.lastSeenMs <= staleMs;
  const liveInstalls = (t) => [...installs.values()].filter((i) => isLive(i, t));
  // The install that currently justifies counting, if any (most recent change wins in the unlikely case of two).
  const leader = (t) => liveInstalls(t).filter((i) => !i.paused && i.domain).sort((a, b) => b.changedMs - a.changedMs)[0] ?? null;
  const desired = (t) => (presence.state === 'active' ? leader(t)?.domain ?? null : null);
  // When did we last hear from something that supported counting `domain`? Used to end a run whose source went silent.
  const lastEvidence = (domain, t) => Math.min(t, Math.max(0, ...[...installs.values()].filter((i) => i.domain === domain && !i.paused).map((i) => i.lastSeenMs)));

  function persist(r, endMs) {
    const end = Math.max(endMs, r.startedMs); // a duration can never be negative
    if (end - r.startedMs < minRunMs) {
      if (r.id) { repo.deleteWebsiteRun(r.id); r.id = null; } // shrunk below one second (e.g. idle began before the run did)
      r.endedMs = end;
      return;
    }
    const durationSeconds = Math.round((end - r.startedMs) / 1000);
    try {
      if (!r.id) r.id = repo.insertWebsiteRun({ domain: r.domain, startedAt: iso(r.startedMs), endedAt: iso(end), durationSeconds, sessionDate: localDate(new Date(r.startedMs)) });
      else repo.updateWebsiteRun(r.id, iso(end), durationSeconds);
    } catch (err) {
      console.error('[lil-moon] could not save website run:', err.message);
    }
    r.endedMs = end;
  }

  // Extend the open run to `atMs`, splitting at every local midnight so each row belongs to exactly one calendar day.
  function checkpoint(atMs) {
    if (!run) return;
    const end = Math.max(atMs, run.startedMs);
    for (;;) {
      const mid = nextLocalMidnight(run.startedMs);
      if (end <= mid) break;
      persist(run, mid);
      floorMs = Math.max(floorMs, mid);
      run = { id: null, domain: run.domain, startedMs: mid, endedMs: mid };
    }
    persist(run, end);
  }

  function closeRun(atMs) {
    if (!run) return;
    checkpoint(atMs);
    floorMs = run.endedMs;
    run = null;
  }

  // Bring the open run in line with the current inputs. atMs = when the change really happened.
  function apply(atMs, nowMs) {
    const want = desired(nowMs);
    if (run && run.domain !== want) closeRun(atMs);
    else if (run) checkpoint(nowMs);
    if (!run && want) run = { id: null, domain: want, startedMs: Math.max(atMs, floorMs), endedMs: Math.max(atMs, floorMs) };
  }

  // True when nothing live still supports the run (as opposed to presence or a pause having changed).
  const leaderlessBecauseSilent = (domain, t) => presence.state === 'active' && ![...installs.values()].some((i) => i.domain === domain && !i.paused && isLive(i, t));

  const status = () => {
    const t = now();
    const alive = liveInstalls(t);
    const lead = leader(t);
    const newest = [...alive].sort((a, b) => b.lastSeenMs - a.lastSeenMs)[0];
    const lastSeen = Math.max(0, ...[...installs.values()].map((i) => i.lastSeenMs));
    return {
      connected: alive.length > 0,
      paused: alive.length > 0 && alive.every((i) => i.paused),
      currentDomain: lead ? lead.domain : null,
      countingDomain: run ? run.domain : null, presence: presence.state,
      lastSyncAt: installs.size ? iso(lastSeen) : null, browser: (lead ?? newest)?.browserName ?? null,
    };
  };

  return {
    // Presence from the idle monitor. atMs may be back-dated to the last input when idleness is detected.
    onPresence(state, atMs = now()) {
      const t = now();
      const at = Math.min(atMs, t);
      if (state === presence.state) return;
      presence = { state, sinceMs: at };
      apply(at, t);
    },

    // One report from the extension. Returns {accepted}. seq makes retries and re-ordered deliveries harmless.
    onBrowser(msg) {
      const t = now();
      // If what was justifying the open run has gone silent for longer than it ever should, it was not running:
      // end the run at its last sign of life before taking in anything new.
      if (run && desired(t) !== run.domain) closeRun(lastEvidence(run.domain, t));
      let inst = installs.get(msg.installId);
      if (!inst) { inst = { domain: null, paused: false, lastSeenMs: t, changedMs: t, lastSeq: -1, browserName: null }; installs.set(msg.installId, inst); }
      inst.lastSeenMs = t;
      inst.browserName = msg.browser || inst.browserName;
      if (msg.seq <= inst.lastSeq) { apply(t, t); return { accepted: false }; } // duplicate or older than what we have
      inst.lastSeq = msg.seq;
      const claimed = Date.parse(msg.at);
      // Never earlier than the last stored run or the latest presence change (we cannot know what happened in between), never in the future.
      const lo = Math.max(floorMs, presence.sinceMs);
      const at = Math.min(Math.max(Number.isFinite(claimed) ? claimed : t, lo), t);
      const changed = msg.domain !== inst.domain || msg.paused !== inst.paused;
      if (changed) inst.changedMs = t;
      inst.domain = msg.domain;
      inst.paused = msg.paused;
      apply(changed ? at : t, t);
      return { accepted: true };
    },

    // Periodic reconciliation (also called before every read): closes the run if the extension went silent, else checkpoints.
    reconcile() {
      const t = now();
      if (!run) return;
      const want = desired(t);
      if (want === run.domain) return checkpoint(t);
      closeRun(leaderlessBecauseSilent(run.domain, t) ? lastEvidence(run.domain, t) : t);
    },

    // Called on app exit: store whatever is open.
    shutdown() { closeRun(now()); },

    status,
    __state: () => ({ run: run && { ...run }, floorMs, presence: { ...presence }, installs: [...installs.keys()] }),
  };
}

module.exports = { createTracker };
