import { useState } from 'react';
import AsyncBoundary from '../components/AsyncBoundary.jsx';
import DashboardCard from '../components/DashboardCard.jsx';
import { api } from '../lib/api.js';
import { useApi } from '../hooks/useApi.js';
import { fmtWhen } from '../lib/format.js';

const CATS = [['preference', 'Preferences'], ['project', 'Projects'], ['fact', 'Important facts'], ['task', 'Ongoing tasks'], ['instruction', 'Custom instructions']];
const label = (c) => CATS.find(([id]) => id === c)?.[1] ?? c;

export default function MemoryPage() {
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const qs = [q.trim() && `q=${encodeURIComponent(q.trim())}`, cat && `category=${cat}`].filter(Boolean).join('&');
  const mem = useApi(`/api/ai/memories${qs ? `?${qs}` : ''}`);
  const status = useApi('/api/ai/status');
  const [form, setForm] = useState({ category: 'preference', content: '' });
  const [edit, setEdit] = useState(null);
  const [avoid, setAvoid] = useState('');
  const [msg, setMsg] = useState({ text: '', error: false });
  const [confirmClear, setConfirmClear] = useState(false);
  const say = (text, error = false) => setMsg({ text, error });
  const run = async (fn, ok) => { try { await fn(); say(ok); mem.reload(); } catch (e) { say(e.message, true); } };

  return (
    <>
      <div className="page-head"><h1>AI memory</h1><span className="badge">You are in control</span></div>
      <p className="lead">Lil Moon only remembers what you save or approve. It never saves passwords, keys or other secrets, and whole conversations are not memories. Memories are sent to your AI provider as context when this is switched on.</p>
      <span role="status" className={msg.error ? 'msg-error' : ''}>{msg.text}</span>

      <div className="grid">
        <DashboardCard title="Use memory" tone="purple">
          {status.data && (
            <label className="row"><input type="checkbox" checked={status.data.memoryEnabled} onChange={(e) => run(async () => { await api('PUT', '/api/ai/settings', { memoryEnabled: e.target.checked }); status.reload(); }, e.target.checked ? 'Memory is on.' : 'Memory is off. Nothing will be suggested or used.')} /> Let the assistant use and suggest memories</label>
          )}
        </DashboardCard>
        <DashboardCard title="Add a memory">
          <label className="field">Category
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{CATS.map(([id, l]) => <option key={id} value={id}>{l}</option>)}</select>
          </label>
          <label className="field">What should I remember?
            <textarea rows={2} maxLength={500} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} />
          </label>
          <button className="btn btn-strong" disabled={!form.content.trim()} onClick={() => run(async () => { await api('POST', '/api/ai/memories', form); setForm({ ...form, content: '' }); }, 'Memory saved.')}>Save memory</button>
        </DashboardCard>
      </div>

      <AsyncBoundary query={mem}>
        {mem.data && (
          <>
            {mem.data.candidates.length > 0 && (
              <>
                <h2 className="section-title">Waiting for your approval</h2>
                <ul className="history">
                  {mem.data.candidates.map((c) => (
                    <li key={c.id}>
                      <div><strong>{c.content}</strong><span>{label(c.category)} - suggested by the assistant</span></div>
                      <button className="btn btn-small" onClick={() => run(() => api('POST', `/api/ai/memory-candidates/${c.id}/accept`), 'Memory saved.')}>Save</button>
                      <button className="btn btn-small" onClick={() => run(() => api('POST', `/api/ai/memory-candidates/${c.id}/dismiss`, { never: true }), 'Dismissed. I will not suggest it again.')}>Never</button>
                    </li>
                  ))}
                </ul>
              </>
            )}

            <h2 className="section-title">Saved memories</h2>
            <div className="quick">
              <input type="search" className="search" placeholder="Search memories" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search memories" />
              <select value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Filter by category"><option value="">All categories</option>{CATS.map(([id, l]) => <option key={id} value={id}>{l}</option>)}</select>
            </div>
            {mem.data.memories.length === 0
              ? <div className="state">{q || cat ? 'No memories match.' : 'No memories yet. Add one above, or say "remember that..." in the chat.'}</div>
              : <ul className="history">
                {mem.data.memories.map((m) => (
                  <li key={m.id}>
                    {edit?.id === m.id
                      ? <div className="field"><textarea rows={2} maxLength={500} value={edit.content} onChange={(e) => setEdit({ ...edit, content: e.target.value })} aria-label="Edit memory" />
                        <select value={edit.category} onChange={(e) => setEdit({ ...edit, category: e.target.value })} aria-label="Category">{CATS.map(([id, l]) => <option key={id} value={id}>{l}</option>)}</select></div>
                      : <div><strong>{m.content}</strong><span>{label(m.category)} - saved {fmtWhen(m.createdAt)} ({m.origin === 'user' ? 'by you' : 'approved by you'})</span></div>}
                    {edit?.id === m.id
                      ? <><button className="btn btn-small" onClick={() => run(async () => { await api('PATCH', `/api/ai/memories/${m.id}`, { content: edit.content, category: edit.category }); setEdit(null); }, 'Memory updated.')}>Save</button>
                        <button className="btn btn-small" onClick={() => setEdit(null)}>Cancel</button></>
                      : <><button className="btn btn-small" onClick={() => setEdit({ id: m.id, content: m.content, category: m.category })}>Edit</button>
                        <button className="btn btn-small" onClick={() => run(() => api('DELETE', `/api/ai/memories/${m.id}`), 'Memory deleted.')}>Delete</button></>}
                  </li>
                ))}
              </ul>}
            <div className="quick" style={{ marginTop: 16 }}>
              <button className="btn" onClick={() => { if (!confirmClear) { setConfirmClear(true); setTimeout(() => setConfirmClear(false), 4000); return; } setConfirmClear(false); run(() => api('DELETE', '/api/ai/memories'), 'All memories cleared.'); }}>{confirmClear ? 'Click again to delete ALL memories' : 'Clear all memories'}</button>
            </div>

            <h2 className="section-title">Things not to remember</h2>
            <p className="note">Anything containing these phrases is never suggested or saved from chat.</p>
            <div className="quick">
              <input className="search" value={avoid} onChange={(e) => setAvoid(e.target.value)} placeholder="e.g. my sports team" maxLength={200} aria-label="Phrase to avoid" />
              <button className="btn" disabled={avoid.trim().length < 2} onClick={() => run(async () => { await api('POST', '/api/ai/memory-avoid', { phrase: avoid }); setAvoid(''); }, 'Added.')}>Add</button>
            </div>
            <ul className="chips">{mem.data.avoid.map((a) => <li key={a.id}>{a.phrase} <button className="btn btn-small" onClick={() => run(() => api('DELETE', `/api/ai/memory-avoid/${a.id}`), 'Removed.')} aria-label={`Remove ${a.phrase}`}>Remove</button></li>)}</ul>
          </>
        )}
      </AsyncBoundary>
    </>
  );
}
