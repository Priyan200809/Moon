// Turns a detected intent into an approved action and a response. This is the only module that touches the launcher, the browser
// opener, the usage records and the limits engine. Nothing in a spoken phrase is ever executed: phrases only select an intent,
// a name is only ever looked up in the allowlists, and every number comes from the database.
const Apps = require('./applicationRegistry');
const Sites = require('./websiteRegistry');
const { scoreName, decide } = require('./matching');
const { localDate } = require('../database');

const NOT_FOUND_APP = "I couldn't find that application. Please check whether it is installed.";
const HELP = 'Try "open Chrome", "open YouTube", "what time is it", "how much time did I spend on YouTube", "show my daily limits" or "open settings".';
const REFUSALS = {
  protection: "That's a protection setting, so I won't change it by voice. You can change it yourself on the Usage limits page.",
  data: "I won't delete your usage data by voice. You can do that yourself from the dashboard.",
  command: "I can't run commands or scripts. I can only open apps and websites from my approved lists.",
  shell: "I don't open command lines or system tools by voice.",
};

const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
function fmtDuration(sec) {
  const s = Math.max(0, Math.round(sec));
  if (s < 60) return 'less than a minute';
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
  return [h ? plural(h, 'hour') : '', m ? plural(m, 'minute') : ''].filter(Boolean).join(' ');
}

function createCommandExecutor({ repo, tracker = null, limits = null, launcher, opener, now = Date.now }) {
  const today = () => localDate(new Date(now()));
  const trackedWebsites = () => repo.listWebsites();
  const done = (text, extra = {}) => ({ status: 'executed', text, speech: text, ...extra });
  const fail = (text, extra = {}) => ({ status: 'error', text, speech: text, ...extra });

  // ---------- name resolution ----------
  function openCandidates(name) {
    return [
      ...Apps.candidates().map((a) => ({ ...a, score: scoreName(name, a.aliases) })),
      ...Sites.candidates(trackedWebsites()).map((s) => ({ ...s, score: scoreName(name, s.aliases) })),
    ];
  }
  // For "how much time on X": registry apps, application names that really appear in the records, and registry/tracked sites.
  function storedAppNames(rows) {
    const names = new Set(rows.filter((r) => r.category === 'application').map((r) => r.itemName));
    for (const l of repo.listLimits()) if (l.targetType === 'application') names.add(l.target);
    return [...names];
  }
  const aliasesForStored = (stored) => {
    const base = [stored, stored.replace(/\.exe$/i, '')];
    const reg = Apps.APPS.find((a) => scoreName(stored, a.aliases) === 1);
    return reg ? [...new Set([...base, ...reg.aliases, reg.name])] : base;
  };
  function usageCandidates(name, rows) {
    const apps = Apps.candidates().map((a) => ({ ...a, score: scoreName(name, a.aliases) }));
    for (const stored of storedAppNames(rows)) {
      if (apps.some((a) => scoreName(stored, a.aliases) === 1)) continue; // already represented by its registry entry
      const aliases = aliasesForStored(stored);
      apps.push({ kind: 'app', id: `stored:${stored}`, name: stored, aliases, score: scoreName(name, aliases) });
    }
    const sites = Sites.candidates(trackedWebsites()).map((s) => ({ ...s, score: scoreName(name, s.aliases) }));
    return [...apps, ...sites];
  }
  const rowBelongs = (rowName, pick) => scoreName(rowName, pick.aliases) === 1;

  const sayOptions = (opts) => opts.map((o) => o.name).join(' or ');
  const ask = (prompt, options, kind = 'choose') => ({
    status: 'needs_confirmation', text: prompt, speech: prompt,
    confirmation: { kind, prompt, options },
  });

  // ---------- actions that need no confirmation or are approved by one ----------
  async function openApp(app) {
    const r = await launcher.launch(app.id);
    if (r.ok) return done(`Opening ${app.name}.`, { action: { type: 'launch_app', id: app.id } });
    if (r.code === 'not_found' || r.code === 'unknown_app') return fail(NOT_FOUND_APP);
    if (r.code === 'unsupported_platform') return fail('Opening applications by voice only works on Windows.');
    return fail(`I couldn't open ${app.name}. Please try opening it yourself.`);
  }

  async function openSite(url, name) {
    const safe = Sites.validateUrl(url);
    if (!safe) return fail("That doesn't look like a valid website address, so I didn't open it.");
    try { await opener.open(safe); } catch { return fail(`I couldn't open ${name || 'the website'} in your browser.`); }
    let note = '';
    try {
      const host = new URL(safe).hostname.replace(/^www\./, '');
      const l = limits?.snapshot();
      const hit = l?.restrictionsEnabled && l.items.find((i) => i.isEnabled && i.targetType === 'website' && i.status === 'reached' && (host === i.target || host.endsWith(`.${i.target}`)));
      if (hit) note = hit.mode === 'enforce' ? ` Note: ${hit.target} has reached its daily limit and may be blocked.` : ` Note: you've reached today's limit for ${hit.target}.`;
    } catch { /* the note is optional */ }
    return done(`Opening ${name || new URL(safe).hostname}.${note}`);
  }

  async function perform(action) {
    if (action.type === 'launch_app') { const app = Apps.byId(action.id); return app ? openApp(app) : fail(NOT_FOUND_APP); }
    if (action.type === 'open_site') return openSite(action.url, action.name);
    if (action.type === 'clear_history') { const n = repo.clearVoiceHistory(); return done(`Cleared ${plural(n, 'saved voice command')}.`); }
    return fail("I can't do that.");
  }

  const toAction = (pick) => (pick.kind === 'app' ? { type: 'launch_app', id: pick.id } : { type: 'open_site', url: pick.url, name: pick.name });

  // ---------- intents ----------
  async function openTarget(name) {
    if (Apps.isBlockedName(name)) return { status: 'rejected', text: REFUSALS.shell, speech: REFUSALS.shell };
    const d = decide(openCandidates(name));
    if (d.kind === 'one') return perform(toAction(d.pick));
    if (d.kind === 'ambiguous') {
      return ask(`Which one do you mean: ${sayOptions(d.options)}?`, d.options.map((o) => ({ label: o.name, action: toAction(o) })));
    }
    const url = Sites.urlFromSpokenHost(name); // e.g. "example.com": a valid, plain https host, but not one we know
    if (url) return ask(`Open ${new URL(url).hostname} in your browser?`, [{ label: 'Open it', action: { type: 'open_site', url, name: new URL(url).hostname } }], 'yes_no');
    if (/[.]/.test(name)) return fail("That doesn't look like a valid website address, so I didn't open it.");
    return fail(NOT_FOUND_APP);
  }

  function usageNumbers() {
    tracker?.reconcile(); // include the website run that is open right now
    return repo.usageRowsForDate(today());
  }

  function usageTarget(name) {
    if (!name) return { status: 'unknown', text: 'Tell me which app or website, for example: how much time did I spend on YouTube.', speech: 'Tell me which app or website.' };
    const rows = usageNumbers();
    const d = decide(usageCandidates(name, rows));
    if (d.kind === 'none') return fail(`I don't know an app or website called ${name}.`);
    if (d.kind === 'ambiguous') return ask(`Which one do you mean: ${sayOptions(d.options)}? Ask again with the full name.`, [], 'choose');
    const p = d.pick;
    if (p.kind === 'site') {
      if (!trackedWebsites().some((w) => w.domain === p.domain)) return done(`${p.name} isn't on your tracked websites list, so I have no usage for it.`);
      const secs = rows.filter((r) => r.category === 'website' && r.itemName === p.domain).reduce((n, r) => n + r.totalSeconds, 0);
      return done(secs > 0 ? `You have spent ${fmtDuration(secs)} on ${p.name} today.` : `You haven't spent any time on ${p.name} today.`);
    }
    const secs = rows.filter((r) => r.category === 'application' && rowBelongs(r.itemName, p)).reduce((n, r) => n + r.totalSeconds, 0);
    return done(secs > 0 ? `You have spent ${fmtDuration(secs)} on ${p.name} today.` : `I don't have any recorded time for ${p.name} today.`);
  }

  function limitRemaining(name) {
    if (!limits) return fail("I can't read your limits right now.");
    if (!name) return { status: 'unknown', text: 'Tell me which app or website, for example: how much time is left on YouTube.', speech: 'Tell me which app or website.' };
    const snap = limits.snapshot();
    const rows = repo.usageRowsForDate(today());
    const d = decide(usageCandidates(name, rows));
    if (d.kind === 'none') return fail(`I don't know an app or website called ${name}.`);
    if (d.kind === 'ambiguous') return ask(`Which one do you mean: ${sayOptions(d.options)}? Ask again with the full name.`, [], 'choose');
    const p = d.pick;
    const item = snap.items.find((i) => (p.kind === 'site' ? i.targetType === 'website' && i.target === p.domain : i.targetType === 'application' && scoreName(i.target, p.aliases) === 1));
    if (!item) return done(`You haven't set a daily limit for ${p.name}.`);
    if (!item.isEnabled) return done(`The limit for ${p.name} is turned off.`);
    if (!snap.restrictionsEnabled) return done(`${p.name} has a limit of ${fmtDuration(item.dailyLimitSeconds)}, but all restrictions are turned off right now.`);
    if (item.status === 'reached') return done(`You've reached today's limit for ${p.name}.`);
    return done(`You have ${fmtDuration(item.remainingSeconds)} left on ${p.name} today.`);
  }

  function showLimits() {
    if (!limits) return fail("I can't read your limits right now.");
    const snap = limits.snapshot();
    const active = snap.items.filter((i) => i.isEnabled);
    if (!snap.items.length) return done("You haven't set any usage limits yet.", { ui: { navigate: 'limits' } });
    const reached = active.filter((i) => i.status === 'reached').length;
    const text = `You have ${plural(active.length, 'active limit')}${reached ? ` and ${reached} reached today` : ', none reached today'}.${snap.restrictionsEnabled ? '' : ' All restrictions are turned off right now.'}`;
    return done(text, { ui: { navigate: 'limits' }, details: snap.items.map((i) => ({ label: i.target, value: `${fmtDuration(i.usedSeconds)} of ${fmtDuration(i.allowanceSeconds)}${i.isEnabled ? '' : ' (off)'}` })) });
  }

  function showUsage(kind) {
    const cat = kind === 'sites' ? 'website' : 'application';
    const word = kind === 'sites' ? 'website' : 'application';
    const rows = usageNumbers().filter((r) => r.category === cat);
    const nav = { navigate: kind === 'sites' ? 'sites' : 'apps' };
    if (!rows.length) return done(`I haven't recorded any ${word} usage today.`, { ui: nav });
    const total = rows.reduce((n, r) => n + r.totalSeconds, 0);
    const label = (r) => (cat === 'website' ? trackedWebsites().find((w) => w.domain === r.itemName)?.displayName ?? r.itemName : r.itemName);
    const top = rows[0];
    return {
      status: 'executed', ui: nav, sensitive: true,
      text: `${kind === 'sites' ? 'Website' : 'Application'} usage today: ${fmtDuration(total)} across ${plural(rows.length, word)}. Most used: ${label(top)} (${fmtDuration(top.totalSeconds)}).`,
      speech: `You've spent ${fmtDuration(total)} on ${kind === 'sites' ? 'websites' : 'applications'} today. I've put the details on the screen.`, // names are not read aloud unasked
      details: rows.slice(0, 12).map((r) => ({ label: label(r), value: fmtDuration(r.totalSeconds) })),
    };
  }

  async function execute(intent) {
    const s = intent.slots || {};
    switch (intent.name) {
      case 'open_target': return openTarget(s.name);
      case 'open_page': return done(`Opening ${s.label}.`, { ui: { navigate: s.page } });
      case 'show_usage': return showUsage(s.kind);
      case 'show_limits': return showLimits();
      case 'usage_target': return usageTarget(s.name);
      case 'limit_remaining': return limitRemaining(s.name);
      case 'time': return done(`It's ${new Date(now()).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}.`);
      case 'date': return done(`Today is ${new Date(now()).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.`);
      case 'stop_listening': return done('Okay, I stopped listening.', { ui: { action: 'stop_listening' } });
      case 'start_listening': return done("I'm listening.", { ui: { action: 'start_listening' } });
      case 'stop_speaking': return done('Okay.', { speech: '', ui: { action: 'stop_speaking' } });
      case 'clear_conversation': return done('Cleared the conversation.', { speech: '', ui: { action: 'clear_conversation' } });
      case 'clear_history': return ask('Delete all saved voice commands? This cannot be undone.', [{ label: 'Yes, delete them', action: { type: 'clear_history' } }], 'yes_no');
      case 'refused': return { status: 'rejected', text: REFUSALS[intent.slots.reason] || REFUSALS.command, speech: REFUSALS[intent.slots.reason] || REFUSALS.command };
      default: return { status: 'unknown', text: `I didn't understand that. ${HELP}`, speech: "I didn't understand that." };
    }
  }

  return { execute, perform, fmtDuration, NOT_FOUND_APP };
}

module.exports = { createCommandExecutor, fmtDuration, NOT_FOUND_APP };
