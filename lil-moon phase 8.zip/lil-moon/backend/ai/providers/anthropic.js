const { ProviderError, post, sse, safeJson } = require('./common');

function toWire(messages) {
  const out = [];
  for (const m of messages) {
    if (m.role === 'tool') {
      const block = { type: 'tool_result', tool_use_id: m.toolCallId, content: m.content };
      const last = out[out.length - 1];
      if (last?.role === 'user' && Array.isArray(last.content)) last.content.push(block); else out.push({ role: 'user', content: [block] });
    } else if (m.role === 'assistant' && m.toolCalls?.length) {
      out.push({ role: 'assistant', content: [...(m.content ? [{ type: 'text', text: m.content }] : []), ...m.toolCalls.map((c) => ({ type: 'tool_use', id: c.id, name: c.name, input: c.args ?? {} }))] });
    } else out.push({ role: m.role, content: m.content });
  }
  return out;
}

async function* stream({ settings, apiKey, system, messages, tools, signal }) {
  const url = `${(settings.baseUrl || 'https://api.anthropic.com').replace(/\/+$/, '')}/v1/messages`;
  const body = { model: settings.model, max_tokens: 2048, stream: true, system, messages: toWire(messages) };
  if (tools?.length) body.tools = tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.parameters }));
  const res = await post(url, { headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' }, body, signal, apiKey });
  const blocks = new Map();
  for await (const { event, data } of sse(res, signal)) {
    const j = safeJson(data);
    if (event === 'error' || j?.type === 'error') throw new ProviderError('server', 'The AI provider reported an error while answering.');
    if (j?.type === 'content_block_start' && j.content_block?.type === 'tool_use') blocks.set(j.index, { id: j.content_block.id, name: j.content_block.name, args: '' });
    if (j?.type === 'content_block_delta') {
      if (j.delta?.type === 'text_delta' && j.delta.text) yield { type: 'text', text: j.delta.text };
      if (j.delta?.type === 'input_json_delta' && blocks.has(j.index)) blocks.get(j.index).args += j.delta.partial_json ?? '';
    }
    if (j?.type === 'message_stop') break;
  }
  for (const b of blocks.values()) yield { type: 'tool_call', id: b.id, name: b.name, args: b.args ? safeJson(b.args) : {} };
}

module.exports = { stream };
