import { useEffect, useState } from 'react';
import AsyncBoundary from '../components/AsyncBoundary.jsx';
import DashboardCard from '../components/DashboardCard.jsx';
import HistoryList from '../components/HistoryList.jsx';
import SiteCard from '../components/SiteCard.jsx';
import { useApi } from '../hooks/useApi.js';
import { api } from '../lib/api.js';
import { fmtAgo, fmtSec } from '../lib/format.js';

const PRESENCE = { active: '', idle: 'You look idle, so time is not counting', locked: 'Screen locked, so time is not counting', suspended: 'Computer asleep, so time is not counting' };

function trackingState(t) {
  if (!t.connected) return { label: 'Extension not connected', cls: 'pill-off', why: 'Install and pair the browser extension (see below). Nothing is counted until it reports in.' };
  if (t.paused) return { label: 'Paused in browser', cls: 'pill-warn', why: 'You paused tracking from the extension. Resume it from the extension popup.' };
  if (t.presence !== 'active') return { label: 'Waiting for you', cls: 'pill-warn', why: PRESENCE[t.presence] };
  return { label: 'Tracking on', cls: 'pill-on', why: t.countingDomain ? `Counting time on ${t.countingDomain}.` : 'Nothing counting right now (no listed site is in front).' };
}

function useClock() {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id); }, []);
  return now;
}

function StatusCard({ o, query, now }) {
  const st = trackingState(o.tracking);
  const updated = query.refreshedAt ? new Date(query.refreshedAt).toLocaleTimeString() : '';
  return (
    <DashboardCard title="Tracking status" tone="purple" badge={o.tracking.browser ? `Browser: ${o.tracking.browser}` : 'No browser yet'}>
      <p className="status-line"><span className={`pill ${st.cls}`} role="status">{st.label}</span></p>
      <p className="note">{st.why}</p>
      <dl className="usage-stats">
        <div><dt>Last sync from browser</dt><dd>{fmtAgo(o.tracking.lastSyncAt, now)}</dd></div>
        <div><dt>Page updated</dt><dd>{updated || '-'}</dd></div>
        <div><dt>Idle after</dt><dd>{fmtSec(o.idleThresholdSeconds)}</dd></div>
      </dl>
      {query.refreshError && <p className="msg-error" role="alert">Could not refresh: {query.refreshError}</p>}
      <button className="btn btn-small" onClick={query.reload}>Refresh now</button>
    </DashboardCard>
  );
}

function Totals({ o }) {
  return (
    <div className="grid">
      <DashboardCard title="Total tracked today" tone="cream">
        <p className="big">{fmtSec(o.totalSeconds)}</p>
        <p className="note">{o.totalSeconds === 0 ? 'Nothing recorded yet today.' : `Across ${o.sites.filter((s) => s.todaySeconds > 0).length} website(s), counted only while a listed site was in front and you were active.`}</p>
      </DashboardCard>
      <DashboardCard title="Most-used website">
        {o.mostUsed ? (<><p className="big small">{o.mostUsed.displayName}</p><p className="note">{o.mostUsed.domain} - {fmtSec(o.mostUsed.todaySeconds)} today</p></>)
          : <p className="note">No website has any time yet today.</p>}
      </DashboardCard>
      <DashboardCard title="Daily limit" tone="cream" badge="From Settings">
        <p className="big small">{fmtSec(o.dailyLimitSeconds)}</p>
        <p className="note">Each website is measured against this limit. Change it in Settings.</p>
      </DashboardCard>
    </div>
  );
}

function AddSite({ onAdded }) {
  const [domain, setDomain] = useState('');
  const [msg, setMsg] = useState({ text: '', error: false });
  const submit = async (e) => {
    e.preventDefault();
    try { await api('POST', '/api/websites', { domain: domain.trim() }); setDomain(''); setMsg({ text: 'Added.', error: false }); onAdded(); }
    catch (err) { setMsg({ text: err.message, error: true }); }
  };
  return (
    <form className="test-form" onSubmit={submit}>
      <label className="field">Add a website to track
        <input value={domain} onChange={(e) => { setDomain(e.target.value); setMsg({ text: '', error: false }); }} placeholder="example.com" maxLength={253} />
      </label>
      <button className="btn" type="submit" disabled={!domain.trim()}>Add website</button>
      <span role="status" className={msg.error ? 'msg-error' : ''}>{msg.text}</span>
    </form>
  );
}

function IdleSetting({ seconds, onSaved }) {
  const [val, setVal] = useState(seconds);
  const [msg, setMsg] = useState({ text: '', error: false });
  const ok = Number.isInteger(val) && val >= 10 && val <= 3600;
  const save = async () => {
    try { await api('PUT', '/api/settings', { idleThresholdSeconds: val }); setMsg({ text: 'Saved.', error: false }); onSaved(); }
    catch (err) { setMsg({ text: err.message, error: true }); }
  };
  return (
    <div className="test-form">
      <label className="field">Count me as idle after (seconds)
        <input type="number" min="10" max="3600" value={Number.isNaN(val) ? '' : val} aria-invalid={!ok} onChange={(e) => { setVal(e.target.valueAsNumber); setMsg({ text: '', error: false }); }} />
      </label>
      <button className="btn" onClick={save} disabled={!ok || val === seconds}>Save</button>
      <span role="status" className={msg.error ? 'msg-error' : ''}>{msg.text}</span>
      <p className="note">Uses the time since your last keyboard or mouse input, reported by Windows as a single number. Locking the screen or sleeping also stops counting. Default: 60.</p>
    </div>
  );
}

function Pairing() {
  const q = useApi('/api/websites/extension');
  const [show, setShow] = useState(false);
  const [msg, setMsg] = useState('');
  const d = q.data;
  const copy = async () => {
    try { await navigator.clipboard.writeText(d.pairingCode); setMsg('Copied. Paste it into the extension popup.'); }
    catch { setShow(true); setMsg('Could not copy automatically. Select the code and copy it.'); }
  };
  const rotate = async () => { try { await api('POST', '/api/websites/extension/rotate', {}); setShow(false); setMsg('New code created. The old one stopped working; pair the extension again.'); q.reload(); } catch (e) { setMsg(e.message); } };
  return (
    <DashboardCard title="Connect the browser extension" badge="Local only">
      <AsyncBoundary query={q}>
        {d && (
          <>
            <ol className="steps">
              <li>Chrome: open <b>chrome://extensions</b>, switch on <b>Developer mode</b>, choose <b>Load unpacked</b>, and select this app's <b>extension</b> folder. (Edge: <b>edge://extensions</b>.)</li>
              <li>Click the Lil Moon icon in the toolbar, paste the pairing code below, press <b>Connect</b>.</li>
            </ol>
            <p className="code" aria-label="Pairing code">{show ? d.pairingCode : '•'.repeat(24)}</p>
            <div className="site-actions">
              <button className="btn btn-small" onClick={() => setShow(!show)}>{show ? 'Hide' : 'Show'}</button>
              <button className="btn btn-small" onClick={copy}>Copy code</button>
              <button className="btn btn-small" onClick={rotate}>Make a new code</button>
            </div>
            {msg && <p className="note" role="status">{msg}</p>}
            {!d.probedPorts.includes(d.port) && <p className="msg-error" role="alert">Lil Moon is listening on port {d.port}, which the extension does not scan ({d.probedPorts[0]}-{d.probedPorts.at(-1)} are all taken by other programs). Close them and restart Lil Moon.</p>}
            <p className="note">The code only lets the extension send "which listed site is in front". It cannot read your data or change settings.</p>
          </>
        )}
      </AsyncBoundary>
    </DashboardCard>
  );
}

function Privacy({ onDeleted }) {
  const [confirming, setConfirming] = useState(false);
  const [msg, setMsg] = useState({ text: '', error: false });
  const wipe = async () => {
    try { const r = await api('DELETE', '/api/websites/history'); setConfirming(false); setMsg({ text: `Deleted ${r.deleted} website session(s).`, error: false }); onDeleted(); }
    catch (e) { setMsg({ text: e.message, error: true }); }
  };
  return (
    <DashboardCard title="What is tracked, and your data" tone="cream">
      <ul className="plain">
        <li><b>Tracked:</b> the domain of sites on your list (for example youtube.com) and how long it was in front while you were active.</li>
        <li><b>Never collected:</b> page contents, full addresses, search terms, passwords, form input, keystrokes, screenshots, or private-window activity.</li>
        <li><b>Stays here:</b> everything is stored in this app's local database and sent nowhere else, including to any AI service.</li>
        <li><b>You are in control:</b> pause from the extension popup, edit the list above, or delete the history below.</li>
      </ul>
      {!confirming ? (
        <button className="btn" onClick={() => { setConfirming(true); setMsg({ text: '', error: false }); }}>Delete website history</button>
      ) : (
        <div className="state state-error" role="alert">
          <p>Delete all saved website usage? Application usage is not touched. This cannot be undone.</p>
          <button className="btn" onClick={wipe}>Yes, delete it</button> <button className="btn" onClick={() => setConfirming(false)}>Cancel</button>
        </div>
      )}
      {msg.text && <p role="status" className={msg.error ? 'msg-error' : 'note'}>{msg.text}</p>}
    </DashboardCard>
  );
}

export default function WebsitesPage() {
  const overview = useApi('/api/websites/overview', { intervalMs: 5000 });
  const history = useApi('/api/usage/history?category=website&limit=20', { intervalMs: 15000 });
  const now = useClock();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const refresh = () => { overview.reload(); history.reload(); };
  const act = async (fn) => { setBusy(true); setError(''); try { await fn(); refresh(); } catch (e) { setError(e.message); } finally { setBusy(false); } };
  const toggle = (s) => act(() => api('PUT', `/api/websites/${s.id}`, { isEnabled: !s.isEnabled }));
  const remove = (s) => act(() => api('DELETE', `/api/websites/${s.id}`));
  const removeSession = (id) => act(() => api('DELETE', `/api/usage/sessions/${id}`));
  const o = overview.data;

  return (
    <>
      <div className="page-head">
        <h1>Website usage</h1>
        <span className="badge">Real data from your browser</span>
      </div>
      <p className="lead">Time on the sites you listed, counted while the browser is in front, the tab is active, and you are not idle. Nothing here is sample data.</p>

      <AsyncBoundary query={overview}>
        {o && (
          <>
            <StatusCard o={o} query={overview} now={now} />
            <h2 className="section-title">Today</h2>
            <Totals o={o} />

            <h2 className="section-title">Your websites</h2>
            {error && <p className="msg-error" role="alert">{error}</p>}
            {o.sites.length === 0 ? (
              <div className="state">No websites on your list yet. Add one below and it will be counted once the extension is connected.</div>
            ) : (
              <>
                {o.totalSeconds === 0 && <p className="note">Nothing has been recorded today yet, so every bar is empty.</p>}
                <ul className="usage-list">
                  {o.sites.map((s) => <SiteCard key={s.domain} site={s} limitSeconds={o.dailyLimitSeconds} busy={busy} onToggle={toggle} onRemove={remove} />)}
                </ul>
              </>
            )}
            <DashboardCard title="Edit the list" tone="cream"><AddSite onAdded={refresh} /></DashboardCard>
          </>
        )}
      </AsyncBoundary>

      <h2 className="section-title">Set up</h2>
      <div className="grid">
        <Pairing />
        {o && <DashboardCard title="Idle detection" tone="purple" badge="Saved in database"><IdleSetting key={o.idleThresholdSeconds} seconds={o.idleThresholdSeconds} onSaved={refresh} /></DashboardCard>}
        <Privacy onDeleted={refresh} />
      </div>

      <h2 className="section-title">Recent sessions</h2>
      <AsyncBoundary query={history} isEmpty={history.data?.total === 0} empty="No website sessions saved yet.">
        {history.data && (
          <>
            <HistoryList records={history.data.records} onDelete={removeSession} />
            {history.data.total > history.data.records.length && <p className="note">Showing the latest {history.data.records.length} of {history.data.total}. A session is one uninterrupted stretch on one site.</p>}
          </>
        )}
      </AsyncBoundary>
    </>
  );
}
