// Phase 6: limits engine, restriction events, extensions, website enforcement list, API validation, migration.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { openDatabase, createRepository, localDate, MIGRATIONS } = require('../backend/database');
const { startServer } = require('../backend/server');
const { createTracker } = require('../backend/websiteTracker');
const { createLimitEngine } = require('../backend/limits');

const NOON = new Date(2026, 9, 31, 12, 0, 0).getTime();
const DASH = 'dash-token';
const EXT_ORIGIN = 'chrome-extension://abcdefghijklmnopabcdefghijklmnop';
const MIN = 60;

function rig({ db = openDatabase(':memory:'), start = NOON } = {}) {
  const clock = { t: start };
  const repo = createRepository(db);
  const notes = [];
  const tracker = createTracker({ repo, now: () => clock.t });
  const engine = createLimitEngine({ repo, tracker, now: () => clock.t, notify: (a) => notes.push(a.type) });
  let n = 0;
  const addUsage = (category, name, seconds) => { // a stored usage record ending "now"
    const startedAt = new Date(clock.t - seconds * 1000 - (n++) * 7).toISOString();
    repo.insertSession({ category, itemName: name, startedAt, endedAt: new Date(clock.t).toISOString(), durationSeconds: seconds });
  };
  const events = (type) => repo.listEvents({ limit: 200, offset: 0 }).records.filter((e) => !type || e.eventType === type);
  const site = (target, o = {}) => engine.create({ targetType: 'website', target, dailyLimitSeconds: 10 * MIN, mode: 'warn', warningPercent: 80, extensionMinutes: 5, isEnabled: true, ...o });
  const app = (target, o = {}) => engine.create({ targetType: 'application', target, dailyLimitSeconds: 10 * MIN, mode: 'warn', warningPercent: 80, extensionMinutes: 5, isEnabled: true, ...o });
  return { db, repo, clock, notes, tracker, engine, addUsage, events, site, app };
}

test('1/2/4. create application and website limits; duplicates, untracked sites and bad modes are rejected; edit, disable, enable, delete', () => {
  const r = rig();
  const a = r.app('Notepad'); const w = r.site('youtube.com');
  assert.deepEqual([a.targetType, w.targetType, w.isEnabled], ['application', 'website', true]);
  assert.throws(() => r.app('notepad'), { code: 'duplicate', status: 409 });                    // case-insensitive duplicate
  assert.throws(() => r.site('youtube.com'), { code: 'duplicate' });
  assert.throws(() => r.site('not-listed.example'), { code: 'not_tracked' });
  assert.throws(() => r.app('Game', { mode: 'enforce' }), { code: 'unsupported_mode' });         // no safe application blocking yet
  assert.throws(() => r.engine.update(a.id, { mode: 'enforce' }), { code: 'unsupported_mode' });
  assert.equal(r.engine.update(w.id, { dailyLimitSeconds: 1800, mode: 'confirm' }).dailyLimitSeconds, 1800);
  assert.equal(r.engine.update(w.id, { isEnabled: false }).isEnabled, false);
  assert.equal(r.engine.snapshot().items.find((i) => i.id === w.id).status, 'off');
  assert.equal(r.engine.update(w.id, { isEnabled: true }).isEnabled, true);
  assert.deepEqual(r.events().filter((e) => e.limitId === w.id).map((e) => e.eventType).reverse(), ['limit_enabled', 'limit_disabled', 'limit_enabled']);
  r.engine.remove(w.id);
  assert.equal(r.repo.getLimit(w.id), null);
  assert.ok(r.events('limit_deleted').length === 1, 'history outlives the limit');
  assert.deepEqual(r.notes.filter((n) => n === 'enabled' || n === 'disabled'), ['enabled', 'enabled', 'disabled', 'enabled']);
});

test('5/6. the 80% warning and the 100% notice each fire once, however often we evaluate', () => {
  const r = rig(); r.site('youtube.com');
  r.addUsage('website', 'youtube.com', 7 * MIN); r.engine.tick();
  assert.deepEqual(r.notes.filter((n) => n === 'warning' || n === 'reached'), []);               // 70%
  r.addUsage('website', 'youtube.com', 1 * MIN);                                                 // 80%
  for (let i = 0; i < 5; i++) r.engine.tick();
  assert.deepEqual(r.notes.filter((n) => n === 'warning'), ['warning']);
  r.addUsage('website', 'youtube.com', 2 * MIN);                                                 // 100%
  for (let i = 0; i < 5; i++) r.engine.tick();
  assert.deepEqual(r.notes.filter((n) => n === 'reached'), ['reached']);
  assert.equal(r.events('limit_warning').length, 1); assert.equal(r.events('limit_reached').length, 1);
  const it = r.engine.snapshot().items[0];
  assert.deepEqual([it.status, it.remainingSeconds, it.percent], ['reached', 0, 100]);
});

test('jumping straight past 80% sends only the limit-reached notice', () => {
  const r = rig(); r.app('Notepad');
  r.addUsage('application', 'Notepad', 11 * MIN); r.engine.tick(); r.engine.tick();
  assert.deepEqual(r.notes.filter((n) => n !== 'enabled'), ['reached']);
  assert.equal(r.events('limit_warning').length, 0);
});

test('custom warning threshold and case-insensitive application matching', () => {
  const r = rig(); r.app('Notepad', { warningPercent: 50 });
  r.addUsage('application', 'NOTEPAD', 5 * MIN); r.engine.tick();
  assert.equal(r.engine.snapshot().items[0].usedSeconds, 5 * MIN);
  assert.ok(r.notes.includes('warning'));
});

test('7. warning-only never blocks and cannot be "extended"', () => {
  const r = rig(); const w = r.site('youtube.com', { mode: 'warn' });
  r.addUsage('website', 'youtube.com', 20 * MIN); r.engine.tick();
  assert.deepEqual(r.engine.blockedWebsites().items, []);
  assert.throws(() => r.engine.grantExtension(w.id, 5), { code: 'warn_only' });
  assert.equal(r.events('blocked').length, 0);
});

test('8/9. confirmation mode records the decision; approved extra time is measured in usage and ends exactly once per extension', () => {
  const r = rig(); const w = r.site('youtube.com', { mode: 'confirm', extensionMinutes: 5 });
  assert.throws(() => r.engine.grantExtension(w.id, 5), { code: 'not_reached' });                // cannot pre-approve silently
  r.addUsage('website', 'youtube.com', 10 * MIN); r.engine.tick();
  assert.equal(r.engine.snapshot().items[0].needsDecision, true);
  const ok = r.engine.grantExtension(w.id, 5, 'dialog');
  assert.equal(ok.snapshot.status, 'extended'); assert.equal(ok.snapshot.allowanceSeconds, 15 * MIN);
  const ev = r.events('extension_granted')[0];
  assert.deepEqual([ev.extraSeconds, ev.detail, ev.limitId], [300, 'source: dialog', w.id]);
  r.addUsage('website', 'youtube.com', 3 * MIN); r.engine.tick();
  assert.equal(r.engine.snapshot().items[0].status, 'extended');
  r.addUsage('website', 'youtube.com', 2 * MIN); r.engine.tick(); r.engine.tick();                // 15 of 15
  assert.equal(r.engine.snapshot().items[0].status, 'reached');
  assert.equal(r.events('extension_ended').length, 1);
  assert.deepEqual(r.notes.filter((n) => n === 'extension_ended'), ['extension_ended']);
  r.engine.grantExtension(w.id, 10); r.addUsage('website', 'youtube.com', 10 * MIN); r.engine.tick();
  assert.equal(r.events('extension_ended').length, 2);                                           // a second cycle, a second notice
  assert.equal(r.engine.snapshot().items[0].allowanceSeconds, 25 * MIN);
});

test('8b. declining is recorded once and stops the pending prompt', () => {
  const r = rig(); const w = r.site('youtube.com', { mode: 'confirm' });
  r.addUsage('website', 'youtube.com', 10 * MIN); r.engine.tick();
  assert.equal(r.engine.declineExtension(w.id, 'dialog').recorded, true);
  assert.equal(r.engine.declineExtension(w.id, 'dialog').recorded, false);
  assert.equal(r.events('extension_declined').length, 1);
  assert.equal(r.engine.snapshot().items[0].needsDecision, false);
  assert.equal(r.engine.snapshot().items[0].allowanceSeconds, 10 * MIN);                         // nothing was extended
});

test('10. enforcement lists only the configured, reached, enabled website; override and disable lift it; master switch lifts all', () => {
  const r = rig(); const yt = r.site('youtube.com', { mode: 'enforce', extensionMinutes: 5 }); r.site('reddit.com', { mode: 'enforce' }); r.site('github.com', { mode: 'confirm' });
  r.addUsage('website', 'youtube.com', 10 * MIN); r.addUsage('website', 'github.com', 30 * MIN); r.addUsage('website', 'reddit.com', 2 * MIN);
  r.engine.tick();
  const blocked = () => r.engine.blockedWebsites().items.map((i) => i.domain);
  assert.deepEqual(blocked(), ['youtube.com']);                                                  // reddit under limit, github is not enforced
  assert.equal(r.engine.recordBlocked('youtube.com').recorded, true);
  assert.equal(r.engine.recordBlocked('youtube.com').recorded, false);                           // one event per cycle
  assert.equal(r.engine.recordBlocked('reddit.com').recorded, false);
  assert.equal(r.events('blocked').length, 1);
  r.engine.overrideDomain('youtube.com');
  assert.deepEqual(blocked(), []);
  assert.equal(r.events('override')[0].extraSeconds, 300);
  r.addUsage('website', 'youtube.com', 5 * MIN); r.engine.tick();
  assert.deepEqual(blocked(), ['youtube.com']);                                                  // extra time used up: blocked again
  assert.equal(r.engine.recordBlocked('youtube.com').recorded, true);                            // new cycle, new event
  r.engine.setMaster(false); assert.deepEqual(blocked(), []);
  r.engine.setMaster(true); assert.deepEqual(blocked(), ['youtube.com']);
  r.engine.disableDomain('youtube.com'); assert.deepEqual(blocked(), []);
  assert.ok(r.events('restrictions_off').length === 1 && r.events('restrictions_on').length === 1);
  assert.ok(r.engine.blockedWebsites().validUntil > new Date(r.clock.t).toISOString());
  assert.equal(r.engine.limitForDomain('youtube.com').isEnabled, false);
  void yt;
});

test('master switch off: no notifications, no events, usage still recorded', () => {
  const r = rig(); r.site('youtube.com'); r.engine.setMaster(false);
  r.addUsage('website', 'youtube.com', 30 * MIN); r.engine.tick();
  assert.deepEqual(r.notes.filter((n) => n === 'warning' || n === 'reached'), []);
  assert.equal(r.engine.snapshot().items[0].usedSeconds, 30 * MIN);
});

test('15. a new local day resets warning state but never deletes usage history', () => {
  const r = rig(); r.site('youtube.com');
  r.addUsage('website', 'youtube.com', 10 * MIN); r.engine.tick();
  assert.equal(r.events('limit_reached').length, 1);
  r.clock.t += 24 * 3600 * 1000;                                                                  // tomorrow
  const s = r.engine.snapshot();
  assert.equal(s.items[0].usedSeconds, 0); assert.equal(s.items[0].status, 'ok');
  assert.equal(r.repo.usageHistory({ limit: 50, offset: 0, category: 'website' }).total, 1);       // yesterday's record is intact
  r.addUsage('website', 'youtube.com', 9 * MIN); r.engine.tick();
  assert.equal(r.events('limit_warning').length, 1);                                              // the warning can fire again today
  r.addUsage('website', 'youtube.com', 1 * MIN); r.engine.tick();
  assert.equal(r.events('limit_reached').length, 2);
});

test('an extension approved yesterday does not carry into today', () => {
  const r = rig(); const w = r.site('youtube.com', { mode: 'confirm' });
  r.addUsage('website', 'youtube.com', 10 * MIN); r.engine.tick(); r.engine.grantExtension(w.id, 15);
  r.clock.t += 24 * 3600 * 1000;
  assert.equal(r.engine.snapshot().items[0].allowanceSeconds, 10 * MIN);
});

test('14. restart: a fresh engine on the same database does not repeat notifications', () => {
  const db = openDatabase(':memory:');
  let r = rig({ db }); r.site('youtube.com'); r.addUsage('website', 'youtube.com', 8 * MIN); r.engine.tick();
  assert.equal(r.events().filter((e) => e.eventType === 'limit_warning').length, 1);
  const again = rig({ db });                                                                      // "app restarted"
  again.engine.tick(); again.engine.tick();
  assert.equal(again.notes.filter((n) => n === 'warning').length, 0);
  assert.equal(again.events('limit_warning').length, 1);
});

test('concurrent evaluators (two engines, same database) produce exactly one event', () => {
  const db = openDatabase(':memory:');
  const a = rig({ db }); a.site('youtube.com'); a.addUsage('website', 'youtube.com', 10 * MIN);
  const b = rig({ db });
  const first = a.engine.tick(); const second = b.engine.tick();
  assert.equal(first.length + second.length, 1);
  assert.equal(a.events('limit_reached').length, 1);
});

test('editing the limit re-arms today\'s alerts', () => {
  const r = rig(); const w = r.site('youtube.com');
  r.addUsage('website', 'youtube.com', 8 * MIN); r.engine.tick();
  r.engine.update(w.id, { dailyLimitSeconds: 8 * MIN }); r.engine.tick();                         // now at 100%
  assert.equal(r.events('limit_reached').length, 1);
});

test('website usage from the live tracker counts toward limits (no guessed time)', () => {
  const r = rig(); r.site('youtube.com', { dailyLimitSeconds: 2 * MIN });
  const send = (domain, seq, kind = 'change') => r.tracker.onBrowser({ installId: 'install-limit-1', seq, kind, domain, paused: false, at: new Date(r.clock.t).toISOString() });
  send('youtube.com', 0); r.clock.t += 60000; send('youtube.com', 1, 'heartbeat');
  assert.equal(r.engine.snapshot().items[0].usedSeconds, 60);
  send(null, 2); r.clock.t += 600000; send(null, 3, 'heartbeat');                                  // another tab / app in front for 10 min
  assert.equal(r.engine.snapshot().items[0].usedSeconds, 60);                                      // background time never counts
  send('youtube.com', 4); r.clock.t += 60000; send('youtube.com', 5, 'heartbeat'); r.engine.tick();
  assert.equal(r.engine.snapshot().items[0].status, 'reached');
});

// ---------------- HTTP API ----------------
async function web() {
  const db = openDatabase(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lm-lim-')), 'lil-moon.db'));
  const r = rig({ db });
  const api = await startServer({ repo: r.repo, allowedOrigins: ['null'], token: DASH, tracker: r.tracker, limits: r.engine, now: () => r.clock.t });
  const call = async (method, p, body, { token = DASH, origin = 'null' } = {}) => {
    const res = await fetch(api.baseUrl + p, { method, headers: { Authorization: `Bearer ${token}`, Origin: origin, ...(body !== undefined && { 'Content-Type': 'application/json' }) }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, json: await res.json().catch(() => null) };
  };
  const ext = (method, p, body) => call(method, p, body, { token: r.repo.getExtensionToken(), origin: EXT_ORIGIN });
  return { ...r, api, call, ext, stop: async () => { await api.close(); db.close(); } };
}

test('16. invalid input is rejected with friendly 400/404/409 and changes nothing', async () => {
  const t = await web();
  const good = { targetType: 'website', target: 'youtube.com', dailyLimitSeconds: 3600, mode: 'warn' };
  const bad = [
    { ...good, dailyLimitSeconds: 0 }, { ...good, dailyLimitSeconds: -5 }, { ...good, dailyLimitSeconds: 59 }, { ...good, dailyLimitSeconds: 86401 },
    { ...good, dailyLimitSeconds: 60.5 }, { ...good, dailyLimitSeconds: '3600' }, { ...good, dailyLimitSeconds: null }, { ...good, dailyLimitSeconds: 1e12 },
    { ...good, mode: 'kill' }, { ...good, mode: undefined }, { ...good, warningPercent: 0 }, { ...good, warningPercent: 100 }, { ...good, extensionMinutes: 0 }, { ...good, extensionMinutes: 121 },
    { ...good, isEnabled: 'yes' }, { ...good, targetType: 'process' }, { ...good, target: '' }, { ...good, target: 'https://youtube.com/x' }, { ...good, target: 5 },
    { ...good, extra: 1 }, { targetType: 'website', mode: 'warn', dailyLimitSeconds: 3600 }, { ...good, dailyLimitSeconds: undefined },
    { targetType: 'application', target: 'x'.repeat(201), dailyLimitSeconds: 3600, mode: 'warn' }, { targetType: 'application', target: 'bad\u0000name', dailyLimitSeconds: 3600, mode: 'warn' },
  ];
  for (const b of bad) { const r = await t.call('POST', '/api/limits', b); assert.equal(r.status, 400, JSON.stringify(b)); assert.equal(r.json.ok, false); assert.ok(r.json.error.message.length > 10); }
  assert.equal((await t.call('POST', '/api/limits', { ...good, target: 'unknown.example' })).json.error.code, 'not_tracked');
  assert.equal((await t.call('POST', '/api/limits', { targetType: 'application', target: 'Game', dailyLimitSeconds: 3600, mode: 'enforce' })).json.error.code, 'unsupported_mode');
  assert.equal(t.repo.listLimits().length, 0);
  assert.equal((await t.call('PUT', '/api/limits/99', { mode: 'warn' })).status, 404);
  assert.equal((await t.call('PUT', '/api/limits/abc', { mode: 'warn' })).status, 400);
  assert.equal((await t.call('DELETE', '/api/limits/99')).status, 404);
  assert.equal((await t.call('GET', '/api/limits/events?limit=0')).status, 400);
  assert.equal((await t.call('GET', '/api/limits/targets?type=nope')).status, 400);
  assert.equal((await t.call('PUT', '/api/limits/master', { enabled: 'off' })).status, 400);
  assert.equal((await t.call('POST', '/api/limits/1/extensions', { minutes: 500 })).status, 400);
  await t.stop();
});

test('1-4/13. API: create, list with live usage and remaining time, edit, toggle, summary, events, delete; app usage included', async () => {
  const t = await web();
  let r = await t.call('POST', '/api/limits', { targetType: 'website', target: 'WWW.YouTube.com', dailyLimitSeconds: 600, mode: 'confirm', extensionMinutes: 5 });
  assert.equal(r.status, 201); assert.equal(r.json.data.target, 'youtube.com');
  assert.equal((await t.call('POST', '/api/limits', { targetType: 'website', target: 'youtube.com', dailyLimitSeconds: 600, mode: 'warn' })).status, 409);
  const app = (await t.call('POST', '/api/limits', { targetType: 'application', target: 'Notepad', dailyLimitSeconds: 1200, mode: 'warn' })).json.data;
  t.addUsage('website', 'youtube.com', 480); t.addUsage('application', 'notepad', 300);
  const list = (await t.call('GET', '/api/limits')).json.data;
  const yt = list.items.find((i) => i.target === 'youtube.com');
  assert.deepEqual([yt.usedSeconds, yt.remainingSeconds, yt.status, yt.mode, yt.dailyLimitSeconds], [480, 120, 'warning', 'confirm', 600]);
  const sum = (await t.call('GET', '/api/limits/summary')).json.data;
  assert.deepEqual([sum.activeLimits, sum.websiteSeconds, sum.applicationSeconds], [2, 480, 300]);
  assert.equal((await t.call('PUT', `/api/limits/${app.id}`, { isEnabled: false })).json.data.isEnabled, false);
  assert.equal((await t.call('GET', '/api/limits/summary')).json.data.activeLimits, 1);
  const tg = (await t.call('GET', '/api/limits/targets?type=application')).json.data;
  assert.deepEqual(tg.map((x) => x.name), ['notepad']);                                           // only names that were really tracked
  assert.ok((await t.call('GET', '/api/limits/targets?type=website')).json.data.some((x) => x.name === 'youtube.com'));
  t.addUsage('website', 'youtube.com', 120);
  assert.equal((await t.call('GET', '/api/limits')).json.data.items.find((i) => i.target === 'youtube.com').needsDecision, true);
  assert.equal((await t.call('POST', `/api/limits/${yt.id}/extensions`, { minutes: 10 })).status, 201);
  const ev = (await t.call('GET', `/api/limits/events?limitId=${yt.id}&limit=2`)).json.data;
  assert.equal(ev.limit, 2); assert.ok(ev.total >= 3); assert.equal(ev.records[0].eventType, 'extension_granted');
  assert.equal((await t.call('DELETE', `/api/limits/${app.id}`)).status, 200);
  assert.equal((await t.call('GET', '/api/limits')).json.data.items.length, 1);
  await t.stop();
});

test('10b. extension surface: block list in config and activity replies, override, disable, blocked report; only tracked domains; no CRUD with the pairing code', async () => {
  const t = await web();
  await t.call('POST', '/api/limits', { targetType: 'website', target: 'youtube.com', dailyLimitSeconds: 600, mode: 'enforce', extensionMinutes: 5 });
  await t.call('POST', '/api/limits', { targetType: 'website', target: 'github.com', dailyLimitSeconds: 600, mode: 'warn' });
  t.addUsage('website', 'youtube.com', 600); t.addUsage('website', 'github.com', 900);
  const cfg = (await t.ext('GET', '/ext/config')).json.data;
  assert.deepEqual(cfg.restrictions.items.map((i) => i.domain), ['youtube.com']);
  assert.ok(cfg.restrictions.validUntil);
  const act = await t.ext('POST', '/ext/activity', { installId: 'install-api-0001', seq: 0, kind: 'heartbeat', domain: null, paused: false, at: new Date(t.clock.t).toISOString() });
  assert.deepEqual(act.json.data.restrictions.items.map((i) => i.domain), ['youtube.com']);
  assert.equal((await t.ext('POST', '/ext/limits/blocked', { domain: 'youtube.com' })).json.data.recorded, true);
  assert.equal((await t.ext('POST', '/ext/limits/blocked', { domain: 'github.com' })).json.data.recorded, false);   // not enforced: nothing to report
  assert.equal((await t.ext('POST', '/ext/limits/blocked', { domain: 'evil.example' })).status, 400);               // not a tracked domain
  assert.equal((await t.ext('POST', '/ext/limits/override', { domain: 'github.com' })).status, 404);                // warn-only: no override exists
  const ov = await t.ext('POST', '/ext/limits/override', { domain: 'youtube.com' });
  assert.deepEqual([ov.status, ov.json.data.minutes, ov.json.data.restrictions.items.length], [200, 5, 0]);
  t.addUsage('website', 'youtube.com', 300); t.engine.tick();
  assert.equal((await t.ext('GET', '/ext/config')).json.data.restrictions.items.length, 1);
  const off = await t.ext('POST', '/ext/limits/disable', { domain: 'youtube.com' });
  assert.equal(off.json.data.restrictions.items.length, 0);
  assert.equal((await t.call('GET', '/api/limits')).json.data.items.find((i) => i.target === 'youtube.com').isEnabled, false);
  assert.equal((await t.ext('GET', '/api/limits')).status, 403);                                                    // extension origin cannot use /api at all
  assert.equal((await t.call('GET', '/api/limits', undefined, { token: t.repo.getExtensionToken() })).status, 401); // pairing code is not a dashboard token
  assert.equal((await t.ext('POST', '/ext/limits', { targetType: 'website' })).status, 404);                        // no create route for the extension
  await t.stop();
});

test('master switch API and events', async () => {
  const t = await web();
  assert.equal((await t.call('PUT', '/api/limits/master', { enabled: false })).json.data.enabled, false);
  assert.equal((await t.call('GET', '/api/limits')).json.data.restrictionsEnabled, false);
  assert.equal((await t.call('PUT', '/api/limits/master', { enabled: true })).json.data.enabled, true);
  assert.deepEqual((await t.call('GET', '/api/limits/events')).json.data.records.map((e) => e.eventType), ['restrictions_on', 'restrictions_off']);
  await t.stop();
});

test('migration v2 -> v3 keeps usage history and existing restriction events', () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lm-mig-')), 'old.db');
  const old = new DatabaseSync(file);
  for (let i = 0; i < 2; i++) { old.exec('BEGIN'); old.exec(MIGRATIONS[i]); old.exec(`PRAGMA user_version = ${i + 1}`); old.exec('COMMIT'); }
  old.exec("INSERT INTO user_settings (id, daily_limit_seconds, theme, created_at, updated_at) VALUES (1, 7200, 'lilac', 'a', 'b')");
  old.exec("INSERT INTO usage_sessions (category, item_name, started_at, ended_at, duration_seconds, session_date) VALUES ('application','Notepad','2026-10-30T10:00:00.000Z','2026-10-30T10:10:00.000Z',600,'2026-10-30')");
  old.exec("INSERT INTO restriction_events (category, item_name, event_type, created_at) VALUES ('website','youtube.com','limit_warning','2026-10-30T11:00:00.000Z')");
  old.close();
  const db = openDatabase(file); const repo = createRepository(db);
  assert.equal(repo.schemaVersion(), 4);
  assert.equal(repo.usageHistory({ limit: 10, offset: 0 }).total, 1);
  assert.equal(repo.getSettings().dailyLimitSeconds, 7200);
  const ev = repo.listEvents({ limit: 10, offset: 0 }).records;
  assert.deepEqual([ev.length, ev[0].eventType, ev[0].limitId], [1, 'limit_warning', null]);
  assert.equal(repo.restrictionsEnabled(), true);
  assert.ok(db.prepare("SELECT name FROM sqlite_master WHERE name IN ('idx_restriction_created','idx_restriction_item','idx_restriction_limit','idx_limits_enabled','idx_extensions_limit_date')").all().length === 5);
  db.close();
});
