const { THEMES } = require('./database');
const Domain = require('../extension/lib/domain.js');

class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}
const bad = (msg) => new HttpError(400, 'validation_error', msg);
const CATEGORIES = ['application', 'website'];
const ISO_UTC = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,3})?Z$/;

function onlyFields(body, allowed) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw bad('Request body must be a JSON object.');
  for (const k of Object.keys(body)) if (!allowed.includes(k)) throw bad(`Unknown field: ${k}`);
}

function realDate(v, name) {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) throw bad(`${name} must be a date like 2026-10-25.`);
  const d = new Date(`${v}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v) throw bad(`${name} is not a real calendar date.`);
  return v;
}

function int(v, name, min, max, fallback) {
  if (v === undefined) return fallback;
  if (typeof v !== 'string' || !/^\d{1,9}$/.test(v) || Number(v) < min || Number(v) > max) throw bad(`${name} must be a whole number from ${min} to ${max}.`);
  return Number(v);
}

function category(v, name = 'category') {
  if (v === undefined) return undefined;
  if (!CATEGORIES.includes(v)) throw bad(`${name} must be "application" or "website".`);
  return v;
}

function timestamp(v, name) {
  if (typeof v !== 'string' || !ISO_UTC.test(v)) throw bad(`${name} must be a UTC ISO-8601 timestamp like 2026-10-25T14:03:09.000Z.`);
  const d = new Date(v);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v.slice(0, 10)) throw bad(`${name} is not a real date and time.`);
  if (d.getUTCFullYear() < 2000) throw bad(`${name} is too far in the past.`);
  return d;
}

const settingsPatch = (body) => {
  onlyFields(body, ['dailyLimitSeconds', 'theme', 'idleThresholdSeconds']);
  const out = {};
  if ('dailyLimitSeconds' in body) {
    const n = body.dailyLimitSeconds;
    if (!Number.isInteger(n) || n < 300 || n > 86400) throw bad('dailyLimitSeconds must be a whole number from 300 to 86400.');
    out.dailyLimitSeconds = n;
  }
  if ('theme' in body) {
    if (!THEMES.includes(body.theme)) throw bad(`theme must be one of: ${THEMES.join(', ')}.`);
    out.theme = body.theme;
  }
  if ('idleThresholdSeconds' in body) {
    const n = body.idleThresholdSeconds;
    if (!Number.isInteger(n) || n < 10 || n > 3600) throw bad('idleThresholdSeconds must be a whole number from 10 to 3600.');
    out.idleThresholdSeconds = n;
  }
  if (!Object.keys(out).length) throw bad('Provide dailyLimitSeconds, theme, idleThresholdSeconds, or a combination.');
  return out;
};

const sessionBody = (body) => {
  onlyFields(body, ['category', 'itemName', 'startedAt', 'endedAt']);
  if (!CATEGORIES.includes(body.category)) throw bad('category must be "application" or "website".');
  const name = typeof body.itemName === 'string' ? body.itemName.trim() : '';
  if (!name || name.length > 200 || /[\u0000-\u001f\u007f]/.test(name)) throw bad('itemName must be 1 to 200 printable characters.');
  const start = timestamp(body.startedAt, 'startedAt');
  const end = timestamp(body.endedAt, 'endedAt');
  if (start.getTime() > Date.now() + 5 * 60 * 1000) throw bad('startedAt cannot be in the future.');
  if (end < start) throw bad('endedAt must not be before startedAt.');
  const durationSeconds = Math.round((end - start) / 1000);
  if (durationSeconds > 86400) throw bad('A session cannot be longer than 24 hours.');
  return { category: body.category, itemName: name, startedAt: start.toISOString(), endedAt: end.toISOString(), durationSeconds };
};

const historyQuery = (q) => {
  const from = q.from === undefined ? undefined : realDate(q.from, 'from');
  const to = q.to === undefined ? undefined : realDate(q.to, 'to');
  if (from && to && from > to) throw bad('from must not be after to.');
  return { from, to, category: category(q.category), limit: int(q.limit, 'limit', 1, 200, 50), offset: int(q.offset, 'offset', 0, 1000000, 0) };
};

const recordId = (v) => {
  if (!/^[1-9]\d{0,9}$/.test(v)) throw bad('id must be a positive whole number.');
  return Number(v);
};

// ---- Phase 5: websites and extension traffic ----
const domainText = (v, name) => {
  const h = typeof v === 'string' ? Domain.normalizeHost(v.trim().toLowerCase()) : null;
  if (!h) throw bad(`${name} must be a plain domain such as example.com (no https://, path or port).`);
  return h;
};
const prettyName = (domain) => { const l = domain.split('.')[0]; return l.charAt(0).toUpperCase() + l.slice(1); };
const cleanName = (v) => {
  const n = typeof v === 'string' ? v.trim() : '';
  if (!n || n.length > 200 || /[\u0000-\u001f\u007f]/.test(n)) throw bad('displayName must be 1 to 200 printable characters.');
  return n;
};

const websiteBody = (body) => {
  onlyFields(body, ['domain', 'displayName']);
  const domain = domainText(body.domain, 'domain');
  return { domain, displayName: body.displayName === undefined ? prettyName(domain) : cleanName(body.displayName) };
};

const websitePatch = (body) => {
  onlyFields(body, ['isEnabled', 'displayName']);
  const out = {};
  if ('isEnabled' in body) { if (typeof body.isEnabled !== 'boolean') throw bad('isEnabled must be true or false.'); out.isEnabled = body.isEnabled; }
  if ('displayName' in body) out.displayName = cleanName(body.displayName);
  if (!Object.keys(out).length) throw bad('Provide isEnabled, displayName, or both.');
  return out;
};

const aliasBody = (body) => {
  onlyFields(body, ['alias', 'canonical']);
  const alias = domainText(body.alias, 'alias'), canonical = domainText(body.canonical, 'canonical');
  if (alias === canonical) throw bad('alias and canonical must differ.');
  return { alias, canonical };
};

const aliasParam = (v) => domainText(v, 'alias');

// What the browser extension may send. Anything else is rejected; no URLs, titles or paths are accepted.
const extActivity = (body) => {
  onlyFields(body, ['installId', 'seq', 'kind', 'domain', 'paused', 'at', 'browser']);
  if (typeof body.installId !== 'string' || !/^[A-Za-z0-9-]{8,64}$/.test(body.installId)) throw bad('installId must be 8 to 64 letters, digits or hyphens.');
  if (!Number.isSafeInteger(body.seq) || body.seq < 0) throw bad('seq must be a non-negative whole number.');
  if (!['change', 'heartbeat'].includes(body.kind)) throw bad('kind must be "change" or "heartbeat".');
  if (typeof body.paused !== 'boolean') throw bad('paused must be true or false.');
  if (body.domain !== null && !Domain.isHostname(body.domain)) throw bad('domain must be a hostname or null.');
  const at = timestamp(body.at, 'at');
  const browser = body.browser === undefined ? undefined : body.browser;
  if (browser !== undefined && !['chrome', 'edge', 'other'].includes(browser)) throw bad('browser must be chrome, edge or other.');
  return { installId: body.installId, seq: body.seq, kind: body.kind, domain: body.domain, paused: body.paused, at: at.toISOString(), browser };
};

// ---- Phase 6: usage limits ----
const MODES = ['warn', 'confirm', 'enforce'];
const wholeNumber = (v, name, min, max, hint) => {
  if (!Number.isInteger(v) || v < min || v > max) throw bad(`${name} must be a whole number from ${min} to ${max}${hint ? ` ${hint}` : ''}.`);
  return v;
};
const limitTarget = (type, v) => {
  if (type === 'website') return domainText(v, 'target');
  const t = typeof v === 'string' ? v.trim() : '';
  if (!t || t.length > 200 || /[\u0000-\u001f\u007f]/.test(t)) throw bad('target must be an application name of 1 to 200 printable characters.');
  return t;
};
const limitFields = (body, out) => {
  if ('dailyLimitSeconds' in body) out.dailyLimitSeconds = wholeNumber(body.dailyLimitSeconds, 'dailyLimitSeconds', 60, 86400, '(1 minute to 24 hours)');
  if ('mode' in body) { if (!MODES.includes(body.mode)) throw bad(`mode must be one of: ${MODES.join(', ')}.`); out.mode = body.mode; }
  if ('warningPercent' in body) out.warningPercent = wholeNumber(body.warningPercent, 'warningPercent', 1, 99);
  if ('extensionMinutes' in body) out.extensionMinutes = wholeNumber(body.extensionMinutes, 'extensionMinutes', 1, 120);
  if ('isEnabled' in body) { if (typeof body.isEnabled !== 'boolean') throw bad('isEnabled must be true or false.'); out.isEnabled = body.isEnabled; }
  return out;
};
const limitBody = (body) => {
  onlyFields(body, ['targetType', 'target', 'dailyLimitSeconds', 'mode', 'warningPercent', 'extensionMinutes', 'isEnabled']);
  if (!CATEGORIES.includes(body.targetType)) throw bad('targetType must be "application" or "website".');
  if (!('dailyLimitSeconds' in body)) throw bad('dailyLimitSeconds is required.');
  if (!('mode' in body)) throw bad('mode is required.');
  const out = limitFields(body, {});
  return { targetType: body.targetType, target: limitTarget(body.targetType, body.target), warningPercent: 80, extensionMinutes: 10, isEnabled: true, ...out };
};
const limitPatch = (body) => {
  onlyFields(body, ['dailyLimitSeconds', 'mode', 'warningPercent', 'extensionMinutes', 'isEnabled']);
  const out = limitFields(body, {});
  if (!Object.keys(out).length) throw bad('Nothing to change.');
  return out;
};
const extensionBody = (body) => { onlyFields(body, ['minutes']); return { minutes: wholeNumber(body.minutes, 'minutes', 1, 120) }; };
const masterBody = (body) => { onlyFields(body, ['enabled']); if (typeof body.enabled !== 'boolean') throw bad('enabled must be true or false.'); return { enabled: body.enabled }; };
const eventsQuery = (q) => ({ limit: int(q.limit, 'limit', 1, 200, 50), offset: int(q.offset, 'offset', 0, 1000000, 0), limitId: q.limitId === undefined ? undefined : recordId(q.limitId) });
const targetsQuery = (q) => { if (!CATEGORIES.includes(q.type)) throw bad('type must be "application" or "website".'); return q.type; };
const extDomain = (body) => { onlyFields(body, ['domain']); if (!Domain.isHostname(body.domain)) throw bad('domain must be a hostname.'); return body.domain; };

// ---- Phase 7: voice ----
const LANGS = ['en-US', 'ta-IN'];
const voiceSettingsPatch = (body) => {
  onlyFields(body, ['enabled', 'language', 'voiceName', 'speechRate', 'speechVolume', 'muted', 'wakeWordEnabled', 'pushToTalk', 'historyEnabled']);
  const out = {};
  const flag = (k) => { if (k in body) { if (typeof body[k] !== 'boolean') throw bad(`${k} must be true or false.`); out[k] = body[k]; } };
  flag('enabled'); flag('muted'); flag('historyEnabled');
  if ('language' in body) { if (!LANGS.includes(body.language)) throw bad(`language must be one of: ${LANGS.join(', ')}.`); out.language = body.language; }
  if ('voiceName' in body) {
    const n = body.voiceName;
    if (n !== null && (typeof n !== 'string' || !n.trim() || n.length > 200 || /[\u0000-\u001f\u007f]/.test(n))) throw bad('voiceName must be a voice name or null for the system default.');
    out.voiceName = n === null ? null : n.trim();
  }
  if ('speechRate' in body) { if (typeof body.speechRate !== 'number' || !(body.speechRate >= 0.5 && body.speechRate <= 2)) throw bad('speechRate must be a number from 0.5 to 2.'); out.speechRate = body.speechRate; }
  if ('speechVolume' in body) { if (typeof body.speechVolume !== 'number' || !(body.speechVolume >= 0 && body.speechVolume <= 1)) throw bad('speechVolume must be a number from 0 to 1.'); out.speechVolume = body.speechVolume; }
  // Continuous listening is not built. These two stay at "push-to-talk only"; anything else is refused with an explanation.
  if ('wakeWordEnabled' in body && body.wakeWordEnabled !== false) throw new HttpError(409, 'wake_word_unavailable', 'Wake-word listening is not available yet. Lil Moon only listens after you press the microphone.');
  if ('pushToTalk' in body && body.pushToTalk !== true) throw new HttpError(409, 'wake_word_unavailable', 'Push-to-talk is the only listening mode available. Lil Moon only listens after you press the microphone.');
  if (!Object.keys(out).length && !('wakeWordEnabled' in body) && !('pushToTalk' in body)) throw bad('Nothing to change.');
  return out;
};
const voiceCommandBody = (body) => {
  onlyFields(body, ['text', 'source', 'confidence']);
  const text = typeof body.text === 'string' ? body.text.trim() : '';
  if (!text || text.length > 300 || /[\u0000-\u001f\u007f]/.test(text)) throw bad('text must be 1 to 300 printable characters.');
  const source = body.source === undefined ? 'typed' : body.source;
  if (!['voice', 'typed'].includes(source)) throw bad('source must be "voice" or "typed".');
  let confidence = 1;
  if (body.confidence !== undefined) { if (typeof body.confidence !== 'number' || !(body.confidence >= 0 && body.confidence <= 1)) throw bad('confidence must be a number from 0 to 1.'); confidence = body.confidence; }
  return { text, source, confidence };
};
const voiceConfirmBody = (body) => {
  onlyFields(body, ['id', 'choice']);
  if (typeof body.id !== 'string' || !/^[A-Za-z0-9-]{8,64}$/.test(body.id)) throw bad('id is not a valid confirmation id.');
  const c = body.choice;
  if (!(c === 'yes' || c === 'no' || (Number.isInteger(c) && c >= 0 && c <= 4))) throw bad('choice must be "yes", "no" or an option number.');
  return { id: body.id, choice: c };
};
const voiceHistoryQuery = (q) => ({ limit: int(q.limit, 'limit', 1, 200, 50), offset: int(q.offset, 'offset', 0, 1000000, 0) });

module.exports = { HttpError, settingsPatch, sessionBody, historyQuery, category, recordId, websiteBody, websitePatch, aliasBody, aliasParam, extActivity,
  limitBody, limitPatch, extensionBody, masterBody, eventsQuery, targetsQuery, extDomain, MODES,
  voiceSettingsPatch, voiceCommandBody, voiceConfirmBody, voiceHistoryQuery, LANGS };
