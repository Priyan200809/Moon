// /api/voice over real HTTP: validation, token separation, history/settings behaviour.
const test = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('events');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer } = require('../backend/server');
const { createTracker } = require('../backend/websiteTracker');
const { createLimitEngine } = require('../backend/limits');
const { createAppLauncher } = require('../backend/voice/appLauncher');
const { createCommandExecutor } = require('../backend/voice/commandExecutor');
const { createVoiceService } = require('../backend/voice/voiceService');

const DASH = 'dash-token';
const EXT_ORIGIN = 'chrome-extension://abcdefghijklmnopabcdefghijklmnop';

async function boot() {
  const db = openDatabase(':memory:'); const repo = createRepository(db);
  const tracker = createTracker({ repo }); const limits = createLimitEngine({ repo, tracker });
  const spawned = []; const opened = [];
  const launcher = createAppLauncher({ platform: 'win32', env: { SystemRoot: 'C:\\Windows' }, existsSync: (p) => p === 'C:\\Windows\\System32\\notepad.exe', spawn: (exe) => { spawned.push(exe); const e = new EventEmitter(); e.unref = () => {}; setImmediate(() => e.emit('spawn')); return e; } });
  const executor = createCommandExecutor({ repo, tracker, limits, launcher, opener: { open: async (u) => { opened.push(u); } } });
  const service = createVoiceService({ repo, executor, log: { error() {} } });
  const voice = { service, capabilities: () => ({ speech: { local: true, sendsAudioToCloud: false }, commands: [], applications: [], websites: [] }) };
  const api = await startServer({ repo, allowedOrigins: ['null'], token: DASH, tracker, limits, voice });
  const call = async (method, p, body, { token = DASH, origin = 'null' } = {}) => {
    const res = await fetch(api.baseUrl + p, { method, headers: { Authorization: `Bearer ${token}`, Origin: origin, ...(body !== undefined && { 'Content-Type': 'application/json' }) }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, json: await res.json().catch(() => null) };
  };
  return { db, repo, api, call, spawned, opened, stop: async () => { await api.close(); db.close(); } };
}

test('commands over HTTP: executed through the pipeline, validated strictly, never reaching a process when invalid', async () => {
  const t = await boot();
  let r = await t.call('POST', '/api/voice/command', { text: 'Open Notepad.', source: 'typed' });
  assert.deepEqual([r.status, r.json.data.status, r.json.data.text, t.spawned.length], [200, 'executed', 'Opening Notepad.', 1]);
  r = await t.call('POST', '/api/voice/command', { text: 'open youtube', source: 'voice', confidence: 0.95 });
  assert.deepEqual([r.json.data.text, t.opened], ['Opening YouTube.', ['https://www.youtube.com/']]);
  for (const bad of [{}, { text: '' }, { text: 5 }, { text: 'x'.repeat(301) }, { text: 'a\u0000b' }, { text: 'hi', source: 'mic' }, { text: 'hi', confidence: 2 }, { text: 'hi', confidence: '1' }, { text: 'hi', extra: true }, { text: 'hi\nthere' }]) {
    assert.equal((await t.call('POST', '/api/voice/command', bad)).status, 400, JSON.stringify(bad));
  }
  assert.equal(t.spawned.length, 1);
  assert.equal((await t.call('POST', '/api/voice/command', { text: 'blah blah' })).json.data.status, 'unknown');
  await t.stop();
});

test('confirmations over HTTP: ids are single-use and options are validated', async () => {
  const t = await boot();
  const q = (await t.call('POST', '/api/voice/command', { text: 'open example.com' })).json.data;
  assert.equal(q.status, 'needs_confirmation'); assert.deepEqual(q.confirmation.options, ['Open it']); assert.equal(t.opened.length, 0);
  for (const bad of [{}, { id: 'x', choice: 'yes' }, { id: q.confirmation.id, choice: 'maybe' }, { id: q.confirmation.id, choice: 99 }, { id: q.confirmation.id, choice: 'yes', extra: 1 }]) assert.equal((await t.call('POST', '/api/voice/confirm', bad)).status, 400, JSON.stringify(bad));
  assert.equal((await t.call('POST', '/api/voice/confirm', { id: 'aaaaaaaaaaaa', choice: 'yes' })).json.data.status, 'rejected');
  const ok = (await t.call('POST', '/api/voice/confirm', { id: q.confirmation.id, choice: 'yes' })).json.data;
  assert.deepEqual([ok.status, t.opened], ['executed', ['https://example.com/']]);
  assert.equal((await t.call('POST', '/api/voice/confirm', { id: q.confirmation.id, choice: 'yes' })).json.data.status, 'rejected'); // second use refused
  await t.stop();
});

test('settings: defaults are privacy-first; wake word and non-push-to-talk are refused; ranges are enforced', async () => {
  const t = await boot();
  const s = (await t.call('GET', '/api/voice/settings')).json.data;
  assert.deepEqual([s.enabled, s.language, s.wakeWordEnabled, s.pushToTalk, s.historyEnabled, s.muted, s.speechRate, s.speechVolume], [true, 'en-US', false, true, true, false, 1, 1]);
  let r = await t.call('PUT', '/api/voice/settings', { speechRate: 1.5, speechVolume: 0.4, muted: true, voiceName: 'Microsoft Zira Desktop', language: 'ta-IN', historyEnabled: false });
  assert.deepEqual([r.status, r.json.data.speechRate, r.json.data.muted, r.json.data.language, r.json.data.historyEnabled], [200, 1.5, true, 'ta-IN', false]);
  assert.equal((await t.call('PUT', '/api/voice/settings', { voiceName: null })).json.data.voiceName, null);
  r = await t.call('PUT', '/api/voice/settings', { wakeWordEnabled: true }); assert.deepEqual([r.status, r.json.error.code], [409, 'wake_word_unavailable']);
  r = await t.call('PUT', '/api/voice/settings', { pushToTalk: false }); assert.equal(r.status, 409);
  assert.equal((await t.call('PUT', '/api/voice/settings', { wakeWordEnabled: false, pushToTalk: true })).status, 200);
  for (const bad of [{ speechRate: 0.1 }, { speechRate: 3 }, { speechRate: '1' }, { speechVolume: -1 }, { speechVolume: 1.1 }, { language: 'fr-FR' }, { enabled: 'yes' }, { muted: 1 }, { voiceName: '' }, { voiceName: 'a\u0000' }, { voiceName: 'x'.repeat(201) }, { nope: 1 }, {}]) {
    assert.equal((await t.call('PUT', '/api/voice/settings', bad)).status, 400, JSON.stringify(bad));
  }
  assert.equal(t.repo.getVoiceSettings().wakeWordEnabled, false);
  await t.stop();
});

test('history API: newest first, pagination, text only, history-off keeps nothing, clear deletes everything', async () => {
  const t = await boot();
  for (const text of ['what time is it', 'open notepad', 'show app usage']) await t.call('POST', '/api/voice/command', { text, source: 'voice' });
  let h = (await t.call('GET', '/api/voice/history?limit=2')).json.data;
  assert.deepEqual([h.total, h.records.length, h.records[0].recognizedText, h.records[0].source], [3, 2, 'show app usage', 'voice']);
  assert.ok(!('audio' in h.records[0]));
  assert.equal((await t.call('GET', '/api/voice/history?limit=0')).status, 400);
  await t.call('PUT', '/api/voice/settings', { historyEnabled: false });
  await t.call('POST', '/api/voice/command', { text: 'open settings' });
  assert.equal((await t.call('GET', '/api/voice/history')).json.data.total, 3);
  assert.equal((await t.call('DELETE', '/api/voice/history')).json.data.deleted, 3);
  assert.equal((await t.call('GET', '/api/voice/history')).json.data.total, 0);
  await t.stop();
});

test('voice routes belong to the dashboard only: no token, the extension pairing code, or an extension origin all fail', async () => {
  const t = await boot();
  assert.equal((await t.call('GET', '/api/voice/settings', undefined, { token: 'wrong' })).status, 401);
  assert.equal((await t.call('GET', '/api/voice/settings', undefined, { token: t.repo.getExtensionToken() })).status, 401);
  assert.equal((await t.call('POST', '/api/voice/command', { text: 'open notepad' }, { token: t.repo.getExtensionToken(), origin: EXT_ORIGIN })).status, 403);
  assert.equal((await t.call('POST', '/ext/voice/command', { text: 'open notepad' }, { token: t.repo.getExtensionToken(), origin: EXT_ORIGIN })).status, 404);
  assert.equal(t.spawned.length, 0);
  const cap = (await t.call('GET', '/api/voice/capabilities')).json.data;
  assert.deepEqual([cap.speech.local, cap.speech.sendsAudioToCloud], [true, false]);
  await t.stop();
});
