process.env.TZ = 'Asia/Kolkata';
const test = require('node:test');
const assert = require('node:assert/strict');
const domain = require('../backend/domain');
const { merge, subtract } = require('../backend/intervals');
const { createIdleMonitor } = require('../backend/idleMonitor');
const pairing = require('../backend/pairing');

test('configured domains are normalised and shared suffixes are refused', () => {
  const ok = { 'WWW.YouTube.com': 'youtube.com', 'github.com.': 'github.com', ' Reddit.com ': 'reddit.com', 'www.bbc.co.uk': 'bbc.co.uk', 'music.youtube.com': 'music.youtube.com', 'x.com': 'x.com' };
  for (const [input, want] of Object.entries(ok)) assert.equal(domain.normalizeConfiguredDomain(input), want, input);
  for (const bad of ['co.uk', 'com.au', 'localhost', '127.0.0.1', '1.2.3.4', 'a_b.com', 'https://youtube.com', 'youtube.com/watch', 'youtube.com:443', '', null, 42, '-bad.com', 'a..com']) {
    assert.equal(domain.normalizeConfiguredDomain(bad), null, String(bad));
  }
});

test('matching works on whole labels only, honours exact mode and prefers the most specific site', () => {
  const sites = [{ domain: 'youtube.com', matchMode: 'subdomains' }, { domain: 'exact.com', matchMode: 'exact' }, { domain: 'music.youtube.com', matchMode: 'subdomains' }, { domain: 'off.com', matchMode: 'subdomains', isEnabled: false }];
  const m = (h) => domain.matchTracked(h, sites)?.domain ?? null;
  assert.equal(m('www.youtube.com'), 'youtube.com');
  assert.equal(m('m.youtube.com'), 'youtube.com');
  assert.equal(m('YOUTUBE.COM'), 'youtube.com');
  assert.equal(m('music.youtube.com'), 'music.youtube.com');
  assert.equal(m('a.music.youtube.com'), 'music.youtube.com');
  for (const h of ['notyoutube.com', 'youtube.com.evil.net', 'youtubexcom', 'evil-youtube.com', 'youtu.be', 'sub.exact.com', 'off.com', 'www.off.com']) assert.equal(m(h), null, h);
  assert.equal(m('www.exact.com'), 'exact.com');
});

test('interval maths', () => {
  assert.deepEqual(merge([[5, 8], [1, 3], [2, 4], [8, 9]]), [[1, 4], [5, 9]]);
  assert.deepEqual(subtract([[0, 10]], [[2, 3], [5, 7]]), [[0, 2], [3, 5], [7, 10]]);
  assert.deepEqual(subtract([[0, 10]], [[-5, 20]]), []);
  assert.deepEqual(subtract([[0, 10], [20, 30]], [[8, 25]]), [[0, 8], [25, 30]]);
  assert.deepEqual(subtract([[0, 10]], []), [[0, 10]]);
});

test('idle monitor: idle starts when the threshold is crossed and ends at the next input', () => {
  let now = 1_000_000, idle = 0, threshold = 60;
  const m = createIdleMonitor({ getIdleSeconds: () => idle, getThresholdSeconds: () => threshold, now: () => now });
  for (let s = 0; s < 100; s++) { now += 1000; idle = s < 30 ? 0 : idle + 1; m.tick(); } // last input ~30 s in
  assert.equal(m.state().inactive, true);
  assert.equal(m.state().reason, 'idle');
  const lastInput = 1_000_000 + 30 * 1000; // (idle counter restarts at 30 s mark)
  assert.ok(Math.abs(m.state().since - (lastInput + 60_000)) <= 2000, 'idle since last input + threshold');
  now += 5000; idle = 0; m.tick();
  assert.equal(m.state().inactive, false);
  const spans = m.inactiveBetween(0, now);
  assert.equal(spans.length, 1);
  assert.ok(spans[0][1] >= spans[0][0]);
  threshold = 15; idle = 20; now += 1000; m.tick();
  assert.equal(m.state().inactive, true); // threshold is read live from settings
});

test('idle monitor: lock and sleep are tracked separately and overlap cleanly', () => {
  let now = 0;
  const m = createIdleMonitor({ getIdleSeconds: () => 0, getThresholdSeconds: () => 60, now: () => now });
  now = 100; m.lock(); now = 200; m.suspend(); assert.equal(m.state().reason, 'sleeping');
  now = 300; m.resume(); assert.equal(m.state().reason, 'locked');
  now = 400; m.unlock(); assert.equal(m.state().inactive, false);
  assert.deepEqual(m.inactiveBetween(0, 1000), [[100, 400]]);
  now = 500; m.unlock(); m.resume(); // stray events are harmless
  assert.deepEqual(m.inactiveBetween(0, 1000), [[100, 400]]);
});

test('pairing codes: random, formatted, hashed, constant-time verified, case/dash tolerant', () => {
  const a = pairing.generateCode(), b = pairing.generateCode();
  assert.notEqual(a, b);
  assert.match(a, /^([A-Z2-9]{4}-){5}[A-Z2-9]{4}$/);
  const h = pairing.hashCode(a);
  assert.match(h, /^[0-9a-f]{64}$/);
  assert.equal(pairing.verifyCode(a, h), true);
  assert.equal(pairing.verifyCode(a.toLowerCase().replace(/-/g, ' '), h), true);
  assert.equal(pairing.verifyCode(b, h), false);
  assert.equal(pairing.verifyCode('', h), false);
});
