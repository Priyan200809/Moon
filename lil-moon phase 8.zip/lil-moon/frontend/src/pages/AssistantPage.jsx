import { useEffect, useRef, useState } from 'react';
import AiSetup from '../components/AiSetup.jsx';
import Markdown, { CopyButton } from '../components/Markdown.jsx';
import { api, streamChat } from '../lib/api.js';
import { useApi } from '../hooks/useApi.js';
import { fmtWhen } from '../lib/format.js';

function Sources({ sources }) {
  const [err, setErr] = useState('');
  if (!sources?.length) return null;
  const open = async (id) => { try { setErr(''); await api('POST', `/api/files/${id}/open`); } catch (e) { setErr(e.message); } };
  return (
    <ul className="sources" aria-label="Sources">
      {sources.map((s) => (
        <li key={s.n}>
          <span className="src-n">[{s.n}]</span> <strong>{s.name}</strong>{s.section ? ` - ${s.section}` : ''}
          <button type="button" className="btn btn-small" onClick={() => open(s.fileId)}>Open</button>
          <div className="src-snip">{s.snippet}</div>
        </li>
      ))}
      {err && <li className="msg-error" role="alert">{err}</li>}
    </ul>
  );
}

function Card({ card, onDone }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const act = async (fn) => { setBusy(true); try { await fn(); onDone(card); } catch (e) { setErr(e.message); setBusy(false); } };
  if (card.kind === 'confirm') {
    return (
      <div className="ai-card" role="group" aria-label="Approval needed">
        <strong>Lil Moon wants to: {card.summary}</strong><div className="note">{card.detail}</div>
        <div className="quick">
          <button className="btn btn-strong btn-small" disabled={busy} onClick={() => act(() => api('POST', `/api/ai/tools/${card.id}/confirm`, { approve: true }))}>Allow</button>
          <button className="btn btn-small" disabled={busy} onClick={() => act(() => api('POST', `/api/ai/tools/${card.id}/confirm`, { approve: false }))}>Deny</button>
        </div>
        {err && <span className="msg-error">{err}</span>}
      </div>
    );
  }
  return (
    <div className="ai-card" role="group" aria-label="Memory suggestion">
      <strong>Remember this?</strong> <span className="badge">{card.category}</span><div className="note">{card.content}</div>
      <div className="quick">
        <button className="btn btn-strong btn-small" disabled={busy} onClick={() => act(() => api('POST', `/api/ai/memory-candidates/${card.id}/accept`))}>Save</button>
        <button className="btn btn-small" disabled={busy} onClick={() => act(() => api('POST', `/api/ai/memory-candidates/${card.id}/dismiss`, {}))}>Not now</button>
        <button className="btn btn-small" disabled={busy} onClick={() => act(() => api('POST', `/api/ai/memory-candidates/${card.id}/dismiss`, { never: true }))}>Never remember this</button>
      </div>
      {err && <span className="msg-error">{err}</span>}
    </div>
  );
}

export default function AssistantPage({ onNavigate }) {
  const status = useApi('/api/ai/status');
  const files = useApi('/api/files/status');
  const [q, setQ] = useState('');
  const convos = useApi(`/api/ai/conversations${q.trim() ? `?q=${encodeURIComponent(q.trim())}` : ''}`);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState(null);
  const [cards, setCards] = useState([]);
  const [notes, setNotes] = useState([]);
  const [error, setError] = useState('');
  const [input, setInput] = useState('');
  const [useFiles, setUseFiles] = useState(true);
  const [showSetup, setShowSetup] = useState(false);
  const [renaming, setRenaming] = useState(null);
  const [confirm, setConfirm] = useState('');
  const abortRef = useRef(null);
  const endRef = useRef(null);
  const streaming = draft !== null;
  const hasFiles = (files.data?.totals.files ?? 0) > 0;

  useEffect(() => { endRef.current?.scrollIntoView?.({ block: 'end' }); }, [messages, draft, cards]);
  useEffect(() => { if (status.data && !status.data.configured) setShowSetup(true); }, [status.data?.configured]); // eslint-disable-line react-hooks/exhaustive-deps

  const load = async (id) => { try { setMessages(await api('GET', `/api/ai/conversations/${id}/messages`)); } catch (e) { setError(e.message); } };
  const select = (id) => { setActiveId(id); setCards([]); setNotes([]); setError(''); load(id); };
  const newChat = () => { setActiveId(null); setMessages([]); setCards([]); setNotes([]); setError(''); };

  const send = async () => {
    const content = input.trim();
    if (!content || streaming) return;
    setError(''); setNotes([]); setCards([]); setDraft({ text: '' });
    const ctl = new AbortController();
    abortRef.current = ctl;
    let id = activeId;
    try {
      if (!id) { id = (await api('POST', '/api/ai/conversations')).id; setActiveId(id); }
      await streamChat(id, { content, useFiles: useFiles && hasFiles }, (ev) => {
        if (ev.type === 'start') { setMessages((m) => [...m, ev.userMessage]); setInput(''); }
        else if (ev.type === 'token') setDraft((d) => ({ text: (d?.text ?? '') + ev.text }));
        else if (ev.type === 'error') { setError(ev.message); if (ev.code === 'not_configured') setShowSetup(true); }
        else if (ev.type === 'confirm') setCards((c) => [...c, { kind: 'confirm', ...ev.confirmation }]);
        else if (ev.type === 'memory_candidate') setCards((c) => [...c, { kind: 'memory', ...ev.candidate }]);
        else if (ev.type === 'memory_saved') setNotes((n) => [...n, `Saved to memory: ${ev.memory.content}`]);
        else if (ev.type === 'notice') setNotes((n) => [...n, ev.text]);
        else if (ev.type === 'navigate') onNavigate(ev.page);
      }, ctl.signal);
    } catch (e) { setError(e.message); }
    setDraft(null);
    abortRef.current = null;
    if (id) await load(id);
    convos.reload(); status.reload();
  };

  const rename = async (c, title) => { setRenaming(null); if (title.trim() && title !== c.title) { try { await api('PATCH', `/api/ai/conversations/${c.id}`, { title }); convos.reload(); } catch (e) { setError(e.message); } } };
  const remove = async (id) => { try { await api('DELETE', `/api/ai/conversations/${id}`); if (id === activeId) newChat(); convos.reload(); } catch (e) { setError(e.message); } };
  const twoStep = async (key, fn) => { if (confirm !== key) { setConfirm(key); setTimeout(() => setConfirm(''), 4000); return; } setConfirm(''); try { await fn(); } catch (e) { setError(e.message); } };

  return (
    <>
      <div className="page-head">
        <h1>AI assistant</h1>
        <span className="badge">{status.data?.configured ? `${status.data.model}` : 'Setup needed'}</span>
        <button type="button" className="btn btn-small" onClick={() => setShowSetup((s) => !s)}>{showSetup ? 'Hide setup' : 'AI setup'}</button>
      </div>
      {status.status === 'error' && <div className="state state-error" role="alert"><p>{status.error}</p><button className="btn" onClick={status.reload}>Try again</button></div>}
      {showSetup && status.data && <AiSetup status={status.data} onChanged={status.reload} />}

      <div className="chat-layout">
        <aside className="convos" aria-label="Conversations">
          <button type="button" className="btn btn-strong" onClick={newChat}>New conversation</button>
          <input type="search" className="search" placeholder="Search conversations" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search conversations" />
          {convos.status === 'error' ? <p className="msg-error">{convos.error}</p> : !convos.data ? <p className="note">Loading...</p> : convos.data.length === 0
            ? <p className="note">{q ? 'No conversations match.' : 'No conversations yet. Ask something!'}</p>
            : <ul>
              {convos.data.map((c) => (
                <li key={c.id} className={c.id === activeId ? 'active' : ''}>
                  {renaming === c.id
                    ? <input autoFocus defaultValue={c.title} maxLength={200} aria-label="Conversation title" onBlur={(e) => rename(c, e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); if (e.key === 'Escape') setRenaming(null); }} />
                    : <button type="button" className="convo-title" onClick={() => select(c.id)}>{c.title}{c.match && <small>{c.match}</small>}</button>}
                  <span className="convo-actions">
                    <button type="button" className="btn btn-small" onClick={() => setRenaming(c.id)} aria-label={`Rename ${c.title}`}>Rename</button>
                    <button type="button" className="btn btn-small" onClick={() => remove(c.id)} aria-label={`Delete ${c.title}`}>Delete</button>
                  </span>
                </li>
              ))}
            </ul>}
          {convos.data?.length > 0 && <button type="button" className="btn btn-small" onClick={() => twoStep('all', async () => { await api('DELETE', '/api/ai/conversations'); newChat(); convos.reload(); })}>{confirm === 'all' ? 'Click again to delete ALL' : 'Delete all history'}</button>}
        </aside>

        <section className="chat" aria-label="Chat">
          <div className="messages" aria-live="polite">
            {messages.length === 0 && !streaming && (
              <div className="state">Hi! Ask me about your day, your usage, or your documents. {status.data && !status.data.configured && 'First finish AI setup above: I can not answer until a model is connected.'}</div>
            )}
            {messages.map((m) => (
              <article key={m.id} className={`msg msg-${m.role}`}>
                <header><strong>{m.role === 'user' ? 'You' : 'Lil Moon'}</strong><span>{fmtWhen(m.createdAt)}</span>{m.role === 'assistant' && <CopyButton text={m.content} label="Copy" />}</header>
                {m.role === 'assistant' ? <Markdown text={m.content} /> : <p className="plain">{m.content}</p>}
                {m.role === 'assistant' && <Sources sources={m.sources} />}
              </article>
            ))}
            {streaming && (
              <article className="msg msg-assistant">
                <header><strong>Lil Moon</strong></header>
                {draft.text ? <Markdown text={draft.text} /> : <p className="thinking" role="status">Lil Moon is thinking<span>.</span><span>.</span><span>.</span></p>}
              </article>
            )}
            {notes.map((n, i) => <p key={i} className="note-line" role="status">{n}</p>)}
            {cards.map((c, i) => <Card key={`${c.kind}-${c.id}-${i}`} card={c} onDone={(x) => setCards((all) => all.filter((y) => y !== x))} />)}
            {error && <div className="state state-error" role="alert"><p>{error}</p></div>}
            <div ref={endRef} />
          </div>

          <div className="composer">
            <textarea value={input} onChange={(e) => setInput(e.target.value)} rows={3} maxLength={8000} placeholder="Message Lil Moon (Enter to send, Shift+Enter for a new line)" aria-label="Message"
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} />
            <div className="composer-row">
              <label className="row" title={hasFiles ? '' : 'Add a folder on the Local files page first'}>
                <input type="checkbox" checked={useFiles && hasFiles} disabled={!hasFiles} onChange={(e) => setUseFiles(e.target.checked)} /> Search my files
              </label>
              {activeId && messages.length > 0 && !streaming && <button type="button" className="btn btn-small" onClick={() => twoStep('clear', async () => { await api('DELETE', `/api/ai/conversations/${activeId}/messages`); await load(activeId); convos.reload(); })}>{confirm === 'clear' ? 'Click again to clear' : 'Clear conversation'}</button>}
              {streaming
                ? <button type="button" className="btn btn-strong" onClick={() => abortRef.current?.abort()}>Stop generating</button>
                : <button type="button" className="btn btn-strong" onClick={send} disabled={!input.trim()}>Send</button>}
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
