# Lil Moon (Phases 1-3, 5, 6 and 7)

A floating, moon-shaped desktop companion for Windows. Neobrutalism look, built with Electron + React.

## Setup (Windows 10/11)
1. Install Node.js 20 or newer (LTS) from https://nodejs.org (includes npm).
2. Open PowerShell in this folder and run:
```
npm install
```

## Run
- Normal run (builds the UI, then launches): `npm start`
- Development (Vite dev server, UI reloads on save): `npm run dev`
- Build the UI only: `npm run build`
- Backend, tracker and extension-logic tests (plain Node 22.13+, no window): `npm test`
- Electron smoke test: `npm run smoke` (Linux/CI with a display; see "Testing")

## Use
- Drag the moon anywhere. A short click opens the dashboard; a drag never does.
- Clicking again focuses (or restores) the same dashboard window.
- Dashboard buttons: Minimize, Close (moon stays), Exit Lil Moon (quits everything).
- Right-click the moon for Open dashboard / Exit Lil Moon.
- The moon's position is saved to `%APPDATA%\lil-moon\settings.json` and restored on launch.

## Dashboard and local database (Phases 2-3)
Sections: Home, Application usage, Website usage, Voice assistant, Settings. Data comes from a local SQLite database through a local-only API. See `docs/BACKEND.md` for the schema, API reference, time-zone strategy and security notes.
- **Real (database-backed):** daily limit (default 3 h), theme, usage summaries, usage history, database status.
- **Website usage (Phase 5):** real tracking through the browser extension in `extension/`. See **Website tracking** below and `docs/WEBSITE_TRACKING.md`.
- **Manual for now:** application tracking is not built in this copy of the project. Use "Add a test session" on the Application usage page to create records.
- **Placeholders:** voice assistant (mic, history, examples), "Start with Windows", automatic application tracking, restrictions.

## Layout
```
backend/    database.js (SQLite, migrations, queries), validators.js, server.js (Express API + /ext routes),
            websiteTracker.js (session maths), idleMonitor.js (idle / lock / sleep)
extension/  Chrome/Edge Manifest V3 extension (manifest.json, background.js, popup.*, lib/domain.js, lib/core.js, icons/)
electron/   main.js (lifecycle + IPC validation), windowManager.js (windows, drag), settingsStore.js (moon position file), preload.js (bridge)
frontend/   React UI (one bundle, routes #/moon and #/dashboard): pages/, components/, hooks/, data/sampleData.js
scripts/    dev.js (Vite + Electron), smoke.js (automated test)
```

## Website tracking (Phase 5)
1. `npm start`. In the dashboard open **Website usage**: the **Connect the browser extension** card shows a pairing code.
2. Chrome: open `chrome://extensions`, turn on **Developer mode**, **Load unpacked**, choose this project's `extension` folder. Edge: `edge://extensions`, same steps.
3. Click the Lil Moon toolbar icon, paste the pairing code, press **Connect**. The popup shows status, current site, today's time, and Pause/Resume.
Counts time only on sites in your list (defaults: youtube, instagram, github, reddit, linkedin; edit them on the page), while the browser is in front, the tab is active, you are not idle (default 60 s), and tracking is not paused. Private windows are never tracked. Full design, permissions, privacy and the Windows checklist: `docs/WEBSITE_TRACKING.md`.

## Usage limits (Phase 6)
Dashboard -> **Usage limits**: per-application and per-website daily limits with three modes (warning only, ask me first, block for websites), 80%/100% notifications, user-approved extra time, a master "turn off all restrictions" switch and a restriction history. Website blocking is done by the browser extension (only the exact limited site, only the active tab, with override/disable and automatic fail-open). **Application blocking is not implemented** (Phase 4 was not available); applications get warnings and questions only. Details, API, test results and a manual checklist: `docs/LIMITS.md`.

## Voice assistant (Phase 7)
Dashboard -> **Voice assistant** (or right-click the moon -> **Talk to Lil Moon**): press the microphone, say one command, see what was heard, and get a text and spoken reply. Recognition is **local** (Windows' built-in offline speech recogniser; no cloud, no audio stored), listening is push-to-talk only, and voice can only open a fixed list of apps and websites, answer from your own usage records, and navigate the dashboard. You can also type commands. Details, safety model, test results and the Windows checklist: `docs/VOICE.md`.

## Security
contextIsolation on, nodeIntegration off, sandbox on, preload exposes only fixed no-argument commands, main checks that each command comes from the correct window's top frame, navigation and new windows are blocked, production CSP is set in index.html. No filesystem or shell access is exposed.

## Troubleshooting
- Blank or missing moon: run `npm run build` first, or use `npm start`.
- Electron download failed during install: re-run `npm install`, or `node node_modules/electron/install.js`.
- Port 5173 busy in dev: close the other Vite process.
- Moon hidden behind a full-screen exclusive game: expected; borderless/windowed games are fine.
- Reset the moon's position: delete `%APPDATA%\lil-moon\settings.json`.
- Dashboard says it could not open the database: the file is kept untouched; close other copies of Lil Moon and press Try again. To start fresh, quit Lil Moon and delete `%APPDATA%\lil-moon\lil-moon.db*` (this erases your data).
- A console warning that SQLite is experimental is expected.

## Implemented
Floating frameless transparent always-on-top moon, drag vs click detection, dashboard with sample-data cards, single dashboard instance, minimize/close/exit, edge clamping, multi-monitor and display-change handling, saved position.

## Known limitations
- Voice assistant and "Start with Windows" are placeholders. Application tracking is not part of this copy (Phase 4 was not available when Phase 5 was built).
- No tray icon or app icon yet (the moon's right-click menu is the way out without opening the dashboard).
- Windows-specific behaviour (DPI scaling, always-on-top over other topmost windows) was not tested on real Windows.

## Testing
`npm test` runs the backend, tracker, limits, notifier, extension-API and extension-logic tests (113 in total). `npm run smoke` runs two phases (set `SMOKE_PHASE=1` then `2` with the same `SMOKE_DIR`) to check restart persistence. Under Linux use `xvfb-run -a npx electron --no-sandbox scripts/smoke.js`.
