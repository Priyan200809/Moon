import { useEffect, useRef, useState } from 'react';
import AsyncBoundary from '../components/AsyncBoundary.jsx';
import DashboardCard from '../components/DashboardCard.jsx';
import { useApi } from '../hooks/useApi.js';
import { api } from '../lib/api.js';
import { fmtWhen } from '../lib/format.js';
import { useVoiceAssistant } from '../voice/useVoiceAssistant.js';
import * as tts from '../voice/textToSpeechService.js';

const PERMISSION = {
  granted: ['Allowed', 'Windows lets Lil Moon use your microphone.'],
  denied: ['Blocked by Windows', 'Open Windows Settings > Privacy & security > Microphone and allow desktop apps. Then try again.'],
  restricted: ['Restricted', 'Your system settings restrict microphone use.'],
  'not-determined': ['Not asked yet', 'Windows will use your default microphone when you press Listen.'],
  unknown: ['Not known', 'Windows decides when you press Listen. You can always type a command instead.'],
};
const STATUS_LABEL = { executed: 'Done', needs_confirmation: 'Asked you', cancelled: 'Cancelled', rejected: 'Refused', unknown: 'Not understood', error: 'Problem' };
const LANGS = [['en-US', 'English (US)'], ['ta-IN', 'Tamil (needs a Windows Tamil speech pack)']];

function MicIcon() {
  return (
    <svg viewBox="0 0 24 24" width="44" height="44" aria-hidden="true">
      <rect x="9" y="2" width="6" height="12" rx="3" fill="#FFE500" stroke="#000" strokeWidth="2" />
      <path d="M5 11a7 7 0 0 0 14 0M12 18v4" fill="none" stroke="#000" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function Indicators({ phase }) {
  const on = (p) => (phase === p ? ' pill-on' : '');
  return (
    <p className="status-line" role="status" aria-live="polite">
      <span className={`pill${on('listening')}`}>{phase === 'listening' ? '● Listening' : 'Listening: off'}</span>{' '}
      <span className={`pill${on('processing')}`}>{phase === 'processing' ? '● Processing' : 'Processing: idle'}</span>{' '}
      <span className={`pill${on('speaking')}`}>{phase === 'speaking' ? '● Speaking' : 'Speaking: idle'}</span>
    </p>
  );
}

function SettingsCard({ settings, voices, ttsOk, onChange, onTest, onClearHistory, historyCount }) {
  const [rate, setRate] = useState(settings.speechRate);
  const [vol, setVol] = useState(settings.speechVolume);
  const [confirming, setConfirming] = useState(false);
  useEffect(() => { setRate(settings.speechRate); setVol(settings.speechVolume); }, [settings.speechRate, settings.speechVolume]);
  return (
    <DashboardCard title="Voice settings" tone="cream" badge="Saved locally">
      <div className="limit-form">
        <label className="check"><input type="checkbox" checked={settings.enabled} onChange={(e) => onChange({ enabled: e.target.checked })} /> Voice assistant is on</label>

        <label className="field">Speech language
          <select value={settings.language} onChange={(e) => onChange({ language: e.target.value })}>{LANGS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
          {settings.language !== 'en-US' && <span className="note">Windows must have this language's speech recognition installed. If it does not, Lil Moon will say so and you can switch back to English.</span>}
        </label>

        <label className="field">Microphone
          <select disabled value="default"><option value="default">System default microphone</option></select>
          <span className="note">Windows speech recognition always uses the default input. Change it in Windows Sound settings.</span>
        </label>

        <label className="field">Assistant voice
          <select value={settings.voiceName ?? ''} disabled={!ttsOk} onChange={(e) => onChange({ voiceName: e.target.value || null })}>
            <option value="">System default voice</option>
            {voices.map((v) => <option key={v.name} value={v.name}>{v.name} ({v.lang})</option>)}
          </select>
          {!ttsOk && <span className="note">No speech voices are available on this system, so replies are shown as text only.</span>}
        </label>

        <div className="two">
          <label className="field">Speech speed: {rate.toFixed(1)}x
            <input type="range" min="0.5" max="2" step="0.1" value={rate} onChange={(e) => setRate(e.target.valueAsNumber)} onPointerUp={() => onChange({ speechRate: rate })} onKeyUp={() => onChange({ speechRate: rate })} onBlur={() => rate !== settings.speechRate && onChange({ speechRate: rate })} />
          </label>
          <label className="field">Speech volume: {Math.round(vol * 100)}%
            <input type="range" min="0" max="1" step="0.05" value={vol} onChange={(e) => setVol(e.target.valueAsNumber)} onPointerUp={() => onChange({ speechVolume: vol })} onKeyUp={() => onChange({ speechVolume: vol })} onBlur={() => vol !== settings.speechVolume && onChange({ speechVolume: vol })} />
          </label>
        </div>
        <label className="check"><input type="checkbox" checked={settings.muted} onChange={(e) => onChange({ muted: e.target.checked })} /> Mute assistant voice (replies stay on screen)</label>
        <div className="site-actions"><button className="btn btn-small" onClick={onTest} disabled={!ttsOk}>Test voice</button></div>

        <fieldset className="fs">
          <legend>Listening mode</legend>
          <label className="mode"><input type="radio" checked readOnly /> <span><b>Push-to-talk</b><br /><span className="note">Lil Moon listens only after you press the microphone, for one command, then stops. (Always on.)</span></span></label>
          <label className="mode mode-off"><input type="checkbox" disabled checked={false} readOnly /> <span><b>Wake word</b><br /><span className="note">Not available. Hands-free listening is not built, so the microphone is never open in the background.</span></span></label>
        </fieldset>

        <label className="check"><input type="checkbox" checked={settings.historyEnabled} onChange={(e) => onChange({ historyEnabled: e.target.checked })} /> Save voice command history (text only, never audio)</label>
        {!confirming ? (
          <div className="site-actions"><button className="btn btn-small" onClick={() => setConfirming(true)} disabled={historyCount === 0}>Clear voice history</button></div>
        ) : (
          <div className="state state-error" role="alert"><p>Delete all {historyCount} saved voice commands?</p>
            <button className="btn btn-small" onClick={() => { setConfirming(false); onClearHistory(); }}>Yes, delete</button> <button className="btn btn-small" onClick={() => setConfirming(false)}>Cancel</button></div>
        )}
      </div>
    </DashboardCard>
  );
}

function History({ tick, onCount }) {
  const q = useApi(`/api/voice/history?limit=30&t=${tick}`);
  useEffect(() => { if (q.data) onCount(q.data.total); }, [q.data]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <AsyncBoundary query={q} isEmpty={q.data?.total === 0} empty="No voice commands saved yet. Commands you speak or type appear here with what Lil Moon did.">
      {q.data && (
        <ul className="history">
          {q.data.records.map((r) => (
            <li key={r.id}>
              <div><strong>{r.recognizedText}</strong><span>{fmtWhen(r.createdAt)} · {r.source === 'voice' ? 'spoken' : 'typed'} · {r.intent}</span><span>{r.responseText}</span></div>
              <b>{STATUS_LABEL[r.status] ?? r.status}</b><span />
            </li>
          ))}
        </ul>
      )}
    </AsyncBoundary>
  );
}

export default function VoicePage({ onNavigate, activation = 0 }) {
  const settingsQ = useApi('/api/voice/settings');
  const caps = useApi('/api/voice/capabilities');
  const [settings, setSettings] = useState(null);
  const [voices, setVoices] = useState([]);
  const [historyCount, setHistoryCount] = useState(0);
  const [msg, setMsg] = useState('');
  const [typed, setTyped] = useState('');
  const ttsOk = tts.ttsAvailable();
  useEffect(() => { if (settingsQ.data) setSettings(settingsQ.data); }, [settingsQ.data]);
  useEffect(() => { tts.listVoices().then(setVoices).catch(() => setVoices([])); }, []);

  const v = useVoiceAssistant({ settings, onNavigate });
  const busy = v.phase === 'listening' || v.phase === 'processing';

  // "Talk to Lil Moon" in the moon's menu: start ONE session, once per activation.
  const handled = useRef(0);
  useEffect(() => { if (activation > handled.current && settings) { handled.current = activation; v.startListening(); } }, [activation, settings]); // eslint-disable-line react-hooks/exhaustive-deps

  const change = async (patch) => {
    setMsg('');
    try { setSettings(await api('PUT', '/api/voice/settings', patch)); } catch (e) { setMsg(e.message); settingsQ.reload(); }
  };
  const test = () => tts.speak('This is how I will sound.', { voiceName: settings?.voiceName, rate: settings?.speechRate, volume: settings?.speechVolume, muted: false });
  const clearHistory = async () => { try { await api('DELETE', '/api/voice/history'); setMsg('Voice history cleared.'); v.clear(); setHistoryCount(0); setHistoryRefresh((n) => n + 1); } catch (e) { setMsg(e.message); } };
  const [historyRefresh, setHistoryRefresh] = useState(0);
  const submit = (e) => { e.preventDefault(); const t = typed; setTyped(''); v.runCommand(t, 'typed', 1); };
  const [permTitle, permText] = PERMISSION[v.micStatus] || PERMISSION.unknown;

  return (
    <>
      <div className="page-head">
        <h1>Voice assistant</h1>
        <span className="badge">{v.phase === 'listening' ? 'Microphone ON' : 'Microphone off'}</span>
      </div>
      <p className="lead">Press the microphone, say one command, and Lil Moon shows what it heard before it acts. Speech is recognised on this computer by Windows; nothing is uploaded and no audio is saved.</p>

      <AsyncBoundary query={settingsQ}>
        {settings && (
          <>
            <div className="grid">
              <DashboardCard title="Talk to Lil Moon" tone="purple" badge="Push-to-talk">
                <button className={`mic${v.phase === 'listening' ? ' mic-live' : ''}`} aria-label={v.phase === 'listening' ? 'Stop listening' : 'Start listening'} aria-pressed={v.phase === 'listening'} onClick={v.phase === 'listening' ? v.stopListening : v.startListening} disabled={v.phase === 'processing'}>
                  <MicIcon />
                </button>
                <Indicators phase={v.phase} />
                {v.phase === 'listening' && <p className="live-bar" role="status">● Microphone is on. Speak now, or press Stop.</p>}
                <div className="site-actions">
                  <button className="btn btn-small" onClick={v.startListening} disabled={busy || !settings.enabled}>Start listening</button>
                  <button className="btn btn-small" onClick={v.stopListening} disabled={v.phase !== 'listening'}>Stop listening</button>
                  <button className="btn btn-small" onClick={v.stopSpeaking} disabled={v.phase !== 'speaking'}>Stop speaking</button>
                </div>
                {v.error && <p className="msg-error" role="alert">{v.error}</p>}
              </DashboardCard>

              <DashboardCard title="Microphone permission" tone="cream" badge={permTitle}>
                <p className="note">{permText}</p>
                <div className="site-actions">
                  <button className="btn btn-small" onClick={() => window.lilMoon?.voice?.openMicrophoneSettings()}>Open Windows microphone settings</button>
                  <button className="btn btn-small" onClick={v.refreshPermission}>Check again</button>
                </div>
              </DashboardCard>
            </div>

            <h2 className="section-title">This conversation</h2>
            <div className="grid">
              <DashboardCard title="What I heard"><p className="big small" aria-live="polite">{v.partial || v.recognized || '-'}</p><p className="note">{v.partial ? 'Live transcription (not final yet)' : v.recognized ? 'Recognised command' : 'Nothing heard yet.'}</p></DashboardCard>
              <DashboardCard title="Lil Moon says" tone="cream">
                <p className="big small" aria-live="polite">{v.response ? v.response.text : '-'}</p>
                {v.response?.details?.length > 0 && <ul className="plain">{v.response.details.map((d) => <li key={d.label}><b>{d.label}</b>: {d.value}</li>)}</ul>}
                {v.response && <div className="site-actions"><button className="btn btn-small" onClick={v.repeatAloud} disabled={!ttsOk || settings.muted}>Repeat aloud</button></div>}
                {!ttsOk && <p className="note">Speech voices are not available here, so replies are text only.</p>}
              </DashboardCard>
            </div>

            {v.confirmation && (
              <div className="state state-error" role="alert">
                <p><b>{v.confirmation.prompt}</b></p>
                {v.confirmation.kind === 'yes_no'
                  ? <><button className="btn btn-small" onClick={() => v.confirm('yes')}>{v.confirmation.options[0]}</button> <button className="btn btn-small" onClick={() => v.confirm('no')}>No</button></>
                  : <>{v.confirmation.options.map((o, i) => <span key={o}><button className="btn btn-small" onClick={() => v.confirm(i)}>{o}</button>{' '}</span>)}<button className="btn btn-small" onClick={() => v.confirm('no')}>Cancel</button></>}
                <p className="note">You can also say "yes", "no" or "the first one".</p>
              </div>
            )}

            <form className="test-form" onSubmit={submit}>
              <label className="field">Or type a command (same safety checks as speech)
                <input value={typed} onChange={(e) => setTyped(e.target.value)} placeholder='for example: open Notepad' maxLength={300} disabled={!settings.enabled} />
              </label>
              <button className="btn" type="submit" disabled={!typed.trim() || !settings.enabled}>Run command</button>
              <button className="btn" type="button" onClick={v.clear} disabled={v.conversation.length === 0}>Clear conversation</button>
            </form>

            {v.conversation.length > 0 && (
              <ul className="history" aria-label="Conversation">
                {v.conversation.slice(-12).map((m) => (
                  <li key={m.id}><div><strong>{m.role === 'user' ? (m.source === 'voice' ? 'You said' : 'You typed') : 'Lil Moon'}</strong><span>{m.text}</span></div><b>{m.role === 'assistant' ? STATUS_LABEL[m.status] ?? '' : ''}</b><span /></li>
                ))}
              </ul>
            )}

            <h2 className="section-title">Things you can say</h2>
            <AsyncBoundary query={caps}>
              {caps.data && (
                <div className="grid">
                  {caps.data.commands.map((g) => (
                    <DashboardCard key={g.group} title={g.group} tone="cream">
                      <ul className="examples">{g.examples.map((c) => <li key={c}>"{c}" <button className="btn btn-small" onClick={() => v.runCommand(c, 'typed', 1)} disabled={busy}>Try</button></li>)}</ul>
                    </DashboardCard>
                  ))}
                </div>
              )}
            </AsyncBoundary>

            <h2 className="section-title">Where your voice goes</h2>
            <DashboardCard title="Privacy" tone="purple">
              <ul className="plain">
                <li><b>Speech recognition is local.</b> {caps.data?.speech.label ?? 'Windows offline speech recognition'} handles your microphone on this computer. Lil Moon only receives the recognised text. Nothing is sent to a cloud service.</li>
                <li><b>No recording.</b> No audio is stored by Lil Moon. The microphone opens only after you press Listen (or choose "Talk to Lil Moon" from the moon's menu), for one command, and closes by itself. The "Microphone ON" bar shows whenever it is open.</li>
                <li><b>Replies are spoken with your installed Windows voices</b>, also locally. Lists of apps or sites are shown on screen, not read aloud.</li>
                <li><b>Only approved actions.</b> Voice can open a fixed list of apps and websites, answer questions from your own usage records, and move around the dashboard. It cannot run commands, change protection settings or delete your data.</li>
              </ul>
            </DashboardCard>

            <h2 className="section-title">Settings</h2>
            {msg && <p className="msg-error" role="alert">{msg}</p>}
            <SettingsCard settings={settings} voices={voices} ttsOk={ttsOk} onChange={change} onTest={test} onClearHistory={clearHistory} historyCount={historyCount} />

            <h2 className="section-title">Command history</h2>
            <History tick={v.historyTick + historyRefresh} onCount={setHistoryCount} />
          </>
        )}
      </AsyncBoundary>
    </>
  );
}
