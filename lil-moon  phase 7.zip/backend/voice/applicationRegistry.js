// The ONLY applications voice can launch. Each entry is a fixed list of absolute install locations built from a short list of
// trusted Windows environment variables. Nothing a person says is ever turned into a path, an argument or a command.
// Shells, terminals and system-administration tools are deliberately absent and are refused by name (see BLOCKED).
const P = (...p) => p;
const APPS = [
  { id: 'chrome', name: 'Google Chrome', aliases: ['chrome', 'google chrome', 'chrome browser', 'crome'], paths: P('%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe', '%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe', '%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe') },
  { id: 'edge', name: 'Microsoft Edge', aliases: ['edge', 'microsoft edge', 'ms edge'], paths: P('%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe', '%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe') },
  { id: 'firefox', name: 'Mozilla Firefox', aliases: ['firefox', 'mozilla firefox', 'fire fox'], paths: P('%ProgramFiles%\\Mozilla Firefox\\firefox.exe', '%ProgramFiles(x86)%\\Mozilla Firefox\\firefox.exe') },
  { id: 'vscode', name: 'Visual Studio Code', aliases: ['vs code', 'vscode', 'v s code', 'visual studio code', 'code'], paths: P('%LOCALAPPDATA%\\Programs\\Microsoft VS Code\\Code.exe', '%ProgramFiles%\\Microsoft VS Code\\Code.exe', '%ProgramFiles(x86)%\\Microsoft VS Code\\Code.exe') },
  { id: 'visualstudio', name: 'Visual Studio', aliases: ['visual studio'], paths: P('%ProgramFiles%\\Microsoft Visual Studio\\2022\\Community\\Common7\\IDE\\devenv.exe', '%ProgramFiles%\\Microsoft Visual Studio\\2022\\Professional\\Common7\\IDE\\devenv.exe', '%ProgramFiles%\\Microsoft Visual Studio\\2022\\Enterprise\\Common7\\IDE\\devenv.exe') },
  { id: 'notepad', name: 'Notepad', aliases: ['notepad', 'note pad'], paths: P('%SystemRoot%\\System32\\notepad.exe') },
  { id: 'calculator', name: 'Calculator', aliases: ['calculator', 'calc', 'calculater'], paths: P('%SystemRoot%\\System32\\calc.exe') },
  { id: 'explorer', name: 'File Explorer', aliases: ['file explorer', 'explorer', 'windows explorer', 'files', 'my computer', 'this pc'], paths: P('%SystemRoot%\\explorer.exe') },
  { id: 'paint', name: 'Paint', aliases: ['paint', 'ms paint', 'mspaint'], paths: P('%SystemRoot%\\System32\\mspaint.exe') },
];

// Only these variables may appear in a path template.
const ENV_ALLOWED = ['ProgramFiles', 'ProgramFiles(x86)', 'LOCALAPPDATA', 'SystemRoot'];

// Words that make a request a "run a command line / admin tool" request, never an application launch.
const BLOCKED_WORDS = ['cmd', 'powershell', 'pwsh', 'terminal', 'shell', 'bash', 'wsl', 'regedit', 'registry', 'diskpart', 'msconfig', 'gpedit', 'mmc', 'runas', 'taskkill', 'wmic', 'cscript', 'wscript', 'mshta', 'rundll32'];
const BLOCKED_PHRASES = ['command prompt', 'command line', 'task scheduler', 'group policy', 'windows security', 'defender', 'antivirus', 'on screen keyboard', 'narrator', 'magnifier', 'accessibility'];
const isBlockedName = (name) => {
  const t = String(name).toLowerCase();
  const w = t.split(/[^a-z0-9]+/);
  return BLOCKED_WORDS.some((b) => w.includes(b)) || BLOCKED_PHRASES.some((p) => t.includes(p));
};

const byId = (id) => APPS.find((a) => a.id === id) || null;
const candidates = () => APPS.map((a) => ({ kind: 'app', id: a.id, name: a.name, aliases: a.aliases }));

module.exports = { APPS, ENV_ALLOWED, isBlockedName, byId, candidates };
