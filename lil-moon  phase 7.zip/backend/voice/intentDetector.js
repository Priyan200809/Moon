// Rule-based intent detection: normalised phrase -> one of a fixed set of intents. Anything else is "unknown".
// No model, no eval, no dynamic code: a phrase can only ever select one of these named intents with text slots.
const PAGES = [
  [/^(?:home|dashboard|main page|start page)$/, 'home', 'Home'],
  [/^(?:settings|preferences|options)$/, 'settings', 'Settings'],
  [/^(?:voice assistant|voice|assistant|voice page)$/, 'voice', 'Voice assistant'],
];
const T = '(?:open|show|go to|take me to|switch to|navigate to|view|display)';
const OWN = '(?:\\s+(?:me|my|the))*';

const RULES = [
  // ----- security: things voice may never do -----
  ['refused', /^(?:turn off|disable|stop|pause|remove|cancel)\s+(?:all\s+)?(?:my\s+|the\s+)?(?:restrictions?|limits?|blocking|blocks?|warnings?|privacy|security|tracking)\b.*$/, () => ({ reason: 'protection' })],
  ['refused', /^(?:delete|erase|wipe|remove|clear)\s+(?:all\s+)?(?:my\s+|the\s+)?(?:usage|website|app|application|browsing|tracking)\s+(?:data|history|records?)$/, () => ({ reason: 'data' })],
  ['refused', /^(?:run|execute|type|send)\s+(?:the\s+|a\s+)?(?:command|script|shell|powershell|cmd|sql|query|code)\b.*$/, () => ({ reason: 'command' })],
  // ----- assistant controls -----
  ['stop_listening', /^(?:stop|end|cancel|quit)\s+listening$/],
  ['start_listening', /^(?:start|begin|resume|keep)\s+listening$|^listen$/],
  ['stop_speaking', /^(?:stop|quit)\s+(?:talking|speaking)$|^(?:be\s+quiet|quiet|silence|shut\s+up)$/],
  ['repeat', /^(?:repeat(?:\s+that)?|say\s+that\s+again|what\s+did\s+you\s+say|come\s+again)$/],
  ['clear_history', /^(?:clear|delete|erase)\s+(?:my\s+|the\s+)?(?:voice\s+)?(?:command\s+)?history$/],
  ['clear_conversation', /^(?:clear|reset|start\s+over)(?:\s+(?:the|this|my))?\s*(?:conversation|chat|screen|transcript)?$/],
  // ----- system information -----
  ['time', /^(?:what(?:'s|\s+is)?\s+)?(?:the\s+)?(?:current\s+)?time(?:\s+is\s+it)?(?:\s+now)?$|^tell\s+me\s+the\s+time$|^what\s+time\s+is\s+it$/],
  ['date', /^(?:what(?:'s|\s+is)?\s+)?(?:today'?s?\s+date|the\s+date|date\s+today|today'?s?\s+date\s+is)$|^what\s+day\s+is\s+(?:it|today)$|^tell\s+me\s+the\s+date$/],
  ['limit_remaining', new RegExp(`^how\\s+much\\s+(?:time|longer)\\s+(?:is\\s+|do\\s+i\\s+have\\s+|have\\s+i\\s+got\\s+|am\\s+i\\s+allowed\\s+)?(?:left|remaining|remains)(?:\\s+(?:on|for|with|in|of)\\s+(.+?))?(?:\\s+today)?$|^(?:what(?:'s|\\s+is)\\s+)?(?:the\\s+)?time\\s+(?:left|remaining)\\s+(?:on|for)\\s+(.+?)(?:\\s+today)?$`), (m) => ({ name: m[1] || m[2] || null })],
  ['usage_target', /^how\s+(?:much|long)\s+(?:time\s+)?(?:did|have|do|was|has)\s+i\s+(?:spent|spend|used|use|been\s+(?:on|using|in)|was\s+on|am\s+i\s+on)?(?:\s+time)?(?:\s+(?:on|in|using|with))?\s*(.+?)(?:\s+today)?$/, (m) => ({ name: m[1] })],
  ['usage_target', /^how\s+much\s+(?:time\s+)?(?:on|for)\s+(.+?)\s+today$/, (m) => ({ name: m[1] })],
  ['show_limits', new RegExp(`^${T}${OWN}\\s+(?:daily\\s+)?(?:usage\\s+)?limits(?:\\s+page)?$|^what\\s+are\\s+my\\s+(?:daily\\s+)?limits$`)],
  ['show_usage', new RegExp(`^${T}${OWN}\\s+(?:app|apps|application|applications|program|programs)\\s+usage(?:\\s+(?:page|today))?$`), () => ({ kind: 'apps' })],
  ['show_usage', new RegExp(`^${T}${OWN}\\s+(?:website|websites|web|site|sites)\\s+usage(?:\\s+(?:page|today))?$`), () => ({ kind: 'sites' })],
  // ----- dashboard navigation -----
  ['open_page', new RegExp(`^${T}${OWN}\\s+(.+?)(?:\\s+(?:page|screen|tab))?$`), (m) => {
    for (const [re, page, label] of PAGES) if (re.test(m[1])) return { page, label };
    return null; // not a dashboard page: fall through to "open <something>"
  }],
  // ----- open an application or website (resolved against allowlists later; this only extracts the spoken name) -----
  ['open_target', /^(?:open|launch|start|visit|bring\s+up|load|go\s+to|take\s+me\s+to)(?:\s+up)?\s+(?:the\s+)?(.+?)(?:\s+(?:app|application|website|site|page))?$/, (m) => ({ name: m[1] })],
  // ----- answers to a pending question -----
  ['confirm_yes', /^(?:yes|yeah|yep|yup|sure|ok|okay|confirm|do it|go ahead|correct|that'?s right|affirmative)$/],
  ['confirm_no', /^(?:no|nope|nah|cancel|never\s*mind|don'?t|stop|negative|wrong|that'?s wrong)$/],
  ['confirm_choice', /^(?:the\s+)?(first|second|third|fourth|1|2|3|4|one|two|three|four)(?:\s+one)?$/, (m) => ({ index: ({ first: 0, one: 0, 1: 0, second: 1, two: 1, 2: 1, third: 2, three: 2, 3: 2, fourth: 3, four: 3, 4: 3 })[m[1]] })],
];

function detect(text) {
  for (const [name, re, slots] of RULES) {
    const m = re.exec(text);
    if (!m) continue;
    const s = slots ? slots(m) : {};
    if (s === null) continue;
    if (name === 'open_target' && /^(?:listening|listen)$/.test(m[1])) continue;
    if (name === 'clear_conversation' && !/conversation|chat|screen|transcript/.test(text)) continue; // bare "clear" is too easy to mishear
    return { name, slots: s };
  }
  return { name: 'unknown', slots: {} };
}

module.exports = { detect };
