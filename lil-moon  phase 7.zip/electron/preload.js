// Only fixed, argument-free commands are exposed. The main process validates the sender of each one.
const { contextBridge, ipcRenderer } = require('electron');

const cmd = (channel) => () => ipcRenderer.send(channel);

contextBridge.exposeInMainWorld(
  'lilMoon',
  Object.freeze({
    moon: Object.freeze({
      dragStart: cmd('moon:drag-start'),
      dragMove: cmd('moon:drag-move'),
      dragEnd: cmd('moon:drag-end'),
      openDashboard: cmd('dashboard:open'),
      showMenu: cmd('moon:menu'),
    }),
    dashboard: Object.freeze({
      minimize: cmd('dashboard:minimize'),
      close: cmd('dashboard:close'),
      toggleMaximize: cmd('dashboard:toggle-maximize'),
      exitApp: cmd('app:exit'),
    }),
    // Voice: a few fixed operations. The only argument is a language code, which the main process validates against an allowlist.
    voice: Object.freeze({
      start: (language) => ipcRenderer.invoke('voice:start', { language: String(language) }),
      stop: cmd('voice:stop'),
      permission: () => ipcRenderer.invoke('voice:permission'),
      openMicrophoneSettings: cmd('voice:open-mic-settings'),
      takeActivation: () => ipcRenderer.invoke('voice:take-activation'),
      onEvent: (cb) => { if (typeof cb !== 'function') return () => {}; const h = (_e, d) => cb(d); ipcRenderer.on('voice:event', h); return () => ipcRenderer.removeListener('voice:event', h); },
      onActivate: (cb) => { if (typeof cb !== 'function') return () => {}; const h = () => cb(); ipcRenderer.on('voice:activate', h); return () => ipcRenderer.removeListener('voice:activate', h); },
    }),
    getApiConfig: () => ipcRenderer.invoke('api:config'),
    getVersion: () => ipcRenderer.invoke('app:version'),
  })
);
