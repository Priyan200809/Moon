// Websites voice may open: a fixed list plus the sites on the user's own tracked list. Links are always https, built here
// from a validated host, never from raw speech. Dangerous schemes (javascript:, file:, data:, http:, custom protocols) cannot pass.
const Domain = require('../../extension/lib/domain.js');

const SITES = [
  { domain: 'youtube.com', name: 'YouTube', url: 'https://www.youtube.com/', aliases: ['youtube', 'you tube', 'utube'] },
  { domain: 'instagram.com', name: 'Instagram', url: 'https://www.instagram.com/', aliases: ['instagram', 'insta'] },
  { domain: 'google.com', name: 'Google', url: 'https://www.google.com/', aliases: ['google', 'google search'] },
  { domain: 'github.com', name: 'GitHub', url: 'https://github.com/', aliases: ['github', 'git hub'] },
  { domain: 'reddit.com', name: 'Reddit', url: 'https://www.reddit.com/', aliases: ['reddit'] },
  { domain: 'linkedin.com', name: 'LinkedIn', url: 'https://www.linkedin.com/', aliases: ['linkedin', 'linked in'] },
  { domain: 'mail.google.com', name: 'Gmail', url: 'https://mail.google.com/', aliases: ['gmail', 'google mail', 'g mail'] },
  { domain: 'wikipedia.org', name: 'Wikipedia', url: 'https://www.wikipedia.org/', aliases: ['wikipedia'] },
  { domain: 'stackoverflow.com', name: 'Stack Overflow', url: 'https://stackoverflow.com/', aliases: ['stack overflow', 'stackoverflow'] },
  { domain: 'facebook.com', name: 'Facebook', url: 'https://www.facebook.com/', aliases: ['facebook'] },
  { domain: 'netflix.com', name: 'Netflix', url: 'https://www.netflix.com/', aliases: ['netflix'] },
  { domain: 'spotify.com', name: 'Spotify', url: 'https://open.spotify.com/', aliases: ['spotify web', 'spotify website'] },
];

// Fixed sites + the user's tracked list (a tracked domain adds a site, or renames a fixed one).
function candidates(trackedWebsites = []) {
  const out = new Map(SITES.map((s) => [s.domain, { kind: 'site', id: s.domain, domain: s.domain, name: s.name, url: s.url, aliases: [...s.aliases, s.domain], tracked: false }]));
  for (const w of trackedWebsites) {
    const label = w.domain.split('.')[0];
    const cur = out.get(w.domain);
    if (cur) { cur.tracked = true; cur.aliases = [...new Set([...cur.aliases, w.displayName.toLowerCase()])]; continue; }
    out.set(w.domain, { kind: 'site', id: w.domain, domain: w.domain, name: w.displayName, url: `https://${w.domain}/`, aliases: [w.displayName.toLowerCase(), label, w.domain], tracked: true });
  }
  return [...out.values()];
}

// Strict check of the only thing ever handed to the system browser. Returns the normalised URL string or null.
function validateUrl(value) {
  let u;
  try { u = new URL(String(value)); } catch { return null; }
  if (u.protocol !== 'https:' || u.username || u.password || u.port) return null;
  if (!Domain.isHostname(u.hostname.toLowerCase())) return null;
  if (u.href.length > 2048) return null;
  return u.href;
}

// "github.com" said aloud -> https://github.com/ ; anything that is not a plain hostname -> null.
function urlFromSpokenHost(text) {
  const t = String(text).trim().toLowerCase();
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(t) || !Domain.isHostname(t)) return null;
  return validateUrl(`https://${t}/`);
}

module.exports = { SITES, candidates, validateUrl, urlFromSpokenHost };
