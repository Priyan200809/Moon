import { useState } from 'react';
import AsyncBoundary from '../components/AsyncBoundary.jsx';
import DashboardCard from '../components/DashboardCard.jsx';
import { useSettings } from '../hooks/useSettings.jsx';
import { fmtSec } from '../lib/format.js';

const THEMES = [['sunny', 'Sunny yellow'], ['cream', 'Cream'], ['lilac', 'Lilac']];

function SettingsForm({ settings, save }) {
  const [minutes, setMinutes] = useState(Math.round(settings.dailyLimitSeconds / 60));
  const [theme, setTheme] = useState(settings.theme);
  const [msg, setMsg] = useState({ text: '', error: false });
  const [busy, setBusy] = useState(false);
  const minutesOk = Number.isInteger(minutes) && minutes >= 5 && minutes <= 1440;
  const dirty = minutes !== Math.round(settings.dailyLimitSeconds / 60) || theme !== settings.theme;
  const edit = (fn) => (v) => { fn(v); setMsg({ text: '', error: false }); };

  const onSave = async () => {
    setBusy(true);
    try {
      await save({ dailyLimitSeconds: minutes * 60, theme });
      setMsg({ text: 'Settings saved.', error: false });
    } catch (err) {
      setMsg({ text: err.message, error: true });
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="grid">
        <DashboardCard title="Daily limit" badge="Saved in database">
          <label className="field">Minutes per day
            <input type="number" min="5" max="1440" step="5" value={Number.isNaN(minutes) ? '' : minutes}
              onChange={(e) => edit(setMinutes)(e.target.valueAsNumber)} aria-invalid={!minutesOk} />
          </label>
          <p className="note">{minutesOk ? `That is ${fmtSec(minutes * 60)} a day.` : 'Enter a whole number from 5 to 1440.'} Used as the limit on the usage pages.</p>
        </DashboardCard>

        <DashboardCard title="Theme" tone="purple" badge="Saved in database">
          <fieldset className="choices">
            <legend>Dashboard background</legend>
            {THEMES.map(([id, label]) => (
              <label key={id} className="row"><input type="radio" name="theme" checked={theme === id} onChange={() => edit(setTheme)(id)} /> {label}</label>
            ))}
          </fieldset>
        </DashboardCard>

        <DashboardCard title="Startup" tone="cream" badge="Placeholder">
          <label className="row"><input type="checkbox" disabled /> Start Lil Moon with Windows</label>
          <p className="note">Not available yet. This choice is not saved.</p>
        </DashboardCard>
      </div>

      <div className="save-bar">
        <button className="btn btn-strong" onClick={onSave} disabled={!minutesOk || !dirty || busy}>Save settings</button>
        <span role="status" className={msg.error ? 'msg-error' : ''}>{msg.text}</span>
      </div>
    </>
  );
}

export default function SettingsPage() {
  const { query, save } = useSettings();
  return (
    <>
      <div className="page-head"><h1>Settings</h1></div>
      <AsyncBoundary query={query}>
        {query.data && <SettingsForm settings={query.data} save={save} />}
      </AsyncBoundary>
    </>
  );
}
