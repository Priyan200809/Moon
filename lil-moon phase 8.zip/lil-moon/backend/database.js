// SQLite via Node's built-in node:sqlite (no native module to compile). Used from Electron's main process.
// TIME STRATEGY: every timestamp column holds UTC ISO-8601 with milliseconds ("2026-10-25T14:03:09.120Z").
// session_date is the LOCAL calendar day (YYYY-MM-DD) of started_at on this machine; "today" means the local day.
const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const { ingestSegments } = require('./websiteIngest');
const path = require('path');

const DEFAULT_DAILY_LIMIT_SECONDS = 10800; // 3 hours
const THEMES = ['sunny', 'cream', 'lilac'];

// Append-only list. Index i upgrades schema version i -> i+1 (tracked in PRAGMA user_version).
const MIGRATIONS = [
  `CREATE TABLE user_settings (
     id INTEGER PRIMARY KEY CHECK (id = 1),
     daily_limit_seconds INTEGER NOT NULL DEFAULT ${DEFAULT_DAILY_LIMIT_SECONDS} CHECK (daily_limit_seconds BETWEEN 300 AND 86400),
     theme TEXT NOT NULL DEFAULT 'sunny' CHECK (theme IN ('sunny','cream','lilac')),
     created_at TEXT NOT NULL,
     updated_at TEXT NOT NULL
   );
   CREATE TABLE applications (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     app_name TEXT NOT NULL CHECK (length(trim(app_name)) BETWEEN 1 AND 200),
     executable_name TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(executable_name)) BETWEEN 1 AND 260),
     is_enabled INTEGER NOT NULL DEFAULT 1 CHECK (is_enabled IN (0,1))
   );
   CREATE TABLE websites (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     domain TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(domain)) BETWEEN 1 AND 253),
     display_name TEXT NOT NULL CHECK (length(trim(display_name)) BETWEEN 1 AND 200),
     is_enabled INTEGER NOT NULL DEFAULT 1 CHECK (is_enabled IN (0,1))
   );
   CREATE TABLE usage_sessions (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     category TEXT NOT NULL CHECK (category IN ('application','website')),
     item_name TEXT NOT NULL CHECK (length(trim(item_name)) BETWEEN 1 AND 200),
     started_at TEXT NOT NULL,
     ended_at TEXT NOT NULL,
     duration_seconds INTEGER NOT NULL CHECK (duration_seconds BETWEEN 0 AND 86400),
     session_date TEXT NOT NULL CHECK (session_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
     CHECK (ended_at >= started_at)
   );
   CREATE INDEX idx_usage_date_item ON usage_sessions (session_date, category, item_name);
   CREATE INDEX idx_usage_item_start ON usage_sessions (category, item_name, started_at);
   CREATE INDEX idx_usage_started ON usage_sessions (started_at);
   CREATE TABLE restriction_events (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     category TEXT NOT NULL CHECK (category IN ('application','website')),
     item_name TEXT NOT NULL CHECK (length(trim(item_name)) BETWEEN 1 AND 200),
     event_type TEXT NOT NULL CHECK (event_type IN ('limit_warning','limit_reached','blocked')),
     created_at TEXT NOT NULL
   );
   CREATE INDEX idx_restriction_created ON restriction_events (created_at);
   CREATE INDEX idx_restriction_item ON restriction_events (category, item_name, created_at);`,
  // v2 (Phase 5): website tracking support
  `ALTER TABLE user_settings ADD COLUMN idle_threshold_seconds INTEGER NOT NULL DEFAULT 60 CHECK (idle_threshold_seconds BETWEEN 15 AND 3600);
   ALTER TABLE user_settings ADD COLUMN website_tracking_enabled INTEGER NOT NULL DEFAULT 1 CHECK (website_tracking_enabled IN (0,1));
   ALTER TABLE websites ADD COLUMN match_mode TEXT NOT NULL DEFAULT 'subdomains' CHECK (match_mode IN ('subdomains','exact'));
   CREATE TABLE ingest_log (
     client_id TEXT PRIMARY KEY CHECK (length(client_id) BETWEEN 8 AND 64),
     received_at TEXT NOT NULL
   );
   CREATE INDEX idx_ingest_received ON ingest_log (received_at);
   CREATE TABLE extension_pairing (
     id INTEGER PRIMARY KEY CHECK (id = 1),
     token_hash TEXT NOT NULL,
     created_at TEXT NOT NULL,
     last_seen_at TEXT
   );
   INSERT OR IGNORE INTO websites (domain, display_name) VALUES
     ('youtube.com','YouTube'), ('instagram.com','Instagram'), ('github.com','GitHub'), ('reddit.com','Reddit'), ('linkedin.com','LinkedIn');`,
  // v3 (Phase 8): AI assistant, conversations, memory, local file index
  `CREATE TABLE ai_settings (
     id INTEGER PRIMARY KEY CHECK (id = 1),
     provider TEXT NOT NULL DEFAULT 'openai-compatible' CHECK (provider IN ('openai-compatible','anthropic')),
     model TEXT NOT NULL DEFAULT '' CHECK (length(model) <= 200),
     base_url TEXT NOT NULL DEFAULT '' CHECK (length(base_url) <= 300),
     memory_enabled INTEGER NOT NULL DEFAULT 1 CHECK (memory_enabled IN (0,1)),
     allow_file_excerpts INTEGER NOT NULL DEFAULT 0 CHECK (allow_file_excerpts IN (0,1)),
     updated_at TEXT NOT NULL
   );
   INSERT OR IGNORE INTO ai_settings (id, updated_at) VALUES (1, strftime('%Y-%m-%dT%H:%M:%fZ','now'));
   CREATE TABLE conversations (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     title TEXT NOT NULL CHECK (length(trim(title)) BETWEEN 1 AND 200),
     created_at TEXT NOT NULL,
     updated_at TEXT NOT NULL
   );
   CREATE INDEX idx_conversations_updated ON conversations (updated_at);
   CREATE TABLE messages (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     conversation_id INTEGER NOT NULL REFERENCES conversations (id) ON DELETE CASCADE,
     role TEXT NOT NULL CHECK (role IN ('user','assistant')),
     content TEXT NOT NULL,
     created_at TEXT NOT NULL,
     provider TEXT,
     model TEXT,
     sources_json TEXT
   );
   CREATE INDEX idx_messages_conversation ON messages (conversation_id, id);
   CREATE TABLE memories (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     category TEXT NOT NULL CHECK (category IN ('preference','project','fact','task','instruction')),
     content TEXT NOT NULL CHECK (length(trim(content)) BETWEEN 1 AND 500),
     origin TEXT NOT NULL CHECK (origin IN ('user','confirmed')),
     source_conversation_id INTEGER REFERENCES conversations (id) ON DELETE SET NULL,
     created_at TEXT NOT NULL,
     updated_at TEXT NOT NULL
   );
   CREATE TABLE memory_candidates (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     category TEXT NOT NULL CHECK (category IN ('preference','project','fact','task','instruction')),
     content TEXT NOT NULL CHECK (length(trim(content)) BETWEEN 1 AND 500),
     conversation_id INTEGER REFERENCES conversations (id) ON DELETE CASCADE,
     created_at TEXT NOT NULL
   );
   CREATE TABLE memory_avoid (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     phrase TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(phrase)) BETWEEN 2 AND 200),
     created_at TEXT NOT NULL
   );
   CREATE TABLE indexed_folders (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     path TEXT NOT NULL UNIQUE,
     added_at TEXT NOT NULL,
     last_indexed_at TEXT,
     status TEXT NOT NULL DEFAULT 'idle' CHECK (status IN ('idle','indexing','error')),
     last_error TEXT
   );
   CREATE TABLE indexed_files (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     folder_id INTEGER NOT NULL REFERENCES indexed_folders (id) ON DELETE CASCADE,
     rel_path TEXT NOT NULL,
     name TEXT NOT NULL,
     ext TEXT NOT NULL,
     size_bytes INTEGER NOT NULL,
     mtime_ms INTEGER NOT NULL,
     content_hash TEXT,
     indexed_at TEXT NOT NULL,
     status TEXT NOT NULL CHECK (status IN ('indexed','skipped','error')),
     note TEXT,
     UNIQUE (folder_id, rel_path)
   );
   CREATE INDEX idx_files_name ON indexed_files (name COLLATE NOCASE);
   CREATE TABLE file_chunks (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     file_id INTEGER NOT NULL REFERENCES indexed_files (id) ON DELETE CASCADE,
     chunk_no INTEGER NOT NULL,
     heading TEXT,
     text TEXT NOT NULL,
     UNIQUE (file_id, chunk_no)
   );
   CREATE VIRTUAL TABLE file_chunks_fts USING fts5 (text, heading, content = 'file_chunks', content_rowid = 'id', tokenize = 'porter unicode61');
   CREATE TRIGGER file_chunks_ai AFTER INSERT ON file_chunks BEGIN
     INSERT INTO file_chunks_fts (rowid, text, heading) VALUES (new.id, new.text, new.heading);
   END;
   CREATE TRIGGER file_chunks_ad AFTER DELETE ON file_chunks BEGIN
     INSERT INTO file_chunks_fts (file_chunks_fts, rowid, text, heading) VALUES ('delete', old.id, old.text, old.heading);
   END;
   CREATE TRIGGER file_chunks_au AFTER UPDATE ON file_chunks BEGIN
     INSERT INTO file_chunks_fts (file_chunks_fts, rowid, text, heading) VALUES ('delete', old.id, old.text, old.heading);
     INSERT INTO file_chunks_fts (rowid, text, heading) VALUES (new.id, new.text, new.heading);
   END;
   CREATE TABLE tool_log (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     conversation_id INTEGER REFERENCES conversations (id) ON DELETE SET NULL,
     tool TEXT NOT NULL,
     args_json TEXT NOT NULL,
     outcome TEXT NOT NULL,
     created_at TEXT NOT NULL
   );
   CREATE INDEX idx_tool_log_created ON tool_log (created_at);`,
];

const nowIso = () => new Date().toISOString();
const pad = (n) => String(n).padStart(2, '0');
const localDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

function migrate(db) {
  const version = db.prepare('PRAGMA user_version').get().user_version;
  if (version > MIGRATIONS.length) throw new Error(`Database schema ${version} is newer than this Lil Moon understands.`);
  for (let i = version; i < MIGRATIONS.length; i++) {
    db.exec('BEGIN');
    try {
      db.exec(MIGRATIONS[i]);
      db.exec(`PRAGMA user_version = ${i + 1}`);
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  }
}

// Inserts the single settings row only if none exists. legacy = Phase 2 preferences, imported once if valid.
function seedSettings(db, legacy) {
  let seconds = DEFAULT_DAILY_LIMIT_SECONDS;
  let theme = 'sunny';
  const m = legacy?.defaultDailyLimitMin;
  if (Number.isInteger(m) && m * 60 >= 300 && m * 60 <= 86400) seconds = m * 60;
  if (THEMES.includes(legacy?.theme)) theme = legacy.theme;
  const t = nowIso();
  db.prepare('INSERT OR IGNORE INTO user_settings (id, daily_limit_seconds, theme, created_at, updated_at) VALUES (1, ?, ?, ?, ?)').run(seconds, theme, t, t);
}

function openDatabase(file, { legacyPreferences } = {}) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  try {
    db.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;');
    if (file !== ':memory:') db.exec('PRAGMA journal_mode = WAL;');
    migrate(db);
    seedSettings(db, legacyPreferences);
    return db;
  } catch (err) {
    try { db.close(); } catch { /* already unusable */ }
    throw err;
  }
}

// All SQL lives here and is parameterized; no caller-supplied text is ever concatenated into a statement.
function createRepository(db) {
  const conflict = (message) => Object.assign(new Error(message), { httpStatus: 409, code: 'conflict' });
  const session = (r) => ({ id: r.id, category: r.category, itemName: r.item_name, startedAt: r.started_at, endedAt: r.ended_at, durationSeconds: r.duration_seconds, sessionDate: r.session_date });
  const site = (r) => ({ id: r.id, domain: r.domain, displayName: r.display_name, isEnabled: r.is_enabled === 1, matchMode: r.match_mode });
  const settings = () => {
    const r = db.prepare('SELECT daily_limit_seconds, theme, idle_threshold_seconds, website_tracking_enabled, created_at, updated_at FROM user_settings WHERE id = 1').get();
    return { dailyLimitSeconds: r.daily_limit_seconds, theme: r.theme, idleThresholdSeconds: r.idle_threshold_seconds, websiteTrackingEnabled: r.website_tracking_enabled === 1, createdAt: r.created_at, updatedAt: r.updated_at };
  };
  const siteById = (id) => { const r = db.prepare('SELECT * FROM websites WHERE id = ?').get(id); return r ? site(r) : null; };
  return {
    schemaVersion: () => db.prepare('PRAGMA user_version').get().user_version,
    getSettings: settings,
    updateSettings(patch) {
      const cur = settings();
      const next = { ...cur, ...patch };
      db.prepare('UPDATE user_settings SET daily_limit_seconds = ?, theme = ?, idle_threshold_seconds = ?, website_tracking_enabled = ?, updated_at = ? WHERE id = 1')
        .run(next.dailyLimitSeconds, next.theme, next.idleThresholdSeconds, next.websiteTrackingEnabled ? 1 : 0, nowIso());
      return settings();
    },
    listApplications: () => db.prepare('SELECT id, app_name, executable_name, is_enabled FROM applications ORDER BY app_name COLLATE NOCASE, id').all()
      .map((r) => ({ id: r.id, appName: r.app_name, executableName: r.executable_name, isEnabled: r.is_enabled === 1 })),
    listWebsites: () => db.prepare('SELECT * FROM websites ORDER BY display_name COLLATE NOCASE, id').all().map(site),
    addWebsite({ domain, displayName, matchMode }) {
      try {
        const info = db.prepare('INSERT INTO websites (domain, display_name, match_mode) VALUES (?, ?, ?)').run(domain, displayName, matchMode);
        return siteById(Number(info.lastInsertRowid));
      } catch (err) {
        if (/UNIQUE/i.test(err.message)) throw conflict('That website is already in the list.');
        throw err;
      }
    },
    updateWebsite(id, patch) {
      const cur = siteById(id);
      if (!cur) return null;
      const n = { ...cur, ...patch };
      db.prepare('UPDATE websites SET display_name = ?, match_mode = ?, is_enabled = ? WHERE id = ?').run(n.displayName, n.matchMode, n.isEnabled ? 1 : 0, id);
      return siteById(id);
    },
    deleteWebsite: (id) => db.prepare('DELETE FROM websites WHERE id = ?').run(id).changes > 0,
    deleteWebsiteHistory: () => db.prepare("DELETE FROM usage_sessions WHERE category = 'website'").run().changes,
    getPairing() {
      const r = db.prepare('SELECT token_hash, created_at, last_seen_at FROM extension_pairing WHERE id = 1').get();
      return r ? { tokenHash: r.token_hash, createdAt: r.created_at, lastSeenAt: r.last_seen_at } : null;
    },
    setPairing: (hash) => db.prepare('INSERT OR REPLACE INTO extension_pairing (id, token_hash, created_at, last_seen_at) VALUES (1, ?, ?, NULL)').run(hash, nowIso()),
    clearPairing: () => db.prepare('DELETE FROM extension_pairing WHERE id = 1').run().changes > 0,
    touchPairing: (iso) => db.prepare('UPDATE extension_pairing SET last_seen_at = ? WHERE id = 1').run(iso),
    pruneIngestLog: (beforeIso) => db.prepare('DELETE FROM ingest_log WHERE received_at < ?').run(beforeIso),
    ingestWebsite: (segments, ctx) => ingestSegments(db, segments, ctx),
    usageToday(category) {
      const date = localDate(new Date());
      const rows = db.prepare(
        `SELECT category, item_name, SUM(duration_seconds) AS total, COUNT(*) AS n FROM usage_sessions
         WHERE session_date = ? AND (? IS NULL OR category = ?)
         GROUP BY category, item_name ORDER BY total DESC, item_name COLLATE NOCASE`
      ).all(date, category ?? null, category ?? null);
      const totals = { application: 0, website: 0 };
      const items = rows.map((r) => { totals[r.category] += r.total; return { category: r.category, itemName: r.item_name, totalSeconds: r.total, sessionCount: r.n }; });
      return { date, dailyLimitSeconds: settings().dailyLimitSeconds, totals, items };
    },
    usageHistory({ from, to, category, limit, offset }) {
      const where = ['1 = 1'];
      const args = [];
      if (from) { where.push('session_date >= ?'); args.push(from); }
      if (to) { where.push('session_date <= ?'); args.push(to); }
      if (category) { where.push('category = ?'); args.push(category); }
      const clause = where.join(' AND '); // fixed fragments only; values are bound
      const total = db.prepare(`SELECT COUNT(*) AS n FROM usage_sessions WHERE ${clause}`).get(...args).n;
      const records = db.prepare(`SELECT * FROM usage_sessions WHERE ${clause} ORDER BY started_at DESC, id DESC LIMIT ? OFFSET ?`).all(...args, limit, offset).map(session);
      return { records, total, limit, offset };
    },
    insertSession(s) {
      const sessionDate = localDate(new Date(s.startedAt));
      const info = db.prepare('INSERT INTO usage_sessions (category, item_name, started_at, ended_at, duration_seconds, session_date) VALUES (?, ?, ?, ?, ?, ?)')
        .run(s.category, s.itemName, s.startedAt, s.endedAt, s.durationSeconds, sessionDate);
      return session(db.prepare('SELECT * FROM usage_sessions WHERE id = ?').get(Number(info.lastInsertRowid)));
    },
    deleteSession: (id) => db.prepare('DELETE FROM usage_sessions WHERE id = ?').run(id).changes > 0,
  };
}

module.exports = { openDatabase, createRepository, MIGRATIONS, DEFAULT_DAILY_LIMIT_SECONDS, THEMES, MIGRATION_COUNT: MIGRATIONS.length };
