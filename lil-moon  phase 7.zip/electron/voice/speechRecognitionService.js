// Speech-to-text for push-to-talk: ONE utterance per press, then the microphone is released.
//  * Engine "windows-sapi": Windows' built-in offline recogniser, driven by a fixed script (see sapiScript.js). Local; no network.
//  * The microphone is only ever opened by start(), which only a user action reaches (button, or the moon menu item).
//  * stop() kills the recogniser at once. A hard time limit stops a session that somehow never ends.
//  * Only validated, length-limited text events leave this module.
// The engine is behind a tiny interface (start/stop/events) so a different local engine (e.g. Whisper or Vosk) can replace it later.
const childProcess = require('child_process');
const { encoded } = require('./sapiScript');

const LANGUAGES = ['en-US', 'ta-IN'];
const HARD_LIMIT_MS = 20000;
const MESSAGES = {
  permission_denied: 'Windows is blocking microphone access. Open Windows Settings > Privacy & security > Microphone and allow desktop apps to use it.',
  no_microphone: 'No microphone was found. Plug one in, or pick your microphone in Windows Sound settings, then try again.',
  unsupported_language: "That language isn't installed for Windows speech recognition. Switch to English, or add the language in Windows Settings > Time & language > Speech.",
  unsupported_platform: 'Voice input needs Windows. You can still type commands.',
  engine_unavailable: "Windows speech recognition isn't available on this computer. You can still type commands.",
  microphone_error: 'The microphone stopped working. Check it is connected and not in use by another app, then try again.',
  timeout: "I didn't hear anything. Press the microphone and try again.",
  noise: "I couldn't make that out. Try again a little closer to the microphone, with less background noise.",
  busy: "I'm already listening.",
  failed: "Speech recognition couldn't start. You can still type commands.",
};
const err = (code) => ({ ok: false, error: { code, message: MESSAGES[code] || MESSAGES.failed } });

function createSpeechRecognitionService({ spawn = childProcess.spawn, platform = process.platform, env = process.env, getMicStatus = () => 'unknown', send, setTimeoutFn = setTimeout, clearTimeoutFn = clearTimeout }) {
  let child = null, state = 'idle', killer = null, gotFinal = false, ended = false;

  const emit = (e) => { try { send(e); } catch { /* the window may be gone */ } };
  const setState = (s) => { if (state !== s) { state = s; emit({ type: 'state', state: s }); } };

  function finish(reason) {
    if (ended) return;
    ended = true;
    if (killer) { clearTimeoutFn(killer); killer = null; }
    if (child) { try { child.kill(); } catch { /* already gone */ } child = null; }
    setState('idle');
    if (reason) emit(reason);
  }

  // Accept only the few message shapes the script can produce, with bounded text.
  function handle(msg) {
    if (ended || !msg || typeof msg.type !== 'string') return; // nothing is accepted after the session has ended
    switch (msg.type) {
      case 'ready': setState('listening'); break;
      case 'partial': if (typeof msg.text === 'string') emit({ type: 'partial', text: msg.text.slice(0, 300) }); break;
      case 'final': {
        if (typeof msg.text !== 'string') break;
        gotFinal = true;
        const text = msg.text.trim().slice(0, 300);
        const confidence = typeof msg.confidence === 'number' && msg.confidence >= 0 && msg.confidence <= 1 ? msg.confidence : 0.5;
        if (!text) { finish({ type: 'error', code: 'noise', message: MESSAGES.noise }); break; }
        setState('processing');
        finish({ type: 'final', text, confidence });
        break;
      }
      case 'rejected': if (!gotFinal) finish({ type: 'error', code: 'noise', message: MESSAGES.noise }); break;
      case 'timeout': if (!gotFinal) finish({ type: 'error', code: 'timeout', message: MESSAGES.timeout }); break;
      case 'error': { const code = MESSAGES[msg.code] ? msg.code : 'failed'; finish({ type: 'error', code, message: MESSAGES[code] }); break; }
      default: break;
    }
  }

  return {
    state: () => state,
    start({ language } = {}) {
      if (state !== 'idle') return err('busy');
      if (platform !== 'win32') return err('unsupported_platform');
      if (!LANGUAGES.includes(language)) return err('unsupported_language');
      const mic = getMicStatus();
      if (mic === 'denied' || mic === 'restricted') return err('permission_denied');
      try {
        child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', encoded()], {
          windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'], shell: false,
          env: { ...env, LILMOON_LANG: language, LILMOON_TIMEOUT: '8' },
        });
      } catch { child = null; return err('engine_unavailable'); }
      ended = false; gotFinal = false;
      setState('starting');
      let buf = '';
      child.stdout.setEncoding('utf8');
      child.stdout.on('data', (chunk) => {
        buf += chunk;
        if (buf.length > 20000) buf = buf.slice(-20000);
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (!line) continue;
          try { handle(JSON.parse(line)); } catch { /* ignore anything that is not our JSON */ }
        }
      });
      child.once('error', () => finish({ type: 'error', code: 'engine_unavailable', message: MESSAGES.engine_unavailable }));
      child.once('exit', () => { if (!ended) finish({ type: 'error', code: 'failed', message: MESSAGES.failed }); });
      killer = setTimeoutFn(() => finish({ type: 'error', code: 'timeout', message: MESSAGES.timeout }), HARD_LIMIT_MS);
      return { ok: true };
    },
    // Immediate and unconditional: the person pressed Stop.
    stop() { if (state === 'idle') return { ok: true }; finish({ type: 'stopped' }); return { ok: true }; },
  };
}

module.exports = { createSpeechRecognitionService, LANGUAGES, MESSAGES };
