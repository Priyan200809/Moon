// Local-only REST API inside Electron's main process (no second main process, no second server).
//   /api/*  dashboard: per-launch bearer token, only our own pages' Origin
//   /ext/*  browser extension: user-generated pairing code, only the pinned extension Origin
// Both: 127.0.0.1 only, Host allow-list (DNS rebinding), JSON only, parameterized SQL, no filesystem or shell access.
const express = require('express');
const crypto = require('crypto');
const v = require('./validators');
const pairing = require('./pairing');
const { HttpError } = v;
const { mountAiRoutes } = require('./aiRoutes');

const PREFERRED_PORTS = Array.from({ length: 10 }, (_, i) => 47821 + i); // the extension scans this range
const CONNECTED_WINDOW_MS = 90 * 1000;

const ok = (res, data, status = 200) => res.status(status).json({ ok: true, data });
const safeEqual = (a, b) => {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

function createApp({ repo, token, allowedHosts, allowedOrigins, extensionOrigins = new Set(), activity = null, actions = {}, services = null }) {
  const app = express();
  app.disable('x-powered-by');
  app.disable('etag');
  const live = { lastSyncAt: null, paused: null, browser: null, version: null };
  let failures = [];

  const cors = (req, res, origins) => {
    const origin = req.headers.origin;
    if (origin === undefined) return null;
    if (!origins.has(origin)) return new HttpError(403, 'forbidden_origin', 'Origin not allowed.');
    res.set({
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Headers': 'Authorization, Content-Type',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE',
      'Access-Control-Max-Age': '600',
    });
    return null;
  };

  app.use((req, res, next) => {
    res.set({ 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', Vary: 'Origin' });
    if (!allowedHosts.has(req.headers.host)) return next(new HttpError(403, 'forbidden_host', 'Host not allowed.'));
    next();
  });

  const hasBody = (req) => req.headers['transfer-encoding'] !== undefined || Number(req.headers['content-length'] ?? 0) > 0;
  const needJson = (req, res, next) => {
    if (['POST', 'PUT', 'PATCH'].includes(req.method) && hasBody(req) && !req.is('application/json')) {
      return next(new HttpError(415, 'unsupported_media_type', 'Send Content-Type: application/json.'));
    }
    next();
  };

  // ---------------- dashboard API ----------------
  const api = express.Router();
  api.use((req, res, next) => {
    const bad = cors(req, res, allowedOrigins);
    if (bad) return next(bad);
    if (req.method === 'OPTIONS') return res.status(204).end();
    const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    if (!m || !safeEqual(m[1], token)) return next(new HttpError(401, 'unauthorized', 'Missing or invalid token.'));
    next();
  }, needJson, express.json({ limit: '16kb', strict: true }));

  api.get('/health', (req, res) => ok(res, { status: 'ok', schemaVersion: repo.schemaVersion(), time: new Date().toISOString() }));
  api.get('/settings', (req, res) => ok(res, repo.getSettings()));
  api.put('/settings', (req, res) => ok(res, repo.updateSettings(v.settingsPatch(req.body))));
  api.get('/applications', (req, res) => ok(res, repo.listApplications()));
  api.get('/websites', (req, res) => ok(res, repo.listWebsites()));
  api.post('/websites', (req, res) => ok(res, repo.addWebsite(v.websiteBody(req.body)), 201));
  api.patch('/websites/:id', (req, res) => {
    const row = repo.updateWebsite(v.recordId(req.params.id), v.websitePatch(req.body));
    if (!row) throw new HttpError(404, 'not_found', 'No such website.');
    ok(res, row);
  });
  api.delete('/websites/:id', (req, res) => {
    const id = v.recordId(req.params.id);
    if (!repo.deleteWebsite(id)) throw new HttpError(404, 'not_found', 'No such website.');
    ok(res, { id });
  });
  api.get('/usage/today', (req, res) => ok(res, repo.usageToday(v.category(req.query.category))));
  api.get('/usage/history', (req, res) => ok(res, repo.usageHistory(v.historyQuery(req.query))));
  api.post('/usage/sessions', (req, res) => ok(res, repo.insertSession(v.sessionBody(req.body)), 201));
  api.delete('/usage/sessions/:id', (req, res) => {
    const id = v.recordId(req.params.id);
    if (!repo.deleteSession(id)) throw new HttpError(404, 'not_found', 'No such session.');
    ok(res, { id });
  });
  api.delete('/usage/websites', (req, res) => ok(res, { deleted: repo.deleteWebsiteHistory() }));

  api.get('/extension/status', (req, res) => {
    const p = repo.getPairing();
    const s = repo.getSettings();
    const seen = p?.lastSeenAt ? Date.parse(p.lastSeenAt) : null;
    ok(res, {
      paired: !!p, pairedAt: p?.createdAt ?? null, lastSeenAt: p?.lastSeenAt ?? null,
      connected: seen !== null && Date.now() - seen < CONNECTED_WINDOW_MS,
      extensionPaused: live.paused, browser: live.browser, extensionVersion: live.version,
      trackingEnabled: s.websiteTrackingEnabled, idleThresholdSeconds: s.idleThresholdSeconds,
      activity: activity ? activity.state() : { inactive: false, reason: null, since: null },
    });
  });
  api.post('/extension/pairing', (req, res) => {
    const code = pairing.generateCode();
    repo.setPairing(pairing.hashCode(code));
    Object.assign(live, { lastSyncAt: null, paused: null, browser: null, version: null });
    ok(res, { code }, 201); // shown once; only its hash is stored
  });
  api.delete('/extension/pairing', (req, res) => ok(res, { revoked: repo.clearPairing() }));
  if (services) mountAiRoutes(api, { services });
  app.use('/api', api);

  // ---------------- browser-extension API ----------------
  const ext = express.Router();
  ext.use((req, res, next) => {
    const bad = cors(req, res, extensionOrigins);
    if (bad) return next(bad);
    if (req.method === 'OPTIONS') return res.status(204).end();
    next();
  });
  ext.get('/ping', (req, res) => ok(res, { app: 'lil-moon', api: 1 }));
  ext.use((req, res, next) => {
    const now = Date.now();
    failures = failures.filter((t) => now - t < 60000);
    if (failures.length >= 10) return next(new HttpError(429, 'too_many_attempts', 'Too many failed pairing attempts. Wait a minute.'));
    const p = repo.getPairing();
    const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    if (!p || !m || !pairing.verifyCode(m[1], p.tokenHash)) {
      failures.push(now);
      return next(new HttpError(401, p ? 'unauthorized' : 'not_paired', p ? 'Invalid pairing code.' : 'Lil Moon has no extension paired yet.'));
    }
    next();
  }, needJson, express.json({ limit: '64kb', strict: true }));

  ext.post('/sync', (req, res) => {
    const body = v.syncBody(req.body);
    const nowMs = Date.now();
    const settings = repo.getSettings();
    repo.touchPairing(new Date(nowMs).toISOString());
    Object.assign(live, { lastSyncAt: nowMs, paused: body.paused, browser: body.browser, version: body.version });

    const results = { accepted: [], duplicates: [], rejected: [] };
    const valid = [];
    for (const raw of body.sessions) {
      const seg = v.segment(raw);
      if (!seg.ok) results.rejected.push({ clientId: seg.clientId, reason: 'invalid' });
      else if (!settings.websiteTrackingEnabled) results.rejected.push({ clientId: seg.value.clientId, reason: 'tracking_disabled' });
      else valid.push(seg.value);
    }
    const sites = repo.listWebsites();
    const done = repo.ingestWebsite(valid, { sites, activity, nowMs });
    results.accepted.push(...done.accepted);
    results.duplicates.push(...done.duplicates);
    results.rejected.push(...done.rejected);
    repo.pruneIngestLog(new Date(nowMs - 60 * 24 * 3600 * 1000).toISOString());

    const today = repo.usageToday('website');
    ok(res, {
      config: {
        trackingEnabled: settings.websiteTrackingEnabled,
        idleThresholdSeconds: settings.idleThresholdSeconds,
        domains: sites.filter((s) => s.isEnabled).map((s) => ({ domain: s.domain, displayName: s.displayName, matchMode: s.matchMode })),
      },
      idle: activity ? activity.state() : { inactive: false, reason: null, since: null },
      results,
      today: { date: today.date, websiteSeconds: today.totals.website, items: today.items.slice(0, 5) },
      serverTime: new Date(nowMs).toISOString(),
    });
  });
  ext.post('/open-dashboard', (req, res) => {
    if (typeof actions.openDashboard === 'function') actions.openDashboard();
    ok(res, { opened: true });
  });
  app.use('/ext', ext);

  app.use((req, res, next) => next(new HttpError(404, 'not_found', 'No such endpoint.')));
  app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    const status = err.status ?? err.httpStatus;
    if (err instanceof HttpError || (err.httpStatus && err.code)) return res.status(status).json({ ok: false, error: { code: err.code, message: err.message } });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ ok: false, error: { code: 'invalid_json', message: 'Body is not valid JSON.' } });
    if (err.type === 'entity.too.large') return res.status(413).json({ ok: false, error: { code: 'too_large', message: 'Body is too large.' } });
    console.error('[lil-moon api]', err);
    res.status(500).json({ ok: false, error: { code: 'internal_error', message: 'Something went wrong in the local service.' } });
  });
  return app;
}

const listen = (app, port) => new Promise((resolve, reject) => {
  const server = app.listen(port, '127.0.0.1');
  server.once('listening', () => resolve(server));
  server.once('error', reject);
});

// Tries the fixed range first (so the extension can find us), then falls back to any free port.
async function startServer({ repo, allowedOrigins, extensionOrigins = [], activity = null, actions = {}, services = null, ports = [...PREFERRED_PORTS, 0], token = crypto.randomBytes(32).toString('hex') }) {
  const allowedHosts = new Set();
  const app = createApp({ repo, token, allowedHosts, allowedOrigins: new Set(allowedOrigins), extensionOrigins: new Set(extensionOrigins), activity, actions, services });
  let server;
  for (const p of ports) {
    try { server = await listen(app, p); break; } catch (err) { if (err.code !== 'EADDRINUSE' && err.code !== 'EACCES') throw err; }
  }
  if (!server) throw new Error('No local port available for the Lil Moon service.');
  const port = server.address().port;
  allowedHosts.add(`127.0.0.1:${port}`).add(`localhost:${port}`);
  return {
    port, token, baseUrl: `http://127.0.0.1:${port}`,
    close: () => new Promise((done) => { server.close(() => done()); server.closeAllConnections(); }),
  };
}

module.exports = { createApp, startServer, PREFERRED_PORTS };
