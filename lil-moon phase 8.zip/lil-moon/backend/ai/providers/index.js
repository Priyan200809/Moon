// Providers are interchangeable: the chat code only ever calls provider.stream(...).
// A future dedicated local-model provider is one more file here; Ollama/LM Studio already work through
// "openai-compatible" with a localhost base URL.
const openai = require('./openaiCompatible');
const anthropic = require('./anthropic');

const PROVIDERS = { 'openai-compatible': openai, anthropic };
const isLoopback = (url) => { try { const h = new URL(url).hostname; return h === 'localhost' || h === '127.0.0.1' || h === '[::1]'; } catch { return false; } };

// What is still missing before the assistant can answer? Empty array = ready.
function missingSetup(settings, hasKey) {
  const missing = [];
  if (!settings.model) missing.push('a model name');
  if (settings.provider === 'openai-compatible' && !settings.baseUrl) missing.push('the provider address');
  if (!hasKey && !(settings.provider === 'openai-compatible' && isLoopback(settings.baseUrl))) missing.push('an API key');
  return missing;
}

module.exports = { PROVIDERS, missingSetup, isLoopback, getProvider: (name) => PROVIDERS[name] };
