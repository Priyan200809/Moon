// Restricted application launcher (runs in the Electron main process only; the renderer can never reach it).
//  * Launches ONLY an id from applicationRegistry, at an absolute .exe path expanded from a fixed template.
//  * No shell, no arguments, no user-supplied text anywhere near the process call.
//  * Windows only; on other systems it reports that honestly.
const nodePath = require('path');
const nodeFs = require('fs');
const childProcess = require('child_process');
const registry = require('./applicationRegistry');

function createAppLauncher({ platform = process.platform, env = process.env, existsSync = (p) => nodeFs.existsSync(p) && nodeFs.statSync(p).isFile(), spawn = childProcess.spawn, apps = registry } = {}) {
  const win = nodePath.win32;

  function expand(template) {
    let ok = true;
    const out = template.replace(/%([A-Za-z0-9()]+)%/g, (_, name) => {
      const key = apps.ENV_ALLOWED.find((k) => k.toLowerCase() === name.toLowerCase());
      const val = key && Object.entries(env).find(([k]) => k.toLowerCase() === key.toLowerCase())?.[1];
      if (!val) ok = false;
      return val || '';
    });
    return ok ? win.normalize(out) : null;
  }

  function resolvePath(id) {
    const app = typeof id === 'string' ? apps.byId(id) : null;
    if (!app) return null;
    for (const tpl of app.paths) {
      const p = expand(tpl);
      if (p && win.isAbsolute(p) && p.toLowerCase().endsWith('.exe') && !p.includes('..') && existsSync(p)) return p;
    }
    return null;
  }

  return {
    resolvePath,
    isInstalled: (id) => platform === 'win32' && resolvePath(id) !== null,
    async launch(id) {
      if (!apps.byId(id)) return { ok: false, code: 'unknown_app' };
      if (platform !== 'win32') return { ok: false, code: 'unsupported_platform' };
      const exe = resolvePath(id);
      if (!exe) return { ok: false, code: 'not_found' };
      return new Promise((resolve) => {
        try {
          const child = spawn(exe, [], { detached: true, stdio: 'ignore', shell: false, windowsHide: false });
          child.once('error', () => resolve({ ok: false, code: 'launch_failed' }));
          child.once('spawn', () => { child.unref(); resolve({ ok: true }); });
        } catch { resolve({ ok: false, code: 'launch_failed' }); }
      });
    },
  };
}

module.exports = { createAppLauncher };
