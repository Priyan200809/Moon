// Phase 6 website enforcement: the extension core against the real backend and limit engine. Only the `chrome` object is simulated.
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer, EXT_PORTS } = require('../backend/server');
const { createTracker } = require('../backend/websiteTracker');
const { createLimitEngine } = require('../backend/limits');
const Core = require('../extension/lib/core.js');
const Domain = require('../extension/lib/domain.js');

const clock = { t: new Date(2026, 9, 31, 12, 0, 0).getTime() };
const U = { yt: 'https://www.youtube.com/watch?v=1', ytSub: 'https://m.youtube.com/feed', gh: 'https://github.com/x', fake: 'https://notyoutube.com/', evil: 'https://youtube.com.evil.example/', rd: 'https://www.reddit.com/r/x' };
const BLOCK = 'chrome-extension://testid/blocked.html?d=';

function mockChrome() {
  const local = {}, session = {};
  const c = {
    local, session, updates: [],
    tabs: [{ id: 1, windowId: 1, active: true, incognito: false, url: U.gh }, { id: 2, windowId: 1, active: false, incognito: false, url: U.yt }],
    win: { id: 1, focused: true, state: 'normal', incognito: false },
    storage: {
      local: { get: async (k) => Object.fromEntries((Array.isArray(k) ? k : [k]).filter((x) => x in local).map((x) => [x, structuredClone(local[x])])), set: async (o) => { Object.assign(local, structuredClone(o)); } },
      session: { get: async (k) => Object.fromEntries((Array.isArray(k) ? k : [k]).filter((x) => x in session).map((x) => [x, session[x]])), set: async (o) => { Object.assign(session, o); }, remove: async (k) => { delete session[k]; } },
    },
    windows: { getLastFocused: async (o) => ({ ...c.win, tabs: o?.populate ? structuredClone(c.tabs.filter((t) => t.windowId === c.win.id)) : undefined }) },
    runtime: { getURL: (p) => `chrome-extension://testid/${p}` },
  };
  c.tabs_api = {
    query: async ({ active, windowId }) => structuredClone(c.tabs.filter((t) => (active === undefined || t.active === active) && (windowId === undefined || t.windowId === windowId))),
    update: async (id, { url }) => { c.updates.push({ id, url }); c.tabs.find((t) => t.id === id).url = url; },
  };
  c.tabsProxy = c.tabs_api;
  return c;
}

const open = [];
test.afterEach(async () => { while (open.length) await open.pop()().catch(() => {}); });

async function world() {
  clock.t = new Date(2026, 9, 31, 12, 0, 0).getTime(); // every test starts at noon on the same day
  const db = openDatabase(':memory:'); const repo = createRepository(db);
  const tracker = createTracker({ repo, now: () => clock.t });
  const engine = createLimitEngine({ repo, tracker, now: () => clock.t });
  const api = await startServer({ repo, allowedOrigins: ['null'], tracker, limits: engine, now: () => clock.t, ports: EXT_PORTS });
  const chrome = mockChrome();
  const facade = { storage: chrome.storage, windows: chrome.windows, runtime: chrome.runtime, tabs: chrome.tabs_api };
  const mk = () => Core.createAgent({ chrome: facade, fetchFn: (u, i) => fetch(u, i), domainLib: Domain, uuid: () => 'install-restr-001', now: () => clock.t });
  const w = { db, repo, tracker, engine, api, chrome, mk, code: repo.getExtensionToken() };
  let stopped = false;
  w.stop = async () => { if (stopped) return; stopped = true; await w.api.close().catch(() => {}); try { db.close(); } catch { /* closed */ } };
  open.push(w.stop);
  w.use = (name, secs) => { repo.insertSession({ category: 'website', itemName: name, startedAt: new Date(clock.t - secs * 1000 - Math.random() * 1000).toISOString(), endedAt: new Date(clock.t).toISOString(), durationSeconds: secs }); };
  w.limit = (target, mode, o = {}) => engine.create({ targetType: 'website', target, dailyLimitSeconds: 600, mode, warningPercent: 80, extensionMinutes: 5, isEnabled: true, ...o });
  return w;
}
const activeTab = (c) => c.tabs.find((t) => t.active);
const blockedUrl = (d) => BLOCK + d;

test('enforced limit: only the active tab on the exact configured domain is redirected; everything else is untouched', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  w.limit('youtube.com', 'enforce'); w.limit('reddit.com', 'enforce'); w.use('youtube.com', 600); w.use('reddit.com', 60); w.engine.tick();
  const c = w.chrome;
  await a.heartbeat();                                                  // active tab is github: nothing happens
  assert.deepEqual(c.updates, []);
  c.tabs[0].active = false; c.tabs[1].active = true; await a.heartbeat();   // the YouTube tab is now in front
  assert.deepEqual(c.updates, [{ id: 2, url: blockedUrl('youtube.com') }]);
  assert.equal(c.tabs[0].url, U.gh);                                    // unrelated tab never touched
  await w.stop();
});

test('background tabs of the blocked site are not touched until they are shown; unrelated look-alike domains never match', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  w.limit('youtube.com', 'enforce'); w.use('youtube.com', 600); w.engine.tick(); await a.heartbeat();
  const c = w.chrome;
  c.tabs.push({ id: 3, windowId: 1, active: false, incognito: false, url: U.ytSub });
  await a.heartbeat();
  assert.deepEqual(c.updates, []);                                      // YouTube tabs exist in the background: left alone
  c.tabs.forEach((t) => { t.active = t.id === 3; });
  await a.enforceTab(activeTab(c));                                      // tab 3 is shown (onActivated): blocked, subdomain included
  assert.deepEqual(c.updates.map((u) => u.id), [3]);
  for (const [id, url] of [[4, U.fake], [5, U.evil], [6, U.rd], [7, 'chrome://settings'], [8, 'file:///c:/x.txt']]) {
    c.tabs.push({ id, windowId: 1, active: true, incognito: false, url }); c.tabs.forEach((t) => { t.active = t.id === id; });
    assert.equal(await a.enforceTab(activeTab(c)), false, url);
  }
  assert.equal(c.updates.length, 1);
  await w.stop();
});

test('navigation to the blocked site (also via redirects/subdomains) is caught; other windows and incognito are respected', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  w.limit('youtube.com', 'enforce'); w.use('youtube.com', 600); w.engine.tick(); await a.heartbeat();
  const c = w.chrome;
  const tab = c.tabs[0]; tab.url = U.ytSub;                              // the active tab navigated to m.youtube.com
  assert.equal(await a.enforceTab({ ...tab }), true);
  tab.url = U.yt; tab.incognito = true;                                   // private window: never touched
  assert.equal(await a.enforceTab({ ...tab }), false);
  tab.incognito = false; c.win.focused = false;                           // browser not in front (e.g. VS Code): sweep does nothing
  assert.equal(await a.enforceActive(), false);
  c.win.focused = true;
  assert.equal(await a.enforceActive(), true);                            // focus returns: the active tab is blocked
  await w.stop();
});

test('warning-only and confirmation modes never redirect anything', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  w.limit('youtube.com', 'warn'); w.limit('reddit.com', 'confirm'); w.use('youtube.com', 900); w.use('reddit.com', 900); w.engine.tick();
  const c = w.chrome;
  for (const url of [U.yt, U.rd]) { c.tabs[0].url = url; await a.heartbeat(); assert.equal(await a.enforceTab({ ...c.tabs[0] }), false); }
  assert.deepEqual(c.updates, []);
  await w.stop();
});

test('the app logs the block once; the block page can override (returns to the original page) or turn the limit off', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  w.limit('youtube.com', 'enforce', { extensionMinutes: 5 }); w.use('youtube.com', 600); w.engine.tick();
  const c = w.chrome; c.tabs[0].url = 'https://www.youtube.com/watch?v=ORIGINAL'; await a.heartbeat();
  await a.enforceTab({ ...c.tabs[0], url: 'https://www.youtube.com/watch?v=ORIGINAL' });
  await new Promise((r) => setTimeout(r, 150));
  assert.equal(w.repo.listEvents({ limit: 50, offset: 0 }).records.filter((e) => e.eventType === 'blocked').length, 1);
  await a.enforceTab({ ...c.tabs[0], url: 'https://www.youtube.com/watch?v=ORIGINAL' }); await new Promise((r) => setTimeout(r, 100));
  assert.equal(w.repo.listEvents({ limit: 50, offset: 0 }).records.filter((e) => e.eventType === 'blocked').length, 1);   // not repeated
  await a.overrideBlock('youtube.com');
  assert.equal(await a.resumeUrl(1, 'youtube.com'), 'https://www.youtube.com/watch?v=ORIGINAL');
  assert.equal(await a.enforceTab({ ...activeTab(c), url: U.yt }), false);                              // unblocked after the override
  const ov = w.repo.listEvents({ limit: 50, offset: 0 }).records.find((e) => e.eventType === 'override');
  assert.deepEqual([ov.extraSeconds, ov.detail], [300, 'source: block page']);
  w.use('youtube.com', 300); w.engine.tick(); await a.heartbeat();
  assert.equal(await a.enforceTab({ ...activeTab(c), url: U.yt }), true);                               // extra time used: blocked again
  await a.disableLimit('youtube.com');
  assert.equal(await a.enforceTab({ ...activeTab(c), url: U.yt }), false);
  assert.equal(await a.resumeUrl(99, 'youtube.com'), 'https://youtube.com/');                           // nothing stored: site front page
  await w.stop();
});

test('service-worker restart and backend outage: the stored block list still applies, then fails open (10 minutes silent / local midnight)', async () => {
  const w = await world(); let a = w.mk(); await a.pair(w.code);
  w.limit('youtube.com', 'enforce'); w.use('youtube.com', 600); w.engine.tick(); await a.heartbeat();
  a = w.mk();                                                            // worker restarted: only chrome.storage survives
  await w.api.close();                                                    // and the desktop app is down
  const tab = { ...w.chrome.tabs[0], url: U.yt };
  clock.t += 5 * 60 * 1000;
  assert.equal(await a.enforceTab(tab), true);
  clock.t += 6 * 60 * 1000;                                               // 11 minutes without hearing from the app
  assert.equal(await a.enforceTab({ ...tab }), false);
  await w.stop();

  const w2 = await world(); const b = w2.mk(); await b.pair(w2.code);
  w2.limit('youtube.com', 'enforce'); w2.use('youtube.com', 600); w2.engine.tick(); await b.heartbeat();
  const next = new Date(clock.t); next.setHours(24, 0, 0, 0);
  clock.t = next.getTime() + 1000;                                        // after local midnight the stored block has expired by itself
  assert.equal(await b.enforceTab({ ...w2.chrome.tabs[0], url: U.yt }), false);
  await w2.stop();
});

test('backend reconnection: disabling the limit in the dashboard lifts the block on the next heartbeat', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  const l = w.limit('youtube.com', 'enforce'); w.use('youtube.com', 600); w.engine.tick(); await a.heartbeat();
  assert.equal(await a.enforceTab({ ...w.chrome.tabs[0], url: U.yt }), true);
  w.engine.update(l.id, { isEnabled: false });
  await a.heartbeat();
  assert.equal(await a.enforceTab({ ...w.chrome.tabs[0], url: U.yt }), false);
  const l2 = w.engine.update(l.id, { isEnabled: true }); void l2;
  w.engine.setMaster(false); await a.heartbeat();
  assert.equal(await a.enforceTab({ ...w.chrome.tabs[0], url: U.yt }), false);                          // master switch lifts everything
  await w.stop();
});

test('a failure while enforcing never breaks tracking or syncing', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  w.limit('youtube.com', 'enforce'); w.use('youtube.com', 600); w.engine.tick();
  const broken = Core.createAgent({ chrome: { storage: w.chrome.storage, windows: w.chrome.windows, runtime: w.chrome.runtime, tabs: { query: async () => { throw new Error('tabs api unavailable'); }, update: async () => { throw new Error('nope'); } } }, fetchFn: (u, i) => fetch(u, i), domainLib: Domain, uuid: () => 'install-restr-001', now: () => clock.t });
  await broken.heartbeat();
  assert.equal((await broken.status()).connection.ok, true);
  await w.stop();
});
