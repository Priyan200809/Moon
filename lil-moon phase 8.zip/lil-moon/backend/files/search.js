// Keyword search over indexed chunks (SQLite FTS5, BM25) plus file-name matching. Query text is never put in SQL.
const path = require('path');

const STOP = new Set(('a an the my me mine of in on to for and or is are was were be been am find search show open file files containing contain contains document documents about with what whats which who whom whose where when why how do does did done can could would should will shall may might must have has had it its this that these those there here from at by as if then than so not no yes you your we our they them their i say says said tell give please summarize summary look looking need want know any some all into over under between during').split(' '));
const likeEscape = (s) => s.replace(/[\\%_]/g, (c) => `\\${c}`);

function tokens(query) {
  const all = (String(query).toLowerCase().match(/[\p{L}\p{N}_]+/gu) ?? []).filter((t) => t.length >= 2 || /\d/.test(t)).slice(0, 12);
  const kept = all.filter((t) => !STOP.has(t));
  return kept.length ? kept : all;
}

// Returns chunk-level hits, best first: { chunkId, fileId, name, path, relPath, ext, folder, chunkNo, heading, snippet, rank, nameMatch }
function searchChunks(db, query, { limit = 10 } = {}) {
  const toks = tokens(query);
  if (!toks.length) return [];
  const hits = new Map();
  const sql = `SELECT c.id AS chunk_id, c.chunk_no, c.heading, f.id AS file_id, f.name, f.rel_path, f.ext, fo.path AS folder,
                      snippet(file_chunks_fts, 0, '[', ']', '…', 24) AS snip, bm25(file_chunks_fts, 1.0, 0.5) AS rank
               FROM file_chunks_fts JOIN file_chunks c ON c.id = file_chunks_fts.rowid
                    JOIN indexed_files f ON f.id = c.file_id JOIN indexed_folders fo ON fo.id = f.folder_id
               WHERE file_chunks_fts MATCH ? ORDER BY rank LIMIT ?`;
  const run = (expr, bonus) => {
    for (const r of db.prepare(sql).all(expr, limit * 3)) {
      if (!hits.has(r.chunk_id)) hits.set(r.chunk_id, { chunkId: r.chunk_id, fileId: r.file_id, name: r.name, relPath: r.rel_path, ext: r.ext, folder: r.folder, path: path.join(r.folder, r.rel_path), chunkNo: r.chunk_no, heading: r.heading, snippet: r.snip, rank: r.rank + bonus, nameMatch: false });
    }
  };
  const quoted = toks.map((t, i) => (i === toks.length - 1 ? `"${t}"*` : `"${t}"`)); // tokens are letters/digits/_ only
  run(quoted.join(' AND '), 0);
  const strong = quoted.filter((q) => q.replace(/["*]/g, '').length >= 4);   // loose mode ignores short filler words
  if (hits.size < limit && strong.length > 1) run(strong.join(' OR '), 5);    // looser, ranked below strict matches

  // file-name matches: a file called dbms_notes.txt should be found even if its text never says "dbms notes"
  const nameWhere = toks.map(() => "f.name LIKE ? ESCAPE '\\'").join(' OR ');
  const rows = db.prepare(
    `SELECT f.id AS file_id, f.name, f.rel_path, f.ext, fo.path AS folder,
            (SELECT id FROM file_chunks WHERE file_id = f.id ORDER BY chunk_no LIMIT 1) AS chunk_id,
            (SELECT chunk_no FROM file_chunks WHERE file_id = f.id ORDER BY chunk_no LIMIT 1) AS chunk_no,
            (SELECT substr(text, 1, 160) FROM file_chunks WHERE file_id = f.id ORDER BY chunk_no LIMIT 1) AS snip
     FROM indexed_files f JOIN indexed_folders fo ON fo.id = f.folder_id WHERE f.status = 'indexed' AND (${nameWhere}) LIMIT ?`
  ).all(...toks.map((t) => `%${likeEscape(t)}%`), limit);
  for (const r of rows) {
    if (r.chunk_id == null) continue;
    const matched = toks.filter((t) => r.name.toLowerCase().includes(t)).length;
    const existing = [...hits.values()].find((h) => h.fileId === r.file_id);
    if (existing) { existing.nameMatch = true; existing.rank -= 3 * matched; continue; }
    hits.set(r.chunk_id, { chunkId: r.chunk_id, fileId: r.file_id, name: r.name, relPath: r.rel_path, ext: r.ext, folder: r.folder, path: path.join(r.folder, r.rel_path), chunkNo: r.chunk_no, heading: null, snippet: r.snip, rank: -3 * matched, nameMatch: true });
  }
  return [...hits.values()].sort((a, b) => a.rank - b.rank).slice(0, limit);
}

// File-level view for the Local Files page: best chunk per file.
function searchFiles(db, query, { limit = 20 } = {}) {
  const seen = new Set(), out = [];
  for (const h of searchChunks(db, query, { limit: limit * 4 })) {
    if (seen.has(h.fileId)) continue;
    seen.add(h.fileId); out.push(h);
    if (out.length >= limit) break;
  }
  return out;
}

module.exports = { searchChunks, searchFiles, tokens };
