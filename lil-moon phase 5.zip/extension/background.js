// Service worker. Event listeners are registered at top level on purpose: Chrome restarts this worker for any event,
// and everything it needs is re-read from chrome.storage, so a restart loses nothing.
importScripts('lib/domain.js', 'lib/core.js');

const agent = LilMoonCore.createAgent({
  chrome,
  fetchFn: (...a) => fetch(...a),
  domainLib: LilMoonDomain,
  browserName: /Edg\//.test(navigator.userAgent) ? 'edge' : 'chrome', // Edge uses the same extension APIs
  uuid: () => crypto.randomUUID(),
});

const ALARM = 'lil-moon-heartbeat';
// Alarms (not setInterval) survive worker restarts. 0.5 min is the shortest period Chrome allows.
const ensureAlarm = async () => { if (!(await chrome.alarms.get(ALARM))) chrome.alarms.create(ALARM, { periodInMinutes: 0.5 }); };
const change = () => { agent.sync('change').catch(() => {}); };

chrome.tabs.onActivated.addListener(change);                                  // active tab changed
chrome.tabs.onUpdated.addListener((_id, info) => { if (info.url || info.status === 'complete') change(); }); // navigation, incl. to another domain
chrome.tabs.onRemoved.addListener(change);                                     // tab closed
chrome.tabs.onReplaced.addListener(change);
chrome.windows.onFocusChanged.addListener(change);                             // browser gained/lost focus (e.g. switched to VS Code)
chrome.windows.onRemoved.addListener(change);
if (chrome.windows.onBoundsChanged) chrome.windows.onBoundsChanged.addListener(change); // minimise / restore

chrome.runtime.onInstalled.addListener(() => { ensureAlarm(); agent.heartbeat().catch(() => {}); });
chrome.runtime.onStartup.addListener(() => { ensureAlarm(); agent.heartbeat().catch(() => {}); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM) agent.heartbeat().catch(() => {}); });
ensureAlarm();

// Popup <-> worker. Only this extension's own pages can reach it.
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !msg || typeof msg.type !== 'string') return false;
  const ops = {
    status: () => agent.status(),
    summary: () => agent.summary(),
    pause: () => agent.setPaused(true).then(() => agent.status()),
    resume: () => agent.setPaused(false).then(() => agent.status()),
    pair: () => agent.pair(msg.code).then(() => agent.status()),
    unpair: () => agent.unpair().then(() => agent.status()),
    dashboard: () => agent.openDashboard(),
  };
  const op = ops[msg.type];
  if (!op) return false;
  op().then((data) => reply({ ok: true, data }), (e) => reply({ ok: false, error: e.code || 'error' }));
  return true; // reply asynchronously
});
