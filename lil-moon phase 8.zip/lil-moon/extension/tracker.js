// Pure tracking logic (no chrome.* calls) so it can be unit-tested in Node. All state is plain data that
// background.js persists to chrome.storage, so a service-worker restart loses nothing but the last few seconds.
export const STALE_MS = 90_000;        // if we have not "seen" a session for this long, do not count the gap
export const CHECKPOINT_MS = 25_000;   // long sessions are cut into segments so a crash loses little
export const MAX_BUFFER = 2000;        // completed-but-unsent segments kept while the desktop app is offline

// ---- host handling: kept identical to backend/domain.js (tests/domain.test.js checks parity) ----
const LABEL = /^(?!-)[a-z0-9-]{1,63}(?<!-)$/;
export function cleanHost(input) {
  if (typeof input !== 'string') return null;
  const s = input.trim().toLowerCase().replace(/\.$/, '');
  if (!s || s.length > 253) return null;
  const labels = s.split('.');
  if (labels.length < 2 || !labels.every((l) => LABEL.test(l))) return null;
  if (/^\d+$/.test(labels[labels.length - 1])) return null;
  return s;
}
export function matchTracked(host, sites) {
  const h = cleanHost(host);
  if (!h) return null;
  let best = null;
  for (const site of sites) {
    if (site.isEnabled === false) continue;
    const d = site.domain;
    const hit = h === d || h === `www.${d}` || (site.matchMode !== 'exact' && h.endsWith(`.${d}`));
    if (hit && (!best || d.length > best.domain.length)) best = site;
  }
  return best;
}
// Only the hostname is ever extracted; path, query and fragment are discarded here.
export function hostFromUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:' ? cleanHost(u.hostname) : null;
  } catch { return null; }
}

// What should be counted right now? Returns {domain, reason}; domain null means "not counting".
export function decideTarget({ paused, paired, trackingEnabled, windowFocused, incognito, idleBlocked, url, domains }) {
  if (paused) return { domain: null, reason: 'paused' };
  if (!paired) return { domain: null, reason: 'not_paired' };
  if (!trackingEnabled) return { domain: null, reason: 'tracking_disabled' };
  if (!windowFocused) return { domain: null, reason: 'window_not_focused' };
  if (incognito) return { domain: null, reason: 'incognito' };
  if (idleBlocked) return { domain: null, reason: 'idle' };
  const host = hostFromUrl(url);
  if (!host) return { domain: null, reason: 'unsupported_page' };
  const site = matchTracked(host, domains.map((d) => ({ ...d, isEnabled: true })));
  return site ? { domain: site.domain, reason: 'tracking' } : { domain: null, reason: 'not_tracked' };
}

// ---- session state ----
export const emptyState = () => ({ current: null, buffer: [], dropped: 0 });
const iso = (ms) => new Date(ms).toISOString();

function pushSegment(state, seg) {
  const buffer = [...state.buffer, seg];
  const over = Math.max(0, buffer.length - MAX_BUFFER);
  return { ...state, buffer: buffer.slice(over), dropped: state.dropped + over };
}

function closeCurrent(state, now) {
  const c = state.current;
  if (!c) return state;
  let end = now - c.lastSeen > STALE_MS ? c.lastSeen : now; // never credit time we could not observe
  if (end < c.startedAt) end = c.startedAt;                  // clock moved backwards: never a negative duration
  const next = { ...state, current: null };
  return end - c.startedAt >= 1000
    ? pushSegment(next, { clientId: globalThis.crypto.randomUUID(), hostname: c.domain, startedAt: iso(c.startedAt), endedAt: iso(end) })
    : next;
}

// Apply the latest observation. target = {domain} or null.
export function advance(state, target, now) {
  let s = state;
  if (s.current && (!target || target.domain !== s.current.domain)) s = closeCurrent(s, now);
  else if (s.current && now - s.current.lastSeen > STALE_MS) s = closeCurrent(s, now);
  if (target && !s.current) return { ...s, current: { domain: target.domain, startedAt: now, lastSeen: now, checkpointAt: now } };
  if (s.current) return { ...s, current: { ...s.current, lastSeen: now } };
  return s;
}

// Cut a long-running session into a sendable segment and keep counting from now.
export function checkpoint(state, now) {
  const c = state.current;
  if (!c || now - c.checkpointAt < CHECKPOINT_MS) return state;
  const closed = closeCurrent(state, now);
  return { ...closed, current: { domain: c.domain, startedAt: now, lastSeen: now, checkpointAt: now } };
}

// Remove segments the desktop app has acknowledged (accepted, duplicate, or permanently rejected).
export function settle(state, results) {
  const done = new Set([...results.accepted, ...results.duplicates, ...results.rejected.map((r) => r.clientId)]);
  return { ...state, buffer: state.buffer.filter((s) => !done.has(s.clientId)) };
}
