// File discovery -> type detection -> extraction -> cleaning -> chunking -> FTS5 index.
// Read-only on the user's files. Only inside folders the user chose; symlinks are never followed.
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const { extractFile, SUPPORTED, extOf } = require('./extract');
const { chunkSections } = require('./chunk');
const { isDeniedDirName, isDeniedFileName, protectedFolderReason } = require('./guard');
const { redactSecrets } = require('../safety');

const MAX_FILES_PER_FOLDER = 20000;
const yieldNow = () => new Promise((r) => setImmediate(r));

async function* walk(root) {
  const stack = [root];
  while (stack.length) {
    const dir = stack.pop();
    let entries;
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch { continue; } // permission errors: skip, never escalate
    entries.sort((a, b) => a.name.localeCompare(b.name));
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isSymbolicLink()) continue;
      if (e.isDirectory()) { if (!isDeniedDirName(e.name)) stack.push(full); continue; }
      if (e.isFile() && SUPPORTED.has(extOf(e.name)) && !isDeniedFileName(e.name)) yield full;
    }
  }
}

function createIndexer({ aiRepo, userData = null }) {
  const running = new Map();
  const progress = new Map();

  async function run(folderId) {
    const folder = aiRepo.getFolder(folderId);
    if (!folder) return;
    const prog = { state: 'indexing', seen: 0, indexed: 0, unchanged: 0, skipped: 0, errors: 0, current: null };
    progress.set(folderId, prog);
    const reason = protectedFolderReason(folder.path, { userData });
    let root;
    try {
      if (reason) throw new Error(reason);
      root = await fsp.realpath(folder.path);
      if (!(await fsp.stat(root)).isDirectory()) throw new Error('Not a folder.');
    } catch (err) {
      aiRepo.setFolderStatus(folderId, { status: 'error', lastError: err.code === 'ENOENT' ? 'Folder not found. It may have been moved or deleted.' : err.message });
      prog.state = 'error';
      return;
    }
    aiRepo.setFolderStatus(folderId, { status: 'indexing' });
    const seen = new Set();
    try {
      for await (const full of walk(root)) {
        if (!aiRepo.getFolder(folderId)) return; // folder removed while indexing
        if (++prog.seen > MAX_FILES_PER_FOLDER) break;
        const rel = path.relative(root, full).split(path.sep).join('/');
        const name = path.basename(full), ext = extOf(name);
        prog.current = name;
        seen.add(rel);
        let st;
        try { st = await fsp.stat(full); } catch { prog.errors++; continue; }
        const prev = aiRepo.getFileState(folderId, rel);
        if (prev && prev.status !== 'error' && prev.size_bytes === st.size && prev.mtime_ms === Math.floor(st.mtimeMs)) { prog.unchanged++; continue; }
        const base = { folderId, rel, name, ext, size: st.size, mtimeMs: Math.floor(st.mtimeMs) };
        try {
          const { sections } = await extractFile(full, st.size);
          const chunks = chunkSections(sections).map((c) => ({ heading: c.heading, text: redactSecrets(c.text) }));
          if (!chunks.length) { aiRepo.tx(() => { const id = aiRepo.upsertFile({ ...base, status: 'skipped', note: 'No readable text.' }); aiRepo.replaceChunks(id, []); }); prog.skipped++; continue; }
          if (/-----BEGIN [A-Z ]*PRIVATE KEY-----/.test(sections.map((s) => s.text).join('\n'))) throw Object.assign(new Error('Looks like a credential file.'), { skip: true });
          const hash = crypto.createHash('sha256').update(chunks.map((c) => c.text).join('\u0000')).digest('hex');
          if (prev && prev.content_hash === hash && prev.status === 'indexed') { aiRepo.touchFile(prev.id, st.size, base.mtimeMs); prog.unchanged++; continue; }
          aiRepo.tx(() => { aiRepo.replaceChunks(aiRepo.upsertFile({ ...base, hash, status: 'indexed' }), chunks); });
          prog.indexed++;
        } catch (err) {
          const skip = err.skip || /too large|Unsupported|Binary/i.test(err.message);
          aiRepo.tx(() => { const id = aiRepo.upsertFile({ ...base, status: skip ? 'skipped' : 'error', note: err.message.slice(0, 200) }); aiRepo.replaceChunks(id, []); });
          if (skip) prog.skipped++; else prog.errors++;
        }
        await yieldNow();
      }
      for (const f of aiRepo.listFileRels(folderId)) if (!seen.has(f.rel_path)) aiRepo.deleteFile(f.id); // deleted on disk
      aiRepo.setFolderStatus(folderId, { status: 'idle', lastIndexedAt: new Date().toISOString() });
      prog.state = 'done';
    } catch (err) {
      console.error('[lil-moon] indexing failed:', err.message);
      if (aiRepo.getFolder(folderId)) aiRepo.setFolderStatus(folderId, { status: 'error', lastError: 'Indexing stopped because of an unexpected error.' });
      prog.state = 'error';
    }
  }

  return {
    index(folderId) {
      if (!running.has(folderId)) running.set(folderId, run(folderId).finally(() => running.delete(folderId)));
      return running.get(folderId);
    },
    isRunning: (folderId) => running.has(folderId),
    progress: (folderId) => progress.get(folderId) ?? null,
    async idle() { while (running.size) await Promise.all([...running.values()]); },
  };
}

module.exports = { createIndexer };
