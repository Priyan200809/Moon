// Works with any server that speaks the OpenAI "chat completions" protocol: OpenAI, OpenRouter, Groq, Gemini's
// compatibility endpoint, and LOCAL models (Ollama, LM Studio, llama.cpp) by pointing the base URL at localhost.
const { ProviderError, post, sse, safeJson } = require('./common');

function toWire(system, messages) {
  const out = [{ role: 'system', content: system }];
  for (const m of messages) {
    if (m.role === 'tool') out.push({ role: 'tool', tool_call_id: m.toolCallId, content: m.content });
    else if (m.role === 'assistant' && m.toolCalls?.length) {
      out.push({ role: 'assistant', content: m.content || null, tool_calls: m.toolCalls.map((c) => ({ id: c.id, type: 'function', function: { name: c.name, arguments: JSON.stringify(c.args ?? {}) } })) });
    } else out.push({ role: m.role, content: m.content });
  }
  return out;
}

async function* stream({ settings, apiKey, system, messages, tools, signal }) {
  const url = `${settings.baseUrl.replace(/\/+$/, '')}/chat/completions`;
  const body = { model: settings.model, stream: true, messages: toWire(system, messages) };
  if (tools?.length) body.tools = tools.map((t) => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.parameters } }));
  const res = await post(url, { headers: apiKey ? { Authorization: `Bearer ${apiKey}` } : {}, body, signal, apiKey });
  const calls = new Map();
  for await (const { data } of sse(res, signal)) {
    if (data === '[DONE]') break;
    const j = safeJson(data);
    if (j?.error) throw new ProviderError('server', 'The AI provider reported an error while answering.');
    const delta = j?.choices?.[0]?.delta;
    if (!delta) continue;
    if (typeof delta.content === 'string' && delta.content) yield { type: 'text', text: delta.content };
    for (const tc of delta.tool_calls ?? []) {
      const cur = calls.get(tc.index ?? 0) ?? { id: '', name: '', args: '' };
      if (tc.id) cur.id = tc.id;
      if (tc.function?.name) cur.name += tc.function.name;
      if (tc.function?.arguments) cur.args += tc.function.arguments;
      calls.set(tc.index ?? 0, cur);
    }
  }
  for (const c of calls.values()) yield { type: 'tool_call', id: c.id || `call_${Math.random().toString(36).slice(2, 10)}`, name: c.name, args: c.args ? safeJson(c.args) : {} };
}

module.exports = { stream };
