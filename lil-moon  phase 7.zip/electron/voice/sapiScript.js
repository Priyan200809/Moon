// The ONLY PowerShell code Lil Moon ever runs. It is a fixed string, started with -EncodedCommand (no script file, no execution-policy
// override), and it receives just two validated values through environment variables (language code, timeout seconds).
// It uses Windows' built-in offline recogniser (System.Speech / SAPI): audio goes from the microphone to Windows, never to Lil Moon
// and never to a network. Lil Moon receives only JSON lines of recognised TEXT on stdout. Nothing a person says is ever executed here.
// NOTE: this script could not be run in the development environment (no Windows). It is tested only through its JSON protocol.
const SCRIPT = String.raw`
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
function Send($o) { [Console]::Out.WriteLine(($o | ConvertTo-Json -Compress)); [Console]::Out.Flush() }
try { Add-Type -AssemblyName System.Speech } catch { Send @{ type = 'error'; code = 'engine_unavailable' }; exit 2 }
$lang = $env:LILMOON_LANG
$secs = 8
if ($env:LILMOON_TIMEOUT -match '^\d{1,2}$') { $secs = [int]$env:LILMOON_TIMEOUT }
$info = $null
foreach ($ri in [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()) { if ($ri.Culture.Name -eq $lang) { $info = $ri; break } }
if ($null -eq $info) { Send @{ type = 'error'; code = 'unsupported_language' }; exit 3 }
$rec = New-Object System.Speech.Recognition.SpeechRecognitionEngine($info)
try {
  $rec.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))
  $rec.SetInputToDefaultAudioDevice()
} catch { Send @{ type = 'error'; code = 'no_microphone' }; exit 4 }
$rec.InitialSilenceTimeout = [TimeSpan]::FromSeconds($secs)
$rec.BabbleTimeout = [TimeSpan]::FromSeconds(4)
$rec.EndSilenceTimeout = [TimeSpan]::FromMilliseconds(900)
Register-ObjectEvent -InputObject $rec -EventName SpeechHypothesized -SourceIdentifier hyp | Out-Null
Register-ObjectEvent -InputObject $rec -EventName SpeechRecognized -SourceIdentifier rec | Out-Null
Register-ObjectEvent -InputObject $rec -EventName SpeechRecognitionRejected -SourceIdentifier rej | Out-Null
Register-ObjectEvent -InputObject $rec -EventName RecognizeCompleted -SourceIdentifier done | Out-Null
try { $rec.RecognizeAsync([System.Speech.Recognition.RecognizeMode]::Single) } catch { Send @{ type = 'error'; code = 'microphone_error' }; exit 5 }
Send @{ type = 'ready' }
$final = $false
while ($true) {
  $e = Wait-Event -Timeout 1
  if ($null -eq $e) { continue }
  $a = $e.SourceEventArgs
  switch ($e.SourceIdentifier) {
    'hyp' { Send @{ type = 'partial'; text = $a.Result.Text } }
    'rec' { $final = $true; Send @{ type = 'final'; text = $a.Result.Text; confidence = [double]$a.Result.Confidence } }
    'rej' { Send @{ type = 'rejected' } }
    'done' {
      if ($a.Error) { Send @{ type = 'error'; code = 'microphone_error' } }
      elseif ($a.InitialSilenceTimeout -or $a.BabbleTimeout) { Send @{ type = 'timeout' } }
      elseif (-not $final) { Send @{ type = 'rejected' } }
      Send @{ type = 'done' }
      $rec.Dispose()
      exit 0
    }
  }
  Remove-Event -EventIdentifier $e.EventIdentifier
}
`;
module.exports = { SCRIPT, encoded: () => Buffer.from(SCRIPT, 'utf16le').toString('base64') };
