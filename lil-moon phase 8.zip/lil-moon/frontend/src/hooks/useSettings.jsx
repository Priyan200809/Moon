import { createContext, useContext, useEffect } from 'react';
import { api } from '../lib/api.js';
import { useApi } from './useApi.js';

const Ctx = createContext(null);

// Settings live in SQLite behind the local API; the theme is applied as soon as they load.
export function SettingsProvider({ children }) {
  const query = useApi('/api/settings');
  const theme = query.data?.theme ?? 'sunny';
  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  const save = async (patch) => { await api('PUT', '/api/settings', patch); query.reload(); };
  return <Ctx.Provider value={{ query, save }}>{children}</Ctx.Provider>;
}

export const useSettings = () => useContext(Ctx);
