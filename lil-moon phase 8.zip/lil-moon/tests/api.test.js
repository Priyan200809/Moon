// Run with `npm test` (Node 22.13+). Exercises the real database and real HTTP server; no Electron needed.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { DatabaseSync } = require('node:sqlite');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer } = require('../backend/server');

const TOKEN = 'test-token';
const ORIGIN = 'null';
const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lm-db-')), 'lil-moon.db');

async function boot(file = tmp(), legacyPreferences) {
  const db = openDatabase(file, { legacyPreferences });
  const api = await startServer({ repo: createRepository(db), allowedOrigins: [ORIGIN], token: TOKEN, ports: [0] });
  const call = async (method, p, body, headers = {}) => {
    const res = await fetch(api.baseUrl + p, {
      method,
      headers: { Authorization: `Bearer ${TOKEN}`, ...(body !== undefined && { 'Content-Type': 'application/json' }), ...headers },
      body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body),
    });
    return { status: res.status, json: await res.json().catch(() => null), headers: res.headers };
  };
  return { db, api, file, call, stop: async () => { await api.close(); db.close(); } };
}
const raw = (api, headers, method = 'GET', p = '/api/health') => new Promise((resolve, reject) => {
  const req = http.request({ host: '127.0.0.1', port: api.port, path: p, method, headers }, (res) => {
    let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: b }));
  });
  req.on('error', reject); req.end();
});
const ago = (s) => new Date(Date.now() - s * 1000).toISOString();
const session = (o = {}) => ({ category: 'application', itemName: 'Notepad', startedAt: ago(600), endedAt: ago(0), ...o });

test('database initialises with all tables, indexes and schema version 3', async () => {
  const t = await boot();
  const names = (type) => t.db.prepare('SELECT name FROM sqlite_master WHERE type = ?').all(type).map((r) => r.name);
  for (const tbl of ['user_settings', 'applications', 'websites', 'usage_sessions', 'restriction_events', 'ingest_log', 'extension_pairing']) assert.ok(names('table').includes(tbl), tbl);
  for (const idx of ['idx_usage_date_item', 'idx_usage_item_start', 'idx_restriction_created']) assert.ok(names('index').includes(idx), idx);
  assert.equal(t.db.prepare('PRAGMA user_version').get().user_version, 3);
  await t.stop();
});

test('default settings: 3 hours, sunny theme, single row', async () => {
  const t = await boot();
  const { json } = await t.call('GET', '/api/settings');
  assert.equal(json.ok, true);
  assert.equal(json.data.dailyLimitSeconds, 10800);
  assert.equal(json.data.theme, 'sunny');
  assert.equal(t.db.prepare('SELECT COUNT(*) n FROM user_settings').get().n, 1);
  await t.stop();
});

test('settings save and reload; partial updates keep the other field', async () => {
  const t = await boot();
  let r = await t.call('PUT', '/api/settings', { dailyLimitSeconds: 5400 });
  assert.equal(r.status, 200);
  r = await t.call('PUT', '/api/settings', { theme: 'lilac' });
  const { json } = await t.call('GET', '/api/settings');
  assert.equal(json.data.dailyLimitSeconds, 5400);
  assert.equal(json.data.theme, 'lilac');
  assert.ok(json.data.updatedAt >= json.data.createdAt);
  await t.stop();
});

test('invalid settings are rejected with 400 and change nothing', async () => {
  const t = await boot();
  const bodies = [{}, { dailyLimitSeconds: 10 }, { dailyLimitSeconds: 90000 }, { dailyLimitSeconds: 3600.5 }, { dailyLimitSeconds: '3600' },
    { dailyLimitSeconds: null }, { theme: 'neon' }, { theme: 5 }, { dailyLimitSeconds: 3600, extra: 1 }, [], 'x', null];
  for (const b of bodies) {
    const r = await t.call('PUT', '/api/settings', b === 'x' ? '"x"' : b);
    assert.equal(r.status, 400, JSON.stringify(b));
    assert.equal(r.json.ok, false);
    assert.ok(['validation_error', 'invalid_json'].includes(r.json.error.code)); // bare JSON strings/null are refused by the parser
  }
  assert.equal((await t.call('GET', '/api/settings')).json.data.dailyLimitSeconds, 10800);
  await t.stop();
});

test('create, summarise, filter and delete usage sessions', async () => {
  const t = await boot();
  const a = await t.call('POST', '/api/usage/sessions', session({ startedAt: ago(1200), endedAt: ago(600) }));
  assert.equal(a.status, 201);
  assert.equal(a.json.data.durationSeconds, 600);
  assert.match(a.json.data.sessionDate, /^\d{4}-\d{2}-\d{2}$/);
  await t.call('POST', '/api/usage/sessions', session());
  await t.call('POST', '/api/usage/sessions', session({ category: 'website', itemName: 'example.com', startedAt: ago(300), endedAt: ago(0) }));

  const today = (await t.call('GET', '/api/usage/today')).json.data;
  assert.equal(today.dailyLimitSeconds, 10800);
  assert.equal(today.totals.application, 1200);
  assert.equal(today.totals.website, 300);
  assert.equal(today.items[0].itemName, 'Notepad');
  assert.equal(today.items[0].sessionCount, 2);
  assert.equal((await t.call('GET', '/api/usage/today?category=website')).json.data.items.length, 1);

  const all = (await t.call('GET', '/api/usage/history')).json.data;
  assert.equal(all.total, 3);
  const page = (await t.call('GET', '/api/usage/history?limit=1&offset=1')).json.data;
  assert.equal(page.records.length, 1);
  assert.equal(page.total, 3);
  assert.equal((await t.call('GET', '/api/usage/history?category=website')).json.data.total, 1);
  assert.equal((await t.call('GET', `/api/usage/history?from=${today.date}&to=${today.date}`)).json.data.total, 3);
  assert.equal((await t.call('GET', '/api/usage/history?to=2000-01-01')).json.data.total, 0);

  assert.equal((await t.call('DELETE', `/api/usage/sessions/${a.json.data.id}`)).status, 200);
  assert.equal((await t.call('DELETE', `/api/usage/sessions/${a.json.data.id}`)).status, 404);
  assert.equal((await t.call('GET', '/api/usage/history')).json.data.total, 2);
  await t.stop();
});

test('invalid usage sessions are rejected', async () => {
  const t = await boot();
  const cases = {
    badCategory: session({ category: 'game' }), noName: session({ itemName: '  ' }), longName: session({ itemName: 'x'.repeat(201) }),
    controlChars: session({ itemName: 'a\u0000b' }), notIso: session({ startedAt: 'yesterday' }), localTime: session({ startedAt: '2026-10-25T10:00:00' }),
    fakeDate: session({ startedAt: '2026-02-31T10:00:00Z', endedAt: '2026-03-01T10:00:00Z' }), endBeforeStart: session({ startedAt: ago(0), endedAt: ago(60) }),
    future: session({ startedAt: new Date(Date.now() + 3600e3).toISOString(), endedAt: new Date(Date.now() + 7200e3).toISOString() }),
    tooLong: session({ startedAt: ago(90000), endedAt: ago(0) }), ancient: session({ startedAt: '1990-01-01T00:00:00Z', endedAt: '1990-01-01T01:00:00Z' }),
    unknownField: { ...session(), durationSeconds: 5 }, missing: { category: 'application' },
  };
  for (const [name, body] of Object.entries(cases)) {
    const r = await t.call('POST', '/api/usage/sessions', body);
    assert.equal(r.status, 400, name);
    assert.equal(r.json.error.code, 'validation_error', name);
  }
  assert.equal((await t.call('GET', '/api/usage/history')).json.data.total, 0);
  await t.stop();
});

test('invalid query strings and ids are rejected', async () => {
  const t = await boot();
  for (const q of ['category=x', 'limit=0', 'limit=201', 'limit=abc', 'offset=-1', 'from=2026-13-01', 'from=2026-02-31', 'to=nope', 'from=2026-10-02&to=2026-10-01', 'limit=1&limit=2', "category=application' OR 1=1 --"]) {
    assert.equal((await t.call('GET', `/api/usage/history?${q}`)).status, 400, q);
  }
  assert.equal((await t.call('GET', '/api/usage/today?category=x')).status, 400);
  for (const id of ['0', 'abc', '-1', '1.5', '99999999999']) assert.equal((await t.call('DELETE', `/api/usage/sessions/${id}`)).status, 400, id);
  await t.stop();
});

test('SQL injection text is stored as plain data', async () => {
  const t = await boot();
  const evil = "x'); DROP TABLE usage_sessions; --";
  assert.equal((await t.call('POST', '/api/usage/sessions', session({ itemName: evil }))).status, 201);
  assert.equal((await t.call('GET', '/api/usage/history')).json.data.records[0].itemName, evil);
  await t.stop();
});

test('security: token, host, origin, content type, malformed bodies', async () => {
  const t = await boot();
  const noTok = await fetch(t.api.baseUrl + '/api/health');
  assert.equal(noTok.status, 401);
  assert.equal((await t.call('GET', '/api/health', undefined, { Authorization: 'Bearer wrong' })).status, 401);
  assert.equal((await t.call('GET', '/api/health')).status, 200);
  assert.equal((await raw(t.api, { Host: 'evil.example', Authorization: `Bearer ${TOKEN}` })).status, 403);
  assert.equal((await raw(t.api, { Host: `127.0.0.1:${t.api.port}`, Origin: 'https://evil.example', Authorization: `Bearer ${TOKEN}` })).status, 403);
  const pre = await raw(t.api, { Host: `127.0.0.1:${t.api.port}`, Origin: ORIGIN, 'Access-Control-Request-Method': 'PUT' }, 'OPTIONS', '/api/settings');
  assert.equal(pre.status, 204);
  assert.equal(pre.headers['access-control-allow-origin'], ORIGIN);
  assert.equal((await raw(t.api, { Host: `127.0.0.1:${t.api.port}`, Origin: 'https://evil.example' }, 'OPTIONS', '/api/settings')).status, 403);
  assert.equal((await t.call('PUT', '/api/settings', 'dailyLimitSeconds=900', { 'Content-Type': 'text/plain' })).status, 415);
  const malformed = await t.call('PUT', '/api/settings', '{"dailyLimitSeconds":', {});
  assert.equal(malformed.status, 400);
  assert.equal(malformed.json.error.code, 'invalid_json');
  assert.equal((await t.call('PUT', '/api/settings', JSON.stringify({ theme: 'sunny', pad: 'x'.repeat(20000) }))).status, 413);
  const nf = await t.call('GET', '/api/nope');
  assert.equal(nf.status, 404);
  assert.equal(nf.json.ok, false);
  assert.equal(t.api.baseUrl.startsWith('http://127.0.0.1:'), true);
  await t.stop();
});

test('applications and websites lists (empty, then populated; constraints enforced)', async () => {
  const t = await boot();
  assert.deepEqual((await t.call('GET', '/api/applications')).json.data, []);
  assert.deepEqual((await t.call('GET', '/api/websites')).json.data.map((w) => w.domain).sort(), ['github.com', 'instagram.com', 'linkedin.com', 'reddit.com', 'youtube.com']);
  t.db.prepare("INSERT INTO applications (app_name, executable_name) VALUES ('Notepad','notepad.exe')").run();
  t.db.prepare("INSERT INTO websites (domain, display_name, is_enabled) VALUES ('example.com','Example',0)").run();
  assert.throws(() => t.db.prepare("INSERT INTO websites (domain, display_name) VALUES ('YOUTUBE.com','dup')").run());
  assert.deepEqual((await t.call('GET', '/api/applications')).json.data, [{ id: 1, appName: 'Notepad', executableName: 'notepad.exe', isEnabled: true }]);
  assert.equal((await t.call('GET', '/api/websites')).json.data.find((w) => w.domain === 'example.com').isEnabled, false);
  assert.throws(() => t.db.prepare("INSERT INTO applications (app_name, executable_name) VALUES ('Dup','NOTEPAD.EXE')").run());
  assert.throws(() => t.db.prepare("INSERT INTO user_settings (id, daily_limit_seconds, theme, created_at, updated_at) VALUES (2, 900, 'sunny', 'a', 'b')").run());
  assert.throws(() => t.db.prepare("UPDATE user_settings SET theme = 'neon'").run());
  assert.throws(() => t.db.prepare("INSERT INTO restriction_events (category, item_name, event_type, created_at) VALUES ('application','x','explode','t')").run());
  t.db.prepare("INSERT INTO restriction_events (category, item_name, event_type, created_at) VALUES ('application','x','limit_reached','2026-10-25T00:00:00.000Z')").run();
  await t.stop();
});

test('data survives a restart; defaults are not re-applied; schema is not re-run', async () => {
  const file = tmp();
  let t = await boot(file);
  await t.call('PUT', '/api/settings', { dailyLimitSeconds: 7200, theme: 'cream' });
  await t.call('POST', '/api/usage/sessions', session());
  await t.stop();
  t = await boot(file);
  const s = (await t.call('GET', '/api/settings')).json.data;
  assert.equal(s.dailyLimitSeconds, 7200);
  assert.equal(s.theme, 'cream');
  assert.equal((await t.call('GET', '/api/usage/history')).json.data.total, 1);
  assert.equal(t.db.prepare('PRAGMA user_version').get().user_version, 3);
  await t.stop();
});

test('a database from a newer app version is refused, not modified', () => {
  const file = tmp();
  const d = new DatabaseSync(file); d.exec('PRAGMA user_version = 99'); d.close();
  assert.throws(() => openDatabase(file), /newer/);
});

test('Phase 2 preferences are imported once on first creation only', async () => {
  const file = tmp();
  let t = await boot(file, { defaultDailyLimitMin: 90, theme: 'cream' });
  assert.equal((await t.call('GET', '/api/settings')).json.data.dailyLimitSeconds, 5400);
  await t.call('PUT', '/api/settings', { dailyLimitSeconds: 600 });
  await t.stop();
  t = await boot(file, { defaultDailyLimitMin: 90, theme: 'cream' });
  assert.equal((await t.call('GET', '/api/settings')).json.data.dailyLimitSeconds, 600);
  await t.stop();
  t = await boot(tmp(), { defaultDailyLimitMin: 99999, theme: 'bogus' });
  const s = (await t.call('GET', '/api/settings')).json.data;
  assert.equal(s.dailyLimitSeconds, 10800);
  assert.equal(s.theme, 'sunny');
  await t.stop();
});
