import AsyncBoundary from '../components/AsyncBoundary.jsx';
import DashboardCard from '../components/DashboardCard.jsx';
import ProgressBar from '../components/ProgressBar.jsx';
import { MoonArt } from '../components/FloatingMoon.jsx';
import { PAGES } from '../components/Sidebar.jsx';
import { useApi } from '../hooks/useApi.js';
import { fmtSec } from '../lib/format.js';

function Summary({ title, tone, total, items, noun, query }) {
  return (
    <DashboardCard title={title} tone={tone}>
      <AsyncBoundary query={query} isEmpty={items.length === 0} empty={`No ${noun} usage recorded today.`}>
        <p className="big">{fmtSec(total)}</p>
        <p className="note">Most used: {items[0]?.itemName} ({fmtSec(items[0]?.totalSeconds)}). {items.length} {items.length === 1 ? noun : `${noun}s`} today.</p>
      </AsyncBoundary>
    </DashboardCard>
  );
}

export default function Home({ onNavigate }) {
  const today = useApi('/api/usage/today');
  const health = useApi('/api/health');
  const web = useApi('/api/websites/overview', { intervalMs: 10000 });
  const d = today.data;
  const apps = d?.items.filter((i) => i.category === 'application') ?? [];
  const sites = d?.items.filter((i) => i.category === 'website') ?? [];
  const db = health.status === 'error' ? ['Unavailable', ''] : health.data ? ['Connected', 'pill-on'] : ['Checking...', ''];

  return (
    <>
      <section className="welcome">
        <MoonArt className="welcome-moon" />
        <div>
          <h1>Hi, I'm Lil Moon.</h1>
          <p>I float above your windows. Closing this dashboard keeps me on your desktop. Use Exit Lil Moon to stop me.</p>
        </div>
      </section>

      <div className="grid">
        <DashboardCard title="Assistant status">
          <ul className="status-list">
            <li>Moon widget <span className="pill pill-on">Running</span></li>
            <li>Local database <span className={`pill ${db[1]}`}>{db[0]}</span></li>
            <li>Application tracking <span className="pill">Not built yet</span></li>
            <li>Website tracking <span className={`pill ${web.data?.tracking.connected && !web.data.tracking.paused ? 'pill-on' : ''}`}>{web.status === 'error' ? 'Unavailable' : !web.data ? 'Checking...' : !web.data.tracking.connected ? 'Extension not connected' : web.data.tracking.paused ? 'Paused' : 'Tracking on'}</span></li>
            <li>Voice commands <span className="pill">Not built yet</span></li>
          </ul>
        </DashboardCard>

        <DashboardCard title="Today's screen time" tone="purple">
          <AsyncBoundary query={today}>
            {d && (
              <>
                <p className="big">{fmtSec(d.totals.application)}</p>
                <ProgressBar used={d.totals.application} limit={d.dailyLimitSeconds} label="Application time today" />
                <p className="note">
                  {d.totals.application > d.dailyLimitSeconds
                    ? `Over your ${fmtSec(d.dailyLimitSeconds)} daily limit by ${fmtSec(d.totals.application - d.dailyLimitSeconds)}`
                    : `${fmtSec(d.dailyLimitSeconds - d.totals.application)} left of your ${fmtSec(d.dailyLimitSeconds)} daily limit`}
                  {d.totals.application === 0 && ' (nothing recorded yet)'}
                </p>
              </>
            )}
          </AsyncBoundary>
        </DashboardCard>

        <Summary title="Application usage" total={d?.totals.application ?? 0} items={apps} noun="application" query={today} />
        <Summary title="Website usage" tone="cream" total={d?.totals.website ?? 0} items={sites} noun="website" query={today} />
      </div>

      <h2 className="section-title">Go to</h2>
      <div className="quick">
        {PAGES.filter(([id]) => id !== 'home').map(([id, label]) => (
          <button key={id} className="btn" onClick={() => onNavigate(id)}>{label}</button>
        ))}
      </div>
    </>
  );
}
