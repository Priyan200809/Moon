import { useState } from 'react';
import ProgressBar from './ProgressBar.jsx';
import { SiteAvatar } from './SiteCard.jsx';
import { fmtSec } from '../lib/format.js';

// Status is always written out (and given a symbol), never conveyed by colour alone.
export const STATUS = {
  ok: { label: 'Normal', icon: '✓', cls: '' },
  warning: { label: 'Warning: 80% or more used', icon: '⚠', cls: 'flag-warn' },
  reached: { label: 'Limit reached', icon: '⛔', cls: 'flag-over' },
  extended: { label: 'Extra time active', icon: '+', cls: 'flag-live' },
  off: { label: 'Off', icon: '○', cls: '' },
};
export const MODE = {
  warn: { label: 'Warning only', help: 'Notifies you. Never blocks anything.' },
  confirm: { label: 'Ask me first', help: 'At the limit it asks whether to continue, and records your answer.' },
  enforce: { label: 'Block', help: 'Websites only: the browser extension replaces the tab with a block page. You can override or turn it off.' },
};

export default function LimitCard({ item, busy, onEdit, onToggle, onDelete, onExtend, onDecline }) {
  const [confirming, setConfirming] = useState(false);
  const st = STATUS[item.status] ?? STATUS.ok;
  const warnPct = item.status === 'warning' ? `${item.warningPercent}%` : null;
  return (
    <li className={`usage-item limit${item.isEnabled ? '' : ' site-off'}`}>
      <div className="usage-top">
        <div className="site-id">
          {item.targetType === 'website' ? <SiteAvatar domain={item.target} /> : <span className="avatar app" aria-hidden="true">▣</span>}
          <div>
            <h3>{item.target}</h3>
            <span className="domain">{item.targetType === 'website' ? 'Website' : 'Application'} · {MODE[item.mode].label}</span>
          </div>
        </div>
        <div className="site-flags">
          <span className={`flag ${st.cls}`} role="status"><span aria-hidden="true">{st.icon} </span>{st.label}{warnPct ? '' : ''}</span>
          {!item.isEnabled && <span className="flag">Disabled</span>}
        </div>
      </div>
      <ProgressBar used={item.usedSeconds} limit={item.allowanceSeconds} label={`${item.target} usage against today's limit`} />
      <dl className="usage-stats">
        <div><dt>Used today</dt><dd>{fmtSec(item.usedSeconds)}</dd></div>
        <div><dt>Daily limit</dt><dd>{fmtSec(item.dailyLimitSeconds)}</dd></div>
        <div><dt>Remaining</dt><dd>{fmtSec(item.remainingSeconds)}</dd></div>
        <div><dt>Extra approved</dt><dd>{item.extraSeconds ? `+${fmtSec(item.extraSeconds)}` : 'none'}</dd></div>
      </dl>
      {item.status === 'reached' && item.mode !== 'warn' && (
        <div className="site-actions">
          <button className="btn btn-small" disabled={busy} onClick={() => onExtend(item, item.extensionMinutes)}>{item.mode === 'enforce' ? 'Override' : 'Continue'}: {item.extensionMinutes} more minutes</button>
          {item.needsDecision && <button className="btn btn-small" disabled={busy} onClick={() => onDecline(item)}>Not now</button>}
        </div>
      )}
      <div className="site-actions">
        <button className="btn btn-small" disabled={busy} onClick={() => onToggle(item)} aria-pressed={item.isEnabled}>{item.isEnabled ? 'Turn off' : 'Turn on'}</button>
        <button className="btn btn-small" disabled={busy} onClick={() => onEdit(item)}>Edit</button>
        {!confirming ? <button className="btn btn-small" disabled={busy} onClick={() => setConfirming(true)}>Delete</button> : (
          <span className="inline-confirm" role="alert">Delete this limit? <button className="btn btn-small" onClick={() => { setConfirming(false); onDelete(item); }}>Yes, delete</button> <button className="btn btn-small" onClick={() => setConfirming(false)}>Cancel</button></span>
        )}
      </div>
    </li>
  );
}
