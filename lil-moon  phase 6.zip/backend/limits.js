// Usage-limit engine (Phase 6). Pure rules on top of stored usage records; no timers of its own.
//
// Key rules (non-obvious):
//  * Usage always comes from persisted usage_sessions rows for the LOCAL calendar day (the same session_date policy as tracking).
//    The website tracker checkpoints its open run before every evaluation, so "now" is included.
//  * allowance = daily limit + extra time the user approved today. Extra time is measured in USAGE minutes, not wall-clock.
//  * Status: below warning% -> ok; >= warning% -> warning; >= allowance -> reached; approved extra time still unused -> extended.
//  * A notification fires at most once per (limit, local day, kind). The claim is an atomic INSERT OR IGNORE, so repeated
//    ticks, concurrent requests and app restarts cannot repeat it. A new day starts with a clean slate; usage history is untouched.
//  * Each approved extension starts a new "cycle" (cycle = number of extensions today), so "extra time ended" can fire once per cycle.
//  * Application blocking is deliberately NOT offered: it needs the Phase 4 foreground-process service. Website enforcement is
//    performed by the browser extension, which asks this engine which domains are currently blocked.
const { localDate } = require('./database');
const { HttpError } = require('./validators');

const bad = (code, message, status = 400) => new HttpError(status, code, message);
const nextLocalMidnight = (ms) => { const d = new Date(ms); return new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).getTime(); };
const label = (l) => l.target;

function createLimitEngine({ repo, tracker = null, now = Date.now, notify = () => {} }) {
  const today = () => localDate(new Date(now()));

  function evaluate(limit, used, date, masterOn) {
    const extra = repo.extensionSecondsFor(limit.id, date);
    const cycle = repo.extensionCountFor(limit.id, date);
    const allowance = limit.dailyLimitSeconds + extra;
    let status = 'ok';
    if (!limit.isEnabled || !masterOn) status = 'off';
    else if (used >= allowance) status = 'reached';
    else if (extra > 0) status = 'extended';
    else if (used * 100 >= limit.dailyLimitSeconds * limit.warningPercent) status = 'warning';
    return {
      usedSeconds: used, extraSeconds: extra, allowanceSeconds: allowance, remainingSeconds: Math.max(0, allowance - used),
      percent: Math.min(999, Math.round((used / allowance) * 100)), status, cycle,
      needsDecision: status === 'reached' && limit.mode === 'confirm' && !repo.hasState(limit.id, date, `declined:${cycle}`),
    };
  }

  function snapshot() {
    tracker?.reconcile(); // store the open website run up to this instant
    const date = today();
    const masterOn = repo.restrictionsEnabled();
    const usage = repo.usageSecondsByTarget(date);
    const items = repo.listLimits().map((l) => ({ ...l, ...evaluate(l, usage.get(`${l.targetType}:${l.target.toLowerCase()}`) ?? 0, date, masterOn) }));
    let app = 0, site = 0;
    for (const [k, v] of usage) { if (k.startsWith('application:')) app += v; else if (k.startsWith('website:')) site += v; }
    return {
      date, restrictionsEnabled: masterOn, items,
      summary: { activeLimits: items.filter((i) => i.isEnabled).length, reachedToday: items.filter((i) => i.isEnabled && repo.hasState(i.id, date, 'reached:0')).length, applicationSeconds: app, websiteSeconds: site, needsDecision: items.filter((i) => i.needsDecision).length },
    };
  }

  const record = (l, eventType, extra = {}) => repo.addEvent({ category: l.targetType, itemName: l.target, eventType, limitId: l.id, ...extra });

  // Called after tracking updates and on a slow interval. Safe to call as often as you like.
  function tick() {
    const snap = snapshot();
    const actions = [];
    if (snap.restrictionsEnabled) {
      for (const it of snap.items) {
        if (!it.isEnabled) continue;
        if (it.status === 'reached') {
          if (it.cycle === 0) {
            repo.claimState(it.id, snap.date, 'warning'); // jumped straight past the warning: do not send a late 80% notice
            if (repo.claimState(it.id, snap.date, 'reached:0')) { record(it, 'limit_reached', { detail: `used ${it.usedSeconds}s of ${it.allowanceSeconds}s` }); actions.push({ type: 'reached', limit: it, snapshot: it }); }
          } else if (repo.claimState(it.id, snap.date, `ended:${it.cycle}`)) {
            record(it, 'extension_ended', { extraSeconds: it.extraSeconds }); actions.push({ type: 'extension_ended', limit: it, snapshot: it });
          }
        } else if (it.status === 'warning' && repo.claimState(it.id, snap.date, 'warning')) {
          record(it, 'limit_warning', { detail: `${it.percent}% used` }); actions.push({ type: 'warning', limit: it, snapshot: it });
        }
      }
    }
    repo.pruneState(new Date(now() - 14 * 86400000).toISOString().slice(0, 10));
    for (const a of actions) { try { notify(a); } catch (err) { console.error('[lil-moon] notification failed:', err); } }
    return actions;
  }

  const find = (id) => { const l = repo.getLimit(id); if (!l) throw bad('not_found', 'No such limit.', 404); return l; };
  const sayChange = (l, type) => { try { notify({ type, limit: l }); } catch (err) { console.error('[lil-moon] notification failed:', err); } };

  function checkModeFor(type, mode) {
    if (type === 'application' && mode === 'enforce') throw bad('unsupported_mode', 'Blocking applications is not available yet. Choose "Warning only" or "Ask me first" for applications.');
  }

  return {
    snapshot, tick,

    create(input) {
      checkModeFor(input.targetType, input.mode);
      if (input.targetType === 'website' && !repo.listWebsites().some((w) => w.domain === input.target)) {
        throw bad('not_tracked', `${input.target} is not on your tracked websites list. Add it on the Website usage page first.`);
      }
      if (repo.getLimitByTarget(input.targetType, input.target)) throw bad('duplicate', `There is already a limit for ${input.target}. Edit that one instead.`, 409);
      const l = repo.createLimit(input);
      record(l, l.isEnabled ? 'limit_enabled' : 'limit_disabled', { detail: 'created' });
      if (l.isEnabled) sayChange(l, 'enabled');
      return l;
    },

    update(id, patch) {
      const cur = find(id);
      if (patch.mode) checkModeFor(cur.targetType, patch.mode);
      const next = repo.updateLimit(id, patch);
      if (patch.dailyLimitSeconds !== undefined || patch.warningPercent !== undefined) repo.clearState(id, today()); // new thresholds may alert again today
      if (patch.isEnabled !== undefined && patch.isEnabled !== cur.isEnabled) {
        record(next, next.isEnabled ? 'limit_enabled' : 'limit_disabled', { detail: 'toggled' });
        sayChange(next, next.isEnabled ? 'enabled' : 'disabled');
      }
      return next;
    },

    remove(id) {
      const cur = find(id);
      record(cur, 'limit_deleted'); // written first: events outlive the limit
      repo.deleteLimit(id);
      return { id };
    },

    // The user approved extra time. Only possible while the limit is actually reached; never silent, always recorded.
    grantExtension(id, minutes, source = 'dashboard') {
      const l = find(id);
      const ev = snapshot().items.find((i) => i.id === id);
      if (l.mode === 'warn') throw bad('warn_only', 'This limit is warning-only, so nothing is blocked and there is nothing to extend.', 409);
      if (!l.isEnabled || ev.status !== 'reached') throw bad('not_reached', 'Extra time can only be added once the limit has been reached.', 409);
      repo.addExtension(id, today(), minutes * 60);
      const rec = record(l, l.mode === 'enforce' ? 'override' : 'extension_granted', { extraSeconds: minutes * 60, detail: `source: ${source}` });
      sayChange(l, 'extension_granted');
      return { eventId: rec, minutes, snapshot: snapshot().items.find((i) => i.id === id) };
    },

    declineExtension(id, source = 'dashboard') {
      const l = find(id);
      const ev = snapshot().items.find((i) => i.id === id);
      if (l.mode !== 'confirm' || ev.status !== 'reached') throw bad('not_pending', 'There is no pending decision for this limit.', 409);
      const first = repo.claimState(id, today(), `declined:${ev.cycle}`);
      if (first) record(l, 'extension_declined', { detail: `source: ${source}` });
      return { recorded: first };
    },

    setMaster(on) {
      if (repo.restrictionsEnabled() === on) return { enabled: on };
      repo.setRestrictionsEnabled(on);
      repo.addEvent({ category: 'all', itemName: 'All restrictions', eventType: on ? 'restrictions_on' : 'restrictions_off' });
      sayChange({ target: 'All restrictions' }, on ? 'master_on' : 'master_off');
      return { enabled: on };
    },

    // ---- website enforcement surface (what the extension may ask) ----
    blockedWebsites() {
      const snap = snapshot();
      if (!snap.restrictionsEnabled) return { items: [], validUntil: new Date(nextLocalMidnight(now())).toISOString() };
      return {
        validUntil: new Date(nextLocalMidnight(now())).toISOString(), // fail-open at local midnight even if the extension never hears from us again
        items: snap.items.filter((i) => i.isEnabled && i.targetType === 'website' && i.mode === 'enforce' && i.status === 'reached')
          .map((i) => ({ domain: i.target, usedSeconds: i.usedSeconds, allowanceSeconds: i.allowanceSeconds, extensionMinutes: i.extensionMinutes })),
      };
    },
    recordBlocked(domain) { // the extension reports that it really redirected a tab; one event per cycle
      const it = snapshot().items.find((i) => i.targetType === 'website' && i.target === domain && i.mode === 'enforce' && i.isEnabled && i.status === 'reached');
      if (!it) return { recorded: false };
      const first = repo.claimState(it.id, today(), `blocked:${it.cycle}`);
      if (first) { record(it, 'blocked', { detail: 'tab redirected by the browser extension' }); sayChange(it, 'blocked'); }
      return { recorded: first };
    },
    overrideDomain(domain) {
      const it = repo.getLimitByTarget('website', domain);
      if (!it || it.mode !== 'enforce') throw bad('no_restriction', 'No enforced restriction for that website.', 404);
      return this.grantExtension(it.id, it.extensionMinutes, 'block page');
    },
    disableDomain(domain) {
      const it = repo.getLimitByTarget('website', domain);
      if (!it) throw bad('no_restriction', 'No limit for that website.', 404);
      return this.update(it.id, { isEnabled: false });
    },
    limitForDomain(domain) {
      const it = snapshot().items.find((i) => i.targetType === 'website' && i.target === domain);
      return it ? { id: it.id, mode: it.mode, status: it.status, usedSeconds: it.usedSeconds, allowanceSeconds: it.allowanceSeconds, remainingSeconds: it.remainingSeconds, isEnabled: it.isEnabled } : null;
    },
    label,
  };
}

module.exports = { createLimitEngine };
