import { useEffect, useState } from 'react';
import { api } from '../lib/api.js';
import { fmtSec } from '../lib/format.js';
import { MODE } from './LimitCard.jsx';

const blank = { targetType: 'website', target: '', minutes: 60, mode: 'warn', warningPercent: 80, extensionMinutes: 10, isEnabled: true };

function problems(f, editing) {
  const e = {};
  if (!editing && !f.target.trim()) e.target = f.targetType === 'website' ? 'Choose a website from your tracked list.' : 'Enter or choose an application name.';
  if (!Number.isInteger(f.minutes) || f.minutes < 1) e.minutes = 'Enter a whole number of minutes, 1 or more.';
  else if (f.minutes > 1440) e.minutes = 'A daily limit cannot be more than 24 hours (1440 minutes).';
  if (!Number.isInteger(f.warningPercent) || f.warningPercent < 1 || f.warningPercent > 99) e.warningPercent = 'Use a number from 1 to 99.';
  if (f.mode === 'enforce' && f.targetType === 'application') e.mode = 'Blocking applications is not available yet. Choose Warning only or Ask me first.';
  return e;
}

export default function LimitForm({ editing, onDone, onCancel }) {
  const [f, setF] = useState(blank);
  const [targets, setTargets] = useState([]);
  const [errors, setErrors] = useState({});
  const [msg, setMsg] = useState({ text: '', error: false });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (editing) setF({ targetType: editing.targetType, target: editing.target, minutes: Math.round(editing.dailyLimitSeconds / 60), mode: editing.mode, warningPercent: editing.warningPercent, extensionMinutes: editing.extensionMinutes, isEnabled: editing.isEnabled });
    else setF(blank);
    setErrors({}); setMsg({ text: '', error: false });
  }, [editing]);

  useEffect(() => {
    let live = true;
    api('GET', `/api/limits/targets?type=${f.targetType}`).then((t) => live && setTargets(t)).catch(() => live && setTargets([]));
    return () => { live = false; };
  }, [f.targetType]);

  const set = (patch) => { setF((x) => ({ ...x, ...patch })); setMsg({ text: '', error: false }); };
  const num = (e) => (e.target.value === '' ? NaN : e.target.valueAsNumber);

  const submit = async (e) => {
    e.preventDefault();
    const found = problems(f, !!editing);
    setErrors(found);
    if (Object.keys(found).length) return;
    setSaving(true);
    try {
      const common = { dailyLimitSeconds: f.minutes * 60, mode: f.mode, warningPercent: f.warningPercent, extensionMinutes: f.extensionMinutes, isEnabled: f.isEnabled };
      if (editing) await api('PUT', `/api/limits/${editing.id}`, common);
      else await api('POST', '/api/limits', { targetType: f.targetType, target: f.target.trim(), ...common });
      setMsg({ text: editing ? 'Limit updated.' : 'Limit added.', error: false });
      if (!editing) setF(blank);
      onDone();
    } catch (err) { setMsg({ text: err.message, error: true }); } finally { setSaving(false); }
  };

  const listId = 'limit-targets';
  return (
    <form className="limit-form" onSubmit={submit} noValidate>
      <fieldset disabled={!!editing} className="fs">
        <legend>What to limit</legend>
        <label><input type="radio" name="type" checked={f.targetType === 'website'} onChange={() => set({ targetType: 'website', target: '', mode: f.mode === 'enforce' ? 'enforce' : f.mode })} /> Website</label>{' '}
        <label><input type="radio" name="type" checked={f.targetType === 'application'} onChange={() => set({ targetType: 'application', target: '', mode: f.mode === 'enforce' ? 'confirm' : f.mode })} /> Application</label>
      </fieldset>

      <label className="field">{f.targetType === 'website' ? 'Website (from your tracked list)' : 'Application name'}
        <input list={listId} value={f.target} disabled={!!editing} aria-invalid={!!errors.target} aria-describedby="err-target"
          onChange={(e) => set({ target: e.target.value })} placeholder={f.targetType === 'website' ? 'youtube.com' : 'Notepad'} maxLength={200} />
        <datalist id={listId}>{targets.map((t) => <option key={t.name} value={t.name}>{t.label}</option>)}</datalist>
        {errors.target && <span id="err-target" className="msg-error" role="alert">{errors.target}</span>}
        {f.targetType === 'application' && targets.length === 0 && <span className="note">No application has been tracked yet. Type the name exactly as it appears in your usage history.</span>}
      </label>

      <label className="field">Daily limit (minutes)
        <input type="number" min="1" max="1440" value={Number.isNaN(f.minutes) ? '' : f.minutes} aria-invalid={!!errors.minutes} onChange={(e) => set({ minutes: num(e) })} />
        {errors.minutes ? <span className="msg-error" role="alert">{errors.minutes}</span> : Number.isInteger(f.minutes) && f.minutes >= 1 && <span className="note">= {fmtSec(f.minutes * 60)} a day</span>}
      </label>

      <fieldset className="fs">
        <legend>What happens at the limit</legend>
        {Object.entries(MODE).map(([id, m]) => {
          const off = id === 'enforce' && f.targetType === 'application';
          return (
            <label key={id} className={`mode${off ? ' mode-off' : ''}`}>
              <input type="radio" name="mode" checked={f.mode === id} disabled={off} onChange={() => set({ mode: id })} />
              <span><b>{m.label}</b><br /><span className="note">{off ? 'Not available for applications yet (needs Windows process control).' : m.help}</span></span>
            </label>
          );
        })}
        {errors.mode && <span className="msg-error" role="alert">{errors.mode}</span>}
      </fieldset>

      <div className="two">
        <label className="field">Warn me at (% of limit)
          <input type="number" min="1" max="99" value={Number.isNaN(f.warningPercent) ? '' : f.warningPercent} aria-invalid={!!errors.warningPercent} onChange={(e) => set({ warningPercent: num(e) })} />
          {errors.warningPercent && <span className="msg-error" role="alert">{errors.warningPercent}</span>}
        </label>
        <label className="field">Extra time when you continue
          <select value={f.extensionMinutes} onChange={(e) => set({ extensionMinutes: Number(e.target.value) })} disabled={f.mode === 'warn'}>
            {[5, 10, 15, 30].map((m) => <option key={m} value={m}>{m} minutes</option>)}
          </select>
        </label>
      </div>

      <label className="check"><input type="checkbox" checked={f.isEnabled} onChange={(e) => set({ isEnabled: e.target.checked })} /> Limit is on</label>

      <div className="site-actions">
        <button className="btn" type="submit" disabled={saving}>{saving ? 'Saving...' : editing ? 'Save changes' : 'Add limit'}</button>
        {editing && <button className="btn" type="button" onClick={onCancel}>Cancel editing</button>}
      </div>
      <p role="status" className={msg.error ? 'msg-error' : 'note'}>{msg.text}</p>
    </form>
  );
}
