// Notification and confirmation behaviour with fake Electron Notification/dialog and the real limit engine.
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDatabase, createRepository } = require('../backend/database');
const { createTracker } = require('../backend/websiteTracker');
const { createLimitEngine } = require('../backend/limits');
const { createNotifier } = require('../electron/notifier');

const NOON = new Date(2026, 9, 31, 12, 0, 0).getTime();
function rig({ answer = 1, inFront = true } = {}) {
  const clock = { t: NOON };
  const repo = createRepository(openDatabase(':memory:'));
  const tracker = createTracker({ repo, now: () => clock.t });
  if (inFront) { tracker.onBrowser({ installId: 'install-note-1', seq: 0, kind: 'change', domain: 'youtube.com', paused: false, at: new Date(clock.t).toISOString() }); }
  const toasts = []; const dialogs = [];
  class FakeNotification { static isSupported() { return true; } constructor(o) { this.o = o; } on() {} show() { toasts.push(this.o); } }
  const dialog = { showMessageBox: async (o) => { dialogs.push(o); return { response: answer }; } };
  let notifier;
  const engine = createLimitEngine({ repo, tracker, now: () => clock.t, notify: (a) => notifier.handle(a) });
  notifier = createNotifier({ Notification: FakeNotification, dialog, engine, tracker, openDashboard: () => {} });
  const use = (n, s) => repo.insertSession({ category: 'website', itemName: n, startedAt: new Date(clock.t - s * 1000 - Math.random() * 500).toISOString(), endedAt: new Date(clock.t).toISOString(), durationSeconds: s });
  const make = (mode) => engine.create({ targetType: 'website', target: 'youtube.com', dailyLimitSeconds: 600, mode, warningPercent: 80, extensionMinutes: 10, isEnabled: true });
  const events = (t) => repo.listEvents({ limit: 100, offset: 0 }).records.filter((e) => e.eventType === t);
  return { clock, repo, engine, toasts, dialogs, use, make, events, notifier };
}
const flush = () => new Promise((r) => setTimeout(r, 20));

test('80% and 100% toasts are silent, say what happens, and appear once', async () => {
  const r = rig(); r.make('warn');
  r.use('youtube.com', 480); r.engine.tick(); r.engine.tick();
  r.use('youtube.com', 120); r.engine.tick(); r.engine.tick();
  const titles = r.toasts.map((t) => t.title);
  assert.equal(titles.filter((t) => t.includes('80%')).length, 1);
  assert.equal(titles.filter((t) => t.includes('Daily limit reached')).length, 1);
  assert.ok(r.toasts.every((t) => t.silent === true));
  assert.match(r.toasts.find((t) => t.title.includes('Daily limit reached')).body, /nothing is blocked/i);
  assert.equal(r.dialogs.length, 0);                                                  // warning-only never asks anything
});

test('confirmation mode: the dialog defaults to the safe choice, "continue" records the extension', async () => {
  const r = rig({ answer: 0 }); r.make('confirm');
  r.use('youtube.com', 600); r.engine.tick(); await flush();
  assert.equal(r.dialogs.length, 1);
  assert.deepEqual([r.dialogs[0].defaultId, r.dialogs[0].cancelId, r.dialogs[0].buttons[1]], [1, 1, 'Not now']);
  assert.match(r.dialogs[0].buttons[0], /10 more minutes/);
  const ev = r.events('extension_granted');
  assert.equal(ev.length, 1); assert.equal(ev[0].extraSeconds, 600); assert.match(ev[0].detail, /dialog/);
  assert.equal(r.engine.snapshot().items[0].allowanceSeconds, 1200);
  r.engine.tick(); await flush();
  assert.equal(r.dialogs.length, 1);                                                  // not asked again
});

test('confirmation mode: "Not now" records the decision and extends nothing', async () => {
  const r = rig({ answer: 1 }); r.make('confirm');
  r.use('youtube.com', 600); r.engine.tick(); await flush();
  assert.equal(r.events('extension_declined').length, 1);
  assert.equal(r.events('extension_granted').length, 0);
  assert.equal(r.engine.snapshot().items[0].allowanceSeconds, 600);
});

test('confirmation mode while the site is not in front: no dialog, a toast, and the decision waits in the dashboard', async () => {
  const r = rig({ inFront: false }); r.make('confirm');
  r.use('youtube.com', 600); r.engine.tick(); await flush();
  assert.equal(r.dialogs.length, 0);
  assert.ok(r.toasts.some((t) => /decide/i.test(t.body)));
  assert.equal(r.engine.snapshot().items[0].needsDecision, true);
  assert.equal(r.events('extension_granted').length + r.events('extension_declined').length, 0);       // nothing decided for the user
});

test('enforced mode explains the method; limit and master-switch changes are announced', async () => {
  const r = rig(); const l = r.make('enforce');
  r.use('youtube.com', 600); r.engine.tick();
  assert.ok(r.toasts.some((t) => /blocked in your browser/i.test(t.body)));
  r.engine.update(l.id, { isEnabled: false }); r.engine.setMaster(false); r.engine.setMaster(true);
  const titles = r.toasts.map((t) => t.title);
  for (const expect of ['Limit turned on', 'Limit turned off', 'All restrictions turned off', 'Restrictions turned on']) assert.ok(titles.includes(expect), expect);
});
