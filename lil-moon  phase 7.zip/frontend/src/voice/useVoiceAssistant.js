import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../lib/api.js';
import * as stt from './speechRecognitionService.js';
import * as tts from './textToSpeechService.js';

const PAGES = ['home', 'apps', 'sites', 'limits', 'voice', 'settings']; // voice may only navigate to these
let nextId = 1;

// One state machine: idle -> listening -> processing -> speaking -> idle. The microphone is only opened by start().
export function useVoiceAssistant({ settings, onNavigate }) {
  const [phase, setPhase] = useState('idle');
  const [partial, setPartial] = useState('');
  const [recognized, setRecognized] = useState('');
  const [response, setResponse] = useState(null);
  const [conversation, setConversation] = useState([]);
  const [confirmation, setConfirmation] = useState(null);
  const [error, setError] = useState('');
  const [micStatus, setMicStatus] = useState('unknown');
  const [historyTick, setHistoryTick] = useState(0);
  const settingsRef = useRef(settings);
  const phaseRef = useRef('idle');
  const restartAfterSpeech = useRef(false);
  const lastSpoken = useRef('');
  settingsRef.current = settings;
  const go = (p) => { phaseRef.current = p; setPhase(p); };

  const refreshPermission = useCallback(() => stt.permission().then(setMicStatus).catch(() => setMicStatus('unknown')), []);
  useEffect(() => { refreshPermission(); }, [refreshPermission]);

  const say = useCallback(async (res) => {
    const s = settingsRef.current;
    const speech = res.speech ?? res.text;
    if (!speech || !s || s.muted || !tts.ttsAvailable()) { go('idle'); return; }
    go('speaking');
    lastSpoken.current = speech;
    await tts.speak(speech, { voiceName: s.voiceName, rate: s.speechRate, volume: s.speechVolume, muted: s.muted });
    if (phaseRef.current === 'speaking') go('idle');
  }, []);

  const startListeningRef = useRef(null);

  const handleResult = useCallback(async (res, userText, source) => {
    setConversation((c) => [...c, { id: nextId++, role: 'user', text: userText, source }, { id: nextId++, role: 'assistant', text: res.text, status: res.status, details: res.details }]);
    setResponse(res);
    setConfirmation(res.confirmation || null);
    setHistoryTick((n) => n + 1);
    const ui = res.ui || {};
    if (ui.navigate && PAGES.includes(ui.navigate)) onNavigate?.(ui.navigate);
    if (ui.action === 'clear_conversation') { setConversation([]); setResponse(null); setRecognized(''); setPartial(''); }
    if (ui.action === 'stop_speaking') tts.stopSpeaking();
    if (ui.action === 'start_listening') restartAfterSpeech.current = true;
    await say(res);
    if (ui.action === 'start_listening' && restartAfterSpeech.current) { restartAfterSpeech.current = false; startListeningRef.current?.(); }
  }, [onNavigate, say]);

  const runCommand = useCallback(async (text, source = 'typed', confidence = 1) => {
    const t = String(text || '').trim();
    if (!t) return;
    tts.stopSpeaking();
    go('processing');
    setError('');
    try {
      const res = await api('POST', '/api/voice/command', { text: t, source, confidence });
      await handleResult(res, t, source);
    } catch (e) {
      const text2 = "I couldn't reach Lil Moon's backend, so I didn't do that.";
      setConversation((c) => [...c, { id: nextId++, role: 'user', text: t, source }, { id: nextId++, role: 'assistant', text: text2, status: 'error' }]);
      setResponse({ status: 'error', text: text2 });
      setError(e.message);
      go('idle');
    }
  }, [handleResult]);

  const confirm = useCallback(async (choice) => {
    if (!confirmation) return;
    go('processing');
    try {
      const res = await api('POST', '/api/voice/confirm', { id: confirmation.id, choice });
      await handleResult(res, choice === 'no' ? 'No' : (typeof choice === 'number' ? confirmation.options[choice] : 'Yes'), 'typed');
    } catch (e) { setError(e.message); go('idle'); }
  }, [confirmation, handleResult]);

  // Voice events from the main process (local speech recogniser).
  useEffect(() => stt.onEvent((e) => {
    if (!e || typeof e.type !== 'string') return;
    if (e.type === 'state') {
      if (e.state === 'starting' || e.state === 'listening') go('listening');
      else if (e.state === 'idle' && phaseRef.current === 'listening') go('idle');
    } else if (e.type === 'partial') setPartial(String(e.text || ''));
    else if (e.type === 'final') { setRecognized(e.text); setPartial(''); runCommand(e.text, 'voice', typeof e.confidence === 'number' ? e.confidence : 0.5); }
    else if (e.type === 'error') { setError(e.message || 'Speech recognition stopped.'); setPartial(''); refreshPermission(); if (phaseRef.current !== 'processing') go('idle'); }
    else if (e.type === 'stopped') { setPartial(''); if (phaseRef.current === 'listening') go('idle'); }
  }), [runCommand, refreshPermission]);

  const startListening = useCallback(async () => {
    const s = settingsRef.current;
    if (phaseRef.current === 'listening' || phaseRef.current === 'processing') return;
    if (s && !s.enabled) { setError('The voice assistant is turned off. Turn it on in the voice settings below.'); return; }
    tts.stopSpeaking();           // never listen to ourselves
    setError(''); setPartial(''); setRecognized(''); go('listening');
    const r = await stt.start(s?.language || 'en-US');
    if (!r?.ok) { setError(r?.error?.message || 'Could not start listening.'); refreshPermission(); go('idle'); }
  }, [refreshPermission]);
  startListeningRef.current = startListening;

  const stopListening = useCallback(() => { stt.stop(); setPartial(''); if (phaseRef.current === 'listening') go('idle'); }, []);
  const stopSpeaking = useCallback(() => { tts.stopSpeaking(); if (phaseRef.current === 'speaking') go('idle'); }, []);
  const repeatAloud = useCallback(() => { if (response) say(response); }, [response, say]);
  const clear = useCallback(() => { setConversation([]); setResponse(null); setRecognized(''); setPartial(''); setConfirmation(null); setError(''); }, []);

  // Leaving the page (or closing the dashboard) must never leave the microphone open.
  useEffect(() => () => { stt.stop(); tts.stopSpeaking(); }, []);

  return { phase, partial, recognized, response, conversation, confirmation, error, micStatus, historyTick, startListening, stopListening, stopSpeaking, runCommand, confirm, repeatAloud, clear, refreshPermission };
}
