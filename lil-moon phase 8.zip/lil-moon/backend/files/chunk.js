// Cleaning and chunking. Chunks are ~1200 characters, split on paragraph then line then character boundaries.
const SIZE = 1200;
const OVERLAP = 150;
const MAX_CHUNKS = 2000;

const clean = (t) => t.normalize('NFC').replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').replace(/[^\S\n]+/g, ' ').replace(/ ?\n ?/g, '\n').replace(/\n{3,}/g, '\n\n').trim();

function pieces(text) {
  const out = [];
  for (const para of text.split(/\n\n/)) {
    if (para.length <= SIZE) { out.push(para); continue; }
    let acc = '';
    for (const line of para.split('\n')) {
      if (line.length > SIZE) {
        if (acc) { out.push(acc); acc = ''; }
        for (let i = 0; i < line.length; i += SIZE - OVERLAP) out.push(line.slice(i, i + SIZE));
      } else if ((acc + '\n' + line).length > SIZE) { out.push(acc); acc = line; }
      else acc = acc ? `${acc}\n${line}` : line;
    }
    if (acc) out.push(acc);
  }
  return out;
}

function chunkSections(sections) {
  const chunks = [];
  for (const s of sections) {
    const text = clean(s.text);
    if (!text) continue;
    let acc = '';
    for (const piece of pieces(text)) {
      if (acc && (acc + '\n\n' + piece).length > SIZE) { chunks.push({ heading: s.heading ?? null, text: acc }); acc = piece; }
      else acc = acc ? `${acc}\n\n${piece}` : piece;
    }
    if (acc) chunks.push({ heading: s.heading ?? null, text: acc });
    if (chunks.length >= MAX_CHUNKS) return chunks.slice(0, MAX_CHUNKS);
  }
  return chunks;
}

module.exports = { clean, chunkSections, SIZE };
