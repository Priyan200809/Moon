const { app, ipcMain } = require('electron');
const wm = require('./windowManager');
const path = require('path');
const store = require('./settingsStore');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer } = require('../backend/server');

// The API accepts requests only from our own pages: file:// (Origin "null") in production, the Vite origin in dev.
const allowedOrigins = process.env.LILMOON_DEV_URL ? [new URL(process.env.LILMOON_DEV_URL).origin] : ['null'];
let backend = null;
let backendError = '';

async function startBackend() {
  try {
    const db = openDatabase(path.join(app.getPath('userData'), 'lil-moon.db'), { legacyPreferences: store.getLegacyPreferences() });
    try {
      backend = { db, api: await startServer({ repo: createRepository(db), allowedOrigins }) };
    } catch (err) { db.close(); throw err; }
  } catch (err) {
    console.error('[lil-moon] backend failed to start:', err);
    backendError = 'Lil Moon could not open its local database. Your data was not changed.';
  }
}

// Accept a command only from the exact window (top frame) that is allowed to send it.
function windowFor(who, event) {
  const win = who === 'moon' ? wm.getMoon() : wm.getDashboard();
  const ok = win && !win.isDestroyed() && event.sender === win.webContents && event.senderFrame === event.sender.mainFrame;
  return ok ? win : null;
}
function on(channel, who, handler) {
  ipcMain.on(channel, (event) => { const win = windowFor(who, event); if (win) handler(win); });
}
function handle(channel, who, handler) {
  ipcMain.handle(channel, (event, payload) => {
    if (!windowFor(who, event)) throw new Error('Rejected');
    return handler(payload);
  });
}

function registerIpc() {
  on('moon:drag-start', 'moon', wm.dragStart);
  on('moon:drag-move', 'moon', wm.dragMove);
  on('moon:drag-end', 'moon', wm.dragEnd);
  on('moon:menu', 'moon', wm.showMoonMenu);
  on('dashboard:open', 'moon', wm.openDashboard);
  on('dashboard:minimize', 'dashboard', (w) => w.minimize());
  on('dashboard:close', 'dashboard', (w) => w.close());
  on('dashboard:toggle-maximize', 'dashboard', (w) => (w.isMaximized() ? w.unmaximize() : w.maximize()));
  on('app:exit', 'dashboard', wm.quit);
  // Only the dashboard window may learn the API address and its per-launch token.
  handle('api:config', 'dashboard', () => (backend ? { baseUrl: backend.api.baseUrl, token: backend.api.token } : { error: backendError }));
  ipcMain.handle('app:version', () => app.getVersion());
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => wm.openDashboard());
  app.whenReady().then(async () => {
    registerIpc();
    await startBackend(); // the moon still appears if the database fails
    wm.createMoon();
  });
  app.on('will-quit', () => {
    if (!backend) return;
    const { api, db } = backend;
    backend = null;
    api.close(); // stops listening and drops connections synchronously
    try { db.close(); } catch { /* ignore */ }
  });
  // The moon keeps the app alive; closing the dashboard never quits.
  app.on('window-all-closed', () => {});
  app.on('before-quit', wm.prepareQuit);
}
