import { useCallback, useEffect, useState } from 'react';
import { api } from '../lib/api.js';

// GET a path; exposes {status, data, error, reload}. Keeps old data visible while reloading.
export function useApi(path) {
  const [state, setState] = useState({ status: 'loading', data: null, error: '' });
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let live = true;
    setState((s) => ({ ...s, status: 'loading', error: '' }));
    api('GET', path)
      .then((data) => live && setState({ status: 'ready', data, error: '' }))
      .catch((e) => live && setState({ status: 'error', data: null, error: e.message }));
    return () => { live = false; };
  }, [path, tick]);
  const reload = useCallback(() => setTick((n) => n + 1), []);
  return { ...state, reload };
}
