// Turns limit-engine actions into native Windows toasts and, in "ask me first" mode, a native confirmation dialog.
//  - Toasts are silent and never take focus, so unrelated work is not interrupted.
//  - The confirmation dialog appears only when the limited website is the one in front right now; otherwise a toast points to the
//    dashboard, where the pending decision waits (nothing is ever extended without an explicit choice).
//  - The engine guarantees one action per limit/day/kind, so nothing here needs to de-duplicate (it only guards double dialogs).
const fmt = (sec) => {
  const s = Math.max(0, Math.round(sec));
  if (s < 60) return `${s} seconds`;
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
  return h ? `${h} h${m ? ` ${m} min` : ''}` : `${m} min`;
};

function createNotifier({ Notification, dialog, engine, tracker, openDashboard, log = console }) {
  const asking = new Set();
  const shown = []; // last few toasts, for the automated smoke test
  const toast = (title, body) => {
    shown.push({ title, body }); if (shown.length > 25) shown.shift();
    try {
      if (!Notification.isSupported()) return;
      const n = new Notification({ title, body, silent: true });
      n.on('click', () => openDashboard());
      n.show();
    } catch (err) { log.error('[lil-moon] toast failed:', err); }
  };

  async function ask(limit, snap) {
    if (asking.has(limit.id)) return;
    asking.add(limit.id);
    try {
      const { response } = await dialog.showMessageBox({
        type: 'question', title: 'Lil Moon', noLink: true,
        buttons: [`Continue for ${limit.extensionMinutes} more minutes`, 'Not now'], defaultId: 1, cancelId: 1, // the safe choice is the default
        message: `You have reached today's limit for ${limit.target}.`,
        detail: `Used ${fmt(snap.usedSeconds)} of ${fmt(snap.allowanceSeconds)}. Continuing adds ${limit.extensionMinutes} minutes for today only, and your choice is saved in the restriction history.`,
      });
      if (response === 0) engine.grantExtension(limit.id, limit.extensionMinutes, 'dialog');
      else engine.declineExtension(limit.id, 'dialog');
    } catch (err) {
      log.error('[lil-moon] confirmation could not be recorded:', err.message); // e.g. the limit changed while the dialog was open
    } finally { asking.delete(limit.id); }
  }

  const inFront = (limit) => limit.targetType === 'website' && tracker && tracker.status().countingDomain === limit.target;

  function reachedBy(limit, snap, again) {
    const lead = again ? `Extra time for ${limit.target} is used up.` : `Daily limit reached: ${limit.target}.`;
    if (limit.mode === 'warn') return toast(lead, 'Warning only: nothing is blocked.');
    if (limit.mode === 'enforce') return toast(lead, 'It is now blocked in your browser. Open Lil Moon to override or turn the limit off.');
    if (inFront(limit)) return void ask(limit, snap);
    return toast(lead, 'Open Lil Moon to decide whether to continue.');
  }

  return {
    shown,
    handle(a) {
      const l = a.limit;
      switch (a.type) {
        case 'warning': return toast(`${l.target}: ${a.snapshot.percent}% of today's limit`, `${fmt(a.snapshot.remainingSeconds)} left today.`);
        case 'reached': return reachedBy(l, a.snapshot, false);
        case 'extension_ended': return reachedBy(l, a.snapshot, true);
        case 'extension_granted': return toast(`Extra time approved: ${l.target}`, 'It was saved in the restriction history.');
        case 'blocked': return toast(`${l.target} is blocked for now`, 'Only this site is affected. Open Lil Moon to override or turn the limit off.');
        case 'enabled': return toast('Limit turned on', `${l.target}: ${fmt(l.dailyLimitSeconds)} a day.`);
        case 'disabled': return toast('Limit turned off', `${l.target} is no longer limited.`);
        case 'master_on': return toast('Restrictions turned on', 'Limits are active again.');
        case 'master_off': return toast('All restrictions turned off', 'Usage is still recorded. Nothing will warn or block.');
        default: return undefined;
      }
    },
  };
}

module.exports = { createNotifier, fmt };
