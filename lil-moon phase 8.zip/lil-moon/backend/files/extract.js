// Text extraction per file type. Returns { sections: [{ heading, text }] }. Never executes or modifies the file.
const fsp = require('fs/promises');
const path = require('path');
const { readEntry } = require('./zip');

const TEXT_EXT = new Set(['txt', 'md', 'csv', 'json', 'py', 'js', 'jsx', 'ts', 'tsx', 'html', 'css', 'sql']);
const SUPPORTED = new Set([...TEXT_EXT, 'pdf', 'docx']);
const MAX_TEXT_BYTES = 2 * 1024 * 1024;
const MAX_BINARY_BYTES = 25 * 1024 * 1024;
const MAX_PDF_PAGES = 500;

const unxml = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16))).replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d))).replace(/&amp;/g, '&');

const extOf = (name) => path.extname(name).slice(1).toLowerCase();
const maxBytesFor = (ext) => (ext === 'pdf' || ext === 'docx' ? MAX_BINARY_BYTES : MAX_TEXT_BYTES);

function decodeText(buf) {
  if (buf.includes(0)) throw new Error('Binary content, skipped.');
  return buf.toString('utf8').replace(/^\uFEFF/, '');
}

function markdownSections(text) {
  const sections = [];
  let heading = null, lines = [];
  const flush = () => { if (lines.join('').trim()) sections.push({ heading, text: lines.join('\n') }); lines = []; };
  for (const line of text.split(/\r?\n/)) {
    const m = /^#{1,6}\s+(.+?)\s*#*$/.exec(line);
    if (m) { flush(); heading = m[1]; }
    lines.push(line);
  }
  flush();
  return sections;
}

function csvSections(text) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim());
  if (!lines.length) return [];
  const header = lines[0], out = [];
  for (let i = 1; i < lines.length || i === 1; i += 20) out.push({ heading: `Columns: ${header.slice(0, 120)}`, text: [header, ...lines.slice(i, i + 20)].join('\n') });
  return out;
}

function docxSections(buf) {
  const xml = readEntry(buf, 'word/document.xml');
  if (!xml) throw new Error('Not a Word document.');
  const sections = [];
  let heading = null, paras = [];
  const flush = () => { if (paras.join('').trim()) sections.push({ heading, text: paras.join('\n') }); paras = []; };
  for (const p of xml.toString('utf8').split('</w:p>')) {
    const style = /<w:pStyle w:val="([^"]+)"/.exec(p)?.[1] ?? '';
    const text = unxml([...p.matchAll(/<w:t(?:\s[^>]*)?>([^<]*)<\/w:t>|<w:tab\/>|<w:br\/>/g)].map((m) => (m[0].startsWith('<w:tab') ? '\t' : m[0].startsWith('<w:br') ? '\n' : m[1])).join(''));
    if (!text.trim()) continue;
    if (/^Heading\d|^Title$/i.test(style)) { flush(); heading = text.trim().slice(0, 120); }
    paras.push(text);
  }
  flush();
  return sections;
}

let pdfjs = null;
async function pdfSections(buf) {
  pdfjs ??= await import('pdfjs-dist/legacy/build/pdf.mjs');
  const task = pdfjs.getDocument({ data: new Uint8Array(buf), isEvalSupported: false, disableFontFace: true, useSystemFonts: false, verbosity: 0 });
  const doc = await task.promise;
  try {
    const sections = [];
    for (let n = 1; n <= Math.min(doc.numPages, MAX_PDF_PAGES); n++) {
      const page = await doc.getPage(n);
      const content = await page.getTextContent();
      const text = content.items.map((i) => i.str + (i.hasEOL ? '\n' : ' ')).join('');
      if (text.trim()) sections.push({ heading: `Page ${n}`, text });
      page.cleanup();
    }
    return sections;
  } finally { await task.destroy(); }
}

async function extractFile(fullPath, size) {
  const ext = extOf(fullPath);
  if (!SUPPORTED.has(ext)) throw new Error('Unsupported file type.');
  if (size > maxBytesFor(ext)) throw new Error('File is too large to index.');
  const buf = await fsp.readFile(fullPath);
  if (ext === 'pdf') return { sections: await pdfSections(buf) };
  if (ext === 'docx') return { sections: docxSections(buf) };
  const text = decodeText(buf);
  if (ext === 'md') return { sections: markdownSections(text) };
  if (ext === 'csv') return { sections: csvSections(text) };
  return { sections: [{ heading: null, text }] };
}

module.exports = { extractFile, SUPPORTED, extOf };
