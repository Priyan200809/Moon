import { fmtSec, fmtWhen } from '../lib/format.js';

export default function HistoryList({ records, onDelete }) {
  return (
    <ul className="history">
      {records.map((r) => (
        <li key={r.id}>
          <div>
            <strong>{r.itemName}</strong>
            <span>{fmtWhen(r.startedAt)}</span>
          </div>
          <b>{fmtSec(r.durationSeconds)}</b>
          <button className="btn btn-small" onClick={() => onDelete(r.id)} aria-label={`Delete session for ${r.itemName}`}>Delete</button>
        </li>
      ))}
    </ul>
  );
}
