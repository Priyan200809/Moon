// Service worker. Event-driven and restart-safe: every handler re-reads state from chrome.storage, asks the
// browser what is focused right now ("observe"), and lets tracker.js decide. Nothing relies on timers firing on time.
import { advance, checkpoint, decideTarget, emptyState, settle } from './tracker.js';

const KEY = 'lilMoonState';
const PORTS = Array.from({ length: 10 }, (_, i) => 47821 + i);
const ALARM = 'lil-moon-tick';

const defaults = () => ({
  ...emptyState(), paused: false, pairingCode: '', port: null,
  config: { trackingEnabled: true, idleThresholdSeconds: 60, domains: [] },
  desktop: { online: false, authOk: true, lastOkAt: null, lastError: '', idle: { inactive: false, reason: null } },
  today: { websiteSeconds: 0 }, idleFallback: 'active', lastSyncAttempt: 0, lastDecision: { domain: null, reason: 'not_paired' },
});

let mem = null;
let queue = Promise.resolve();
const run = (fn) => (queue = queue.then(fn, fn)); // serialise: events can arrive while a sync is in flight

async function load() {
  if (!mem) mem = { ...defaults(), ...((await chrome.storage.local.get(KEY))[KEY] ?? {}) };
  return mem;
}
const save = () => chrome.storage.local.set({ [KEY]: mem });

// ---- what does the browser say is happening right now? ----
async function observe() {
  let win = null;
  try { win = await chrome.windows.getLastFocused(); } catch { /* no window */ }
  const focused = !!win && win.focused === true && win.state !== 'minimized' && win.type !== 'devtools';
  let tab = null;
  if (focused) [tab] = await chrome.tabs.query({ active: true, windowId: win.id });
  return { windowFocused: focused, incognito: !!(win?.incognito || tab?.incognito), url: tab?.url ?? null };
}

// ---- talking to the desktop app (loopback only) ----
async function request(s, path, { method = 'GET', body, auth = true } = {}) {
  const ports = s.port ? [s.port, ...PORTS.filter((p) => p !== s.port)] : PORTS;
  let lastErr = null;
  for (const port of ports) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), s.port === port ? 4000 : 700);
    try {
      const res = await fetch(`http://127.0.0.1:${port}${path}`, {
        method, signal: ctl.signal,
        headers: { ...(auth && { Authorization: `Bearer ${s.pairingCode}` }), ...(body && { 'Content-Type': 'application/json' }) },
        body: body ? JSON.stringify(body) : undefined,
      });
      const json = await res.json().catch(() => null);
      if (json && (json.ok || json.error)) { s.port = port; return { status: res.status, json }; }
    } catch (err) { lastErr = err; } finally { clearTimeout(timer); }
  }
  s.port = null;
  throw lastErr ?? new Error('Lil Moon is not running.');
}

async function sync(s, now) {
  s.lastSyncAttempt = now;
  const batch = s.buffer.slice(0, 100);
  try {
    const { status, json } = await request(s, '/ext/sync', {
      method: 'POST', body: { paused: s.paused, browser: 'chrome', version: chrome.runtime.getManifest().version, sessions: batch },
    });
    if (status === 401) {
      Object.assign(s.desktop, { online: true, authOk: false, lastError: 'The pairing code was rejected. Create a new one in Lil Moon.' });
      return;
    }
    if (!json.ok) { Object.assign(s.desktop, { online: true, lastError: json.error?.message ?? 'Sync failed.' }); return; }
    const d = json.data;
    const left = settle({ ...emptyState(), buffer: s.buffer }, d.results);
    s.buffer = left.buffer;
    s.config = d.config;
    s.today = { websiteSeconds: d.today.websiteSeconds };
    Object.assign(s.desktop, { online: true, authOk: true, lastOkAt: now, lastError: '', idle: d.idle });
    if (chrome.idle?.setDetectionInterval) chrome.idle.setDetectionInterval(Math.max(15, d.config.idleThresholdSeconds));
  } catch {
    Object.assign(s.desktop, { online: false, lastError: 'Lil Moon is not running or not reachable.' });
  }
}

// ---- the one reconciliation routine every trigger funnels into ----
function reconcile({ tick = false, forceSync = false } = {}) {
  return run(async () => {
    const s = await load();
    const now = Date.now();
    const obs = await observe();
    const decision = decideTarget({
      paused: s.paused, paired: !!s.pairingCode, trackingEnabled: s.config.trackingEnabled, domains: s.config.domains, ...obs,
      // chrome.idle is only a fallback while the desktop app (the real idle authority) is unreachable.
      idleBlocked: !s.desktop.online && s.idleFallback !== 'active',
    });
    let st = advance(s, decision.domain ? decision : null, now);
    if (tick) st = checkpoint(st, now);
    Object.assign(s, { current: st.current, buffer: st.buffer, dropped: st.dropped, lastDecision: decision });
    const due = s.pairingCode && (forceSync || tick || (s.buffer.length > 0 && now - s.lastSyncAttempt > 5000));
    if (due) await sync(s, now);
    await save();
    return s;
  });
}

function status(s) {
  const site = s.config.domains.find((d) => d.domain === s.current?.domain);
  return {
    paused: s.paused, paired: !!s.pairingCode, desktopOnline: s.desktop.online, authOk: s.desktop.authOk, lastOkAt: s.desktop.lastOkAt,
    lastError: s.desktop.lastError, trackingEnabled: s.config.trackingEnabled, desktopIdle: s.desktop.idle,
    current: s.current?.domain ?? null, currentName: site?.displayName ?? s.current?.domain ?? null, reason: s.lastDecision.reason,
    todayWebsiteSeconds: s.today.websiteSeconds, buffered: s.buffer.length, dropped: s.dropped,
  };
}

// ---- wiring (all listeners registered synchronously at start-up, as MV3 requires) ----
const poke = () => { reconcile().catch(() => {}); };
chrome.tabs.onActivated.addListener(poke);
chrome.tabs.onUpdated.addListener((id, change) => { if (change.url || change.status === 'complete' || change.status === 'loading') poke(); });
chrome.tabs.onRemoved.addListener(poke);
chrome.tabs.onReplaced.addListener(poke);
chrome.windows.onFocusChanged.addListener(poke);
chrome.windows.onRemoved.addListener(poke);
chrome.idle.onStateChanged.addListener((state) => run(async () => { (await load()).idleFallback = state; await save(); }).then(poke));
chrome.runtime.onStartup.addListener(() => { ensureAlarm(); reconcile({ forceSync: true }).catch(() => {}); });
chrome.runtime.onInstalled.addListener(() => { ensureAlarm(); reconcile({ forceSync: true }).catch(() => {}); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM) reconcile({ tick: true }).catch(() => {}); });
function ensureAlarm() { chrome.alarms.create(ALARM, { periodInMinutes: 0.5 }); } // 30 s: the minimum Chrome allows
ensureAlarm();
poke(); // service worker just (re)started: recover any open session and re-sync

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (sender.id !== chrome.runtime.id) return false;
  (async () => {
    if (msg.type === 'togglePause') { (await load()).paused = !mem.paused; await save(); return status(await reconcile({ forceSync: true })); }
    if (msg.type === 'pair') {
      const code = String(msg.code ?? '').trim();
      if (!/^[A-Za-z0-9-]{10,40}$/.test(code)) return { ...status(await load()), lastError: 'That does not look like a pairing code.' };
      Object.assign(await load(), { pairingCode: code }); mem.desktop.authOk = true; await save();
      return status(await reconcile({ forceSync: true }));
    }
    if (msg.type === 'unpair') { Object.assign(await load(), { pairingCode: '', config: defaults().config, today: { websiteSeconds: 0 } }); await save(); return status(await reconcile()); }
    if (msg.type === 'openDashboard') { const s = await load(); try { await request(s, '/ext/open-dashboard', { method: 'POST', body: {} }); } catch { /* app not running */ } return status(s); }
    if (msg.type === 'syncNow') return status(await reconcile({ forceSync: true }));
    return status(await reconcile());
  })().then(reply, (e) => reply({ error: String(e?.message ?? e) }));
  return true; // async reply
});
