# Lil Moon (Phase 1)

A floating, moon-shaped desktop companion for Windows. Neobrutalism look, built with Electron + React.

## Setup (Windows 10/11)
1. Install Node.js 20 or newer (LTS) from https://nodejs.org (includes npm).
2. Open PowerShell in this folder and run:
```
npm install
```

## Run
- Normal run (builds the UI, then launches): `npm start`
- Development (Vite dev server, UI reloads on save): `npm run dev`
- Build the UI only: `npm run build`
- Backend/database tests (plain Node 22.13+, no window): `npm test`
- Electron smoke test: `npm run smoke` (Linux/CI with a display; see "Testing")

## Use
- Drag the moon anywhere. A short click opens the dashboard; a drag never does.
- Clicking again focuses (or restores) the same dashboard window.
- Dashboard buttons: Minimize, Close (moon stays), Exit Lil Moon (quits everything).
- Right-click the moon for Open dashboard / Exit Lil Moon.
- The moon's position is saved to `%APPDATA%\lil-moon\settings.json` and restored on launch.

## Dashboard and local database (Phases 2-3)
Sections: Home, Application usage, Website usage, Voice assistant, Settings. Data comes from a local SQLite database through a local-only API. See `docs/BACKEND.md` for the schema, API reference, time-zone strategy and security notes.
- **Real (database-backed):** daily limit (default 3 h), theme, usage summaries, usage history, database status.
- **Manual for now:** nothing is tracked automatically. Use "Add a test session" on the usage pages to create records (they can be deleted from History).
- **Placeholders:** voice assistant (mic, history, examples), "Start with Windows", automatic application/website tracking, restrictions.

## Layout
```
backend/    database.js (SQLite, migrations, queries), validators.js, server.js (Express API)
electron/   main.js (lifecycle + IPC validation), windowManager.js (windows, drag), settingsStore.js (moon position file), preload.js (bridge)
frontend/   React UI (one bundle, routes #/moon and #/dashboard): pages/, components/, hooks/, data/sampleData.js
scripts/    dev.js (Vite + Electron), smoke.js (automated test)
```

## Security
contextIsolation on, nodeIntegration off, sandbox on, preload exposes only fixed no-argument commands, main checks that each command comes from the correct window's top frame, navigation and new windows are blocked, production CSP is set in index.html. No filesystem or shell access is exposed.

## Troubleshooting
- Blank or missing moon: run `npm run build` first, or use `npm start`.
- Electron download failed during install: re-run `npm install`, or `node node_modules/electron/install.js`.
- Port 5173 busy in dev: close the other Vite process.
- Moon hidden behind a full-screen exclusive game: expected; borderless/windowed games are fine.
- Reset the moon's position: delete `%APPDATA%\lil-moon\settings.json`.
- Dashboard says it could not open the database: the file is kept untouched; close other copies of Lil Moon and press Try again. To start fresh, quit Lil Moon and delete `%APPDATA%\lil-moon\lil-moon.db*` (this erases your data).
- A console warning that SQLite is experimental is expected.

## Implemented
Floating frameless transparent always-on-top moon, drag vs click detection, dashboard with sample-data cards, single dashboard instance, minimize/close/exit, edge clamping, multi-monitor and display-change handling, saved position.

## Known limitations
- Application/website usage, voice assistant and settings are visual placeholders; sample data is labelled.
- No tray icon or app icon yet (the moon's right-click menu is the way out without opening the dashboard).
- Windows-specific behaviour (DPI scaling, always-on-top over other topmost windows) was not tested on real Windows.

## Testing
`npm test` runs the 13 backend tests. `npm run smoke` runs two phases (set `SMOKE_PHASE=1` then `2` with the same `SMOKE_DIR`) to check restart persistence. Under Linux use `xvfb-run -a npx electron --no-sandbox scripts/smoke.js`.
