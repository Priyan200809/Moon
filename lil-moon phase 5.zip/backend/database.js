// SQLite via Node's built-in node:sqlite (no native module to compile). Used from Electron's main process.
// TIME STRATEGY: every timestamp column holds UTC ISO-8601 with milliseconds ("2026-10-25T14:03:09.120Z").
// session_date is the LOCAL calendar day (YYYY-MM-DD) of started_at on this machine; "today" means the local day.
const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULT_DAILY_LIMIT_SECONDS = 10800; // 3 hours
const THEMES = ['sunny', 'cream', 'lilac'];

// Append-only list. Index i upgrades schema version i -> i+1 (tracked in PRAGMA user_version).
const MIGRATIONS = [
  `CREATE TABLE user_settings (
     id INTEGER PRIMARY KEY CHECK (id = 1),
     daily_limit_seconds INTEGER NOT NULL DEFAULT ${DEFAULT_DAILY_LIMIT_SECONDS} CHECK (daily_limit_seconds BETWEEN 300 AND 86400),
     theme TEXT NOT NULL DEFAULT 'sunny' CHECK (theme IN ('sunny','cream','lilac')),
     created_at TEXT NOT NULL,
     updated_at TEXT NOT NULL
   );
   CREATE TABLE applications (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     app_name TEXT NOT NULL CHECK (length(trim(app_name)) BETWEEN 1 AND 200),
     executable_name TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(executable_name)) BETWEEN 1 AND 260),
     is_enabled INTEGER NOT NULL DEFAULT 1 CHECK (is_enabled IN (0,1))
   );
   CREATE TABLE websites (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     domain TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(domain)) BETWEEN 1 AND 253),
     display_name TEXT NOT NULL CHECK (length(trim(display_name)) BETWEEN 1 AND 200),
     is_enabled INTEGER NOT NULL DEFAULT 1 CHECK (is_enabled IN (0,1))
   );
   CREATE TABLE usage_sessions (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     category TEXT NOT NULL CHECK (category IN ('application','website')),
     item_name TEXT NOT NULL CHECK (length(trim(item_name)) BETWEEN 1 AND 200),
     started_at TEXT NOT NULL,
     ended_at TEXT NOT NULL,
     duration_seconds INTEGER NOT NULL CHECK (duration_seconds BETWEEN 0 AND 86400),
     session_date TEXT NOT NULL CHECK (session_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
     CHECK (ended_at >= started_at)
   );
   CREATE INDEX idx_usage_date_item ON usage_sessions (session_date, category, item_name);
   CREATE INDEX idx_usage_item_start ON usage_sessions (category, item_name, started_at);
   CREATE INDEX idx_usage_started ON usage_sessions (started_at);
   CREATE TABLE restriction_events (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     category TEXT NOT NULL CHECK (category IN ('application','website')),
     item_name TEXT NOT NULL CHECK (length(trim(item_name)) BETWEEN 1 AND 200),
     event_type TEXT NOT NULL CHECK (event_type IN ('limit_warning','limit_reached','blocked')),
     created_at TEXT NOT NULL
   );
   CREATE INDEX idx_restriction_created ON restriction_events (created_at);
   CREATE INDEX idx_restriction_item ON restriction_events (category, item_name, created_at);`,
  // v1 -> v2 (Phase 5, website tracking): idle threshold + extension pairing token on the settings row, configurable
  // domain aliases, a unique index so the same website run can never be stored twice, and the default tracked sites.
  `ALTER TABLE user_settings ADD COLUMN idle_threshold_seconds INTEGER NOT NULL DEFAULT 60 CHECK (idle_threshold_seconds BETWEEN 10 AND 3600);
   ALTER TABLE user_settings ADD COLUMN extension_token TEXT;
   CREATE TABLE domain_aliases (
     alias TEXT PRIMARY KEY COLLATE NOCASE CHECK (length(trim(alias)) BETWEEN 3 AND 253),
     canonical TEXT NOT NULL COLLATE NOCASE CHECK (length(trim(canonical)) BETWEEN 3 AND 253)
   );
   CREATE UNIQUE INDEX ux_usage_website_start ON usage_sessions (item_name, started_at) WHERE category = 'website';
   INSERT OR IGNORE INTO websites (domain, display_name, is_enabled) VALUES
     ('youtube.com','YouTube',1), ('instagram.com','Instagram',1), ('github.com','GitHub',1), ('reddit.com','Reddit',1), ('linkedin.com','LinkedIn',1);
   INSERT OR IGNORE INTO domain_aliases (alias, canonical) VALUES ('youtu.be','youtube.com'), ('redd.it','reddit.com'), ('lnkd.in','linkedin.com');`,
];

const nowIso = () => new Date().toISOString();
const pad = (n) => String(n).padStart(2, '0');
const localDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

function migrate(db) {
  const version = db.prepare('PRAGMA user_version').get().user_version;
  if (version > MIGRATIONS.length) throw new Error(`Database schema ${version} is newer than this Lil Moon understands.`);
  for (let i = version; i < MIGRATIONS.length; i++) {
    db.exec('BEGIN');
    try {
      db.exec(MIGRATIONS[i]);
      db.exec(`PRAGMA user_version = ${i + 1}`);
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  }
}

// Inserts the single settings row only if none exists. legacy = Phase 2 preferences, imported once if valid.
function seedSettings(db, legacy) {
  let seconds = DEFAULT_DAILY_LIMIT_SECONDS;
  let theme = 'sunny';
  const m = legacy?.defaultDailyLimitMin;
  if (Number.isInteger(m) && m * 60 >= 300 && m * 60 <= 86400) seconds = m * 60;
  if (THEMES.includes(legacy?.theme)) theme = legacy.theme;
  const t = nowIso();
  db.prepare('INSERT OR IGNORE INTO user_settings (id, daily_limit_seconds, theme, created_at, updated_at) VALUES (1, ?, ?, ?, ?)').run(seconds, theme, t, t);
}

function openDatabase(file, { legacyPreferences } = {}) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  try {
    db.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;');
    if (file !== ':memory:') db.exec('PRAGMA journal_mode = WAL;');
    migrate(db);
    seedSettings(db, legacyPreferences);
    return db;
  } catch (err) {
    try { db.close(); } catch { /* already unusable */ }
    throw err;
  }
}

// All SQL lives here and is parameterized; no caller-supplied text is ever concatenated into a statement.
function createRepository(db) {
  const session = (r) => ({ id: r.id, category: r.category, itemName: r.item_name, startedAt: r.started_at, endedAt: r.ended_at, durationSeconds: r.duration_seconds, sessionDate: r.session_date });
  const settings = () => {
    const r = db.prepare('SELECT daily_limit_seconds, theme, idle_threshold_seconds, created_at, updated_at FROM user_settings WHERE id = 1').get();
    return { dailyLimitSeconds: r.daily_limit_seconds, theme: r.theme, idleThresholdSeconds: r.idle_threshold_seconds, createdAt: r.created_at, updatedAt: r.updated_at };
  };
  return {
    schemaVersion: () => db.prepare('PRAGMA user_version').get().user_version,
    getSettings: settings,
    updateSettings(patch) {
      const cur = settings();
      db.prepare('UPDATE user_settings SET daily_limit_seconds = ?, theme = ?, idle_threshold_seconds = ?, updated_at = ? WHERE id = 1')
        .run(patch.dailyLimitSeconds ?? cur.dailyLimitSeconds, patch.theme ?? cur.theme, patch.idleThresholdSeconds ?? cur.idleThresholdSeconds, nowIso());
      return settings();
    },
    listApplications: () => db.prepare('SELECT id, app_name, executable_name, is_enabled FROM applications ORDER BY app_name COLLATE NOCASE, id').all()
      .map((r) => ({ id: r.id, appName: r.app_name, executableName: r.executable_name, isEnabled: r.is_enabled === 1 })),
    listWebsites: () => db.prepare('SELECT id, domain, display_name, is_enabled FROM websites ORDER BY display_name COLLATE NOCASE, id').all()
      .map((r) => ({ id: r.id, domain: r.domain, displayName: r.display_name, isEnabled: r.is_enabled === 1 })),
    usageToday(category) {
      const date = localDate(new Date());
      const rows = db.prepare(
        `SELECT category, item_name, SUM(duration_seconds) AS total, COUNT(*) AS n FROM usage_sessions
         WHERE session_date = ? AND (? IS NULL OR category = ?)
         GROUP BY category, item_name ORDER BY total DESC, item_name COLLATE NOCASE`
      ).all(date, category ?? null, category ?? null);
      const totals = { application: 0, website: 0 };
      const items = rows.map((r) => { totals[r.category] += r.total; return { category: r.category, itemName: r.item_name, totalSeconds: r.total, sessionCount: r.n }; });
      return { date, dailyLimitSeconds: settings().dailyLimitSeconds, totals, items };
    },
    usageHistory({ from, to, category, limit, offset }) {
      const where = ['1 = 1'];
      const args = [];
      if (from) { where.push('session_date >= ?'); args.push(from); }
      if (to) { where.push('session_date <= ?'); args.push(to); }
      if (category) { where.push('category = ?'); args.push(category); }
      const clause = where.join(' AND '); // fixed fragments only; values are bound
      const total = db.prepare(`SELECT COUNT(*) AS n FROM usage_sessions WHERE ${clause}`).get(...args).n;
      const records = db.prepare(`SELECT * FROM usage_sessions WHERE ${clause} ORDER BY started_at DESC, id DESC LIMIT ? OFFSET ?`).all(...args, limit, offset).map(session);
      return { records, total, limit, offset };
    },
    insertSession(s) {
      const sessionDate = localDate(new Date(s.startedAt));
      const info = db.prepare('INSERT INTO usage_sessions (category, item_name, started_at, ended_at, duration_seconds, session_date) VALUES (?, ?, ?, ?, ?, ?)')
        .run(s.category, s.itemName, s.startedAt, s.endedAt, s.durationSeconds, sessionDate);
      return session(db.prepare('SELECT * FROM usage_sessions WHERE id = ?').get(Number(info.lastInsertRowid)));
    },
    deleteSession: (id) => db.prepare('DELETE FROM usage_sessions WHERE id = ?').run(id).changes > 0,

    // ---- Phase 5: website tracking ----
    // Pairing secret for the browser extension. Separate from the dashboard's per-launch token and valid only on /ext routes.
    getExtensionToken() {
      let t = db.prepare('SELECT extension_token FROM user_settings WHERE id = 1').get().extension_token;
      if (!t) { t = crypto.randomBytes(24).toString('hex'); db.prepare('UPDATE user_settings SET extension_token = ? WHERE id = 1').run(t); }
      return t;
    },
    rotateExtensionToken() {
      const t = crypto.randomBytes(24).toString('hex');
      db.prepare('UPDATE user_settings SET extension_token = ? WHERE id = 1').run(t);
      return t;
    },
    addWebsite({ domain, displayName }) {
      const info = db.prepare('INSERT INTO websites (domain, display_name, is_enabled) VALUES (?, ?, 1)').run(domain, displayName);
      return this.listWebsites().find((w) => w.id === Number(info.lastInsertRowid));
    },
    updateWebsite(id, patch) {
      const cur = db.prepare('SELECT display_name, is_enabled FROM websites WHERE id = ?').get(id);
      if (!cur) return null;
      db.prepare('UPDATE websites SET display_name = ?, is_enabled = ? WHERE id = ?')
        .run(patch.displayName ?? cur.display_name, patch.isEnabled === undefined ? cur.is_enabled : (patch.isEnabled ? 1 : 0), id);
      return this.listWebsites().find((w) => w.id === id);
    },
    deleteWebsite: (id) => db.prepare('DELETE FROM websites WHERE id = ?').run(id).changes > 0, // history is kept
    listAliases: () => db.prepare('SELECT alias, canonical FROM domain_aliases ORDER BY alias').all().map((r) => ({ alias: r.alias.toLowerCase(), canonical: r.canonical.toLowerCase() })),
    setAlias: (alias, canonical) => { db.prepare('INSERT INTO domain_aliases (alias, canonical) VALUES (?, ?) ON CONFLICT(alias) DO UPDATE SET canonical = excluded.canonical').run(alias, canonical); },
    deleteAlias: (alias) => db.prepare('DELETE FROM domain_aliases WHERE alias = ?').run(alias).changes > 0,

    // Latest end of any stored website run; the tracker never starts a new run before this (no overlaps, no double counting).
    lastWebsiteEndMs() {
      const r = db.prepare("SELECT MAX(ended_at) AS e FROM usage_sessions WHERE category = 'website'").get();
      return r.e ? new Date(r.e).getTime() : 0;
    },
    // One row per uninterrupted run. It is created once, then extended by checkpoints, so a crash loses at most one checkpoint.
    insertWebsiteRun(run) {
      const info = db.prepare("INSERT INTO usage_sessions (category, item_name, started_at, ended_at, duration_seconds, session_date) VALUES ('website', ?, ?, ?, ?, ?)")
        .run(run.domain, run.startedAt, run.endedAt, run.durationSeconds, run.sessionDate);
      return Number(info.lastInsertRowid);
    },
    updateWebsiteRun: (id, endedAt, durationSeconds) =>
      db.prepare("UPDATE usage_sessions SET ended_at = ?, duration_seconds = ? WHERE id = ? AND category = 'website' AND ? >= started_at").run(endedAt, durationSeconds, id, endedAt).changes > 0,
    deleteWebsiteRun: (id) => db.prepare("DELETE FROM usage_sessions WHERE id = ? AND category = 'website'").run(id).changes > 0,
    deleteWebsiteHistory: () => db.prepare("DELETE FROM usage_sessions WHERE category = 'website'").run().changes,
    websiteUsageForDate(date) {
      return db.prepare("SELECT item_name, SUM(duration_seconds) AS total, COUNT(*) AS n FROM usage_sessions WHERE category = 'website' AND session_date = ? GROUP BY item_name")
        .all(date).map((r) => ({ domain: r.item_name, totalSeconds: r.total, sessionCount: r.n }));
    },
  };
}

module.exports = { openDatabase, createRepository, localDate, DEFAULT_DAILY_LIMIT_SECONDS, DEFAULT_IDLE_THRESHOLD_SECONDS: 60, THEMES, MIGRATION_COUNT: MIGRATIONS.length };
