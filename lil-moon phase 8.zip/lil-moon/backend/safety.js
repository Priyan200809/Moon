// Secret and sensitivity detection shared by the file indexer (redaction) and the memory system (refusal).
const luhn = (digits) => {
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = Number(digits[i]);
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n; alt = !alt;
  }
  return sum % 10 === 0;
};

const SECRET_PATTERNS = [
  /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?(?:-----END [A-Z ]*PRIVATE KEY-----|$)/g,
  /\bsk-[A-Za-z0-9_-]{16,}/g,
  /\bAKIA[0-9A-Z]{16}\b/g,
  /\bgh[pousr]_[A-Za-z0-9]{30,}/g,
  /\bxox[baprs]-[A-Za-z0-9-]{10,}/g,
  /\bAIza[0-9A-Za-z_-]{30,}/g,
  /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}/g,
  /\bBearer\s+[A-Za-z0-9._~+/-]{20,}=*/g,
  /\b(?:password|passwd|pwd|passcode|secret|token|api[_-]?key|access[_-]?token|auth[_-]?token|client[_-]?secret)\b["']?\s*[:=]\s*["']?[^\s"',;]{4,}/gi,
];
const CARD = /\b(?:\d[ -]?){13,19}\b/g;

function redactSecrets(text) {
  let out = text;
  for (const re of SECRET_PATTERNS) out = out.replace(re, '[REDACTED]');
  return out.replace(CARD, (m) => (luhn(m.replace(/\D/g, '')) ? '[REDACTED]' : m));
}
const containsSecret = (text) => redactSecrets(text) !== text;

// Things a memory must never hold, even if the user types them: credentials and identifiers.
const NEVER_REMEMBER = /\b(?:my\s+)?(?:password|passwd|passcode|pin(?:\s+code)?|otp|cvv|cvc|card\s+number|credit\s+card|debit\s+card|ssn|social\s+security|aadhaar|passport\s+number|bank\s+account|account\s+number|private\s+key|seed\s+phrase|recovery\s+(?:code|phrase)|api\s*key|access\s*token|secret\s*key)\b/i;
// Sensitive personal topics: never proposed by the model; a person can still note them deliberately elsewhere.
const SENSITIVE_TOPIC = /\b(?:diagnos\w*|medical\s+condition|medication|therapy|depress\w*|anxiety\s+disorder|religio\w*|political\s+(?:party|view)\w*|sexual\s+orientation|immigration\s+status|criminal\s+record|salary|income)\b/i;

function memoryProblem(text, { fromModel = false } = {}) {
  if (containsSecret(text) || NEVER_REMEMBER.test(text)) return 'secret';
  if (fromModel && SENSITIVE_TOPIC.test(text)) return 'sensitive';
  return null;
}

module.exports = { redactSecrets, containsSecret, memoryProblem };
