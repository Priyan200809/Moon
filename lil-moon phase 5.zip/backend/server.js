// Local-only REST API. Runs inside Electron's main process (no second main process, no second server).
// Defences: 127.0.0.1 only, random port, Host allow-list (DNS rebinding), Origin allow-list, per-launch bearer token.
const express = require('express');
const crypto = require('crypto');
const v = require('./validators');
const Domain = require('../extension/lib/domain.js');
const { localDate } = require('./database');
const { HttpError } = v;

// Browser extensions (Chrome and Edge both use this scheme) may only reach the /ext routes, with their own pairing token.
const EXT_ORIGIN = /^chrome-extension:\/\/[a-p]{32}$/;
const EXT_PORTS = Array.from({ length: 10 }, (_, i) => 47615 + i); // the extension probes these; the dashboard learns the real port by IPC

const ok = (res, data, status = 200) => res.status(status).json({ ok: true, data });
const safeEqual = (a, b) => {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

function createApp({ repo, token, allowedHosts, allowedOrigins, tracker = null, hooks = {}, now = Date.now, getPort = () => 0 }) {
  const app = express();
  app.disable('x-powered-by');
  app.disable('etag');

  app.use((req, res, next) => {
    res.set({ 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', Vary: 'Origin' });
    if (!allowedHosts.has(req.headers.host)) return next(new HttpError(403, 'forbidden_host', 'Host not allowed.'));
    const isExt = req.path.startsWith('/ext/');
    const origin = req.headers.origin;
    if (origin !== undefined) {
      if (!(isExt ? EXT_ORIGIN.test(origin) : allowedOrigins.has(origin))) return next(new HttpError(403, 'forbidden_origin', 'Origin not allowed.'));
      res.set({
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Headers': 'Authorization, Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE',
        'Access-Control-Max-Age': '600',
      });
    }
    if (req.method === 'OPTIONS') return res.status(204).end();
    // Two separate secrets: the dashboard's per-launch token opens /api, the pairing token opens /ext. Neither works on the other's routes.
    const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    if (!m || !safeEqual(m[1], isExt ? repo.getExtensionToken() : token)) return next(new HttpError(401, 'unauthorized', 'Missing or invalid token.'));
    if ((req.method === 'POST' || req.method === 'PUT') && !req.is('application/json')) {
      return next(new HttpError(415, 'unsupported_media_type', 'Send Content-Type: application/json.'));
    }
    next();
  });
  app.use(express.json({ limit: '16kb', strict: true }));

  // Everything the Website Usage page shows, computed from real rows only (plus live tracker state).
  function overview() {
    tracker?.reconcile();
    const date = localDate(new Date(now()));
    const settings = repo.getSettings();
    const usage = new Map(repo.websiteUsageForDate(date).map((u) => [u.domain, u]));
    const sites = repo.listWebsites().map((w) => {
      const u = usage.get(w.domain); usage.delete(w.domain);
      return { id: w.id, domain: w.domain, displayName: w.displayName, isEnabled: w.isEnabled, isTracked: true, todaySeconds: u?.totalSeconds ?? 0, sessionCount: u?.sessionCount ?? 0 };
    });
    for (const u of usage.values()) { // removed from the list but has history today
      sites.push({ id: null, domain: u.domain, displayName: u.domain, isEnabled: false, isTracked: false, todaySeconds: u.totalSeconds, sessionCount: u.sessionCount });
    }
    sites.sort((a, b) => b.todaySeconds - a.todaySeconds || a.displayName.localeCompare(b.displayName));
    const status = tracker ? tracker.status() : { connected: false, paused: false, currentDomain: null, countingDomain: null, presence: 'active', lastSyncAt: null, browser: null };
    for (const s of sites) s.isCounting = status.countingDomain === s.domain;
    const totalSeconds = sites.reduce((n, s) => n + s.todaySeconds, 0);
    const top = sites[0] && sites[0].todaySeconds > 0 ? sites[0] : null;
    return {
      date, dailyLimitSeconds: settings.dailyLimitSeconds, idleThresholdSeconds: settings.idleThresholdSeconds, totalSeconds,
      mostUsed: top && { domain: top.domain, displayName: top.displayName, todaySeconds: top.todaySeconds },
      tracking: status, sites,
    };
  }

  const r = express.Router();
  r.get('/health', (req, res) => ok(res, { status: 'ok', schemaVersion: repo.schemaVersion(), time: new Date().toISOString() }));
  r.get('/settings', (req, res) => ok(res, repo.getSettings()));
  r.put('/settings', (req, res) => ok(res, repo.updateSettings(v.settingsPatch(req.body))));
  r.get('/applications', (req, res) => ok(res, repo.listApplications()));
  r.get('/websites', (req, res) => ok(res, repo.listWebsites()));
  // Specific website routes first, then the :id ones.
  r.get('/websites/overview', (req, res) => ok(res, overview()));
  r.delete('/websites/history', (req, res) => {
    tracker?.reconcile();
    tracker?.shutdown(); // store and close whatever is open, then forget the stored history
    ok(res, { deleted: repo.deleteWebsiteHistory() });
  });
  r.get('/websites/aliases', (req, res) => ok(res, repo.listAliases()));
  r.post('/websites/aliases', (req, res) => { const a = v.aliasBody(req.body); repo.setAlias(a.alias, a.canonical); ok(res, a, 201); });
  r.delete('/websites/aliases/:alias', (req, res) => {
    if (!repo.deleteAlias(v.aliasParam(req.params.alias))) throw new HttpError(404, 'not_found', 'No such alias.');
    ok(res, { deleted: true });
  });
  r.get('/websites/extension', (req, res) => ok(res, { pairingCode: repo.getExtensionToken(), port: getPort(), probedPorts: EXT_PORTS }));
  r.post('/websites/extension/rotate', (req, res) => ok(res, { pairingCode: repo.rotateExtensionToken(), port: getPort(), probedPorts: EXT_PORTS }));
  r.post('/websites', (req, res) => {
    const b = v.websiteBody(req.body);
    if (repo.listWebsites().some((w) => w.domain === b.domain)) throw new HttpError(409, 'conflict', 'That website is already on the list.');
    ok(res, repo.addWebsite(b), 201);
  });
  r.put('/websites/:id', (req, res) => {
    const w = repo.updateWebsite(v.recordId(req.params.id), v.websitePatch(req.body));
    if (!w) throw new HttpError(404, 'not_found', 'No such website.');
    ok(res, w);
  });
  r.delete('/websites/:id', (req, res) => {
    const id = v.recordId(req.params.id);
    if (!repo.deleteWebsite(id)) throw new HttpError(404, 'not_found', 'No such website.');
    ok(res, { id });
  });
  r.get('/usage/today', (req, res) => ok(res, repo.usageToday(v.category(req.query.category))));
  r.get('/usage/history', (req, res) => ok(res, repo.usageHistory(v.historyQuery(req.query))));
  r.post('/usage/sessions', (req, res) => ok(res, repo.insertSession(v.sessionBody(req.body)), 201));
  r.delete('/usage/sessions/:id', (req, res) => {
    const id = v.recordId(req.params.id);
    if (!repo.deleteSession(id)) throw new HttpError(404, 'not_found', 'No such session.');
    ok(res, { id });
  });
  app.use('/api', r);

  // ---- Browser extension surface: a handful of fixed operations, nothing else ----
  const e = express.Router();
  e.get('/ping', (req, res) => ok(res, { app: 'lil-moon', phase: 5 }));
  e.get('/config', (req, res) => ok(res, {
    domains: repo.listWebsites().filter((w) => w.isEnabled).map((w) => w.domain),
    aliases: Object.fromEntries(repo.listAliases().map((a) => [a.alias, a.canonical])),
    stripPrefixes: Domain.DEFAULT_STRIP_PREFIXES,
    idleThresholdSeconds: repo.getSettings().idleThresholdSeconds,
    heartbeatSeconds: 30,
  }));
  e.post('/activity', (req, res) => {
    const m = v.extActivity(req.body);
    // The extension is never trusted to decide what is tracked: re-check the domain against the enabled list here.
    if (m.domain !== null) {
      const enabled = repo.listWebsites().filter((w) => w.isEnabled).map((w) => w.domain);
      const aliases = Object.fromEntries(repo.listAliases().map((a) => [a.alias, a.canonical]));
      m.domain = Domain.matchTracked(Domain.normalizeHost(m.domain, { aliases }), enabled) ?? Domain.matchTracked(m.domain, enabled);
    }
    const { accepted } = tracker ? tracker.onBrowser(m) : { accepted: false };
    ok(res, { accepted, serverTime: new Date(now()).toISOString(), tracking: tracker?.status() ?? null });
  });
  e.get('/summary', (req, res) => {
    const o = overview();
    const cur = o.sites.find((s) => s.domain === o.tracking.currentDomain);
    ok(res, { date: o.date, totalSeconds: o.totalSeconds, dailyLimitSeconds: o.dailyLimitSeconds, currentDomain: o.tracking.currentDomain, currentDomainSeconds: cur?.todaySeconds ?? 0, tracking: o.tracking });
  });
  e.post('/open-dashboard', (req, res) => { hooks.openDashboard?.(); ok(res, { opened: !!hooks.openDashboard }); });
  app.use('/ext', e);

  app.use((req, res, next) => next(new HttpError(404, 'not_found', 'No such endpoint.')));
  app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    if (err instanceof HttpError) return res.status(err.status).json({ ok: false, error: { code: err.code, message: err.message } });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ ok: false, error: { code: 'invalid_json', message: 'Body is not valid JSON.' } });
    if (err.type === 'entity.too.large') return res.status(413).json({ ok: false, error: { code: 'too_large', message: 'Body is too large.' } });
    console.error('[lil-moon api]', err);
    res.status(500).json({ ok: false, error: { code: 'internal_error', message: 'Something went wrong in the local service.' } });
  });
  return app;
}

function startServer({ repo, allowedOrigins, token = crypto.randomBytes(32).toString('hex'), tracker = null, hooks = {}, now = Date.now, ports = [0] }) {
  const allowedHosts = new Set();
  let boundPort = 0;
  const app = createApp({ repo, token, allowedHosts, allowedOrigins: new Set(allowedOrigins), tracker, hooks, now, getPort: () => boundPort });
  // Try the preferred ports in order (so the extension can find us), then fall back to a random free one.
  const listen = (port) => new Promise((resolve, reject) => {
    // Express 5 passes a listen failure (e.g. EADDRINUSE) to this callback instead of throwing.
    const server = app.listen(port, '127.0.0.1', (err) => (err ? reject(err) : resolve(server)));
  });
  return (async () => {
    let server, lastErr;
    for (const p of ports) {
      try { server = await listen(p); break; } catch (err) { lastErr = err; if (err.code !== 'EADDRINUSE') throw err; }
    }
    if (!server) { try { server = await listen(0); } catch { throw lastErr; } }
    boundPort = server.address().port;
    allowedHosts.add(`127.0.0.1:${boundPort}`).add(`localhost:${boundPort}`);
    return {
      port: boundPort, token, baseUrl: `http://127.0.0.1:${boundPort}`,
      close: () => new Promise((done) => { server.close(() => done()); server.closeAllConnections(); }),
    };
  })();
}

module.exports = { createApp, startServer, EXT_PORTS };
