# Lil Moon backend (Phase 3)

## Architecture
```
React dashboard --fetch + Bearer token--> Express (127.0.0.1:random port) --> repository --> SQLite file
        ^                                  runs inside Electron's existing main process
        +-- address + token come from preload getApiConfig() (dashboard window only)
```
- No second Electron process and no second server. The moon window never receives the token.
- The renderer cannot run SQL; it can only call the endpoints below. All SQL is in `backend/database.js` and parameterized.
- Database: Node's built-in `node:sqlite` (Electron 45 bundles Node 24). **No native module, no rebuild step.** It is marked experimental by Node, so a warning is printed in the console. Plain-Node tests need Node 22.13+.
- File: `<userData>/lil-moon.db` (Windows: `%APPDATA%\lil-moon\lil-moon.db`), WAL mode (`-wal` and `-shm` side files are normal).
- If the database cannot be opened (for example it is corrupt), the moon still starts, the dashboard shows an error with "Try again", and the file is never deleted or overwritten.
- First launch after upgrading from Phase 2: the saved daily limit and theme are imported once into SQLite; later launches never touch them.

## Time strategy
All timestamps (`created_at`, `updated_at`, `started_at`, `ended_at`) are **UTC ISO-8601 with milliseconds**, e.g. `2026-10-25T14:03:09.120Z`. `session_date` is the **local calendar day (YYYY-MM-DD) of `started_at` on this computer**, computed by the server. "Today" means the local day. A session that crosses midnight counts entirely toward the day it started. Changing the computer's time zone does not rewrite old `session_date` values.

## Schema (version 1, tracked with `PRAGMA user_version`; new versions append to the migration list)
| Table | Columns and constraints |
|---|---|
| user_settings | id PK (always 1), daily_limit_seconds INT 300..86400 default 10800, theme in (sunny, cream, lilac), created_at, updated_at |
| applications | id PK, app_name, executable_name UNIQUE (case-insensitive), is_enabled 0/1 |
| websites | id PK, domain UNIQUE (case-insensitive), display_name, is_enabled 0/1 |
| usage_sessions | id PK, category in (application, website), item_name 1..200, started_at, ended_at (>= started_at), duration_seconds 0..86400, session_date |
| restriction_events | id PK, category, item_name, event_type in (limit_warning, limit_reached, blocked), created_at |

Indexes: `idx_usage_date_item (session_date, category, item_name)`, `idx_usage_item_start (category, item_name, started_at)`, `idx_usage_started (started_at)`, `idx_restriction_created (created_at)`, `idx_restriction_item (category, item_name, created_at)`.
`applications`, `websites` and `restriction_events` exist but nothing writes to them yet (later phases).

## API
Every request needs `Authorization: Bearer <token>` (random per launch), a `Host` of `127.0.0.1:<port>` or `localhost:<port>`, and, if an `Origin` header is sent, an allowed one. POST/PUT need `Content-Type: application/json` (max 16 KB).
Success: `{"ok":true,"data":...}`. Error: `{"ok":false,"error":{"code","message"}}`.

| Method and path | Purpose | Notes |
|---|---|---|
| GET /api/health | status, schemaVersion, time | |
| GET /api/settings | `{dailyLimitSeconds, theme, createdAt, updatedAt}` | |
| PUT /api/settings | update either or both fields | dailyLimitSeconds integer 300..86400; theme sunny/cream/lilac; unknown fields rejected |
| GET /api/applications | list | |
| GET /api/websites | list | |
| GET /api/usage/today?category= | `{date, dailyLimitSeconds, totals:{application,website}, items:[{category,itemName,totalSeconds,sessionCount}]}` | category optional |
| GET /api/usage/history?from=&to=&category=&limit=&offset= | `{records,total,limit,offset}` newest first | dates YYYY-MM-DD (local day); limit 1..200 default 50 |
| POST /api/usage/sessions | body `{category,itemName,startedAt,endedAt}` (UTC ISO) -> 201 with the record | duration and session_date are computed by the server; max 24 h; not in the future |
| DELETE /api/usage/sessions/:id | remove one session | 404 if missing |

Status codes: 200, 201, 400 (validation / bad JSON), 401 (token), 403 (host or origin), 404, 413, 415, 500 (generic message; details only in the console).

## Security notes
- Listens on 127.0.0.1 only (not reachable from other machines). The random port and token change every launch.
- Origin allow-list: `null` (the file:// page) in production, the Vite origin in development. A website open in your browser cannot call the API: wrong Origin, and it has no token.
- Host allow-list defends against DNS rebinding. Token comparison is constant-time.
- Known limit: another program running as you could read the token from the dashboard's memory. That is outside what a local app can prevent.
