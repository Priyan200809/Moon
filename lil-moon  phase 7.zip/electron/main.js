const { app, ipcMain, powerMonitor, Notification, dialog, shell, systemPreferences } = require('electron');
const wm = require('./windowManager');
const path = require('path');
const store = require('./settingsStore');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer, EXT_PORTS } = require('../backend/server');
const { createTracker } = require('../backend/websiteTracker');
const { createIdleMonitor } = require('../backend/idleMonitor');
const { createLimitEngine } = require('../backend/limits');
const { createNotifier } = require('./notifier');
const { createSpeechRecognitionService } = require('./voice/speechRecognitionService');
const { createAppLauncher } = require('../backend/voice/appLauncher');
const { createCommandExecutor } = require('../backend/voice/commandExecutor');
const { createVoiceService } = require('../backend/voice/voiceService');
const Apps = require('../backend/voice/applicationRegistry');
const Sites = require('../backend/voice/websiteRegistry');

// The API accepts requests only from our own pages: file:// (Origin "null") in production, the Vite origin in dev.
const allowedOrigins = process.env.LILMOON_DEV_URL ? [new URL(process.env.LILMOON_DEV_URL).origin] : ['null'];
let backend = null;
let backendError = '';

// Phase 5: website tracking. One presence detector (idleMonitor) feeds one tracker; the extension only says which site is in front.
function startTracking(repo) {
  const tracker = createTracker({ repo });
  let threshold = { at: 0, seconds: 60 };
  const idle = createIdleMonitor({
    getIdleSeconds: () => powerMonitor.getSystemIdleTime(),
    getThresholdSeconds: () => { // re-read the saved threshold at most every 5 s
      if (Date.now() - threshold.at > 5000) threshold = { at: Date.now(), seconds: repo.getSettings().idleThresholdSeconds };
      return threshold.seconds;
    },
    onChange: (state, atMs) => tracker.onPresence(state, atMs),
  });
  const detach = idle.attach(powerMonitor); // lock-screen, unlock-screen, suspend, resume
  idle.start();
  // Phase 6: limits are evaluated from stored usage after every tracking update and on this slow interval (never trusting a timer for time itself).
  let notifier = null;
  const limits = createLimitEngine({ repo, tracker, notify: (a) => notifier && notifier.handle(a) });
  notifier = createNotifier({ Notification, dialog, engine: limits, tracker, openDashboard: () => wm.openDashboard() });
  const reconcile = setInterval(() => { tracker.reconcile(); limits.tick(); }, 15000);
  setTimeout(() => limits.tick(), 3000);
  wm.setMenuExtras(() => [
    { label: 'Talk to Lil Moon', click: () => activateVoice() },
    {
      label: 'Warnings and restrictions on', type: 'checkbox', checked: repo.restrictionsEnabled(), // a reliable "disable all" that does not need the dashboard
      click: (item) => { limits.setMaster(item.checked); limits.tick(); },
    },
  ]);
  return { tracker, idle, limits, notifier, stop: () => { clearInterval(reconcile); idle.stop(); detach(); tracker.shutdown(); } };
}

// Phase 7: voice. Speech-to-text runs locally (Windows offline recogniser); commands run through the allowlisted pipeline in this process.
let speech = null;
let activationPending = false;
function startVoice(repo, tracking) {
  const launcher = createAppLauncher();
  // The one place that hands a URL to the system browser. The executor has already validated it; this checks again.
  const opener = { open: async (url) => { if (!Sites.validateUrl(url)) throw new Error('blocked url'); await shell.openExternal(url, { activate: true }); } };
  const executor = createCommandExecutor({ repo, tracker: tracking.tracker, limits: tracking.limits, launcher, opener });
  const service = createVoiceService({ repo, executor });
  const sendToDashboard = (event) => { const w = wm.getDashboard(); if (w && !w.isDestroyed()) w.webContents.send('voice:event', event); };
  speech = createSpeechRecognitionService({ send: sendToDashboard, getMicStatus: () => { try { return systemPreferences.getMediaAccessStatus('microphone'); } catch { return 'unknown'; } } });
  const capabilities = () => ({
    speech: { engine: 'windows-sapi', label: 'Windows offline speech recognition', local: true, sendsAudioToCloud: false, available: process.platform === 'win32', languages: ['en-US', 'ta-IN'], note: 'Audio is handled by Windows on this computer. Lil Moon receives only the recognised text.' },
    speechOutput: { engine: 'system-voices', label: 'Windows voices through Chromium speechSynthesis', local: true },
    applications: Apps.APPS.map((a) => ({ id: a.id, name: a.name, installed: launcher.isInstalled(a.id) })),
    websites: Sites.candidates(repo.listWebsites()).map((s) => ({ name: s.name, domain: s.domain })),
    commands: [
      { group: 'Open apps', examples: ['Open Chrome', 'Open VS Code', 'Open Notepad', 'Open Calculator', 'Open File Explorer'] },
      { group: 'Open websites', examples: ['Open YouTube', 'Open Instagram', 'Open Google', 'Open GitHub'] },
      { group: 'Information', examples: ['What time is it', "What's today's date", 'How much time did I spend on Chrome', 'How much time is left on YouTube', 'Show my daily limits', 'Show my website usage'] },
      { group: 'Dashboard', examples: ['Open home', 'Show app usage', 'Show website usage', 'Open usage limits', 'Open settings', 'Open voice assistant'] },
      { group: 'Assistant', examples: ['Stop listening', 'Start listening', 'Repeat that', 'Clear conversation', 'Stop talking'] },
    ],
  });
  return { service, capabilities, speech };
}
// "Talk to Lil Moon" in the moon's menu: open the dashboard on the Voice page; the page starts ONE listening session (visible indicator).
function activateVoice() {
  activationPending = true;
  const existing = wm.getDashboard();
  const win = wm.openDashboard();
  if (existing && win && !win.webContents.isLoading()) win.webContents.send('voice:activate');
}

async function startBackend() {
  try {
    const db = openDatabase(path.join(app.getPath('userData'), 'lil-moon.db'), { legacyPreferences: store.getLegacyPreferences() });
    try {
      const repo = createRepository(db);
      const tracking = startTracking(repo);
      try {
        const api = await startServer({
          repo, allowedOrigins, tracker: tracking.tracker, limits: tracking.limits, voice: startVoice(repo, tracking), ports: [...EXT_PORTS, 0],
          hooks: { openDashboard: () => wm.openDashboard() },
        });
        backend = { db, api, tracking };
      } catch (err) { tracking.stop(); throw err; }
    } catch (err) { db.close(); throw err; }
  } catch (err) {
    console.error('[lil-moon] backend failed to start:', err);
    backendError = 'Lil Moon could not open its local database. Your data was not changed.';
  }
}

// Accept a command only from the exact window (top frame) that is allowed to send it.
function windowFor(who, event) {
  const win = who === 'moon' ? wm.getMoon() : wm.getDashboard();
  const ok = win && !win.isDestroyed() && event.sender === win.webContents && event.senderFrame === event.sender.mainFrame;
  return ok ? win : null;
}
function on(channel, who, handler) {
  ipcMain.on(channel, (event) => { const win = windowFor(who, event); if (win) handler(win); });
}
function handle(channel, who, handler) {
  ipcMain.handle(channel, (event, payload) => {
    if (!windowFor(who, event)) throw new Error('Rejected');
    return handler(payload);
  });
}

function registerIpc() {
  on('moon:drag-start', 'moon', wm.dragStart);
  on('moon:drag-move', 'moon', wm.dragMove);
  on('moon:drag-end', 'moon', wm.dragEnd);
  on('moon:menu', 'moon', wm.showMoonMenu);
  on('dashboard:open', 'moon', wm.openDashboard);
  on('dashboard:minimize', 'dashboard', (w) => w.minimize());
  on('dashboard:close', 'dashboard', (w) => w.close());
  on('dashboard:toggle-maximize', 'dashboard', (w) => (w.isMaximized() ? w.unmaximize() : w.maximize()));
  on('app:exit', 'dashboard', wm.quit);
  // Only the dashboard window may learn the API address and its per-launch token.
  handle('api:config', 'dashboard', () => (backend ? { baseUrl: backend.api.baseUrl, token: backend.api.token } : { error: backendError }));
  // Voice (dashboard only). Starting the microphone is always a deliberate user action.
  handle('voice:start', 'dashboard', (p) => {
    if (!speech) return { ok: false, error: { code: 'failed', message: 'Voice is not available right now.' } };
    return speech.start({ language: p && typeof p.language === 'string' ? p.language : '' });
  });
  on('voice:stop', 'dashboard', () => speech && speech.stop());
  handle('voice:permission', 'dashboard', () => { try { return process.platform === 'win32' || process.platform === 'darwin' ? systemPreferences.getMediaAccessStatus('microphone') : 'unknown'; } catch { return 'unknown'; } });
  on('voice:open-mic-settings', 'dashboard', () => { if (process.platform === 'win32') shell.openExternal('ms-settings:privacy-microphone'); }); // a fixed constant, never built from input
  handle('voice:take-activation', 'dashboard', () => { const was = activationPending; activationPending = false; return was; });
  ipcMain.handle('app:version', () => app.getVersion());
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => wm.openDashboard());
  app.whenReady().then(async () => {
    registerIpc();
    await startBackend(); // the moon still appears if the database fails
    wm.createMoon();
  });
  app.on('will-quit', () => {
    if (!backend) return;
    const { api, db, tracking } = backend;
    backend = null;
    try { if (speech) speech.stop(); } catch { /* ignore */ }
    try { tracking.stop(); } catch (err) { console.error('[lil-moon] could not store the open website run:', err); } // before the database closes
    api.close(); // stops listening and drops connections synchronously
    try { db.close(); } catch { /* ignore */ }
  });
  // The moon keeps the app alive; closing the dashboard never quits.
  app.on('window-all-closed', () => {});
  app.on('before-quit', wm.prepareQuit);
}

// Exposed for the automated smoke test only (it is not reachable from any renderer).
module.exports = { __services: () => backend, __activateVoice: () => activateVoice() };
