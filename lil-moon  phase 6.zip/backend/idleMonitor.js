// The single idle/presence detector for Lil Moon. Pure logic with injected inputs, so it is fully testable without Electron.
// Inputs: seconds since last keyboard/mouse input (the OS reports only a number; nothing is logged) + lock/suspend events.
// States, strongest first: suspended > locked > idle > active.
function createIdleMonitor({ getIdleSeconds, getThresholdSeconds, onChange, now = Date.now, pollMs = 1000, timers = { setInterval, clearInterval } }) {
  let locked = false, suspended = false, idle = false, current = 'active', handle = null;

  const compute = () => (suspended ? 'suspended' : locked ? 'locked' : idle ? 'idle' : 'active');
  const update = (atMs) => {
    const next = compute();
    if (next === current) return;
    current = next;
    onChange(next, atMs);
  };

  function poll() {
    const secs = getIdleSeconds();
    const was = idle;
    idle = secs >= getThresholdSeconds();
    // When idleness is first noticed, the person actually stopped `secs` ago: report that moment, not the detection moment.
    update(idle && !was ? now() - secs * 1000 : now());
  }

  return {
    start() { if (!handle) { poll(); handle = timers.setInterval(poll, pollMs); } },
    stop() { if (handle) { timers.clearInterval(handle); handle = null; } },
    poll,
    lock() { locked = true; update(now()); },
    unlock() { locked = false; poll(); update(now()); },
    suspend() { suspended = true; update(now()); },
    resume() { suspended = false; poll(); update(now()); },
    state: () => current,
    // Wire Electron's powerMonitor (lock-screen / unlock-screen / suspend / resume). Returns a detach function.
    attach(pm) {
      const map = { 'lock-screen': this.lock, 'unlock-screen': this.unlock, suspend: this.suspend, resume: this.resume };
      const bound = Object.entries(map).map(([ev, fn]) => [ev, fn.bind(this)]);
      bound.forEach(([ev, fn]) => pm.on(ev, fn));
      return () => bound.forEach(([ev, fn]) => pm.removeListener(ev, fn));
    },
  };
}

module.exports = { createIdleMonitor };
