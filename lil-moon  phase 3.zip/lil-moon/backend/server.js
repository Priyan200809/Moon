// Local-only REST API. Runs inside Electron's main process (no second main process, no second server).
// Defences: 127.0.0.1 only, random port, Host allow-list (DNS rebinding), Origin allow-list, per-launch bearer token.
const express = require('express');
const crypto = require('crypto');
const v = require('./validators');
const { HttpError } = v;

const ok = (res, data, status = 200) => res.status(status).json({ ok: true, data });
const safeEqual = (a, b) => {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

function createApp({ repo, token, allowedHosts, allowedOrigins }) {
  const app = express();
  app.disable('x-powered-by');
  app.disable('etag');

  app.use((req, res, next) => {
    res.set({ 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', Vary: 'Origin' });
    if (!allowedHosts.has(req.headers.host)) return next(new HttpError(403, 'forbidden_host', 'Host not allowed.'));
    const origin = req.headers.origin;
    if (origin !== undefined) {
      if (!allowedOrigins.has(origin)) return next(new HttpError(403, 'forbidden_origin', 'Origin not allowed.'));
      res.set({
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Headers': 'Authorization, Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE',
        'Access-Control-Max-Age': '600',
      });
    }
    if (req.method === 'OPTIONS') return res.status(204).end();
    const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
    if (!m || !safeEqual(m[1], token)) return next(new HttpError(401, 'unauthorized', 'Missing or invalid token.'));
    if ((req.method === 'POST' || req.method === 'PUT') && !req.is('application/json')) {
      return next(new HttpError(415, 'unsupported_media_type', 'Send Content-Type: application/json.'));
    }
    next();
  });
  app.use(express.json({ limit: '16kb', strict: true }));

  const r = express.Router();
  r.get('/health', (req, res) => ok(res, { status: 'ok', schemaVersion: repo.schemaVersion(), time: new Date().toISOString() }));
  r.get('/settings', (req, res) => ok(res, repo.getSettings()));
  r.put('/settings', (req, res) => ok(res, repo.updateSettings(v.settingsPatch(req.body))));
  r.get('/applications', (req, res) => ok(res, repo.listApplications()));
  r.get('/websites', (req, res) => ok(res, repo.listWebsites()));
  r.get('/usage/today', (req, res) => ok(res, repo.usageToday(v.category(req.query.category))));
  r.get('/usage/history', (req, res) => ok(res, repo.usageHistory(v.historyQuery(req.query))));
  r.post('/usage/sessions', (req, res) => ok(res, repo.insertSession(v.sessionBody(req.body)), 201));
  r.delete('/usage/sessions/:id', (req, res) => {
    const id = v.recordId(req.params.id);
    if (!repo.deleteSession(id)) throw new HttpError(404, 'not_found', 'No such session.');
    ok(res, { id });
  });
  app.use('/api', r);

  app.use((req, res, next) => next(new HttpError(404, 'not_found', 'No such endpoint.')));
  app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    if (err instanceof HttpError) return res.status(err.status).json({ ok: false, error: { code: err.code, message: err.message } });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ ok: false, error: { code: 'invalid_json', message: 'Body is not valid JSON.' } });
    if (err.type === 'entity.too.large') return res.status(413).json({ ok: false, error: { code: 'too_large', message: 'Body is too large.' } });
    console.error('[lil-moon api]', err);
    res.status(500).json({ ok: false, error: { code: 'internal_error', message: 'Something went wrong in the local service.' } });
  });
  return app;
}

function startServer({ repo, allowedOrigins, token = crypto.randomBytes(32).toString('hex') }) {
  const allowedHosts = new Set();
  const app = createApp({ repo, token, allowedHosts, allowedOrigins: new Set(allowedOrigins) });
  return new Promise((resolve, reject) => {
    const server = app.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      allowedHosts.add(`127.0.0.1:${port}`).add(`localhost:${port}`);
      resolve({
        port, token, baseUrl: `http://127.0.0.1:${port}`,
        close: () => new Promise((done) => { server.close(() => done()); server.closeAllConnections(); }),
      });
    });
    server.on('error', reject);
  });
}

module.exports = { createApp, startServer };
