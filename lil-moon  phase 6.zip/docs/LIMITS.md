# Usage limits, warnings and restrictions (Phase 6)

Built on the project as it exists in this copy: Phases 1-3 and Phase 5 (website tracking). **Phase 4 (Windows application tracking) was not available** (its upload was empty), so there is no foreground-application service. Application limits therefore work on whatever application usage is stored in `usage_sessions` (category `application`) and, in this copy, warn or ask only. Nothing about applications was tested against real foreground tracking.

## What you can do
Per application or per website: a daily limit (1 minute to 24 hours), a mode, a warning percentage (default 80), the extra time offered when you continue (5/10/15/30 min, 1-120 via API), and an on/off switch that keeps the settings. One limit per target (case-insensitive). Target names: websites must already be on your tracked list (normalised domain); applications are free text matched, case-insensitively, to the `item_name` of stored application usage (suggestions come from `applications` and usage history). A master switch turns every warning, question and block off at once (dashboard, or the moon's right-click menu); usage keeps being recorded.

## Modes
| Mode | At the warning % | At 100% | Blocks? |
|---|---|---|---|
| Warning only (`warn`) | silent toast | silent toast "nothing is blocked" | never |
| Ask me first (`confirm`) | silent toast | if that website is in front: native dialog "Continue for N more minutes" / "Not now" (default and Esc = Not now); otherwise a toast, and the decision waits as a banner on the Usage limits page | never; extra time only if you say yes |
| Block (`enforce`, websites only) | silent toast | toast; the extension redirects the active tab on that domain to a block page | that website only, until you override, turn it off, midnight, or the app is gone ~10 min |

Extra time is measured in **usage** minutes, not clock time: approving 10 minutes raises today's allowance by 10 minutes, and "extra time used up" fires once usage reaches the new allowance (then you are asked/blocked again; each approval is one cycle). Nothing is ever extended silently: every grant, decline and override is an event with who/where (`source: dialog | dashboard | block page`).

## How enforcement works
**Websites (implemented).** The desktop app decides what is blocked (limit reached + mode `enforce` + enabled + master switch on) and tells the extension in every `/ext/activity` reply and `/ext/config`. The extension then, on tab activation, navigation, window focus and every 30 s heartbeat, replaces the **active tab of the focused, non-private window** if its URL matches a blocked domain, using `chrome.tabs.update` to an extension page (`blocked.html`). Matching is exactly the tracking rule: the listed domain and its true subdomains (`m.youtube.com` yes; `notyoutube.com`, `youtube.com.evil.example` no). Background tabs of that site are left alone until they are shown. Why not `declarativeNetRequest`/`webRequest`: redirecting arbitrary navigations needs broad host permissions (`<all_urls>`); the existing `tabs` permission is enough for this approach, and no new permission was added. The block page explains the method and offers: allow N more minutes (records an `override` event, returns you to the page you were opening), turn this limit off, open Lil Moon, go back. The popup also has "Turn off this site's limit".
Fail-open rules: the block list expires at the next local midnight; and if the desktop app has not confirmed it for 10 minutes (app closed or crashed) the extension stops blocking, so you can never be trapped. The list is stored in `chrome.storage.local`, so it survives service-worker and browser restarts; it is refreshed on every heartbeat (so a limit reached while you are on the site is enforced within about 30 s) and after the backend reconnects.
Limits: a determined user can disable the extension or use another browser; tabs restored by the browser are checked when they become active; the 30 s heartbeat bounds how late a block can be.

**Applications (not implemented, on purpose).** Safe blocking needs the Phase 4 foreground-process service and a documented, consent-based method (for example: warn, then ask the user to close the app, or minimise only that one window). None of that exists in this copy, and the app never terminates, suspends or injects into any process. The API rejects `mode: enforce` for applications with a friendly message, and the form disables it. When Phase 4 is merged, application accounting must keep writing `usage_sessions` rows only while the app is in the foreground and the user is not idle (the shared idle monitor), and any enforcement must stay opt-in per limit, target exactly the chosen executable, never touch system, security or accessibility processes, and never repeat a kill.

## Notifications
Native Windows toasts (`silent: true`, no focus steal) for: warning %, limit reached, extra time used up, extra time approved, block issued, limit turned on/off, master switch on/off. Each warning/limit event is claimed with an atomic `INSERT OR IGNORE` on `(limit, local day, kind)`, so it fires once per day per cycle even with concurrent evaluators or an app restart. A new local day starts fresh; usage history is never reset or deleted by day change (old state rows are pruned after 14 days). Editing a limit's size or warning % re-arms today's alerts. If you jump straight past the warning (e.g. a long session is stored at once) only the limit-reached notice is sent.

## Database (schema v3, migration keeps all data)
`usage_limits`, `limit_extensions`, `limit_state` (notification de-duplication), `user_settings.restrictions_enabled`, and `restriction_events` rebuilt with more event types and `limit_id`, `extra_seconds`, `detail` (existing rows copied; verified by a migration test). Indexes: `idx_limits_enabled`, `idx_extensions_limit_date`, `idx_restriction_created`, `idx_restriction_item`, `idx_restriction_limit`. Usage is always computed from stored `usage_sessions` for the local `session_date` (the same policy as tracking). Events: `limit_warning, limit_reached, blocked, extension_granted, extension_declined, extension_ended, limit_enabled, limit_disabled, limit_deleted, override, restrictions_on, restrictions_off`.

## API (dashboard token; same `{ok,data}` / `{ok:false,error}` conventions)
`GET /api/limits` (live usage, remaining, status, needsDecision), `GET /api/limits/summary`, `GET /api/limits/targets?type=`, `GET /api/limits/events?limit&offset&limitId`, `POST /api/limits`, `PUT /api/limits/:id` (limit/mode/warning/extension/enabled; the target cannot be changed), `DELETE /api/limits/:id`, `POST /api/limits/:id/extensions {minutes}` (only when reached, never in warn mode), `POST /api/limits/:id/decline`, `PUT /api/limits/master {enabled}`.
Extension (pairing code only): block list inside `GET /ext/config` and `POST /ext/activity` replies; `POST /ext/limits/blocked`, `/ext/limits/override` (uses the limit's own configured minutes, only for an enforced limit), `/ext/limits/disable`, each limited to an exactly tracked domain. The extension cannot create, edit or delete limits, or read events.

## Commands
```
npm install
npm start                # app + backend; builds the UI first
npm run dev              # live UI reload
npm test                 # 81 tests, plain Node 22.13+ (files run one after another: they share the extension port range)
npm run smoke            # Electron integration test, see README for the two-phase restart check
```
Chrome extension: `chrome://extensions` -> Developer mode -> Load unpacked -> the `extension` folder (reload it after updating); open Lil Moon -> Website usage -> copy the pairing code -> toolbar icon -> paste -> Connect.

## What was actually run (Linux, Node 22 + Electron 45 under Xvfb)
| Area | How | Result |
|---|---|---|
| Phase 3 API tests (13, three assertions updated for the new schema version/default sites) | `npm test` | Passed |
| Website tracker + idle monitor (16) | fake clock, real SQLite | Passed |
| Extension API (10) | real server | Passed |
| Extension logic with a simulated `chrome` object against the real backend (9) | `extension-core.test.js` | Passed |
| Limits engine, API, validation, migration (20): create app/website limits; edit/delete; disable/enable; 80% once; 100% once; jump past 80%; warn never blocks; confirm records decision; decline; extension expiry per cycle; enforced list covers only the configured domain; override/disable/master switch; day rollover keeps history; restart and concurrent evaluators do not repeat events; invalid input (24 bad payloads); extension routes and token separation; migration v2->v3 | real SQLite + HTTP | Passed |
| Notifier (5): toast text, silent, once; dialog defaults to "Not now"; continue/decline recorded; no dialog when the site is not in front; enforced wording | fake Electron `Notification`/`dialog` + real engine | Passed |
| Extension enforcement (8): only the active tab on the exact domain; background tabs untouched; look-alike domains, internal pages and incognito untouched; navigation; unfocused browser; warn/confirm never redirect; blocked event once; override returns to the original page; disable; service-worker restart; backend down then fail-open (10 min, midnight); reconnect lifts the block; enforcement errors cannot break tracking | extension code + real backend; only `chrome` simulated | Passed |
| Electron smoke (phase 1 + restart phase 2) | real windows, real `powerMonitor` events, real notifier, real dashboard UI | Phase 1-3 and Phase 5 checks still pass; new Phase 6 checks pass (limits page empty state, UI validation message, UI creation, duplicate/unsupported-mode rejection, 80% and 100% toasts once, events once, enforced block list, master switch, extra time recorded, disable keeps settings, limit + history survive restart). The one failure is **dashboard minimize** (no window manager under bare Xvfb), as in every earlier phase |

## NOT verified
- Everything in a real Chrome/Edge (redirect to the block page, `tabs.onUpdated`/`onActivated` timing, restored tabs, popup/block-page rendering, multi-window behaviour) and on real Windows (native toast appearance, dialog focus behaviour, lock/sleep).
- Application usage from real foreground tracking, "accounting pauses when the application loses focus" for applications, and "restriction does not terminate unrelated processes" (no process control exists, so nothing can terminate anything; this is by construction, not a test of a feature).
- That the moon right-click "Warnings and restrictions on" item toggles correctly (native menu cannot be driven here; the same `setMaster` call is tested).
- Browser restart with the block page open, and two browsers enforcing at once.

## Manual test checklist (Windows)
Use a 1-minute limit so each case takes a minute. Dashboard -> Usage limits -> Add a limit.
1. **Create:** website `youtube.com`, 1 minute, Warning only. It appears with 0s used.
2. **Warning (80%):** watch YouTube (extension paired, Website usage shows "Counting now") for ~50 s. One quiet toast "80% of today's limit". It does not repeat.
3. **Limit reached:** at 60 s one toast "Daily limit reached... nothing is blocked". YouTube keeps working. The card says "Limit reached"; History lists the events once each.
4. **Ask me first:** edit the limit to "Ask me first". Edit the limit to "Ask me first" and raise it by a minute (editing re-arms today's alerts); with YouTube in front, a dialog appears when you reach it again. "Not now" -> history shows "You chose not to continue". Reopen: choose "Continue for N more minutes" -> "You approved extra time (+N min)". After N more minutes of YouTube you are asked again ("extra time used up").
5. **Block:** edit the limit to "Block". YouTube is already past its limit today, so within about 30 seconds the active YouTube tab is replaced by the Lil Moon block page (switching to the tab also triggers it). Other sites and other tabs work. A look-alike site (e.g. notyoutube.com) works.
6. **Override / turn off:** on the block page press "Allow N more minutes": you return to the page you wanted; history shows "You overrode the block". Use "Turn this limit off" (or the popup button, or the dashboard) and confirm YouTube is free again.
7. **Master switch:** "Turn off all restrictions" (dashboard or moon right-click menu): nothing blocks or warns; usage still counts. Turn back on.
8. **Restarts:** while blocked, restart Chrome, then disable/re-enable the extension (service worker restart), then quit Lil Moon for 12 minutes (block must lift by itself), then start it again (block returns if still reached).
9. **Day rollover:** (or change the clock) after midnight the usage shows 0, alerts can fire again, and yesterday's usage is still in History.
10. **Validation:** try 0, -5, 1441 minutes, empty target, a duplicate target, an application in Block mode: each shows a clear message and nothing is saved.
11. **Phases 1-5:** drag/click the moon, dashboard buttons, Website usage page and extension popup still work.
12. **Applications:** until Phase 4 is merged, add an application limit for a name that has stored usage (use "Add a test session" on Application usage) and check the 80%/100% toasts and decision banner.

## Known limitations
- No application blocking (see above). No foreground application accounting in this copy.
- Block latency up to ~30 s after the limit is crossed (heartbeat), because the extension is told on its next report; the active run is stored up to the second when the desktop app evaluates.
- A website limit measures the tracked domain including its subdomains; there is no separate "exact host only" policy, because usage itself is counted per tracked domain.
- Per-limit configuration offers 5/10/15/30 minutes in the UI (the API accepts 1-120).
- Closing the app or the extension lifts website blocks by design (fail-open); this is a personal self-control tool, not a security boundary.
