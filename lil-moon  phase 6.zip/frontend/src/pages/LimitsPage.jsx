import { useState } from 'react';
import AsyncBoundary from '../components/AsyncBoundary.jsx';
import DashboardCard from '../components/DashboardCard.jsx';
import LimitCard from '../components/LimitCard.jsx';
import LimitForm from '../components/LimitForm.jsx';
import { useApi } from '../hooks/useApi.js';
import { api } from '../lib/api.js';
import { fmtSec, fmtWhen } from '../lib/format.js';

const EVENT = {
  limit_warning: 'Warning shown', limit_reached: 'Limit reached', blocked: 'Blocked in the browser', extension_granted: 'You approved extra time',
  extension_declined: 'You chose not to continue', extension_ended: 'Extra time used up', limit_enabled: 'Limit turned on', limit_disabled: 'Limit turned off',
  limit_deleted: 'Limit deleted', override: 'You overrode the block', restrictions_on: 'All restrictions turned on', restrictions_off: 'All restrictions turned off',
};

export default function LimitsPage() {
  const limits = useApi('/api/limits', { intervalMs: 5000 });
  const summary = useApi('/api/limits/summary', { intervalMs: 5000 });
  const events = useApi('/api/limits/events?limit=25', { intervalMs: 10000 });
  const [editing, setEditing] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const refresh = () => { limits.reload(); summary.reload(); events.reload(); };
  const act = async (fn) => { setBusy(true); setError(''); try { await fn(); refresh(); } catch (e) { setError(e.message); } finally { setBusy(false); } };

  const toggle = (i) => act(() => api('PUT', `/api/limits/${i.id}`, { isEnabled: !i.isEnabled }));
  const remove = (i) => act(async () => { await api('DELETE', `/api/limits/${i.id}`); if (editing?.id === i.id) setEditing(null); });
  const extend = (i, minutes) => act(() => api('POST', `/api/limits/${i.id}/extensions`, { minutes }));
  const decline = (i) => act(() => api('POST', `/api/limits/${i.id}/decline`, {}));
  const master = (enabled) => act(() => api('PUT', '/api/limits/master', { enabled }));

  const d = limits.data;
  const s = summary.data;
  const pending = d ? d.items.filter((i) => i.needsDecision) : [];

  return (
    <>
      <div className="page-head">
        <h1>Usage limits</h1>
        <span className="badge">{d ? (d.restrictionsEnabled ? 'Restrictions on' : 'Restrictions OFF') : 'Loading'}</span>
      </div>
      <p className="lead">Set a daily limit for an application or a website. Usage comes from what was actually tracked today; nothing here is sample data.</p>

      <AsyncBoundary query={limits}>
        {d && (
          <>
            <DashboardCard title="Master switch" tone={d.restrictionsEnabled ? 'cream' : 'purple'} badge={d.restrictionsEnabled ? 'On' : 'Off'}>
              <p className="note">{d.restrictionsEnabled
                ? 'Warnings, questions and blocks are active. Usage is always recorded either way.'
                : 'ALL warnings, questions and blocks are paused. Usage is still being recorded.'}</p>
              <button className="btn" disabled={busy} onClick={() => master(!d.restrictionsEnabled)}>{d.restrictionsEnabled ? 'Turn off all restrictions' : 'Turn restrictions back on'}</button>
              <p className="note">You can also do this from the moon's right-click menu.</p>
            </DashboardCard>

            <h2 className="section-title">Today</h2>
            <div className="grid">
              <DashboardCard title="Active limits" tone="cream"><p className="big">{s?.activeLimits ?? '-'}</p></DashboardCard>
              <DashboardCard title="Limits reached today"><p className="big">{s?.reachedToday ?? '-'}</p></DashboardCard>
              <DashboardCard title="Application usage today" tone="cream"><p className="big small">{s ? fmtSec(s.applicationSeconds) : '-'}</p></DashboardCard>
              <DashboardCard title="Website usage today"><p className="big small">{s ? fmtSec(s.websiteSeconds) : '-'}</p></DashboardCard>
            </div>

            {pending.length > 0 && (
              <div className="state state-error" role="alert">
                <p><b>Waiting for your decision:</b></p>
                {pending.map((i) => (
                  <p key={i.id}>{i.target} reached its limit. <button className="btn btn-small" disabled={busy} onClick={() => extend(i, i.extensionMinutes)}>Continue {i.extensionMinutes} more minutes</button> <button className="btn btn-small" disabled={busy} onClick={() => decline(i)}>Not now</button></p>
                ))}
              </div>
            )}

            <h2 className="section-title">Your limits</h2>
            {error && <p className="msg-error" role="alert">{error}</p>}
            {d.items.length === 0 ? (
              <div className="state">No limits yet. Add one below. Application limits use the usage recorded for that application; website limits use your tracked websites.</div>
            ) : (
              <ul className="usage-list">
                {d.items.map((i) => <LimitCard key={i.id} item={i} busy={busy} onEdit={(x) => { setEditing(x); window.scrollTo?.(0, 0); }} onToggle={toggle} onDelete={remove} onExtend={extend} onDecline={decline} />)}
              </ul>
            )}
          </>
        )}
      </AsyncBoundary>

      <DashboardCard title={editing ? `Edit limit: ${editing.target}` : 'Add a limit'} tone="cream" badge={editing ? 'Editing' : 'New'}>
        <LimitForm editing={editing} onDone={() => { setEditing(null); refresh(); }} onCancel={() => setEditing(null)} />
      </DashboardCard>

      <h2 className="section-title">How blocking works</h2>
      <DashboardCard title="What each mode does" tone="purple">
        <ul className="plain">
          <li><b>Warning only:</b> a quiet notification at your warning percentage and at 100%. Nothing is blocked.</li>
          <li><b>Ask me first:</b> at 100% a question appears if the site is in front, otherwise it waits here. Your answer and any extra time are saved below.</li>
          <li><b>Block (websites):</b> the Lil Moon browser extension swaps the active tab for a block page, only on that website. You can allow more time or turn the limit off right on that page, here, or from the extension popup. It lifts by itself at midnight, and if the app is closed for about 10 minutes.</li>
          <li><b>Applications:</b> warnings and questions only. Closing or blocking programs needs Windows process control, which Lil Moon does not do yet, so it is not offered.</li>
        </ul>
      </DashboardCard>

      <h2 className="section-title">Restriction history</h2>
      <AsyncBoundary query={events} isEmpty={events.data?.total === 0} empty="Nothing yet. Warnings, decisions, extra time and blocks will be listed here.">
        {events.data && (
          <ul className="history">
            {events.data.records.map((e) => (
              <li key={e.id}>
                <div><strong>{e.itemName}</strong><span>{fmtWhen(e.createdAt)}</span></div>
                <b>{EVENT[e.eventType] ?? e.eventType}{e.extraSeconds ? ` (+${fmtSec(e.extraSeconds)})` : ''}</b>
                <span />
              </li>
            ))}
          </ul>
        )}
      </AsyncBoundary>
    </>
  );
}
