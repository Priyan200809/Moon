// Interval maths on [startMs, endMs) pairs.
function merge(list) {
  const sorted = list.filter(([s, e]) => e > s).sort((a, b) => a[0] - b[0]);
  const out = [];
  for (const [s, e] of sorted) {
    const last = out[out.length - 1];
    if (last && s <= last[1]) last[1] = Math.max(last[1], e);
    else out.push([s, e]);
  }
  return out;
}

function subtract(pieces, cuts) {
  const c = merge(cuts);
  const out = [];
  for (const [s, e] of pieces) {
    let cur = s;
    for (const [cs, ce] of c) {
      if (ce <= cur) continue;
      if (cs >= e) break;
      if (cs > cur) out.push([cur, cs]);
      cur = Math.max(cur, ce);
      if (cur >= e) break;
    }
    if (cur < e) out.push([cur, e]);
  }
  return out;
}

// Splits at local midnight (DST-safe: uses calendar arithmetic, not +24h).
function splitAtLocalMidnight([s, e]) {
  const out = [];
  let cur = s;
  while (cur < e) {
    const d = new Date(cur);
    const next = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).getTime();
    out.push([cur, Math.min(next, e)]);
    cur = next;
  }
  return out;
}

module.exports = { merge, subtract, splitAtLocalMidnight };
