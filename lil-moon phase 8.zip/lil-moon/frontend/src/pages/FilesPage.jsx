import { useState } from 'react';
import AsyncBoundary from '../components/AsyncBoundary.jsx';
import { api } from '../lib/api.js';
import { useApi } from '../hooks/useApi.js';
import { fmtWhen } from '../lib/format.js';

const OPENS = new Set(['txt', 'md', 'pdf', 'docx', 'csv', 'json']);

function Snippet({ text }) {
  return <>{text.split(/(\[[^\]]+\])/g).map((p, i) => (/^\[[^\]]+\]$/.test(p) ? <mark key={i}>{p.slice(1, -1)}</mark> : p))}</>;
}

export default function FilesPage() {
  const [indexing, setIndexing] = useState(false);
  const status = useApi('/api/files/status', { intervalMs: indexing ? 1500 : 8000 });
  const folders = status.data?.folders ?? [];
  const busy = folders.some((f) => f.status === 'indexing');
  if (busy !== indexing) setIndexing(busy);
  const [q, setQ] = useState('');
  const [results, setResults] = useState(null);
  const [searching, setSearching] = useState(false);
  const [msg, setMsg] = useState({ text: '', error: false });
  const [confirmId, setConfirmId] = useState(null);
  const say = (text, error = false) => setMsg({ text, error });

  const act = async (fn, ok) => { try { const r = await fn(); if (ok) say(typeof ok === 'function' ? ok(r) : ok); status.reload(); } catch (e) { say(e.message, true); } };
  const search = async (e) => {
    e.preventDefault();
    if (!q.trim()) return;
    setSearching(true); say('');
    try { setResults(await api('GET', `/api/files/search?q=${encodeURIComponent(q.trim())}`)); } catch (err) { say(err.message, true); setResults(null); }
    setSearching(false);
  };

  return (
    <>
      <div className="page-head"><h1>Local files</h1><span className="badge">Stays on this computer</span></div>
      <p className="lead">Lil Moon only reads the folders you add here, never the whole computer. Files are read, never changed, and are not sent anywhere unless you allow it in AI setup. Passwords, private keys, system and browser folders are always skipped.</p>
      <span role="status" className={msg.error ? 'msg-error' : ''}>{msg.text}</span>

      <h2 className="section-title">Indexed folders</h2>
      <div className="quick"><button className="btn btn-strong" onClick={() => act(() => api('POST', '/api/files/folders'), (r) => (r.cancelled ? 'No folder chosen.' : 'Folder added. Indexing started.'))}>Add folder</button></div>
      <AsyncBoundary query={status} isEmpty={folders.length === 0} empty="No folders yet. Add a folder with your notes, assignments or documents to search them.">
        <ul className="usage-list">
          {folders.map((f) => (
            <li key={f.id} className="usage-item">
              <div className="usage-top"><h3 className="path">{f.path}</h3><span className={`flag${f.status === 'error' ? ' flag-over' : ''}`}>{f.status === 'indexing' ? 'Indexing...' : f.status === 'error' ? 'Problem' : 'Up to date'}</span></div>
              {f.status === 'indexing' && f.progress && <p className="note" role="status">Looked at {f.progress.seen} files, indexed {f.progress.indexed}{f.progress.current ? `. Now: ${f.progress.current}` : ''}</p>}
              {f.status === 'error' && <p className="msg-error" role="alert">{f.lastError}</p>}
              <dl className="usage-stats">
                <div><dt>Indexed files</dt><dd>{f.indexedFiles}</dd></div>
                <div><dt>Skipped / errors</dt><dd>{f.skippedFiles} / {f.errorFiles}</dd></div>
                <div><dt>Last indexed</dt><dd>{f.lastIndexedAt ? fmtWhen(f.lastIndexedAt) : 'Not yet'}</dd></div>
              </dl>
              <div className="quick" style={{ marginTop: 12 }}>
                <button className="btn btn-small" disabled={f.status === 'indexing'} onClick={() => act(() => api('POST', `/api/files/folders/${f.id}/reindex`), 'Re-indexing started.')}>Re-index</button>
                <button className="btn btn-small" onClick={() => { if (confirmId !== f.id) { setConfirmId(f.id); setTimeout(() => setConfirmId(null), 4000); return; } setConfirmId(null); act(() => api('DELETE', `/api/files/folders/${f.id}`), 'Folder removed and its index deleted. Your files were not touched.'); }}>{confirmId === f.id ? 'Click again to remove' : 'Remove folder'}</button>
              </div>
            </li>
          ))}
        </ul>
      </AsyncBoundary>

      <h2 className="section-title">Search</h2>
      <form className="quick" onSubmit={search} role="search">
        <input className="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder='Try "DBMS notes" or "GCD program"' maxLength={200} aria-label="Search your files" />
        <button className="btn btn-strong" type="submit" disabled={!q.trim() || searching || folders.length === 0}>{searching ? 'Searching...' : 'Search'}</button>
      </form>
      {results && (results.length === 0
        ? <div className="state">No files matched. If you just added a folder, wait for indexing to finish.</div>
        : <ul className="history">
          {results.map((r) => (
            <li key={`${r.fileId}`}>
              <div><strong>{r.name}{r.nameMatch && <span className="badge" style={{ marginLeft: 8 }}>name match</span>}</strong><span className="path">{r.path}{r.section ? ` - ${r.section}` : ''}</span><span className="snip"><Snippet text={r.snippet} /></span></div>
              <button className="btn btn-small" onClick={() => act(() => api('POST', `/api/files/${r.fileId}/open`), (x) => (x.opened ? 'Opened.' : 'Shown in the folder (scripts are never launched).'))}>{OPENS.has(r.ext) ? 'Open' : 'Show in folder'}</button>
            </li>
          ))}
        </ul>)}
    </>
  );
}
