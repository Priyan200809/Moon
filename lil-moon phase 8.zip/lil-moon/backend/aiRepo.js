// Persistence for conversations, memory, AI settings, the file index and the tool log. Parameterized SQL only.
const nowIso = () => new Date().toISOString();
const likeEscape = (s) => s.replace(/[\\%_]/g, (c) => `\\${c}`);
const conflict = (message) => Object.assign(new Error(message), { httpStatus: 409, code: 'conflict' });

function createAiRepository(db) {
  const tx = (fn) => { db.exec('BEGIN'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } };
  const conv = (r) => (r ? { id: r.id, title: r.title, createdAt: r.created_at, updatedAt: r.updated_at } : null);
  const msg = (r) => ({ id: r.id, conversationId: r.conversation_id, role: r.role, content: r.content, createdAt: r.created_at, provider: r.provider, model: r.model, sources: r.sources_json ? JSON.parse(r.sources_json) : [] });
  const mem = (r) => (r ? { id: r.id, category: r.category, content: r.content, origin: r.origin, createdAt: r.created_at, updatedAt: r.updated_at } : null);
  const folder = (r) => (r ? { id: r.id, path: r.path, addedAt: r.added_at, lastIndexedAt: r.last_indexed_at, status: r.status, lastError: r.last_error } : null);

  return {
    tx,
    // ---- AI settings (no secrets here; the API key lives in the main process key store)
    getAiSettings() {
      const r = db.prepare('SELECT * FROM ai_settings WHERE id = 1').get();
      return { provider: r.provider, model: r.model, baseUrl: r.base_url, memoryEnabled: r.memory_enabled === 1, allowFileExcerpts: r.allow_file_excerpts === 1 };
    },
    updateAiSettings(patch) {
      const n = { ...this.getAiSettings(), ...patch };
      db.prepare('UPDATE ai_settings SET provider = ?, model = ?, base_url = ?, memory_enabled = ?, allow_file_excerpts = ?, updated_at = ? WHERE id = 1')
        .run(n.provider, n.model, n.baseUrl, n.memoryEnabled ? 1 : 0, n.allowFileExcerpts ? 1 : 0, nowIso());
      return this.getAiSettings();
    },

    // ---- conversations and messages
    createConversation(title = 'New conversation') {
      const t = nowIso();
      return conv(db.prepare('SELECT * FROM conversations WHERE id = ?').get(Number(db.prepare('INSERT INTO conversations (title, created_at, updated_at) VALUES (?, ?, ?)').run(title, t, t).lastInsertRowid)));
    },
    getConversation: (id) => conv(db.prepare('SELECT * FROM conversations WHERE id = ?').get(id)),
    renameConversation(id, title) {
      db.prepare('UPDATE conversations SET title = ?, updated_at = ? WHERE id = ?').run(title, nowIso(), id);
      return this.getConversation(id);
    },
    deleteConversation: (id) => db.prepare('DELETE FROM conversations WHERE id = ?').run(id).changes > 0,
    deleteAllConversations: () => db.prepare('DELETE FROM conversations').run().changes,
    listConversations(q) {
      if (!q) return db.prepare('SELECT * FROM conversations ORDER BY updated_at DESC, id DESC LIMIT 200').all().map(conv);
      const like = `%${likeEscape(q)}%`;
      return db.prepare(
        `SELECT c.*, (SELECT substr(m.content, 1, 160) FROM messages m WHERE m.conversation_id = c.id AND m.content LIKE ? ESCAPE '\\' ORDER BY m.id LIMIT 1) AS match
         FROM conversations c
         WHERE c.title LIKE ? ESCAPE '\\' OR EXISTS (SELECT 1 FROM messages m WHERE m.conversation_id = c.id AND m.content LIKE ? ESCAPE '\\')
         ORDER BY c.updated_at DESC, c.id DESC LIMIT 200`
      ).all(like, like, like).map((r) => ({ ...conv(r), match: r.match ?? null }));
    },
    addMessage({ conversationId, role, content, provider = null, model = null, sources = null }) {
      return tx(() => {
        const t = nowIso();
        const info = db.prepare('INSERT INTO messages (conversation_id, role, content, created_at, provider, model, sources_json) VALUES (?, ?, ?, ?, ?, ?, ?)')
          .run(conversationId, role, content, t, provider, model, sources?.length ? JSON.stringify(sources) : null);
        db.prepare('UPDATE conversations SET updated_at = ? WHERE id = ?').run(t, conversationId);
        const c = this.getConversation(conversationId);
        if (role === 'user' && c.title === 'New conversation') {
          this.renameConversation(conversationId, content.replace(/\s+/g, ' ').trim().slice(0, 60) || 'New conversation');
        }
        return msg(db.prepare('SELECT * FROM messages WHERE id = ?').get(Number(info.lastInsertRowid)));
      });
    },
    clearMessages(conversationId) { db.prepare('DELETE FROM messages WHERE conversation_id = ?').run(conversationId); return conv(db.prepare('UPDATE conversations SET updated_at = ? WHERE id = ? RETURNING *').get(nowIso(), conversationId)); },
    listMessages: (conversationId) => db.prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY id').all(conversationId).map(msg),

    // ---- memory (separate from raw conversations)
    listMemories({ q, category } = {}) {
      const where = ['1 = 1'], args = [];
      if (category) { where.push('category = ?'); args.push(category); }
      if (q) { where.push("content LIKE ? ESCAPE '\\'"); args.push(`%${likeEscape(q)}%`); }
      return db.prepare(`SELECT * FROM memories WHERE ${where.join(' AND ')} ORDER BY updated_at DESC, id DESC`).all(...args).map(mem);
    },
    addMemory({ category, content, origin, sourceConversationId = null }) {
      if (db.prepare('SELECT 1 FROM memories WHERE lower(content) = lower(?)').get(content)) throw conflict('You already have that memory.');
      const t = nowIso();
      const info = db.prepare('INSERT INTO memories (category, content, origin, source_conversation_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)').run(category, content, origin, sourceConversationId, t, t);
      return mem(db.prepare('SELECT * FROM memories WHERE id = ?').get(Number(info.lastInsertRowid)));
    },
    updateMemory(id, patch) {
      const cur = db.prepare('SELECT * FROM memories WHERE id = ?').get(id);
      if (!cur) return null;
      db.prepare('UPDATE memories SET category = ?, content = ?, updated_at = ? WHERE id = ?').run(patch.category ?? cur.category, patch.content ?? cur.content, nowIso(), id);
      return mem(db.prepare('SELECT * FROM memories WHERE id = ?').get(id));
    },
    deleteMemory: (id) => db.prepare('DELETE FROM memories WHERE id = ?').run(id).changes > 0,
    clearMemories() { return tx(() => { const n = db.prepare('DELETE FROM memories').run().changes; db.prepare('DELETE FROM memory_candidates').run(); return n; }); },
    addCandidate({ category, content, conversationId = null }) {
      if (db.prepare('SELECT 1 FROM memory_candidates WHERE lower(content) = lower(?)').get(content) || db.prepare('SELECT 1 FROM memories WHERE lower(content) = lower(?)').get(content)) return null;
      const info = db.prepare('INSERT INTO memory_candidates (category, content, conversation_id, created_at) VALUES (?, ?, ?, ?)').run(category, content, conversationId, nowIso());
      return this.getCandidate(Number(info.lastInsertRowid));
    },
    getCandidate: (id) => { const r = db.prepare('SELECT * FROM memory_candidates WHERE id = ?').get(id); return r ? { id: r.id, category: r.category, content: r.content, conversationId: r.conversation_id, createdAt: r.created_at } : null; },
    listCandidates: () => db.prepare('SELECT * FROM memory_candidates ORDER BY id').all().map((r) => ({ id: r.id, category: r.category, content: r.content, conversationId: r.conversation_id, createdAt: r.created_at })),
    deleteCandidate: (id) => db.prepare('DELETE FROM memory_candidates WHERE id = ?').run(id).changes > 0,
    listAvoid: () => db.prepare('SELECT id, phrase, created_at FROM memory_avoid ORDER BY id').all().map((r) => ({ id: r.id, phrase: r.phrase, createdAt: r.created_at })),
    addAvoid(phrase) {
      try { db.prepare('INSERT INTO memory_avoid (phrase, created_at) VALUES (?, ?)').run(phrase, nowIso()); } catch (e) { if (!/UNIQUE/i.test(e.message)) throw e; }
      return this.listAvoid();
    },
    removeAvoid: (id) => db.prepare('DELETE FROM memory_avoid WHERE id = ?').run(id).changes > 0,
    isAvoided(content) {
      const c = content.toLowerCase();
      return this.listAvoid().some((a) => c.includes(a.phrase.toLowerCase()));
    },

    // ---- local file index
    addFolder(p) {
      try {
        const info = db.prepare('INSERT INTO indexed_folders (path, added_at) VALUES (?, ?)').run(p, nowIso());
        return this.getFolder(Number(info.lastInsertRowid));
      } catch (e) { if (/UNIQUE/i.test(e.message)) throw conflict('That folder is already indexed.'); throw e; }
    },
    getFolder: (id) => folder(db.prepare('SELECT * FROM indexed_folders WHERE id = ?').get(id)),
    listFolders: () => db.prepare(
      `SELECT f.*, (SELECT COUNT(*) FROM indexed_files x WHERE x.folder_id = f.id AND x.status = 'indexed') AS indexed,
              (SELECT COUNT(*) FROM indexed_files x WHERE x.folder_id = f.id AND x.status = 'skipped') AS skipped,
              (SELECT COUNT(*) FROM indexed_files x WHERE x.folder_id = f.id AND x.status = 'error') AS errors
       FROM indexed_folders f ORDER BY f.id`).all().map((r) => ({ ...folder(r), indexedFiles: r.indexed, skippedFiles: r.skipped, errorFiles: r.errors })),
    removeFolder: (id) => db.prepare('DELETE FROM indexed_folders WHERE id = ?').run(id).changes > 0,
    setFolderStatus(id, { status, lastError = null, lastIndexedAt }) {
      db.prepare('UPDATE indexed_folders SET status = ?, last_error = ?, last_indexed_at = COALESCE(?, last_indexed_at) WHERE id = ?').run(status, lastError, lastIndexedAt ?? null, id);
    },
    getFileState: (folderId, rel) => db.prepare('SELECT id, size_bytes, mtime_ms, content_hash, status FROM indexed_files WHERE folder_id = ? AND rel_path = ?').get(folderId, rel) ?? null,
    upsertFile(f) {
      db.prepare(
        `INSERT INTO indexed_files (folder_id, rel_path, name, ext, size_bytes, mtime_ms, content_hash, indexed_at, status, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT (folder_id, rel_path) DO UPDATE SET name = excluded.name, ext = excluded.ext, size_bytes = excluded.size_bytes, mtime_ms = excluded.mtime_ms,
           content_hash = excluded.content_hash, indexed_at = excluded.indexed_at, status = excluded.status, note = excluded.note`
      ).run(f.folderId, f.rel, f.name, f.ext, f.size, f.mtimeMs, f.hash ?? null, nowIso(), f.status, f.note ?? null);
      return db.prepare('SELECT id FROM indexed_files WHERE folder_id = ? AND rel_path = ?').get(f.folderId, f.rel).id;
    },
    replaceChunks(fileId, chunks) {
      db.prepare('DELETE FROM file_chunks WHERE file_id = ?').run(fileId);
      const ins = db.prepare('INSERT INTO file_chunks (file_id, chunk_no, heading, text) VALUES (?, ?, ?, ?)');
      chunks.forEach((c, i) => ins.run(fileId, i, c.heading, c.text));
    },
    touchFile: (id, size, mtimeMs) => db.prepare('UPDATE indexed_files SET size_bytes = ?, mtime_ms = ?, indexed_at = ? WHERE id = ?').run(size, mtimeMs, nowIso(), id),
    listFileRels: (folderId) => db.prepare('SELECT id, rel_path FROM indexed_files WHERE folder_id = ?').all(folderId),
    deleteFile: (id) => db.prepare('DELETE FROM indexed_files WHERE id = ?').run(id).changes > 0,
    getFile(id) {
      const r = db.prepare('SELECT f.*, fo.path AS folder_path FROM indexed_files f JOIN indexed_folders fo ON fo.id = f.folder_id WHERE f.id = ?').get(id);
      return r ? { id: r.id, folderId: r.folder_id, folderPath: r.folder_path, relPath: r.rel_path, name: r.name, ext: r.ext, sizeBytes: r.size_bytes, mtimeMs: r.mtime_ms, status: r.status, note: r.note } : null;
    },
    getChunks: (fileId, from, limit) => db.prepare('SELECT id, chunk_no, heading, text FROM file_chunks WHERE file_id = ? AND chunk_no >= ? ORDER BY chunk_no LIMIT ?').all(fileId, from, limit).map((r) => ({ id: r.id, chunkNo: r.chunk_no, heading: r.heading, text: r.text })),
    fileStats: () => ({ files: db.prepare("SELECT COUNT(*) n FROM indexed_files WHERE status = 'indexed'").get().n, chunks: db.prepare('SELECT COUNT(*) n FROM file_chunks').get().n }),

    // ---- tool log
    logTool({ conversationId = null, tool, args, outcome }) {
      db.prepare('INSERT INTO tool_log (conversation_id, tool, args_json, outcome, created_at) VALUES (?, ?, ?, ?, ?)').run(conversationId, tool, JSON.stringify(args ?? {}).slice(0, 2000), String(outcome).slice(0, 300), nowIso());
    },
    listToolLog: (limit = 50) => db.prepare('SELECT id, tool, args_json, outcome, created_at FROM tool_log ORDER BY id DESC LIMIT ?').all(limit).map((r) => ({ id: r.id, tool: r.tool, args: JSON.parse(r.args_json), outcome: r.outcome, createdAt: r.created_at })),
    clearToolLog: () => db.prepare('DELETE FROM tool_log').run().changes,
  };
}

module.exports = { createAiRepository };
