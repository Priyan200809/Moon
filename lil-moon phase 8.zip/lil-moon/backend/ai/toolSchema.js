// Tiny JSON-schema subset validator for tool arguments (object of string / integer / enum properties).
// Anything the model sends that is not declared is rejected; nothing is coerced.
function validateArgs(parameters, args) {
  if (args === undefined || args === null) args = {};
  if (typeof args !== 'object' || Array.isArray(args)) return { error: 'Arguments must be an object.' };
  const props = parameters.properties ?? {};
  for (const k of Object.keys(args)) if (!(k in props)) return { error: `Unknown argument: ${k}` };
  const out = {};
  for (const [k, spec] of Object.entries(props)) {
    const v = args[k];
    if (v === undefined) { if (parameters.required?.includes(k)) return { error: `Missing argument: ${k}` }; continue; }
    if (spec.type === 'string') {
      if (typeof v !== 'string') return { error: `${k} must be a string.` };
      if (spec.maxLength && v.length > spec.maxLength) return { error: `${k} is too long.` };
      if (spec.enum && !spec.enum.includes(v)) return { error: `${k} must be one of: ${spec.enum.join(', ')}.` };
      if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v)) return { error: `${k} contains control characters.` };
    } else if (spec.type === 'integer') {
      if (!Number.isInteger(v) || (spec.minimum !== undefined && v < spec.minimum) || (spec.maximum !== undefined && v > spec.maximum)) return { error: `${k} must be a whole number${spec.minimum !== undefined ? ` from ${spec.minimum} to ${spec.maximum}` : ''}.` };
    } else return { error: `Unsupported schema type for ${k}.` };
    out[k] = v;
  }
  return { value: out };
}

module.exports = { validateArgs };
