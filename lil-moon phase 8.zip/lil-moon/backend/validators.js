const { THEMES } = require('./database');
const { normalizeConfiguredDomain } = require('./domain');

class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}
const bad = (msg) => new HttpError(400, 'validation_error', msg);
const CATEGORIES = ['application', 'website'];
const ISO_UTC = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,3})?Z$/;

function onlyFields(body, allowed) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw bad('Request body must be a JSON object.');
  for (const k of Object.keys(body)) if (!allowed.includes(k)) throw bad(`Unknown field: ${k}`);
}

function realDate(v, name) {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) throw bad(`${name} must be a date like 2026-10-25.`);
  const d = new Date(`${v}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v) throw bad(`${name} is not a real calendar date.`);
  return v;
}

function int(v, name, min, max, fallback) {
  if (v === undefined) return fallback;
  if (typeof v !== 'string' || !/^\d{1,9}$/.test(v) || Number(v) < min || Number(v) > max) throw bad(`${name} must be a whole number from ${min} to ${max}.`);
  return Number(v);
}

function category(v, name = 'category') {
  if (v === undefined) return undefined;
  if (!CATEGORIES.includes(v)) throw bad(`${name} must be "application" or "website".`);
  return v;
}

function timestamp(v, name) {
  if (typeof v !== 'string' || !ISO_UTC.test(v)) throw bad(`${name} must be a UTC ISO-8601 timestamp like 2026-10-25T14:03:09.000Z.`);
  const d = new Date(v);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v.slice(0, 10)) throw bad(`${name} is not a real date and time.`);
  if (d.getUTCFullYear() < 2000) throw bad(`${name} is too far in the past.`);
  return d;
}

const settingsPatch = (body) => {
  onlyFields(body, ['dailyLimitSeconds', 'theme', 'idleThresholdSeconds', 'websiteTrackingEnabled']);
  const out = {};
  if ('dailyLimitSeconds' in body) {
    const n = body.dailyLimitSeconds;
    if (!Number.isInteger(n) || n < 300 || n > 86400) throw bad('dailyLimitSeconds must be a whole number from 300 to 86400.');
    out.dailyLimitSeconds = n;
  }
  if ('theme' in body) {
    if (!THEMES.includes(body.theme)) throw bad(`theme must be one of: ${THEMES.join(', ')}.`);
    out.theme = body.theme;
  }
  if ('idleThresholdSeconds' in body) {
    const n = body.idleThresholdSeconds;
    if (!Number.isInteger(n) || n < 15 || n > 3600) throw bad('idleThresholdSeconds must be a whole number from 15 to 3600.');
    out.idleThresholdSeconds = n;
  }
  if ('websiteTrackingEnabled' in body) {
    if (typeof body.websiteTrackingEnabled !== 'boolean') throw bad('websiteTrackingEnabled must be true or false.');
    out.websiteTrackingEnabled = body.websiteTrackingEnabled;
  }
  if (!Object.keys(out).length) throw bad('Provide at least one setting to change.');
  return out;
};

const sessionBody = (body) => {
  onlyFields(body, ['category', 'itemName', 'startedAt', 'endedAt']);
  if (!CATEGORIES.includes(body.category)) throw bad('category must be "application" or "website".');
  const name = typeof body.itemName === 'string' ? body.itemName.trim() : '';
  if (!name || name.length > 200 || /[\u0000-\u001f\u007f]/.test(name)) throw bad('itemName must be 1 to 200 printable characters.');
  const start = timestamp(body.startedAt, 'startedAt');
  const end = timestamp(body.endedAt, 'endedAt');
  if (start.getTime() > Date.now() + 5 * 60 * 1000) throw bad('startedAt cannot be in the future.');
  if (end < start) throw bad('endedAt must not be before startedAt.');
  const durationSeconds = Math.round((end - start) / 1000);
  if (durationSeconds > 86400) throw bad('A session cannot be longer than 24 hours.');
  return { category: body.category, itemName: name, startedAt: start.toISOString(), endedAt: end.toISOString(), durationSeconds };
};

const historyQuery = (q) => {
  const from = q.from === undefined ? undefined : realDate(q.from, 'from');
  const to = q.to === undefined ? undefined : realDate(q.to, 'to');
  if (from && to && from > to) throw bad('from must not be after to.');
  return { from, to, category: category(q.category), limit: int(q.limit, 'limit', 1, 200, 50), offset: int(q.offset, 'offset', 0, 1000000, 0) };
};

const recordId = (v) => {
  if (!/^[1-9]\d{0,9}$/.test(v)) throw bad('id must be a positive whole number.');
  return Number(v);
};

const MATCH_MODES = ['subdomains', 'exact'];
const displayName = (v) => {
  const n = typeof v === 'string' ? v.trim() : '';
  if (!n || n.length > 100 || /[\u0000-\u001f\u007f]/.test(n)) throw bad('displayName must be 1 to 100 printable characters.');
  return n;
};
const websiteBody = (body) => {
  onlyFields(body, ['domain', 'displayName', 'matchMode']);
  const domain = normalizeConfiguredDomain(body.domain);
  if (!domain) throw bad('domain must be a plain site name like youtube.com (no http://, path or port; shared suffixes like co.uk are refused).');
  if (body.matchMode !== undefined && !MATCH_MODES.includes(body.matchMode)) throw bad('matchMode must be "subdomains" or "exact".');
  return { domain, displayName: body.displayName === undefined ? domain : displayName(body.displayName), matchMode: body.matchMode ?? 'subdomains' };
};
const websitePatch = (body) => {
  onlyFields(body, ['displayName', 'matchMode', 'isEnabled']);
  const out = {};
  if ('displayName' in body) out.displayName = displayName(body.displayName);
  if ('matchMode' in body) { if (!MATCH_MODES.includes(body.matchMode)) throw bad('matchMode must be "subdomains" or "exact".'); out.matchMode = body.matchMode; }
  if ('isEnabled' in body) { if (typeof body.isEnabled !== 'boolean') throw bad('isEnabled must be true or false.'); out.isEnabled = body.isEnabled; }
  if (!Object.keys(out).length) throw bad('Provide displayName, matchMode or isEnabled.');
  return out;
};

// Extension batch: structure errors are 400; each bad session is reported individually.
const syncBody = (body) => {
  onlyFields(body, ['paused', 'browser', 'version', 'sessions']);
  if (typeof body.paused !== 'boolean') throw bad('paused must be true or false.');
  const short = (x, name) => { if (typeof x !== 'string' || x.length > 30 || !/^[\w .-]*$/.test(x)) throw bad(`${name} must be a short plain string.`); return x; };
  if (!Array.isArray(body.sessions) || body.sessions.length > 100) throw bad('sessions must be an array of at most 100 items.');
  return { paused: body.paused, browser: short(body.browser, 'browser'), version: short(body.version, 'version'), sessions: body.sessions };
};
const segment = (raw) => {
  try {
    onlyFields(raw, ['clientId', 'hostname', 'startedAt', 'endedAt']);
    if (typeof raw.clientId !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(raw.clientId)) throw bad('clientId');
    if (typeof raw.hostname !== 'string' || raw.hostname.length > 253) throw bad('hostname');
    const start = timestamp(raw.startedAt, 'startedAt'), end = timestamp(raw.endedAt, 'endedAt');
    if (end < start || end - start > 86400000) throw bad('range');
    return { ok: true, value: { clientId: raw.clientId, hostname: raw.hostname, startedAt: start.toISOString(), endedAt: end.toISOString() } };
  } catch (err) {
    if (err instanceof HttpError) return { ok: false, clientId: typeof raw?.clientId === 'string' && /^[A-Za-z0-9_-]{8,64}$/.test(raw.clientId) ? raw.clientId : null };
    throw err;
  }
};

// ---- Phase 8 ----
const validBaseUrl = (u) => {
  if (u === '') return true;
  try {
    const x = new URL(u);
    if (x.username || x.password || x.search || x.hash) return false;
    return x.protocol === 'https:' || (x.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(x.hostname)); // plain http only for local models
  } catch { return false; }
};
const text = (v, name, min, max) => {
  const t = typeof v === 'string' ? v.trim() : '';
  if (t.length < min || t.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(t)) throw bad(`${name} must be ${min} to ${max} characters.`);
  return t;
};
const CATS = ['preference', 'project', 'fact', 'task', 'instruction'];
const aiSettingsPatch = (body) => {
  onlyFields(body, ['provider', 'model', 'baseUrl', 'memoryEnabled', 'allowFileExcerpts']);
  const out = {};
  if ('provider' in body) { if (!['openai-compatible', 'anthropic'].includes(body.provider)) throw bad('provider must be "openai-compatible" or "anthropic".'); out.provider = body.provider; }
  if ('model' in body) { if (typeof body.model !== 'string' || body.model.length > 200 || !/^[\w.:/@+-]*$/.test(body.model)) throw bad('model must be a plain model name.'); out.model = body.model.trim(); }
  if ('baseUrl' in body) { if (typeof body.baseUrl !== 'string' || body.baseUrl.length > 300 || !validBaseUrl(body.baseUrl.trim())) throw bad('baseUrl must be an https:// address (http:// is allowed only for localhost) without credentials or query.'); out.baseUrl = body.baseUrl.trim(); }
  for (const k of ['memoryEnabled', 'allowFileExcerpts']) if (k in body) { if (typeof body[k] !== 'boolean') throw bad(`${k} must be true or false.`); out[k] = body[k]; }
  if (!Object.keys(out).length) throw bad('Nothing to change.');
  return out;
};
const apiKeyBody = (body) => {
  onlyFields(body, ['key']);
  if (typeof body.key !== 'string' || body.key.length < 8 || body.key.length > 400 || !/^[\x21-\x7e]+$/.test(body.key)) throw bad('key must be 8 to 400 visible characters with no spaces.');
  return body.key;
};
const titleBody = (body) => { onlyFields(body, ['title']); return text(body.title, 'title', 1, 200); };
const optionalTitle = (body) => { onlyFields(body ?? {}, ['title']); return body?.title === undefined ? 'New conversation' : text(body.title, 'title', 1, 200); };
const messageBody = (body) => {
  onlyFields(body, ['content', 'useFiles']);
  const content = text(body.content, 'content', 1, 8000);
  if (body.useFiles !== undefined && typeof body.useFiles !== 'boolean') throw bad('useFiles must be true or false.');
  return { content, useFiles: body.useFiles === true };
};
const memoryBody = (body) => {
  onlyFields(body, ['category', 'content']);
  if (!CATS.includes(body.category)) throw bad(`category must be one of: ${CATS.join(', ')}.`);
  return { category: body.category, content: text(body.content, 'content', 1, 500) };
};
const memoryPatch = (body) => {
  onlyFields(body, ['category', 'content']);
  const out = {};
  if ('category' in body) { if (!CATS.includes(body.category)) throw bad('Unknown category.'); out.category = body.category; }
  if ('content' in body) out.content = text(body.content, 'content', 1, 500);
  if (!Object.keys(out).length) throw bad('Nothing to change.');
  return out;
};
const avoidBody = (body) => { onlyFields(body, ['phrase']); return text(body.phrase, 'phrase', 2, 200); };
const approveBody = (body) => { onlyFields(body, ['approve']); if (typeof body.approve !== 'boolean') throw bad('approve must be true or false.'); return body.approve; };
const queryText = (q, name = 'q', optional = true) => {
  if (q === undefined) { if (optional) return undefined; throw bad(`${name} is required.`); }
  if (typeof q !== 'string') throw bad(`${name} must be text.`);
  return text(q, name, 1, 200);
};
const limitQuery = (q, def, max) => { if (q === undefined) return def; if (typeof q !== 'string' || !/^\d{1,3}$/.test(q) || Number(q) < 1 || Number(q) > max) throw bad(`limit must be 1 to ${max}.`); return Number(q); };

module.exports = {
  aiSettingsPatch, apiKeyBody, titleBody, optionalTitle, messageBody, memoryBody, memoryPatch, avoidBody, approveBody, queryText, limitQuery, CATS,
  websiteBody, websitePatch, syncBody, segment, HttpError, settingsPatch, sessionBody, historyQuery, category, recordId };
