// Speech-recognition service: process handling, privacy and error mapping through its JSON protocol with a fake process.
// The real Windows recogniser (System.Speech) could NOT be run in the development environment; this checks everything around it.
const test = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('events');
const { createSpeechRecognitionService } = require('../electron/voice/speechRecognitionService');
const { SCRIPT, encoded } = require('../electron/voice/sapiScript');

function rig(opts = {}) {
  const events = []; const spawns = []; const kills = []; const timers = [];
  let proc;
  const spawn = (cmd, args, o) => {
    proc = new EventEmitter(); proc.stdout = new EventEmitter(); proc.stdout.setEncoding = () => {};
    proc.kill = () => kills.push(1);
    spawns.push({ cmd, args, o });
    return proc;
  };
  const svc = createSpeechRecognitionService({
    spawn, platform: opts.platform ?? 'win32', env: { PATH: 'x', SystemRoot: 'C:\\Windows' }, getMicStatus: () => opts.mic ?? 'granted', send: (e) => events.push(e),
    setTimeoutFn: (fn, ms) => { timers.push({ fn, ms }); return timers.length; }, clearTimeoutFn: () => {},
  });
  const line = (o) => proc.stdout.emit('data', `${typeof o === 'string' ? o : JSON.stringify(o)}\n`);
  return { svc, events, spawns, kills, timers, line, exit: () => proc.emit('exit', 1), proc: () => proc };
}

test('refusals happen before any process or microphone is touched', () => {
  let r = rig({ platform: 'linux' }); assert.equal(r.svc.start({ language: 'en-US' }).error.code, 'unsupported_platform');
  r = rig(); assert.equal(r.svc.start({ language: 'fr-FR' }).error.code, 'unsupported_language');
  assert.equal(r.svc.start({}).error.code, 'unsupported_language');
  assert.equal(r.svc.start({ language: 'en-US; calc' }).error.code, 'unsupported_language');
  for (const mic of ['denied', 'restricted']) { r = rig({ mic }); const x = r.svc.start({ language: 'en-US' }); assert.deepEqual([x.ok, x.error.code], [false, 'permission_denied']); assert.match(x.error.message, /Privacy/); assert.equal(r.spawns.length, 0); }
});

test('push-to-talk session: fixed command line, live partials, one final result, then the process is gone and the mic released', () => {
  const r = rig();
  assert.deepEqual(r.svc.start({ language: 'en-US' }), { ok: true });
  const { cmd, args, o } = r.spawns[0];
  assert.equal(cmd, 'powershell.exe');
  assert.deepEqual(args, ['-NoProfile', '-NonInteractive', '-EncodedCommand', encoded()]);          // nothing but constants
  assert.equal(o.shell, false); assert.equal(o.windowsHide, true); assert.equal(o.env.LILMOON_LANG, 'en-US'); assert.equal(o.env.LILMOON_TIMEOUT, '8');
  assert.equal(Buffer.from(args[3], 'base64').toString('utf16le'), SCRIPT);
  assert.deepEqual(r.events.map((e) => e.state), ['starting']);
  r.line({ type: 'ready' }); assert.equal(r.svc.state(), 'listening');
  r.line({ type: 'partial', text: 'open' }); r.line({ type: 'partial', text: 'open chrome' });
  r.line({ type: 'final', text: ' open chrome ', confidence: 0.91 });
  assert.deepEqual(r.events.filter((e) => e.type !== 'state').map((e) => [e.type, e.text, e.confidence]), [['partial', 'open', undefined], ['partial', 'open chrome', undefined], ['final', 'open chrome', 0.91]]);
  assert.equal(r.svc.state(), 'idle'); assert.equal(r.kills.length, 1);
  r.line({ type: 'partial', text: 'late' });                                                    // ignored after the session ended
  assert.equal(r.events.filter((e) => e.type === 'partial').length, 2);
  assert.deepEqual(r.svc.start({ language: 'en-US' }), { ok: true });                           // a new press starts a new session
});

test('stop works at any moment and kills the recogniser immediately', () => {
  const r = rig(); r.svc.start({ language: 'en-US' }); r.line({ type: 'ready' });
  assert.equal(r.svc.start({ language: 'en-US' }).error.code, 'busy');
  r.svc.stop();
  assert.equal(r.kills.length, 1); assert.equal(r.svc.state(), 'idle');
  assert.ok(r.events.some((e) => e.type === 'stopped'));
  assert.deepEqual(r.svc.stop(), { ok: true });                                                 // stopping when idle is harmless
  const q = rig(); q.svc.start({ language: 'en-US' }); q.svc.stop(); assert.equal(q.kills.length, 1);  // also before "ready"
});

test('timeout, background noise, empty results and a hung session give friendly errors', () => {
  const cases = [[{ type: 'timeout' }, 'timeout', /didn't hear anything/], [{ type: 'rejected' }, 'noise', /background noise/], [{ type: 'final', text: '   ', confidence: 1 }, 'noise', /background noise/]];
  for (const [msg, code, re] of cases) { const r = rig(); r.svc.start({ language: 'en-US' }); r.line({ type: 'ready' }); r.line(msg); const e = r.events.find((x) => x.type === 'error'); assert.deepEqual([e.code, re.test(e.message), r.svc.state()], [code, true, 'idle']); }
  const h = rig(); h.svc.start({ language: 'en-US' }); h.timers[0].fn();                         // the 20 s safety limit fires
  assert.equal(h.events.find((x) => x.type === 'error').code, 'timeout'); assert.equal(h.kills.length, 1);
});

test('engine errors are mapped to guidance; unknown codes and garbage output are harmless', () => {
  for (const [code, re] of [['unsupported_language', /language/i], ['no_microphone', /No microphone/], ['microphone_error', /microphone stopped/], ['engine_unavailable', /type commands/]]) {
    const r = rig(); r.svc.start({ language: 'ta-IN' }); r.line({ type: 'error', code });
    const e = r.events.find((x) => x.type === 'error'); assert.equal(e.code, code); assert.match(e.message, re);
  }
  const g = rig(); g.svc.start({ language: 'en-US' });
  for (const junk of ['not json', '{"type":42}', '{"type":"evil","text":"x"}', 'null', '[]', '{"type":"error","code":"<script>"}']) g.line(junk);
  assert.equal(g.events.filter((e) => e.type === 'error').length, 1);                           // only the unknown code, mapped to the generic message
  assert.equal(g.events.find((e) => e.type === 'error').code, 'failed');
  const x = rig(); x.svc.start({ language: 'en-US' }); x.exit(); assert.equal(x.events.at(-1).code, 'failed');   // recogniser died without a result
  const s = rig(); s.svc.start({ language: 'en-US' }); s.proc().emit('error', new Error('ENOENT')); assert.equal(s.events.at(-1).code, 'engine_unavailable');
});

test('transcripts are length-limited and confidence is validated', () => {
  const r = rig(); r.svc.start({ language: 'en-US' }); r.line({ type: 'ready' });
  r.line({ type: 'final', text: 'a'.repeat(5000), confidence: 7 });
  const f = r.events.find((e) => e.type === 'final'); assert.deepEqual([f.text.length, f.confidence], [300, 0.5]);
});

test('the PowerShell script is fixed, offline, and cannot execute anything it hears', () => {
  for (const bad of [/Invoke-Expression/i, /\biex\b/i, /Invoke-Command/i, /Start-Process/i, /DownloadString/i, /WebClient/i, /Invoke-WebRequest/i, /-ExecutionPolicy/i, /Set-ExecutionPolicy/i, /\bcmd\b/i, /\.Text\s*\|/]) assert.doesNotMatch(SCRIPT, bad, String(bad));
  assert.match(SCRIPT, /System\.Speech/); assert.match(SCRIPT, /DictationGrammar/); assert.match(SCRIPT, /SetInputToDefaultAudioDevice/);
  assert.deepEqual([...new Set(SCRIPT.match(/\$env:[A-Z_]+/g))].sort(), ['$env:LILMOON_LANG', '$env:LILMOON_TIMEOUT']);
  assert.doesNotMatch(SCRIPT, /http/i);                                                          // no network access at all
});
