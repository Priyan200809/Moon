// Website tracker + idle monitor against a real SQLite database and a controllable clock.
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDatabase, createRepository, localDate } = require('../backend/database');
const { createTracker } = require('../backend/websiteTracker');
const { createIdleMonitor } = require('../backend/idleMonitor');

const T0 = new Date(2026, 9, 31, 10, 0, 0).getTime(); // 31 Oct 2026, 10:00 local

function rig({ start = T0, db = openDatabase(':memory:') } = {}) {
  const clock = { t: start };
  const repo = createRepository(db);
  const tracker = createTracker({ repo, now: () => clock.t });
  let seq = 0;
  let last = null;
  const install = 'install-abc12345';
  const send = (domain, paused, kind, s) => tracker.onBrowser({ installId: install, seq: s ?? seq++, kind, domain, paused, at: new Date(clock.t).toISOString(), browser: 'chrome' });
  const r = {
    clock, repo, db, tracker,
    // Time passes the way it does with a healthy extension: a heartbeat every 30 s. {silent:true} = the extension is gone.
    advance: (sec, { silent = false } = {}) => {
      let left = sec;
      while (left > 0) {
        const step = Math.min(30, left);
        clock.t += step * 1000; left -= step;
        if (last && !silent) send(last.domain, last.paused, 'heartbeat');
      }
    },
    report: (domain, { paused = false, kind = 'change', s } = {}) => { last = { domain, paused }; return send(domain, paused, kind, s); },
    rows: () => db.prepare("SELECT item_name, started_at, ended_at, duration_seconds, session_date FROM usage_sessions WHERE category = 'website' ORDER BY started_at").all(),
    total: (domain) => db.prepare("SELECT COALESCE(SUM(duration_seconds),0) n FROM usage_sessions WHERE category = 'website' AND item_name = ?").get(domain).n,
  };
  return r;
}

test('1. YouTube active for 10 minutes -> about 10 minutes, one row, category website', () => {
  const r = rig();
  r.report('youtube.com');
  r.advance(600);
  r.tracker.reconcile();
  r.tracker.shutdown();
  const rows = r.rows();
  assert.equal(rows.length, 1);
  assert.equal(rows[0].item_name, 'youtube.com');
  assert.equal(rows[0].duration_seconds, 600);
  assert.equal(rows[0].session_date, localDate(new Date(T0)));
});

test('2. YouTube -> Instagram ends one session and starts the next, with no overlap', () => {
  const r = rig();
  r.report('youtube.com'); r.advance(120);
  r.report('instagram.com'); r.advance(60);
  r.tracker.shutdown();
  const [a, b] = r.rows();
  assert.deepEqual([a.item_name, a.duration_seconds, b.item_name, b.duration_seconds], ['youtube.com', 120, 'instagram.com', 60]);
  assert.ok(a.ended_at <= b.started_at);
});

test('3/4/5. an untracked tab, another application, or a minimised browser (domain null) stops counting', () => {
  const r = rig();
  r.report('github.com'); r.advance(100);
  r.report(null); r.advance(500);            // switched tab / to VS Code / minimised
  r.report('github.com'); r.advance(50);     // back
  r.tracker.shutdown();
  assert.equal(r.total('github.com'), 150);
  assert.equal(r.rows().length, 2);
});

test('6/7. going idle stops usage at the last input; resuming activity restarts it', () => {
  const r = rig();
  r.report('reddit.com'); r.advance(30);
  // the person stopped 60 s ago and the monitor only noticed now: usage ends at the last input
  r.advance(60); r.tracker.onPresence('idle', r.clock.t - 60000);
  r.advance(300);                              // away
  r.tracker.onPresence('active', r.clock.t);
  r.advance(40);
  r.tracker.shutdown();
  const rows = r.rows();
  assert.deepEqual(rows.map((x) => x.duration_seconds), [30, 40]);
});

test('6b. lock and sleep behave like idle; idleness that began before the run leaves no row', () => {
  const r = rig();
  r.tracker.onPresence('locked'); r.advance(10);
  r.report('github.com'); r.advance(200);      // extension reports a site while locked: not counted
  assert.equal(r.rows().length, 0);
  r.tracker.onPresence('active'); r.advance(20);
  r.tracker.onPresence('suspended'); r.advance(1000);
  r.tracker.onPresence('active'); r.advance(5);
  r.tracker.shutdown();
  assert.deepEqual(r.rows().map((x) => x.duration_seconds), [20, 5]);

  const q = rig();
  q.report('github.com'); q.advance(5);
  q.tracker.onPresence('idle', q.clock.t - 60000); // idle began 55 s before this run started
  q.tracker.shutdown();
  assert.equal(q.rows().length, 0);
});

test('8. pausing in the extension counts nothing; resuming counts again', () => {
  const r = rig();
  r.report('youtube.com'); r.advance(60);
  r.report('youtube.com', { paused: true }); r.advance(600);
  r.report('youtube.com', { paused: false }); r.advance(30);
  r.tracker.shutdown();
  assert.deepEqual(r.rows().map((x) => x.duration_seconds), [60, 30]);
});

test('9. browser closed: the run ends at the last heartbeat, not minutes later', () => {
  const r = rig();
  r.report('youtube.com'); r.advance(60);          // heartbeats every 30 s; the last one arrives 60 s in
  r.advance(1800, { silent: true });                // Chrome was closed
  r.tracker.reconcile();
  assert.equal(r.total('youtube.com'), 60);
  assert.equal(r.tracker.status().connected, false);
  r.tracker.reconcile();
  assert.equal(r.total('youtube.com'), 60);
});

test('10. service-worker restart: repeated heartbeats and a re-sent report create no duplicates', () => {
  const r = rig();
  r.report('youtube.com', { s: 5 }); r.advance(30, { silent: true });
  assert.equal(r.report('youtube.com', { s: 5 }).accepted, false);            // retry of the same message
  r.report('youtube.com', { kind: 'heartbeat', s: 6 }); r.advance(30, { silent: true });
  r.report('youtube.com', { kind: 'heartbeat', s: 7 }); r.advance(30, { silent: true });
  r.tracker.shutdown();
  assert.equal(r.rows().length, 1);
  assert.equal(r.rows()[0].duration_seconds, 90);
  assert.equal(r.report('instagram.com', { s: 2 }).accepted, false);          // out-of-order older message is ignored
});

test('11. a message delayed by an outage cannot be back-dated before the last stored run', () => {
  const r = rig();
  r.report('youtube.com'); r.advance(100);
  r.report(null);                                  // run 1 = 100 s
  const end = r.rows()[0].ended_at;
  r.advance(300);
  // delayed delivery of a report that claims it happened 10 minutes ago
  r.tracker.onBrowser({ installId: 'install-abc12345', seq: 99, kind: 'change', domain: 'github.com', paused: false, at: new Date(r.clock.t - 600000).toISOString() });
  r.advance(20);
  r.tracker.shutdown();
  const rows = r.rows();
  assert.equal(rows.length, 2);
  assert.ok(rows[1].started_at >= end, 'second run starts at or after the first one ended');
  assert.equal(rows[1].duration_seconds, 20 + 300); // clamped to the last run end (earliest provable moment)
});

test('12/13. data survives a restart; a new tracker never overlaps stored runs; daily totals add up', () => {
  const db = openDatabase(':memory:');
  let r = rig({ db });
  r.report('github.com'); r.advance(300);
  r.tracker.shutdown();
  const storedEnd = r.rows()[0].ended_at;

  const restarted = rig({ start: T0 + 250 * 1000, db }); // restarted while the stored run already reaches T0+300 (clock skew)
  restarted.report('github.com'); restarted.advance(100);   // clock is now T0+350
  restarted.tracker.shutdown();
  const rows = restarted.rows();
  assert.equal(rows.length, 2);
  assert.ok(rows[1].started_at >= storedEnd);
  assert.equal(rows[1].duration_seconds, 50); // only the time after the stored run counts
  assert.equal(restarted.repo.websiteUsageForDate(localDate(new Date(T0)))[0].totalSeconds, 350);
});

test('13b. a run crossing local midnight is split into one row per calendar day', () => {
  const start = new Date(2026, 9, 31, 23, 50, 0).getTime();
  const r = rig({ start });
  r.report('youtube.com'); r.advance(1200);       // 20 minutes: 10 before midnight, 10 after
  r.tracker.shutdown();
  const rows = r.rows();
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.map((x) => [x.session_date, x.duration_seconds]), [['2026-10-31', 600], ['2026-11-01', 600]]);
  assert.equal(rows[0].ended_at, rows[1].started_at);
});

test('14. checkpoints extend a single row instead of adding rows', () => {
  const r = rig();
  r.report('youtube.com');
  r.advance(600); // 20 heartbeats
  assert.equal(r.rows().length, 1);
  assert.equal(r.rows()[0].duration_seconds, 600);
  assert.throws(() => r.repo.insertWebsiteRun({ domain: 'youtube.com', startedAt: r.rows()[0].started_at, endedAt: r.rows()[0].ended_at, durationSeconds: 600, sessionDate: '2026-10-31' }), 'unique index blocks an identical run');
});

test('sub-second flicks are not stored; durations are never negative', () => {
  const r = rig();
  r.report('youtube.com'); r.clock.t += 400; r.report(null);
  assert.equal(r.rows().length, 0);
  r.report('github.com'); r.advance(10); r.tracker.onPresence('idle', r.clock.t - 99999999);
  for (const row of r.rows()) assert.ok(row.duration_seconds >= 0);
});

test('idle monitor: threshold, back-dated idle start, lock, sleep, resume', () => {
  const events = [];
  const c = { t: T0, idle: 0, threshold: 60 };
  const m = createIdleMonitor({ getIdleSeconds: () => c.idle, getThresholdSeconds: () => c.threshold, now: () => c.t, onChange: (s, at) => events.push([s, at]) });
  c.idle = 59; m.poll(); assert.equal(m.state(), 'active');
  c.t += 1000; c.idle = 60; m.poll();
  assert.deepEqual(events.at(-1), ['idle', c.t - 60000]);
  c.idle = 0; c.t += 5000; m.poll(); assert.equal(events.at(-1)[0], 'active');
  m.lock(); assert.equal(m.state(), 'locked');
  c.idle = 500; m.unlock(); assert.equal(m.state(), 'idle');   // unlocked but nobody touched the machine yet
  c.idle = 0; m.poll(); assert.equal(m.state(), 'active');
  m.suspend(); assert.equal(m.state(), 'suspended');
  m.lock(); m.resume(); assert.equal(m.state(), 'locked');      // still locked after waking
  m.unlock(); assert.equal(m.state(), 'active');
  c.threshold = 600; c.idle = 100; m.poll(); assert.equal(m.state(), 'active'); // threshold is configurable
});

test('idle monitor attaches to a power monitor and detaches cleanly', () => {
  const EventEmitter = require('events');
  const pm = new EventEmitter();
  const seen = [];
  const m = createIdleMonitor({ getIdleSeconds: () => 0, getThresholdSeconds: () => 60, onChange: (s) => seen.push(s) });
  const detach = m.attach(pm);
  pm.emit('lock-screen'); pm.emit('unlock-screen'); pm.emit('suspend'); pm.emit('resume');
  assert.deepEqual(seen, ['locked', 'active', 'suspended', 'active']);
  detach();
  assert.equal(pm.listenerCount('lock-screen'), 0);
});

test('two browsers at once: the unfocused one reporting null every heartbeat does not cancel the focused one', () => {
  const r = rig();
  const send = (id, domain, seq, kind = 'heartbeat') => r.tracker.onBrowser({ installId: id, seq, kind, domain, paused: false, at: new Date(r.clock.t).toISOString(), browser: id.startsWith('edge') ? 'edge' : 'chrome' });
  send('chrome-install-1', null, 0, 'change'); send('edge-install-0001', 'youtube.com', 0, 'change');
  for (let i = 1; i <= 20; i++) { r.clock.t += 30000; send('chrome-install-1', null, i); send('edge-install-0001', 'youtube.com', i); }
  assert.equal(r.rows().length, 1);
  assert.equal(r.rows()[0].duration_seconds, 600);
  assert.equal(r.tracker.status().browser, 'edge');
  // focus moves to Chrome (Edge now reports null): the site changes hands without double counting
  r.clock.t += 30000; send('edge-install-0001', null, 21, 'change'); send('chrome-install-1', 'github.com', 21, 'change');
  r.clock.t += 30000; send('chrome-install-1', 'github.com', 22); send('edge-install-0001', null, 22);
  r.tracker.shutdown();
  assert.deepEqual(r.rows().map((x) => [x.item_name, x.duration_seconds]), [['youtube.com', 630], ['github.com', 30]]);
  // pausing only one of them does not stop the other
  const q = rig();
  const sq = (id, domain, paused, seq) => q.tracker.onBrowser({ installId: id, seq, kind: 'change', domain, paused, at: new Date(q.clock.t).toISOString() });
  sq('chrome-install-1', 'github.com', false, 0); q.advance(0);
  sq('edge-install-0001', null, true, 0);
  q.clock.t += 20000; sq('chrome-install-1', 'github.com', false, 1);
  assert.equal(q.tracker.status().paused, false);
  q.tracker.shutdown(); assert.equal(q.rows()[0].duration_seconds, 20);
});
