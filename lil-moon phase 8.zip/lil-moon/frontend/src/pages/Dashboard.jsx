import { useState } from 'react';
import Sidebar from '../components/Sidebar.jsx';
import Home from './Home.jsx';
import UsagePage from './UsagePage.jsx';
import VoicePage from './VoicePage.jsx';
import SettingsPage from './SettingsPage.jsx';
import AssistantPage from './AssistantPage.jsx';
import MemoryPage from './MemoryPage.jsx';
import FilesPage from './FilesPage.jsx';

export default function Dashboard() {
  const api = window.lilMoon?.dashboard;
  const [page, setPage] = useState('home');

  return (
    <div className="dash">
      <div className="titlebar">
        <strong>Lil Moon</strong>
        <div className="win-buttons">
          <button onClick={() => api?.minimize()} aria-label="Minimize dashboard">Minimize</button>
          <button onClick={() => api?.close()} aria-label="Close dashboard">Close</button>
          <button className="exit" onClick={() => api?.exitApp()} aria-label="Exit Lil Moon completely">Exit Lil Moon</button>
        </div>
      </div>
      <div className="shell">
        <Sidebar page={page} onNavigate={setPage} />
        <main className="content">
          {page === 'home' && <Home onNavigate={setPage} />}
          {page === 'apps' && <UsagePage kind="apps" />}
          {page === 'sites' && <UsagePage kind="sites" />}
          {page === 'voice' && <VoicePage />}
          {page === 'assistant' && <AssistantPage onNavigate={setPage} />}
          {page === 'memory' && <MemoryPage />}
          {page === 'files' && <FilesPage />}
          {page === 'settings' && <SettingsPage />}
        </main>
      </div>
    </div>
  );
}
