const $ = (id) => document.getElementById(id);
const fmt = (s) => { s = Math.round(s); if (s < 60) return `${s}s`; const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? `${h}h ${m}m` : `${m}m`; };
const WHY = {
  paused: 'Tracking is paused. Nothing is being counted.', not_paired: 'Not connected yet. Enter a pairing code from Lil Moon.',
  tracking_disabled: 'Website tracking is switched off in the Lil Moon dashboard.', window_not_focused: 'Chrome is not the focused window, so nothing is counted.',
  incognito: 'Incognito windows are never tracked.', idle: 'You are idle, so nothing is counted.', unsupported_page: 'This page cannot be tracked (browser or internal page).',
  not_tracked: 'This site is not on your tracked list, so nothing is recorded.', tracking: 'Counting time on this site.',
};

function render(s) {
  if (!s || s.error) { $('pill').textContent = 'Error'; $('pill').className = 'pill off'; return; }
  const idle = s.desktopIdle?.inactive;
  const pill = s.paused ? ['Paused', 'off'] : !s.paired ? ['Not connected', 'off'] : s.current && !idle ? ['Tracking', 'on'] : [idle ? 'Idle' : 'Waiting', ''];
  $('pill').textContent = pill[0]; $('pill').className = `pill ${pill[1]}`;
  $('current').textContent = s.current ? s.currentName : 'No tracked site';
  $('why').textContent = idle && s.current ? `Lil Moon says you are ${s.desktopIdle.reason}: time is not counted.` : WHY[s.reason] ?? '';
  $('today').textContent = s.paired ? fmt(s.todayWebsiteSeconds) : '-';
  const conn = !s.paired ? 'Not paired.' : !s.desktopOnline ? `Lil Moon is not reachable. ${s.buffered} finished session(s) are saved here and will be sent when it is back.` : !s.authOk ? s.lastError : `Connected. Last sync ${s.lastOkAt ? fmt((Date.now() - s.lastOkAt) / 1000) + ' ago' : 'just now'}.`;
  $('conn').textContent = s.dropped ? `${conn} ${s.dropped} old session(s) were dropped (buffer full).` : conn;
  $('pairForm').hidden = s.paired && s.authOk;
  $('pause').textContent = s.paused ? 'Resume tracking' : 'Pause tracking';
}

const send = (msg) => chrome.runtime.sendMessage(msg).then(render);
$('pause').addEventListener('click', () => send({ type: 'togglePause' }));
$('open').addEventListener('click', () => send({ type: 'openDashboard' }));
$('unpair').addEventListener('click', (e) => { e.preventDefault(); send({ type: 'unpair' }); });
$('pairForm').addEventListener('submit', (e) => { e.preventDefault(); send({ type: 'pair', code: $('code').value }); $('code').value = ''; });
send({ type: 'getStatus' });
setInterval(() => send({ type: 'getStatus' }), 2000);
