// Single owner of settings.json. Moon position and user preferences live side by side and never clobber each other.
const { app } = require('electron');
const fs = require('fs');
const path = require('path');

const THEMES = ['sunny', 'cream', 'lilac'];
const DEFAULTS = { defaultDailyLimitMin: 360, theme: 'sunny', startWithWindows: false };
const file = () => path.join(app.getPath('userData'), 'settings.json');

function read() {
  try {
    const s = JSON.parse(fs.readFileSync(file(), 'utf8'));
    return s && typeof s === 'object' && !Array.isArray(s) ? s : {};
  } catch {
    return {};
  }
}

function write(data) {
  const tmp = file() + '.tmp';
  fs.mkdirSync(path.dirname(tmp), { recursive: true });
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file());
}

// Throws a user-readable Error for anything outside the allowed shape (IPC input is untrusted).
function validate(p) {
  if (!p || typeof p !== 'object') throw new Error('Settings are invalid.');
  const m = p.defaultDailyLimitMin;
  if (!Number.isInteger(m) || m < 5 || m > 1440) throw new Error('Daily limit must be a whole number of minutes from 5 to 1440.');
  if (!THEMES.includes(p.theme)) throw new Error('Unknown theme.');
  if (typeof p.startWithWindows !== 'boolean') throw new Error('Startup preference must be on or off.');
  return { defaultDailyLimitMin: m, theme: p.theme, startWithWindows: p.startWithWindows };
}

module.exports = {
  getPreferences() {
    try { return validate({ ...DEFAULTS, ...read().preferences }); } catch { return { ...DEFAULTS }; }
  },
  savePreferences(p) {
    const v = validate(p);
    write({ ...read(), preferences: v });
    return v;
  },
  getMoon: () => read().moon,
  saveMoon: (moon) => write({ ...read(), moon }),
};
