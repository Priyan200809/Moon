// Automated smoke test, run with `npm run smoke` (two phases: persistence is checked across a restart).
// It drives the real windows and IPC; it cannot judge visuals or true Windows behaviour.
const { app, screen } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');

const phase = process.env.SMOKE_PHASE || '1';
const dir = process.env.SMOKE_DIR || fs.mkdtempSync(path.join(os.tmpdir(), 'lilmoon-'));
app.setPath('userData', dir);
require('../electron/main.js');
const wm = require('../electron/windowManager');

const results = [];
const check = (name, ok) => { results.push(ok); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}`); };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const errors = [];
const watch = (win, tag) => {
  win.webContents.on('console-message', (e) => { if (e.level === 'error') errors.push(`${tag}: ${e.message}`); });
  win.webContents.on('did-fail-load', (_e, c, d) => errors.push(`${tag}: load failed ${c} ${d}`));
};
const fire = (win, code) => win.webContents.executeJavaScript(code).catch(() => {}); // window may vanish mid-call
const ev = (win, code) => win.webContents.executeJavaScript(code);
const call = (win, method, p, body) => ev(win, `(async()=>{const c=await window.lilMoon.getApiConfig();const r=await fetch(c.baseUrl+${JSON.stringify(p)},{method:${JSON.stringify(method)},headers:{Authorization:'Bearer '+c.token,'Content-Type':'application/json'},body:${body === undefined ? 'undefined' : JSON.stringify(JSON.stringify(body))}});return {status:r.status,json:await r.json()}})()`);
const pointer = (type, x, y) =>
  `document.querySelector('.moon').dispatchEvent(new PointerEvent('${type}',{bubbles:true,button:0,pointerId:1,screenX:${x},screenY:${y}}))`;

app.whenReady().then(async () => {
  try {
    await wait(1500);
    const moon = wm.getMoon();
    watch(moon, 'moon');
    await moon.webContents.reload(); await wait(1000);
    const prefs = moon.webContents.getLastWebPreferences();
    check('moon window created, always on top', !!moon && moon.isAlwaysOnTop());
    check('security: contextIsolation, no nodeIntegration, sandbox',
      prefs.contextIsolation === true && prefs.nodeIntegration === false && prefs.sandbox === true);
    check('renderer sees only the lilMoon bridge (no require/process)',
      await ev(moon, `typeof window.lilMoon==='object' && typeof require==='undefined' && typeof process==='undefined'`));

    const wa = screen.getPrimaryDisplay().workArea;
    if (phase === '2') {
      const saved = JSON.parse(fs.readFileSync(path.join(dir, 'settings.json'), 'utf8')).moon;
      const [x, y] = moon.getPosition();
      check('moon position restored after restart', x === saved.x && y === saved.y);
      const d2 = wm.openDashboard(); watch(d2, 'dashboard'); await wait(2500);
      const st = (await call(d2, 'GET', '/api/settings')).json.data;
      check('settings persisted in SQLite across restart', st.dailyLimitSeconds === 5400 && st.theme === 'lilac');
      check('usage records persisted in SQLite across restart', (await call(d2, 'GET', '/api/usage/history')).json.data.total === 1);
      check('saved theme applied on launch', (await ev(d2, `document.documentElement.dataset.theme`)) === 'lilac');
    } else {
      const start = moon.getPosition();
      let cur = { x: start[0] + 50, y: start[1] + 50 };
      wm.__setCursor(() => cur);
      await ev(moon, pointer('pointerdown', 500, 500));
      cur = { x: cur.x - 200, y: cur.y - 150 };
      await ev(moon, pointer('pointermove', 300, 350));
      await wait(100);
      const moved = moon.getPosition();
      check('dragging moves the moon', moved[0] !== start[0] && moved[1] !== start[1]);
      await ev(moon, pointer('pointerup', 300, 350));
      await wait(200);
      check('dragging does not open the dashboard', wm.getDashboard() === null);
      const saved = JSON.parse(fs.readFileSync(path.join(dir, 'settings.json'), 'utf8')).moon;
      check('position saved to disk', saved.x === moved[0] && saved.y === moved[1]);

      cur = { x: -9000, y: -9000 };
      await ev(moon, pointer('pointerdown', 300, 350));
      await ev(moon, pointer('pointermove', 100, 100));
      await ev(moon, pointer('pointerup', 100, 100));
      await wait(100);
      const [ex, ey] = moon.getPosition();
      check('dragging off-screen is clamped into the work area',
        ex >= wa.x && ey >= wa.y && ex + wm.MOON <= wa.x + wa.width && ey + wm.MOON <= wa.y + wa.height);
      const [fx, fy] = moon.getPosition();
      const sf = path.join(dir, 'settings.json');
      fs.writeFileSync(sf, JSON.stringify({ ...JSON.parse(fs.readFileSync(sf, 'utf8')), moon: { x: fx, y: fy } }));

      for (let i = 0; i < 3; i++) {
        await ev(moon, pointer('pointerdown', 10, 10));
        await ev(moon, pointer('pointerup', 10, 10));
      }
      await wait(2500);
      const dash = wm.getDashboard();
      check('clicking the moon opens the dashboard', !!dash);
      check('repeated clicks create no duplicate dashboards', require('electron').BrowserWindow.getAllWindows().length === 2);
      watch(dash, 'dashboard');
      await dash.webContents.reload(); await wait(1200);
      const text = (sel) => ev(dash, `document.querySelector(${JSON.stringify(sel)})?.textContent ?? ''`);
      const nav = async (label) => { await ev(dash, `[...document.querySelectorAll('.nav-btn')].find(b=>b.textContent===${JSON.stringify(label)}).click()`); await wait(250); };
      const setInput = (sel, val) => ev(dash, `(()=>{const el=document.querySelector(${JSON.stringify(sel)});Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,${JSON.stringify(String(val))});el.dispatchEvent(new Event('input',{bubbles:true}));})()`);
      const click = (sel) => ev(dash, `document.querySelector(${JSON.stringify(sel)}).click()`);
      const body = () => ev(dash, `document.body.innerText`);
      check('database file created in the user-data folder', fs.existsSync(path.join(dir, 'lil-moon.db')));
      check('dashboard has 5 nav sections', (await ev(dash, `document.querySelectorAll('.nav-btn').length`)) === 5);
      await wait(600);
      let b = await body();
      check('home: branding, status, database connected, empty state', b.includes("Hi, I'm Lil Moon.") && b.includes('Assistant status') && b.includes('Connected') && b.includes('nothing recorded yet'));
      check('API health endpoint', (await call(dash, 'GET', '/api/health')).status === 200);
      check('API rejects a request without the token', (await ev(dash, `(async()=>{const c=await window.lilMoon.getApiConfig();return (await fetch(c.baseUrl+'/api/health')).status})()`)) === 401);
      check('moon window cannot obtain the API token', (await ev(moon, `window.lilMoon.getApiConfig().then(()=>'leak',()=>'rejected')`)) === 'rejected');
      check('default daily limit is 3 hours (10800 s)', (await call(dash, 'GET', '/api/settings')).json.data.dailyLimitSeconds === 10800);
      await nav('Settings');
      check('settings page shows the saved limit (180 min)', (await ev(dash, `document.querySelector('.field input').value`)) === '180');
      await setInput('.field input', 90); await click('.btn-strong'); await wait(700);
      check('changing the limit in the UI saves it to SQLite', (await call(dash, 'GET', '/api/settings')).json.data.dailyLimitSeconds === 5400 && (await body()).includes('Settings saved.'));
      check('API rejects an invalid limit with 400', (await call(dash, 'PUT', '/api/settings', { dailyLimitSeconds: 10 })).status === 400);
      await nav('Application usage');
      b = await body();
      check('application page: empty states, no sample data', b.includes('No application usage recorded today') && b.includes('No sessions saved yet') && !b.includes('Sample data'));
      await setInput('.test-form input', 'Test app'); await click('.test-form button'); await wait(900);
      b = await body();
      check('adding a session in the UI shows it in today and history', b.includes('Test app') && b.includes('10m') && (await call(dash, 'GET', '/api/usage/history')).json.data.total === 1);
      const bad = await call(dash, 'POST', '/api/usage/sessions', { category: 'application', itemName: 'x', startedAt: 'nope', endedAt: 'nope' });
      check('API rejects an invalid session with 400', bad.status === 400 && bad.json.ok === false);
      await nav('Website usage');
      check('website page: empty state', (await text('h1')) === 'Website usage' && (await body()).includes('No website usage recorded today'));
      await nav('Voice assistant');
      check('voice page is honest about being unimplemented', (await body()).includes('not built yet') && (await body()).includes('Not listening'));
      await call(dash, 'PUT', '/api/settings', { theme: 'lilac' });
      await dash.webContents.reload(); await wait(1500);
      check('saved theme is applied after reload', (await ev(dash, `document.documentElement.dataset.theme`)) === 'lilac');
      await ev(dash, `window.lilMoon.dashboard.minimize()`); await wait(400);
      check('dashboard minimize (needs a window manager, may fail under bare Xvfb)', dash.isMinimized());
      await ev(moon, pointer('pointerdown', 10, 10)); await ev(moon, pointer('pointerup', 10, 10)); await wait(400);
      check('clicking the moon restores a minimized dashboard', !dash.isMinimized());
      await fire(dash, `window.lilMoon.dashboard.close()`); await wait(500);
      check('closing dashboard keeps the moon alive', wm.getDashboard() === null && !moon.isDestroyed() && moon.isVisible());
      await ev(moon, pointer('pointerdown', 10, 10)); await ev(moon, pointer('pointerup', 10, 10)); await wait(2000);
      app.on('will-quit', () => {
        check('explicit Exit quits the app', true);
        check('no JavaScript errors in renderers', errors.length === 0);
        process.exit(results.every(Boolean) ? 0 : 1);
      });
      await fire(wm.getDashboard(), `window.lilMoon.dashboard.exitApp()`);
      await wait(3000);
      check('explicit Exit quits the app', false);
    }
    check('no JavaScript errors in renderers', errors.length === 0);
    if (errors.length) console.log(errors);
  } catch (err) {
    console.error(err); check('smoke run completed without exception', false);
  }
  process.exit(results.every(Boolean) ? 0 : 1);
});
