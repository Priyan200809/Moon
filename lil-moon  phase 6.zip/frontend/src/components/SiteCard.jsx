import ProgressBar from './ProgressBar.jsx';
import { fmtSec } from '../lib/format.js';

// Icons are drawn locally (a coloured letter). Fetching real favicons would tell a third party which sites you use.
const COLORS = ['#B98AFF', '#FFE500', '#7BF1A8', '#FF9EC4', '#8ED0FF', '#FFB56B'];
const colorFor = (s) => COLORS[[...s].reduce((n, c) => n + c.charCodeAt(0), 0) % COLORS.length];
export const SiteAvatar = ({ domain }) => <span className="avatar" style={{ background: colorFor(domain) }} aria-hidden="true">{domain[0].toUpperCase()}</span>;

export default function SiteCard({ site, limitSeconds, busy, onToggle, onRemove }) {
  const over = site.todaySeconds > limitSeconds;
  return (
    <li className={`usage-item site${site.isEnabled ? '' : ' site-off'}`}>
      <div className="usage-top">
        <div className="site-id">
          <SiteAvatar domain={site.domain} />
          <div>
            <h3>{site.displayName}</h3>
            <span className="domain">{site.domain}</span>
          </div>
        </div>
        <div className="site-flags">
          {site.isCounting && <span className="flag flag-live" role="status">Counting now</span>}
          {!site.isTracked && <span className="flag">Not on your list</span>}
          {site.isTracked && !site.isEnabled && <span className="flag">Off</span>}
          <span className={`flag${over ? ' flag-over' : ''}`}>{over ? `Over by ${fmtSec(site.todaySeconds - limitSeconds)}` : `${fmtSec(limitSeconds - site.todaySeconds)} left`}</span>
        </div>
      </div>
      <ProgressBar used={site.todaySeconds} limit={limitSeconds} label={`${site.displayName} usage today`} />
      <dl className="usage-stats">
        <div><dt>Time today</dt><dd>{fmtSec(site.todaySeconds)}</dd></div>
        <div><dt>Daily limit</dt><dd>{fmtSec(limitSeconds)}</dd></div>
        <div><dt>Remaining</dt><dd>{over ? '0s' : fmtSec(limitSeconds - site.todaySeconds)}</dd></div>
        <div><dt>Sessions</dt><dd>{site.sessionCount}</dd></div>
      </dl>
      {site.isTracked && (
        <div className="site-actions">
          <button className="btn btn-small" disabled={busy} onClick={() => onToggle(site)} aria-pressed={site.isEnabled}>{site.isEnabled ? 'Stop tracking' : 'Track again'}</button>
          <button className="btn btn-small" disabled={busy} onClick={() => onRemove(site)} aria-label={`Remove ${site.displayName} from the list`}>Remove from list</button>
        </div>
      )}
    </li>
  );
}
