// The command pipeline: normalise -> detect intent -> validate -> permission/confirmation check -> approved action -> response.
// One instance per app; it also owns the single pending question ("Which one?", "Open example.com?") and the last answer for "repeat that".
const crypto = require('crypto');
const { normalize } = require('./commandParser');
const { detect } = require('./intentDetector');
const { createVoiceHistoryService } = require('./voiceHistoryService');

const PENDING_TTL_MS = 60 * 1000;
const MIN_CONFIDENCE = 0.6; // below this, anything that DOES something (not just answers) is read back for confirmation
const READ_ONLY = new Set(['time', 'date', 'usage_target', 'limit_remaining', 'show_limits', 'show_usage', 'open_page', 'stop_listening', 'stop_speaking', 'clear_conversation', 'repeat', 'refused', 'unknown', 'confirm_yes', 'confirm_no', 'confirm_choice']);

function createVoiceService({ repo, executor, now = Date.now, log = console }) {
  const history = createVoiceHistoryService({ repo });
  let pending = null; // { id, kind, prompt, options:[{label, action}], expiresAt }
  let last = null;    // { text, speech } of the last real answer

  const publicPending = () => pending && { id: pending.id, kind: pending.kind, prompt: pending.prompt, options: pending.options.map((o) => o.label) };
  const withPending = (res) => (res.status === 'needs_confirmation' ? { ...res, confirmation: publicPending() } : res);

  function setPending(confirmation) {
    pending = { id: crypto.randomUUID(), kind: confirmation.kind, prompt: confirmation.prompt, options: confirmation.options, expiresAt: now() + PENDING_TTL_MS };
  }
  const live = () => { if (pending && pending.expiresAt <= now()) pending = null; return pending; };

  function finish(result, { text, intent, source }) {
    const res = { ...result, intent };
    if (res.status === 'needs_confirmation' && res.confirmation?.options?.length) setPending(res.confirmation);
    else if (res.status === 'needs_confirmation') res.status = 'executed'; // a plain clarification with nothing to choose
    const out = withPending(res);
    if (out.status !== 'unknown' && out.intent !== 'repeat' && out.text) last = { text: out.text, speech: out.speech ?? out.text };
    try { history.record({ text, intent, status: out.status, response: out.text, source }); } catch (err) { log.error('[lil-moon] could not save voice history:', err.message); }
    return out;
  }

  async function safeExecute(fn, intent) {
    try { return await fn(); } catch (err) {
      log.error('[lil-moon] voice command failed:', err.message);
      return { status: 'error', text: "Something went wrong while doing that, so I didn't do it. Lil Moon's data may be unavailable right now.", speech: 'Something went wrong.', intent };
    }
  }

  const service = {
    // text: what was recognised (or typed). confidence: recogniser confidence 0..1 (typed input is 1).
    async run(raw, { source = 'typed', confidence = 1 } = {}) {
      const settings = repo.getVoiceSettings();
      if (!settings.enabled) return { status: 'rejected', intent: 'disabled', text: 'The voice assistant is turned off. You can turn it on in Settings.', speech: '' };
      const n = normalize(raw);
      if (!n.ok) {
        const text = n.reason === 'too_long' ? 'That was too long for me to handle. Please say a shorter command.' : "I didn't catch anything. Please try again.";
        return finish({ status: 'unknown', text, speech: text }, { text: '', intent: 'unknown', source });
      }
      const intent = detect(n.text);

      // An answer to the question we asked a moment ago.
      const p = live();
      if (p && ['confirm_yes', 'confirm_no', 'confirm_choice'].includes(intent.name)) {
        const opts = p.options;
        if (intent.name === 'confirm_no') { pending = null; return finish({ status: 'cancelled', text: "Okay, I won't do that.", speech: "Okay, I won't." }, { text: n.text, intent: 'confirm_no', source }); }
        const pick = intent.name === 'confirm_choice' ? opts[intent.slots.index] : p.kind === 'yes_no' ? opts[0] : null;
        if (!pick) return finish({ status: 'needs_confirmation', text: p.kind === 'choose' ? `Please say which one: ${opts.map((o) => o.label).join(' or ')}.` : 'Please say yes or no.', speech: 'Please say which one.', confirmation: { kind: p.kind, prompt: p.prompt, options: opts } }, { text: n.text, intent: intent.name, source });
        pending = null;
        if (pick.action.type === 'rerun') return service.run(pick.action.text, { source: 'typed', confidence: 1 }); // the user has now agreed to what was heard
        const res = await safeExecute(() => executor.perform(pick.action), 'confirm');
        return finish(res, { text: n.text, intent: 'confirm', source });
      }
      pending = null; // any other request abandons the question without doing anything

      if (intent.name === 'repeat') {
        const res = last ? { status: 'executed', text: last.text, speech: last.speech } : { status: 'executed', text: "I haven't said anything yet.", speech: "I haven't said anything yet." };
        return finish(res, { text: n.text, intent: 'repeat', source });
      }
      if (['confirm_yes', 'confirm_no', 'confirm_choice'].includes(intent.name)) {
        return finish({ status: 'unknown', text: "I didn't ask you anything. " + 'Try "open Chrome" or "what time is it".', speech: "I didn't ask you anything." }, { text: '', intent: 'unknown', source });
      }

      // Display-before-acting: a doubtful recognition is read back, and nothing that does something happens until the user agrees.
      if (source === 'voice' && confidence < MIN_CONFIDENCE && !READ_ONLY.has(intent.name)) {
        const prompt = `I heard "${n.text}". Should I do that?`;
        return finish({ status: 'needs_confirmation', text: prompt, speech: prompt, confirmation: { kind: 'yes_no', prompt, options: [{ label: 'Yes, do it', action: { type: 'rerun', text: n.text } }] } }, { text: n.text, intent: intent.name, source });
      }

      const res = await safeExecute(() => executor.execute(intent), intent.name);
      return finish(res, { text: n.text, intent: intent.name, source });
    },

    // Button form of the same thing (choice: 'yes' | 'no' | option index).
    async confirm({ id, choice }) {
      const p = live();
      if (!p || p.id !== id) return { status: 'rejected', intent: 'confirm', text: 'That question has expired. Please ask again.', speech: '' };
      pending = null;
      if (choice === 'no') return finish({ status: 'cancelled', text: "Okay, I won't do that.", speech: "Okay, I won't." }, { text: 'no', intent: 'confirm_no', source: 'typed' });
      const pick = choice === 'yes' ? p.options[0] : p.options[choice];
      if (!pick) return finish({ status: 'rejected', text: 'That is not one of the options.', speech: '' }, { text: 'confirm', intent: 'confirm', source: 'typed' });
      if (pick.action.type === 'rerun') return service.run(pick.action.text, { source: 'typed', confidence: 1 }); // the user has now agreed to what was heard
      const res = await safeExecute(() => executor.perform(pick.action), 'confirm');
      return finish(res, { text: pick.label, intent: 'confirm', source: 'typed' });
    },

    pendingQuestion: () => publicPending(live()),
    history,
  };
  return service;
}

module.exports = { createVoiceService, MIN_CONFIDENCE };
