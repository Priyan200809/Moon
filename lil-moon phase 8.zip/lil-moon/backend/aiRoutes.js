// Dashboard-only routes for the assistant, memory and local files (mounted under /api, bearer-token protected).
const v = require('./validators');
const { HttpError } = v;
const { missingSetup } = require('./ai/providers');
const { memoryProblem } = require('./safety');

const ok = (res, data, status = 200) => res.status(status).json({ ok: true, data });

function mountAiRoutes(api, { services }) {
  const { aiRepo, files, tools, chat, keyStore } = services;
  const status = () => {
    const s = aiRepo.getAiSettings();
    const missing = missingSetup(s, keyStore.has());
    return { ...s, keyConfigured: keyStore.has(), keySource: keyStore.source(), configured: missing.length === 0, missing }; // the key itself is never returned
  };
  const convOr404 = (id) => { const c = aiRepo.getConversation(id); if (!c) throw new HttpError(404, 'not_found', 'No such conversation.'); return c; };

  // ---- provider setup (write-only key)
  api.get('/ai/status', (req, res) => ok(res, status()));
  api.put('/ai/settings', (req, res) => { aiRepo.updateAiSettings(v.aiSettingsPatch(req.body)); ok(res, status()); });
  api.put('/ai/key', (req, res) => { keyStore.set(v.apiKeyBody(req.body)); ok(res, status()); });
  api.delete('/ai/key', (req, res) => { keyStore.clear(); ok(res, status()); });

  // ---- conversations
  api.get('/ai/conversations', (req, res) => ok(res, aiRepo.listConversations(v.queryText(req.query.q))));
  api.post('/ai/conversations', (req, res) => ok(res, aiRepo.createConversation(v.optionalTitle(req.body)), 201));
  api.delete('/ai/conversations', (req, res) => ok(res, { deleted: aiRepo.deleteAllConversations() }));
  api.patch('/ai/conversations/:id', (req, res) => { const id = v.recordId(req.params.id); convOr404(id); ok(res, aiRepo.renameConversation(id, v.titleBody(req.body))); });
  api.delete('/ai/conversations/:id', (req, res) => { const id = v.recordId(req.params.id); if (!aiRepo.deleteConversation(id)) throw new HttpError(404, 'not_found', 'No such conversation.'); ok(res, { id }); });
  api.get('/ai/conversations/:id/messages', (req, res) => { const id = v.recordId(req.params.id); convOr404(id); ok(res, aiRepo.listMessages(id)); });

  api.delete('/ai/conversations/:id/messages', (req, res) => { const id = v.recordId(req.params.id); convOr404(id); ok(res, aiRepo.clearMessages(id)); });

  // streaming answer (Server-Sent Events). Closing the connection stops the provider request.
  api.post('/ai/conversations/:id/messages', async (req, res, next) => {
    let started = false;
    const emit = (ev) => { if (!res.writableEnded) res.write(`data: ${JSON.stringify(ev)}\n\n`); };
    try {
      const id = v.recordId(req.params.id);
      convOr404(id);
      const body = v.messageBody(req.body);
      res.status(200).set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
      res.flushHeaders();
      started = true;
      const ctl = new AbortController();
      res.on('close', () => { if (!res.writableEnded) ctl.abort(); });
      await chat.run({ conversationId: id, content: body.content, useFiles: body.useFiles, signal: ctl.signal, emit });
      res.end();
    } catch (err) {
      if (!started) return next(err);
      console.error('[lil-moon ai]', err);
      emit({ type: 'error', code: 'internal', message: 'Something went wrong while answering.' });
      res.end();
    }
  });
  api.post('/ai/tools/:id/confirm', (req, res) => {
    const approve = v.approveBody(req.body);
    if (!/^[0-9a-f-]{36}$/.test(req.params.id)) throw new HttpError(400, 'validation_error', 'Bad confirmation id.');
    const r = tools.resolve(req.params.id, approve);
    if (r.error === 'expired') throw new HttpError(410, 'expired', 'That request expired. Ask again.');
    ok(res, r);
  });
  api.get('/ai/tool-log', (req, res) => ok(res, aiRepo.listToolLog(v.limitQuery(req.query.limit, 50, 200))));
  api.delete('/ai/tool-log', (req, res) => ok(res, { deleted: aiRepo.clearToolLog() }));

  // ---- memory
  api.get('/ai/memories', (req, res) => {
    const category = req.query.category;
    if (category !== undefined && !v.CATS.includes(category)) throw new HttpError(400, 'validation_error', 'Unknown category.');
    ok(res, { memories: aiRepo.listMemories({ q: v.queryText(req.query.q), category }), candidates: aiRepo.listCandidates(), avoid: aiRepo.listAvoid() });
  });
  api.post('/ai/memories', (req, res) => {
    const b = v.memoryBody(req.body);
    if (memoryProblem(b.content)) throw new HttpError(422, 'sensitive_content', 'That looks like a password, key or other secret, so it was not saved.');
    ok(res, aiRepo.addMemory({ ...b, origin: 'user' }), 201);
  });
  api.patch('/ai/memories/:id', (req, res) => {
    const patch = v.memoryPatch(req.body);
    if (patch.content && memoryProblem(patch.content)) throw new HttpError(422, 'sensitive_content', 'That looks like a password, key or other secret, so it was not saved.');
    const row = aiRepo.updateMemory(v.recordId(req.params.id), patch);
    if (!row) throw new HttpError(404, 'not_found', 'No such memory.');
    ok(res, row);
  });
  api.delete('/ai/memories/:id', (req, res) => { const id = v.recordId(req.params.id); if (!aiRepo.deleteMemory(id)) throw new HttpError(404, 'not_found', 'No such memory.'); ok(res, { id }); });
  api.delete('/ai/memories', (req, res) => ok(res, { deleted: aiRepo.clearMemories() }));
  api.post('/ai/memory-candidates/:id/accept', (req, res) => {
    const c = aiRepo.getCandidate(v.recordId(req.params.id));
    if (!c) throw new HttpError(404, 'not_found', 'No such suggestion.');
    if (memoryProblem(c.content)) { aiRepo.deleteCandidate(c.id); throw new HttpError(422, 'sensitive_content', 'That looks like a secret, so it was not saved.'); }
    const m = aiRepo.tx(() => { aiRepo.deleteCandidate(c.id); return aiRepo.addMemory({ category: c.category, content: c.content, origin: 'confirmed', sourceConversationId: c.conversationId }); });
    ok(res, m, 201);
  });
  api.post('/ai/memory-candidates/:id/dismiss', (req, res) => {
    const id = v.recordId(req.params.id);
    const c = aiRepo.getCandidate(id);
    if (!c) throw new HttpError(404, 'not_found', 'No such suggestion.');
    aiRepo.deleteCandidate(id);
    if (req.body?.never === true) aiRepo.addAvoid(c.content.slice(0, 200)); // "never suggest this again"
    ok(res, { id });
  });
  api.post('/ai/memory-avoid', (req, res) => ok(res, aiRepo.addAvoid(v.avoidBody(req.body)), 201));
  api.delete('/ai/memory-avoid/:id', (req, res) => { const id = v.recordId(req.params.id); if (!aiRepo.removeAvoid(id)) throw new HttpError(404, 'not_found', 'No such entry.'); ok(res, { id }); });

  // ---- local files
  api.get('/files/status', (req, res) => ok(res, files.status()));
  api.post('/files/folders', async (req, res) => { const f = await files.addFolder(); ok(res, f ? { folder: f } : { cancelled: true }, f ? 201 : 200); }); // native dialog; no path accepted from the page
  api.delete('/files/folders/:id', (req, res) => { const id = v.recordId(req.params.id); if (!files.removeFolder(id)) throw new HttpError(404, 'not_found', 'No such folder.'); ok(res, { id }); });
  api.post('/files/folders/:id/reindex', (req, res) => { const id = v.recordId(req.params.id); if (!files.reindex(id)) throw new HttpError(404, 'not_found', 'No such folder.'); ok(res, { started: true }, 202); });
  api.get('/files/search', (req, res) => ok(res, files.search(v.queryText(req.query.q, 'q', false), v.limitQuery(req.query.limit, 20, 50))));
  api.post('/files/:id/open', (req, res) => ok(res, files.openFile(v.recordId(req.params.id))));
}

module.exports = { mountAiRoutes };
