// Turns browser-extension segments into usage_sessions rows. Every step is parameterized SQL.
// Pipeline per segment: dedupe by client id -> match configured site -> trim idle/locked/asleep time ->
// remove time already covered by any website session -> split at local midnight -> merge into the previous row or insert.
const { matchTracked } = require('./domain');
const { subtract, splitAtLocalMidnight } = require('./intervals');

const MAX_AGE_MS = 35 * 24 * 3600 * 1000;
const FUTURE_SLACK_MS = 5 * 60 * 1000;
const MERGE_GAP_MS = 2000;
const pad = (n) => String(n).padStart(2, '0');
const localDate = (ms) => { const d = new Date(ms); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };

function ingestSegments(db, segments, { sites, activity, nowMs }) {
  const result = { accepted: [], duplicates: [], rejected: [] };
  const seen = db.prepare('SELECT 1 FROM ingest_log WHERE client_id = ?');
  const covered = db.prepare("SELECT started_at, ended_at FROM usage_sessions WHERE category = 'website' AND ended_at > ? AND started_at < ? ORDER BY started_at");
  const latest = db.prepare("SELECT id, item_name, started_at, ended_at, session_date FROM usage_sessions WHERE category = 'website' ORDER BY ended_at DESC, id DESC LIMIT 1");
  const extend = db.prepare('UPDATE usage_sessions SET ended_at = ?, duration_seconds = ? WHERE id = ?');
  const insert = db.prepare("INSERT INTO usage_sessions (category, item_name, started_at, ended_at, duration_seconds, session_date) VALUES ('website', ?, ?, ?, ?, ?)");
  const log = db.prepare('INSERT INTO ingest_log (client_id, received_at) VALUES (?, ?)');

  for (const seg of segments) {
    if (seen.get(seg.clientId)) { result.duplicates.push(seg.clientId); continue; }
    const site = matchTracked(seg.hostname, sites);
    if (!site) { result.rejected.push({ clientId: seg.clientId, reason: 'not_tracked' }); continue; }
    const s = Date.parse(seg.startedAt), e = Date.parse(seg.endedAt);
    if (e > nowMs + FUTURE_SLACK_MS) { result.rejected.push({ clientId: seg.clientId, reason: 'in_future' }); continue; }
    if (s < nowMs - MAX_AGE_MS) { result.rejected.push({ clientId: seg.clientId, reason: 'too_old' }); continue; }

    db.exec('BEGIN');
    try {
      let pieces = subtract([[s, e]], activity ? activity.inactiveBetween(s, e) : []);
      const existing = covered.all(new Date(s).toISOString(), new Date(e).toISOString()).map((r) => [Date.parse(r.started_at), Date.parse(r.ended_at)]);
      pieces = subtract(pieces, existing).flatMap(splitAtLocalMidnight).filter(([a, b]) => b - a >= 1000);
      for (const [a, b] of pieces) {
        const prev = latest.get();
        const date = localDate(a);
        if (prev && prev.item_name === site.domain && prev.session_date === date) {
          const gap = a - Date.parse(prev.ended_at);
          const total = Math.round((b - Date.parse(prev.started_at)) / 1000);
          if (gap >= 0 && gap <= MERGE_GAP_MS && total <= 86400) { extend.run(new Date(b).toISOString(), total, prev.id); continue; }
        }
        insert.run(site.domain, new Date(a).toISOString(), new Date(b).toISOString(), Math.max(1, Math.round((b - a) / 1000)), date);
      }
      log.run(seg.clientId, new Date(nowMs).toISOString());
      db.exec('COMMIT');
      result.accepted.push(seg.clientId);
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  }
  return result;
}

module.exports = { ingestSegments };
