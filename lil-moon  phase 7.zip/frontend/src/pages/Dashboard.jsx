import { useEffect, useState } from 'react';
import Sidebar from '../components/Sidebar.jsx';
import Home from './Home.jsx';
import UsagePage from './UsagePage.jsx';
import WebsitesPage from './WebsitesPage.jsx';
import LimitsPage from './LimitsPage.jsx';
import VoicePage from './VoicePage.jsx';
import SettingsPage from './SettingsPage.jsx';

export default function Dashboard() {
  const api = window.lilMoon?.dashboard;
  const [page, setPage] = useState('home');
  const [activation, setActivation] = useState(0);

  // "Talk to Lil Moon" (moon menu): open the Voice page and let it start one listening session. takeActivation() makes it happen once.
  useEffect(() => {
    const v = window.lilMoon?.voice;
    if (!v) return undefined;
    const take = async () => { if (await v.takeActivation()) { setPage('voice'); setActivation((n) => n + 1); } };
    take();
    return v.onActivate(take);
  }, []);

  return (
    <div className="dash">
      <div className="titlebar">
        <strong>Lil Moon</strong>
        <div className="win-buttons">
          <button onClick={() => api?.minimize()} aria-label="Minimize dashboard">Minimize</button>
          <button onClick={() => api?.close()} aria-label="Close dashboard">Close</button>
          <button className="exit" onClick={() => api?.exitApp()} aria-label="Exit Lil Moon completely">Exit Lil Moon</button>
        </div>
      </div>
      <div className="shell">
        <Sidebar page={page} onNavigate={setPage} />
        <main className="content">
          {page === 'home' && <Home onNavigate={setPage} />}
          {page === 'apps' && <UsagePage kind="apps" />}
          {page === 'sites' && <WebsitesPage />}
          {page === 'limits' && <LimitsPage />}
          {page === 'voice' && <VoicePage onNavigate={setPage} activation={activation} />}
          {page === 'settings' && <SettingsPage />}
        </main>
      </div>
    </div>
  );
}
