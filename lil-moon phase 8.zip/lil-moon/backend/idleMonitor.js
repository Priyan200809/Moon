// The ONE idle/lock/sleep detector for Lil Moon. It records inactive intervals; the website ingest trims
// reported browser sessions against them, so it does not matter how late the browser extension reports.
// Inputs are injected so it can be tested without Electron. "Idle" starts when the threshold is crossed
// (last input + threshold): the quiet time before that still counts as use (reading, watching a video).
const { merge } = require('./intervals');

const KEEP_MS = 48 * 3600 * 1000;

function createIdleMonitor({ getIdleSeconds, getThresholdSeconds, now = Date.now }) {
  const closed = []; // [startMs, endMs, reason]
  const open = new Map(); // reason -> startMs

  const begin = (reason, at) => { if (!open.has(reason)) open.set(reason, at); };
  const end = (reason, at) => {
    if (!open.has(reason)) return;
    const start = open.get(reason);
    open.delete(reason);
    if (at > start) closed.push([start, at, reason]);
  };

  return {
    tick() {
      const t = now();
      const idle = getIdleSeconds();
      const threshold = getThresholdSeconds();
      if (idle >= threshold) begin('idle', t - (idle - threshold) * 1000);
      else end('idle', t - idle * 1000);
      const cutoff = t - KEEP_MS;
      while (closed.length && closed[0][1] < cutoff) closed.shift();
    },
    lock: () => begin('locked', now()),
    unlock: () => end('locked', now()),
    suspend: () => begin('sleeping', now()),
    resume: () => end('sleeping', now()),
    state() {
      const reasons = [...open.keys()];
      const reason = ['sleeping', 'locked', 'idle'].find((r) => reasons.includes(r)) ?? null;
      return { inactive: reason !== null, reason, since: reason ? open.get(reason) : null };
    },
    inactiveBetween(fromMs, toMs) {
      const t = now();
      const all = [...closed.map(([s, e]) => [s, e]), ...[...open.values()].map((s) => [s, t])];
      return merge(all.filter(([s, e]) => e > fromMs && s < toMs));
    },
  };
}

module.exports = { createIdleMonitor };
