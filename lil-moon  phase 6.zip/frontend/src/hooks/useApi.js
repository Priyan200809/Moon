import { useCallback, useEffect, useState } from 'react';
import { api } from '../lib/api.js';

// GET a path; exposes {status, data, error, reload, refreshedAt, refreshError}. Keeps old data visible while reloading.
// With { intervalMs } it also refreshes quietly in the background (paused while the window is hidden).
export function useApi(path, { intervalMs } = {}) {
  const [state, setState] = useState({ status: 'loading', data: null, error: '', refreshedAt: null, refreshError: '' });
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let live = true;
    setState((s) => ({ ...s, status: 'loading', error: '' }));
    api('GET', path)
      .then((data) => live && setState({ status: 'ready', data, error: '', refreshedAt: Date.now(), refreshError: '' }))
      .catch((e) => live && setState({ status: 'error', data: null, error: e.message, refreshedAt: null, refreshError: '' }));
    return () => { live = false; };
  }, [path, tick]);
  useEffect(() => {
    if (!intervalMs) return undefined;
    let live = true;
    const id = setInterval(() => {
      if (document.hidden) return;
      api('GET', path)
        .then((data) => live && setState({ status: 'ready', data, error: '', refreshedAt: Date.now(), refreshError: '' }))
        .catch((e) => live && setState((s) => ({ ...s, refreshError: e.message })));
    }, intervalMs);
    return () => { live = false; clearInterval(id); };
  }, [path, intervalMs]);
  const reload = useCallback(() => setTick((n) => n + 1), []);
  return { ...state, reload };
}
