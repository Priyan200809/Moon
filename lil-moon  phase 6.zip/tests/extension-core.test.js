// The extension's core logic (lib/core.js + lib/domain.js) driven against the REAL desktop backend over real HTTP.
// Only the `chrome` browser API is simulated. This is NOT a test inside a real browser; see docs/WEBSITE_TRACKING.md for that checklist.
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer, EXT_PORTS } = require('../backend/server');
const { createTracker } = require('../backend/websiteTracker');
const Core = require('../extension/lib/core.js');
const Domain = require('../extension/lib/domain.js');

const clock = { t: new Date(2026, 9, 31, 12, 0, 0).getTime() };
const URLS = { yt: 'https://www.youtube.com/watch?v=SECRETID&list=abc#t=5', ig: 'https://www.instagram.com/direct/inbox/?token=zzz', gh: 'https://github.com/org/private-repo/issues?q=salary', other: 'https://news.example.org/story', internal: 'chrome://settings/passwords', ext: 'chrome-extension://abcdefghijklmnopabcdefghijklmnop/page.html' };

function mockChrome() {
  const store = {};
  const win = { focused: true, state: 'normal', incognito: false, tabs: [{ active: true, incognito: false, url: URLS.yt }, { active: false, incognito: false, url: URLS.gh }] };
  return {
    store, win,
    storage: { local: {
      get: async (keys) => Object.fromEntries(keys.filter((k) => k in store).map((k) => [k, structuredClone(store[k])])),
      set: async (o) => { Object.assign(store, structuredClone(o)); },
    }, session: { get: async () => ({}), set: async () => {}, remove: async () => {} } },
    windows: { getLastFocused: async () => structuredClone(win) },
    show: (url, over = {}) => { win.tabs = [{ active: true, incognito: !!over.tabIncognito, url }, { active: false, incognito: false, url: URLS.gh }]; Object.assign(win, { focused: true, state: 'normal', incognito: false }, over); },
  };
}

const open = [];
test.afterEach(async () => { while (open.length) await open.pop()().catch(() => {}); }); // a failing test must not leave its server on the shared port

async function world({ ports = EXT_PORTS, db = openDatabase(':memory:') } = {}) {
  const repo = createRepository(db);
  const tracker = createTracker({ repo, now: () => clock.t });
  const api = await startServer({ repo, allowedOrigins: ['null'], tracker, now: () => clock.t, ports });
  const sent = [];
  const fetchFn = async (url, init) => { if (init?.body) sent.push(init.body); return fetch(url, init); };
  const chrome = mockChrome();
  const mk = () => Core.createAgent({ chrome, fetchFn, domainLib: Domain, uuid: () => 'install-test-0001', now: () => clock.t });
  const rows = () => db.prepare("SELECT item_name, duration_seconds FROM usage_sessions WHERE category = 'website' ORDER BY started_at").all().map((r) => ({ ...r }));
  const w = { db, repo, tracker, api, chrome, mk, sent, rows, code: repo.getExtensionToken() };
  let stopped = false;
  w.stop = async () => { if (stopped) return; stopped = true; await w.api.close().catch(() => {}); try { db.close(); } catch { /* closed */ } };
  open.push(w.stop);
  return w;
}
const pass = async (w, agent, sec) => { for (let left = sec; left > 0; left -= 30) { clock.t += Math.min(30, left) * 1000; await agent.heartbeat(); } };

test('pairing: wrong code refused, right code connects and loads the site list', async () => {
  const w = await world(); const a = w.mk();
  await assert.rejects(a.pair('nope'), { code: 'bad_code' });
  await assert.rejects(a.pair('0'.repeat(48)), { code: 'unauthorized' });
  assert.equal((await a.status()).paired, false);
  await a.pair(w.code);
  const s = await a.status();
  assert.equal(s.paired, true); assert.equal(s.connection.ok, true); assert.equal(s.trackedCount, 5);
  await w.stop();
});

test('open YouTube for 10 minutes, then switch to Instagram, another tab, VS Code (focus lost), minimise', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  w.chrome.show(URLS.yt); await a.sync();
  await pass(w, a, 600);
  w.chrome.show(URLS.ig); await a.sync();                 // YouTube -> Instagram
  await pass(w, a, 120);
  w.chrome.show(URLS.other); await a.sync();               // an unlisted tab
  await pass(w, a, 300);
  w.chrome.show(URLS.gh); await a.sync(); await pass(w, a, 60);
  w.chrome.win.focused = false; await a.sync();            // Chrome -> VS Code
  await pass(w, a, 300);
  w.chrome.show(URLS.gh); await a.sync(); await pass(w, a, 30);
  w.chrome.win.state = 'minimized'; await a.sync();        // minimise
  await pass(w, a, 300);
  assert.deepEqual(w.rows(), [
    { item_name: 'youtube.com', duration_seconds: 600 }, { item_name: 'instagram.com', duration_seconds: 120 },
    { item_name: 'github.com', duration_seconds: 60 }, { item_name: 'github.com', duration_seconds: 30 },
  ]);
  await w.stop();
});

test('background tabs never count: the listed site is open but another tab is active', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  w.chrome.show(URLS.other); await a.sync(); await pass(w, a, 300); // github is open in a background tab the whole time
  assert.deepEqual(w.rows(), []);
  await w.stop();
});

test('pause and resume in the extension; incognito and internal pages are never reported', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  w.chrome.show(URLS.yt); await a.sync(); await pass(w, a, 60);
  await a.setPaused(true); await pass(w, a, 600);
  assert.equal((await a.status()).paused, true);
  await a.setPaused(false); await pass(w, a, 30);
  assert.deepEqual(w.rows().map((r) => r.duration_seconds), [60, 30]);

  const before = w.rows().length;
  w.chrome.show(URLS.yt, { incognito: true }); await a.sync(); await pass(w, a, 120);
  w.chrome.show(URLS.yt, { tabIncognito: true }); await a.sync(); await pass(w, a, 120);
  for (const u of [URLS.internal, URLS.ext, 'about:blank', 'file:///C:/secret.txt', 'view-source:https://youtube.com']) { w.chrome.show(u); await a.sync(); await pass(w, a, 60); }
  assert.equal(w.rows().length, before);
  assert.equal(w.rows().at(-1).duration_seconds, 30);
  await w.stop();
});

test('service-worker restart: a new agent over the same storage continues without duplicates', async () => {
  const w = await world(); let a = w.mk(); await a.pair(w.code);
  w.chrome.show(URLS.yt); await a.sync(); await pass(w, a, 120);
  a = w.mk();                                   // worker killed and restarted: all in-memory state gone
  await a.sync(); await a.sync();               // wake-up events with unchanged state send nothing new
  await pass(w, a, 120);
  assert.deepEqual(w.rows(), [{ item_name: 'youtube.com', duration_seconds: 240 }]);
  await w.stop();
});

test('disconnect and reconnect: reports queue while the desktop app is down, flush in order, no duplicate rows', async () => {
  const db = openDatabase(':memory:');
  let w = await world({ db }); const a = w.mk(); await a.pair(w.code);
  w.chrome.show(URLS.yt); await a.sync(); await pass(w, a, 60);
  await w.api.close();                          // desktop app quits (the database file would persist; here the handle is reused)
  clock.t += 5000; w.chrome.show(URLS.gh); await a.sync();
  clock.t += 30000; await a.heartbeat();
  let s = await a.status();
  assert.equal(s.connection.ok, false); assert.ok(s.queued >= 1 && s.queued <= 3);
  const api2 = await startServer({ repo: w.repo, allowedOrigins: ['null'], tracker: w.tracker, now: () => clock.t, ports: EXT_PORTS });
  w.api = api2;
  await pass(w, a, 60);
  s = await a.status();
  assert.equal(s.connection.ok, true); assert.equal(s.queued, 0);
  const rows = w.rows();
  assert.equal(rows[0].item_name, 'youtube.com');
  assert.equal(rows.filter((r) => r.item_name === 'github.com').length, 1);
  const spans = db.prepare("SELECT started_at, ended_at FROM usage_sessions WHERE category = 'website' ORDER BY started_at").all();
  for (let i = 1; i < spans.length; i++) assert.ok(spans[i].started_at >= spans[i - 1].ended_at, 'no overlap');
  await api2.close(); db.close();
});

test('privacy: only a listed domain, a flag and counters ever leave the extension (never URLs, paths, queries, titles)', async () => {
  const w = await world(); const a = w.mk(); await a.pair(w.code);
  for (const u of [URLS.yt, URLS.ig, URLS.gh, URLS.other, URLS.internal]) { w.chrome.show(u); await a.sync(); await pass(w, a, 30); }
  assert.ok(w.sent.length > 5);
  for (const body of w.sent) {
    const m = JSON.parse(body);
    assert.deepEqual(Object.keys(m).sort(), ['at', 'browser', 'domain', 'installId', 'kind', 'paused', 'seq']);
    assert.ok(m.domain === null || ['youtube.com', 'instagram.com', 'github.com'].includes(m.domain));
    assert.doesNotMatch(body, /SECRETID|private-repo|salary|token=|inbox|news\.example|passwords|\/watch|https?:/);
  }
  await w.stop();
});

test('port discovery: finds the app on a later port in the list; a different service on a port is ignored', async () => {
  const http = require('http');
  const decoy = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end('<h1>not lil moon</h1>'); });
  await new Promise((r) => decoy.listen(EXT_PORTS[0], '127.0.0.1', r)).catch(() => {});
  const w = await world({ ports: EXT_PORTS });
  const a = w.mk(); await a.pair(w.code);
  assert.equal((await a.status()).connection.ok, true);
  assert.ok((await a.status()).port >= EXT_PORTS[0]);
  await w.stop(); decoy.close();
});

test('domain matching never merges look-alike domains', () => {
  const cfg = { domains: ['youtube.com', 'github.com'], aliases: { 'youtu.be': 'youtube.com' } };
  const t = (u) => Domain.trackedDomainForUrl(u, cfg);
  assert.equal(t('https://www.youtube.com/'), 'youtube.com');
  assert.equal(t('https://m.youtube.com/'), 'youtube.com');
  assert.equal(t('https://music.youtube.com/'), 'youtube.com');
  assert.equal(t('https://youtu.be/abc'), 'youtube.com');
  for (const bad of ['https://notyoutube.com/', 'https://youtube.com.evil.example/', 'https://evil-github.com/', 'https://github.com.cn/', 'https://myyoutube.com/', 'http://127.0.0.1:8080/', 'ftp://youtube.com/', 'javascript:alert(1)', '', null, 5]) assert.equal(t(bad), null, String(bad));
});
