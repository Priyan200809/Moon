// The extension-facing HTTP surface and the website management API, against the real server and database.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer } = require('../backend/server');
const { createTracker } = require('../backend/websiteTracker');

const DASH = 'dash-token';
const EXT_ORIGIN = 'chrome-extension://abcdefghijklmnopabcdefghijklmnop';
const clock = { t: Date.now() };

async function boot(file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lm-ext-')), 'lil-moon.db')) {
  const db = openDatabase(file);
  const repo = createRepository(db);
  const tracker = createTracker({ repo, now: () => clock.t });
  let opened = 0;
  const api = await startServer({ repo, allowedOrigins: ['null'], token: DASH, tracker, now: () => clock.t, hooks: { openDashboard: () => { opened++; } } });
  const pairing = repo.getExtensionToken();
  const req = async (method, p, { token, origin, body, headers } = {}) => {
    const res = await fetch(api.baseUrl + p, {
      method,
      headers: { ...(token && { Authorization: `Bearer ${token}` }), ...(origin && { Origin: origin }), ...(body !== undefined && { 'Content-Type': 'application/json' }), ...headers },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    return { status: res.status, json: await res.json().catch(() => null), headers: res.headers };
  };
  const ext = (method, p, body, o = {}) => req(method, p, { token: pairing, origin: EXT_ORIGIN, body, ...o });
  const dash = (method, p, body) => req(method, p, { token: DASH, origin: 'null', body });
  return { db, repo, tracker, api, pairing, ext, dash, req, opened: () => opened, file, stop: async () => { await api.close(); db.close(); } };
}
let seq = 0;
const activity = (o = {}) => ({ installId: 'install-12345678', seq: seq++, kind: 'change', domain: 'youtube.com', paused: false, at: new Date(clock.t).toISOString(), browser: 'chrome', ...o });

test('pairing: /ext needs the extension token and an extension origin; the dashboard token does not open it, and vice versa', async () => {
  const t = await boot();
  assert.equal((await t.ext('GET', '/ext/ping')).status, 200);
  assert.equal((await t.req('GET', '/ext/ping', { origin: EXT_ORIGIN })).status, 401);                        // no token
  assert.equal((await t.req('GET', '/ext/ping', { token: DASH, origin: EXT_ORIGIN })).status, 401);          // dashboard token is not a pairing code
  assert.equal((await t.req('GET', '/api/health', { token: t.pairing, origin: 'null' })).status, 401);       // pairing code cannot read the dashboard API
  assert.equal((await t.ext('GET', '/ext/ping', undefined, { origin: 'https://evil.example' })).status, 403); // web pages are refused
  assert.equal((await t.ext('GET', '/ext/ping', undefined, { origin: 'chrome-extension://short' })).status, 403);
  assert.equal((await t.req('GET', '/api/health', { token: DASH, origin: EXT_ORIGIN })).status, 403);        // an extension origin cannot use /api
  const rawHost = await new Promise((resolve, reject) => { // fetch cannot forge Host; a raw request can (DNS-rebinding style)
    http.get({ host: '127.0.0.1', port: t.api.port, path: '/ext/ping', headers: { Host: 'evil.example', Authorization: `Bearer ${t.pairing}`, Origin: EXT_ORIGIN } }, (res) => { res.resume(); resolve(res.statusCode); }).on('error', reject);
  });
  assert.equal(rawHost, 403);
  const pre = await t.req('OPTIONS', '/ext/activity', { origin: EXT_ORIGIN });
  assert.equal(pre.status, 204);
  assert.equal(pre.headers.get('access-control-allow-origin'), EXT_ORIGIN);
  assert.equal((await t.ext('POST', '/ext/activity', undefined, { headers: { 'Content-Type': 'text/plain' } })).status === 200, false);
  await t.stop();
});

test('rotating the pairing code locks the old one out immediately', async () => {
  const t = await boot();
  const before = (await t.dash('GET', '/api/websites/extension')).json.data;
  assert.equal(before.pairingCode, t.pairing);
  assert.ok(before.probedPorts.includes(47615));
  const after = (await t.dash('POST', '/api/websites/extension/rotate', {})).json.data;
  assert.notEqual(after.pairingCode, before.pairingCode);
  assert.equal((await t.ext('GET', '/ext/ping')).status, 401);
  assert.equal((await t.ext('GET', '/ext/ping', undefined, { token: after.pairingCode })).status, 200);
  await t.stop();
});

test('config served to the extension: enabled domains only, aliases, idle threshold', async () => {
  const t = await boot();
  const w = (await t.dash('GET', '/api/websites')).json.data.find((x) => x.domain === 'reddit.com');
  await t.dash('PUT', `/api/websites/${w.id}`, { isEnabled: false });
  await t.dash('PUT', '/api/settings', { idleThresholdSeconds: 90 });
  const c = (await t.ext('GET', '/ext/config')).json.data;
  assert.deepEqual(c.domains.sort(), ['github.com', 'instagram.com', 'linkedin.com', 'youtube.com']);
  assert.equal(c.aliases['youtu.be'], 'youtube.com');
  assert.equal(c.idleThresholdSeconds, 90);
  assert.ok(c.stripPrefixes.includes('www'));
  await t.stop();
});

test('activity: validated strictly; a domain not on the list is stored as nothing', async () => {
  const t = await boot();
  const bad = [
    activity({ domain: 'https://youtube.com/watch?v=1' }), activity({ domain: 'youtube.com/path' }), activity({ domain: '127.0.0.1' }),
    activity({ paused: 'no' }), activity({ kind: 'sync' }), activity({ seq: -1 }), activity({ seq: 1.5 }), activity({ installId: 'x' }),
    activity({ at: 'yesterday' }), activity({ browser: 'firefox-ish' }), { ...activity(), url: 'https://youtube.com/x?q=1' }, { ...activity(), title: 'My bank' },
  ];
  for (const b of bad) { const r = await t.ext('POST', '/ext/activity', b); assert.equal(r.status, 400, JSON.stringify(b)); }
  const unlisted = await t.ext('POST', '/ext/activity', activity({ domain: 'example.org' }));
  assert.equal(unlisted.status, 200);
  assert.equal(unlisted.json.data.tracking.countingDomain, null);
  clock.t += 60000;
  await t.ext('POST', '/ext/activity', activity({ domain: 'example.org', kind: 'heartbeat' }));
  assert.equal(t.db.prepare("SELECT COUNT(*) n FROM usage_sessions WHERE category = 'website'").get().n, 0);
  assert.equal(t.db.prepare("SELECT COUNT(*) n FROM usage_sessions WHERE item_name LIKE '%example%'").get().n, 0);
  await t.stop();
});

test('end to end: reports become one database row, retries are idempotent, the dashboard overview is real data', async () => {
  const t = await boot();
  const first = activity({ domain: 'm.youtube.com' });             // subdomain normalises to the tracked domain
  assert.equal((await t.ext('POST', '/ext/activity', first)).json.data.accepted, true);
  assert.equal((await t.ext('POST', '/ext/activity', first)).json.data.accepted, false); // retry of the same message
  clock.t += 30000;
  await t.ext('POST', '/ext/activity', activity({ kind: 'heartbeat', domain: 'youtube.com' }));
  clock.t += 30000;
  await t.ext('POST', '/ext/activity', activity({ kind: 'heartbeat', domain: 'youtu.be' })); // alias
  const rows = t.db.prepare("SELECT item_name, duration_seconds, category FROM usage_sessions").all();
  assert.equal(rows.length, 1);
  assert.deepEqual({ ...rows[0] }, { item_name: 'youtube.com', duration_seconds: 60, category: 'website' });

  const o = (await t.dash('GET', '/api/websites/overview')).json.data;
  const yt = o.sites.find((s) => s.domain === 'youtube.com');
  assert.equal(yt.todaySeconds, 60); assert.equal(yt.isCounting, true);
  assert.equal(o.totalSeconds, 60);
  assert.equal(o.mostUsed.domain, 'youtube.com');
  assert.equal(o.tracking.connected, true);
  assert.equal(o.sites.find((s) => s.domain === 'github.com').todaySeconds, 0); // listed, nothing fabricated
  assert.equal(o.dailyLimitSeconds, 10800);

  const s = (await t.ext('GET', '/ext/summary')).json.data;
  assert.equal(s.currentDomain, 'youtube.com'); assert.equal(s.currentDomainSeconds, 60);

  assert.equal((await t.ext('POST', '/ext/open-dashboard', {})).status, 200);
  assert.equal(t.opened(), 1);
  await t.stop();
});

test('silence from the extension ends the run at its last sign of life (reconciliation on read)', async () => {
  const t = await boot();
  await t.ext('POST', '/ext/activity', activity());
  clock.t += 30000;
  await t.ext('POST', '/ext/activity', activity({ kind: 'heartbeat' }));
  clock.t += 3600000; // browser closed for an hour
  const o = (await t.dash('GET', '/api/websites/overview')).json.data;
  assert.equal(o.totalSeconds, 30);
  assert.equal(o.tracking.connected, false);
  await t.stop();
});

test('backend restart (disconnect/reconnect): stored history stays, new reports continue without overlap', async () => {
  const t1 = await boot();
  await t1.ext('POST', '/ext/activity', activity({ domain: 'github.com' }));
  clock.t += 45000;
  await t1.ext('POST', '/ext/activity', activity({ domain: 'github.com', kind: 'heartbeat' }));
  const file = t1.file;
  await t1.stop();
  clock.t += 20000; // service down for 20 s
  const t2 = await boot(file);
  const r = await t2.req('POST', '/ext/activity', { token: t2.pairing, origin: EXT_ORIGIN, body: activity({ domain: 'github.com', kind: 'heartbeat' }) });
  assert.equal(r.status, 200);
  clock.t += 30000;
  await t2.req('POST', '/ext/activity', { token: t2.pairing, origin: EXT_ORIGIN, body: activity({ domain: 'github.com', kind: 'heartbeat' }) });
  const rows = t2.db.prepare("SELECT started_at, ended_at, duration_seconds FROM usage_sessions ORDER BY started_at").all();
  assert.equal(rows.length, 2);
  assert.ok(rows[1].started_at >= rows[0].ended_at);
  assert.equal(rows[0].duration_seconds, 45);
  assert.equal(rows[1].duration_seconds, 30); // the 20 s outage and the gap before the first report after restart are not counted
  await t2.stop();
});

test('website list management: add, normalise, reject junk, toggle, delete keeps history', async () => {
  const t = await boot();
  let r = await t.dash('POST', '/api/websites', { domain: 'WWW.Example.com' });
  assert.equal(r.status, 201); assert.equal(r.json.data.domain, 'example.com'); assert.equal(r.json.data.displayName, 'Example');
  assert.equal((await t.dash('POST', '/api/websites', { domain: 'example.com' })).status, 409);
  for (const d of ['https://example.com', 'example.com/x', 'localhost', '10.0.0.1', '', 'a b.com', 5, null, 'exa_mple.com']) {
    assert.equal((await t.dash('POST', '/api/websites', { domain: d })).status, 400, String(d));
  }
  assert.equal((await t.dash('POST', '/api/websites', { domain: 'x.com', extra: 1 })).status, 400);
  const id = r.json.data.id;
  r = await t.dash('PUT', `/api/websites/${id}`, { isEnabled: false, displayName: 'My example' });
  assert.deepEqual([r.json.data.isEnabled, r.json.data.displayName], [false, 'My example']);
  assert.equal((await t.dash('PUT', `/api/websites/${id}`, {})).status, 400);
  assert.equal((await t.dash('PUT', '/api/websites/9999', { isEnabled: true })).status, 404);
  t.repo.insertWebsiteRun({ domain: 'example.com', startedAt: new Date(clock.t - 120000).toISOString(), endedAt: new Date(clock.t - 60000).toISOString(), durationSeconds: 60, sessionDate: require('../backend/database').localDate(new Date(clock.t)) });
  assert.equal((await t.dash('DELETE', `/api/websites/${id}`)).status, 200);
  const o = (await t.dash('GET', '/api/websites/overview')).json.data;
  const kept = o.sites.find((s) => s.domain === 'example.com');
  assert.deepEqual([kept.todaySeconds, kept.isTracked], [60, false]); // history survives removal from the list
  await t.stop();
});

test('aliases are configurable; history deletion removes website rows only', async () => {
  const t = await boot();
  assert.equal((await t.dash('POST', '/api/websites/aliases', { alias: 'ig.me', canonical: 'instagram.com' })).status, 201);
  assert.equal((await t.dash('POST', '/api/websites/aliases', { alias: 'same.com', canonical: 'same.com' })).status, 400);
  assert.equal((await t.ext('GET', '/ext/config')).json.data.aliases['ig.me'], 'instagram.com');
  assert.equal((await t.dash('DELETE', '/api/websites/aliases/ig.me')).status, 200);
  assert.equal((await t.dash('DELETE', '/api/websites/aliases/ig.me')).status, 404);

  // inserted directly: the shared test clock runs ahead of real time, which the manual-entry API rightly refuses
  t.repo.insertSession({ category: 'application', itemName: 'Notepad', startedAt: new Date(clock.t - 600000).toISOString(), endedAt: new Date(clock.t - 300000).toISOString(), durationSeconds: 300 });
  await t.ext('POST', '/ext/activity', activity()); clock.t += 30000;
  await t.ext('POST', '/ext/activity', activity({ kind: 'heartbeat' }));
  assert.equal(t.db.prepare("SELECT COUNT(*) n FROM usage_sessions WHERE category = 'website'").get().n, 1);
  const del = await t.dash('DELETE', '/api/websites/history');
  assert.equal(del.json.data.deleted, 1);
  assert.equal(t.db.prepare("SELECT COUNT(*) n FROM usage_sessions WHERE category = 'website'").get().n, 0);
  assert.equal(t.db.prepare("SELECT COUNT(*) n FROM usage_sessions WHERE category = 'application'").get().n, 1);
  await t.stop();
});

test('preferred ports: binds the first free one in the list, falls back to a random port, loopback only', async () => {
  const db = openDatabase(':memory:'); const repo = createRepository(db);
  const blocker = http.createServer().listen(0, '127.0.0.1');
  await new Promise((r) => blocker.once('listening', r));
  const taken = blocker.address().port;
  const a = await startServer({ repo, allowedOrigins: ['null'], ports: [taken, 0] });
  assert.notEqual(a.port, taken);
  assert.ok(a.baseUrl.startsWith('http://127.0.0.1:'));
  await a.close(); blocker.close(); db.close();
});
