import { useState } from 'react';
import AsyncBoundary from '../components/AsyncBoundary.jsx';
import DashboardCard from '../components/DashboardCard.jsx';
import HistoryList from '../components/HistoryList.jsx';
import TestSessionForm from '../components/TestSessionForm.jsx';
import UsageList from '../components/UsageList.jsx';
import { useApi } from '../hooks/useApi.js';
import { api } from '../lib/api.js';

const COPY = {
  apps: { title: 'Application usage', category: 'application', noun: 'application', none: 'No application usage recorded today.' },
  sites: { title: 'Website usage', category: 'website', noun: 'website', none: 'No website usage recorded today.' },
};

export default function UsagePage({ kind }) {
  const { title, category, noun, none } = COPY[kind];
  const today = useApi(`/api/usage/today?category=${category}`);
  const history = useApi(`/api/usage/history?category=${category}&limit=20`);
  const [error, setError] = useState('');
  const refresh = () => { today.reload(); history.reload(); };
  const remove = async (id) => {
    try { setError(''); await api('DELETE', `/api/usage/sessions/${id}`); refresh(); } catch (e) { setError(e.message); }
  };

  return (
    <>
      <div className="page-head">
        <h1>{title}</h1>
        <span className="badge">From your database</span>
      </div>
      <p className="lead">Automatic tracking is not built yet, so nothing is recorded on its own. Sessions appear here once they are saved, for now by the manual form below.</p>

      <h2 className="section-title">Today</h2>
      <AsyncBoundary query={today} isEmpty={today.data?.items.length === 0} empty={`${none} Tracking arrives in a later phase.`}>
        {today.data && <UsageList items={today.data.items} limitSeconds={today.data.dailyLimitSeconds} noun={noun} />}
      </AsyncBoundary>

      <h2 className="section-title">History</h2>
      {error && <p className="msg-error" role="alert">{error}</p>}
      <AsyncBoundary query={history} isEmpty={history.data?.total === 0} empty="No sessions saved yet.">
        {history.data && (
          <>
            <HistoryList records={history.data.records} onDelete={remove} />
            {history.data.total > history.data.records.length && <p className="note">Showing the latest {history.data.records.length} of {history.data.total}.</p>}
          </>
        )}
      </AsyncBoundary>

      <h2 className="section-title">Manual test entry</h2>
      <DashboardCard title="Add a test session" tone="cream" badge="Temporary">
        <TestSessionForm category={category} noun={noun} onAdded={refresh} />
      </DashboardCard>
    </>
  );
}
