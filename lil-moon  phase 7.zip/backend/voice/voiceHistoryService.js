// Voice command history: text only (never audio), respects the on/off setting, and keeps unmatched speech out.
const MAX = 300;
function createVoiceHistoryService({ repo }) {
  return {
    // Returns the new row id, or null when history is off.
    record({ text, intent, status, response, source }) {
      if (!repo.getVoiceSettings().historyEnabled) return null;
      const matched = status !== 'unknown';
      return repo.addVoiceHistory({
        recognizedText: matched ? String(text).slice(0, MAX) : '(not understood)', // unmatched speech could be anything, so it is not kept
        intent: String(intent || 'unknown').slice(0, 60),
        status,
        responseText: String(response || '').slice(0, 1000),
        source: source === 'voice' ? 'voice' : 'typed',
      });
    },
    list: (q) => repo.listVoiceHistory(q),
    clear: () => repo.clearVoiceHistory(),
  };
}
module.exports = { createVoiceHistoryService };
