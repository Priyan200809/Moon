// Hostname handling shared (by copy, see extension/tracker.js and tests/domain.test.js) with the extension.
// Matching is by whole DNS labels, so "notyoutube.com" and "youtube.com.evil.net" never match "youtube.com".
const LABEL = /^(?!-)[a-z0-9-]{1,63}(?<!-)$/;
const SECOND_LEVEL = new Set(['co', 'com', 'org', 'net', 'gov', 'edu', 'ac', 'ne', 'or', 'go']);

function cleanHost(input) {
  if (typeof input !== 'string') return null;
  const s = input.trim().toLowerCase().replace(/\.$/, '');
  if (!s || s.length > 253) return null;
  const labels = s.split('.');
  if (labels.length < 2 || !labels.every((l) => LABEL.test(l))) return null;
  if (/^\d+$/.test(labels[labels.length - 1])) return null; // IPv4-looking
  return s;
}

// For the configurable website list: "WWW.YouTube.com" -> "youtube.com". Refuses shared suffixes like "co.uk".
function normalizeConfiguredDomain(input) {
  let s = cleanHost(input);
  if (!s) return null;
  if (s.startsWith('www.') && s.split('.').length > 2) s = s.slice(4);
  const labels = s.split('.');
  if (labels.length === 2 && SECOND_LEVEL.has(labels[0]) && labels[1].length === 2) return null;
  return s;
}

// sites: [{domain, matchMode: 'subdomains' | 'exact', isEnabled}]. Longest configured domain wins.
function matchTracked(host, sites) {
  const h = cleanHost(host);
  if (!h) return null;
  let best = null;
  for (const site of sites) {
    if (site.isEnabled === false) continue;
    const d = site.domain;
    const hit = h === d || h === `www.${d}` || (site.matchMode !== 'exact' && h.endsWith(`.${d}`));
    if (hit && (!best || d.length > best.domain.length)) best = site;
  }
  return best;
}

module.exports = { cleanHost, normalizeConfiguredDomain, matchTracked };
