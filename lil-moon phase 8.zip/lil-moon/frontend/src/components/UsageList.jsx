import ProgressBar from './ProgressBar.jsx';
import { fmtSec } from '../lib/format.js';

// Each row shows its share of the single daily limit from Settings.
export default function UsageList({ items, limitSeconds, noun }) {
  return (
    <ul className="usage-list">
      {items.map((item) => {
        const over = item.totalSeconds > limitSeconds;
        return (
          <li key={item.itemName} className="usage-item">
            <div className="usage-top">
              <h3>{item.itemName}</h3>
              <span className={`flag${over ? ' flag-over' : ''}`}>{over ? `Over by ${fmtSec(item.totalSeconds - limitSeconds)}` : `${fmtSec(limitSeconds - item.totalSeconds)} left`}</span>
            </div>
            <ProgressBar used={item.totalSeconds} limit={limitSeconds} label={`${item.itemName} ${noun} usage`} />
            <dl className="usage-stats">
              <div><dt>Used today</dt><dd>{fmtSec(item.totalSeconds)}</dd></div>
              <div><dt>Daily limit</dt><dd>{fmtSec(limitSeconds)}</dd></div>
              <div><dt>Sessions</dt><dd>{item.sessionCount}</dd></div>
            </dl>
          </li>
        );
      })}
    </ul>
  );
}
