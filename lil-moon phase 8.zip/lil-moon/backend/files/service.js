// Folder allow-list management and safe opening of indexed files. The renderer never supplies a path:
// folders come from a native dialog in the main process, files are addressed by index id.
const fs = require('fs');
const path = require('path');
const { protectedFolderReason } = require('./guard');
const { searchFiles } = require('./search');

const SAFE_TO_OPEN = new Set(['txt', 'md', 'pdf', 'docx', 'csv', 'json']); // data/document types
// Scripts and web files (.js .py .html .sql ...) are only revealed in the file manager, never launched:
// on Windows, "opening" a .js or .py file can EXECUTE it.
const err = (httpStatus, code, message) => Object.assign(new Error(message), { httpStatus, code });

function createFilesService({ db, aiRepo, indexer, actions = {}, userData = null }) {
  return {
    async addFolderPath(p) {
      let real;
      try { real = fs.realpathSync(p); if (!fs.statSync(real).isDirectory()) throw new Error('x'); }
      catch { throw err(400, 'invalid_folder', 'That folder does not exist or cannot be read.'); }
      const reason = protectedFolderReason(real, { userData });
      if (reason) throw err(403, 'protected_folder', reason);
      const folder = aiRepo.addFolder(real);
      indexer.index(folder.id).catch(() => {});
      return folder;
    },
    async addFolder() {
      const chosen = await actions.pickFolder?.();
      if (!chosen) return null;
      return this.addFolderPath(chosen);
    },
    removeFolder: (id) => aiRepo.removeFolder(id),
    reindex(id) {
      if (!aiRepo.getFolder(id)) return false;
      indexer.index(id).catch(() => {});
      return true;
    },
    reindexAll() { for (const f of aiRepo.listFolders()) indexer.index(f.id).catch(() => {}); },
    status() {
      return { folders: aiRepo.listFolders().map((f) => ({ ...f, progress: indexer.progress(f.id) })), totals: aiRepo.fileStats() };
    },
    search: (q, limit = 20) => searchFiles(db, q, { limit }).map((h) => ({ fileId: h.fileId, name: h.name, path: h.path, ext: h.ext, section: h.heading, snippet: h.snippet, nameMatch: h.nameMatch })),
    openFile(fileId) {
      const f = aiRepo.getFile(fileId);
      if (!f) throw err(404, 'not_found', 'That file is not in the index.');
      let real, root;
      try { root = fs.realpathSync(f.folderPath); real = fs.realpathSync(path.resolve(f.folderPath, f.relPath)); }
      catch { throw err(404, 'not_found', 'The file no longer exists on disk.'); }
      if (!real.startsWith(root + path.sep) || fs.lstatSync(path.resolve(f.folderPath, f.relPath)).isSymbolicLink()) throw err(403, 'forbidden_path', 'That file is outside the indexed folder.');
      if (SAFE_TO_OPEN.has(f.ext)) { actions.openPath?.(real); return { opened: true }; }
      actions.revealPath?.(real);
      return { revealed: true };
    },
  };
}

module.exports = { createFilesService, SAFE_TO_OPEN };
