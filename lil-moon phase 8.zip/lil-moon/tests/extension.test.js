// Extension logic. Part 1: the pure state machine. Part 2: the real background.js and its popup message handlers,
// running against a SIMULATED chrome.* API and the REAL server + SQLite. Real Chrome is not involved.
process.env.TZ = 'Asia/Kolkata';
const test = require('node:test');
const assert = require('node:assert/strict');
const { mock } = test;
const fs = require('fs');
const os = require('os');
const path = require('path');
const { pathToFileURL } = require('url');
const domain = require('../backend/domain');
const { openDatabase, createRepository } = require('../backend/database');
const { startServer, PREFERRED_PORTS } = require('../backend/server');
const { createIdleMonitor } = require('../backend/idleMonitor');

const T = () => import('../extension/tracker.js');
const local = (h, m = 0, s = 0) => new Date(2026, 9, 15, h, m, s).getTime();
const YT = [{ domain: 'youtube.com', matchMode: 'subdomains' }, { domain: 'instagram.com', matchMode: 'subdomains' }];

// ---------------------------------------------------------------- part 1: pure logic
test('extension host parsing keeps only the hostname and refuses unsupported pages', async () => {
  const { hostFromUrl } = await T();
  assert.equal(hostFromUrl('https://www.youtube.com/watch?v=abc&list=x#t=1'), 'www.youtube.com');
  assert.equal(hostFromUrl('https://user:pw@youtube.com:8443/'), 'youtube.com');
  for (const u of ['chrome://settings', 'chrome-extension://x/p.html', 'about:blank', 'file:///C:/a.txt', 'view-source:https://youtube.com', 'http://localhost:3000/', 'http://192.168.0.1/', 'data:text/html,x', '', null, undefined, 'not a url']) assert.equal(hostFromUrl(u), null, String(u));
});

test('extension and backend domain matching behave identically', async () => {
  const x = await T();
  const sites = [{ domain: 'youtube.com', matchMode: 'subdomains' }, { domain: 'exact.com', matchMode: 'exact' }, { domain: 'music.youtube.com', matchMode: 'subdomains' }, { domain: 'o.com', matchMode: 'subdomains', isEnabled: false }];
  for (const h of ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'a.music.youtube.com', 'notyoutube.com', 'youtube.com.evil.net', 'exact.com', 'www.exact.com', 'x.exact.com', 'o.com', 'localhost', '1.2.3.4', 'YOUTUBE.COM.', '', 'a..b']) {
    assert.equal(x.matchTracked(h, sites)?.domain ?? null, domain.matchTracked(h, sites)?.domain ?? null, h);
    assert.equal(x.cleanHost(h), domain.cleanHost(h), h);
  }
});

test('decideTarget: every condition must hold before anything is counted', async () => {
  const { decideTarget } = await T();
  const base = { paused: false, paired: true, trackingEnabled: true, windowFocused: true, incognito: false, idleBlocked: false, url: 'https://www.youtube.com/watch?v=1', domains: YT };
  assert.deepEqual(decideTarget(base), { domain: 'youtube.com', reason: 'tracking' });
  const cases = { paused: ['paused', true], paired: ['not_paired', false], trackingEnabled: ['tracking_disabled', false], windowFocused: ['window_not_focused', false], incognito: ['incognito', true], idleBlocked: ['idle', true] };
  for (const [key, [reason, val]] of Object.entries(cases)) assert.deepEqual(decideTarget({ ...base, [key]: val }), { domain: null, reason }, key);
  assert.equal(decideTarget({ ...base, url: 'chrome://extensions' }).reason, 'unsupported_page');
  assert.equal(decideTarget({ ...base, url: 'https://example.org/' }).reason, 'not_tracked');
});

test('advance/checkpoint: switching, focus loss, stale gaps, backwards clocks, buffer cap', async () => {
  const x = await T();
  let s = x.emptyState();
  s = x.advance(s, { domain: 'youtube.com' }, 1000);
  s = x.advance(s, { domain: 'youtube.com' }, 601_000);
  s = x.advance(s, { domain: 'instagram.com' }, 601_000);            // switch
  assert.deepEqual(s.buffer.map((b) => [b.hostname, Date.parse(b.endedAt) - Date.parse(b.startedAt)]), [['youtube.com', 600_000]]);
  s = x.advance(s, null, 901_000);                                     // focus lost
  assert.equal(s.current, null);
  assert.equal(s.buffer.length, 2);
  s = x.advance(s, { domain: 'youtube.com' }, 1_000_000);
  s = x.advance(s, { domain: 'youtube.com' }, 1_000_000 + x.STALE_MS + 60_000); // browser was closed / asleep: gap not credited
  assert.equal(s.buffer.at(-1).endedAt, new Date(1_000_000).toISOString().replace(/.*/, (v) => v)); // ended at lastSeen, zero length => dropped
  s = x.advance(x.emptyState(), { domain: 'github.com' }, 5000);
  s = x.advance(s, null, 3000);                                        // clock went backwards
  assert.equal(s.buffer.length, 0);                                    // never a negative or zero-length segment
  s = x.advance(x.emptyState(), { domain: 'github.com' }, 0);
  s = x.advance(s, { domain: 'github.com' }, 20_000);
  assert.equal(x.checkpoint(s, 20_000).buffer.length, 0);              // too early
  const cp = x.checkpoint(s, x.CHECKPOINT_MS + 1);
  assert.equal(cp.buffer.length, 1);
  assert.equal(cp.current.domain, 'github.com');
  assert.equal(cp.current.startedAt, x.CHECKPOINT_MS + 1);             // keeps counting without gap or overlap
  let big = x.emptyState();
  for (let i = 0; i < x.MAX_BUFFER + 5; i++) { big = x.advance(big, { domain: 'a.com' }, i * 10_000); big = x.advance(big, null, i * 10_000 + 5000); }
  assert.equal(big.buffer.length, x.MAX_BUFFER);
  assert.equal(big.dropped, 5);
  const ids = big.buffer.slice(0, 3).map((b) => b.clientId);
  assert.equal(x.settle(big, { accepted: [ids[0]], duplicates: [ids[1]], rejected: [{ clientId: ids[2], reason: 'x' }] }).buffer.length, x.MAX_BUFFER - 3);
});

// ---------------------------------------------------------------- part 2: background.js against the real backend
const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lm-ext-')), 'lil-moon.db');
const EXT_ORIGIN = 'chrome-extension://abcdefghijklmnopabcdefghijklmnop';
const TOKEN = 'dash-token';
let importCount = 0;

function makeEnv() {
  const listeners = {};
  const ev = (name) => ({ addListener: (f) => (listeners[name] ??= []).push(f) });
  const store = {};
  const browser = { win: { id: 1, focused: true, state: 'normal', incognito: false, type: 'normal' }, tab: { url: 'https://www.youtube.com/watch?v=SECRET123&t=5', incognito: false } };
  const chrome = {
    runtime: { id: 'self', getManifest: () => ({ version: '0.1.0' }), onStartup: ev('startup'), onInstalled: ev('installed'), onMessage: ev('message') },
    storage: { local: { get: async (k) => ({ [k]: store[k] === undefined ? undefined : structuredClone(store[k]) }), set: async (o) => { Object.assign(store, structuredClone(o)); } } },
    alarms: { create() {}, onAlarm: ev('alarm') },
    tabs: { onActivated: ev('tabAct'), onUpdated: ev('tabUpd'), onRemoved: ev('tabRem'), onReplaced: ev('tabRep'), query: async () => [browser.tab] },
    windows: { onFocusChanged: ev('winFocus'), onRemoved: ev('winRem'), getLastFocused: async () => ({ ...browser.win }) },
    idle: { onStateChanged: ev('idle'), setDetectionInterval() {} },
  };
  return { chrome, listeners, store, browser };
}

async function setup(t, { now = local(12), ports = [0], idle = null, server = null } = {}) {
  mock.timers.reset();
  mock.timers.enable({ apis: ['Date'], now });
  const db = openDatabase(tmp());
  const repo = createRepository(db);
  const env = makeEnv();
  const ctx = { db, repo, env, idle, sent: [], api: null, ports };
  const start = async () => { ctx.api = await startServer({ repo, allowedOrigins: ['null'], extensionOrigins: [EXT_ORIGIN], activity: idle, token: TOKEN, ports: ctx.ports }); return ctx.api; };
  await start();
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {            // record every request the extension makes, and optionally drop a response
    if (String(url).includes('/ext/sync') && init?.body) {
      ctx.sent.push(init.body);
      const body = JSON.parse(init.body);
      const res = await realFetch(url, { ...init, headers: { ...init.headers, Origin: EXT_ORIGIN } });
      if (ctx.dropNextResponse && body.sessions.length) { ctx.dropNextResponse = false; await res.arrayBuffer(); throw new TypeError('connection lost'); }
      return res;
    }
    return realFetch(url, { ...init, headers: { ...init?.headers, Origin: EXT_ORIGIN } });
  };
  globalThis.chrome = env.chrome;
  const load = async () => { await import(`${pathToFileURL(path.resolve('extension/background.js')).href}?n=${++importCount}`); };
  ctx.load = load;
  ctx.rpc = (msg) => new Promise((res) => env.listeners.message.at(-1)(msg, { id: 'self' }, res));
  ctx.emit = async (name, ...args) => { for (const f of env.listeners[name] ?? []) f(...args); return ctx.rpc({ type: 'getStatus' }); }; // rpc queues behind the handlers: a barrier
  ctx.at = (ms) => mock.timers.setTime(ms);
  ctx.tick = () => ctx.emit('alarm', { name: 'lil-moon-tick' });
  // advance time in 1 s steps (idle monitor) with the 30 s alarm, like real life
  ctx.run = async (ms) => { const end = Date.now() + ms; let n = 0; while (Date.now() < end) { ctx.at(Date.now() + 1000); idle?.tick(); if (++n % 30 === 0) await ctx.tick(); } };
  ctx.sync = () => ctx.rpc({ type: 'syncNow' });
  ctx.rows = () => db.prepare("SELECT item_name, duration_seconds, session_date FROM usage_sessions WHERE category = 'website' ORDER BY started_at, id").all();
  ctx.total = () => db.prepare("SELECT COALESCE(SUM(duration_seconds),0) s FROM usage_sessions WHERE category = 'website'").get().s;
  ctx.stop = async () => { globalThis.fetch = realFetch; if (ctx.api) await ctx.api.close(); db.close(); mock.timers.reset(); delete globalThis.chrome; };
  await load();
  const code = (await (await realFetch(ctx.api.baseUrl + '/api/extension/pairing', { method: 'POST', headers: { Authorization: `Bearer ${TOKEN}` } })).json()).data.code;
  ctx.code = code;
  ctx.pair = async () => ctx.rpc({ type: 'pair', code });
  ctx.browser = env.browser;
  return ctx;
}
const yt = (t, url = 'https://www.youtube.com/watch?v=SECRET123&t=5') => { t.browser.tab = { url, incognito: false }; return t.emit('tabAct', {}); };

test('e2e: pairing, then YouTube for 10 minutes is recorded as about 10 minutes', async (c) => {
  const t = await setup(c);
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'not_paired');
  await t.run(120_000);
  assert.equal(t.total(), 0); // nothing is recorded or sent before pairing
  const s = await t.pair();
  assert.equal(s.paired, true);
  assert.equal(s.desktopOnline, true);
  assert.equal(s.reason, 'tracking');
  assert.equal(s.current, 'youtube.com');
  await t.run(600_000);
  await yt(t, 'https://example.org/'); // leave: closes the session
  await t.sync();
  assert.equal(t.rows().length, 1);
  assert.equal(t.total(), 600);
  assert.equal(t.rows()[0].item_name, 'youtube.com');
  await t.stop();
});

test('e2e: YouTube -> Instagram -> another tab; background tabs and untracked sites are not counted', async (c) => {
  const t = await setup(c);
  await t.pair();
  await t.run(300_000);
  await yt(t, 'https://m.instagram.com/reels/');       // switch
  await t.run(300_000);
  await yt(t, 'https://news.example.org/');             // untracked tab becomes active
  await t.run(300_000);
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'not_tracked');
  await yt(t, 'https://music.youtube.com/');            // subdomain merges into youtube.com
  await t.run(120_000);
  await yt(t, 'chrome://settings');
  await t.sync();
  assert.deepEqual(t.rows().map((r) => [r.item_name, r.duration_seconds]), [['youtube.com', 300], ['instagram.com', 300], ['youtube.com', 120]]);
  await t.stop();
});

test('e2e: leaving Chrome, minimising, incognito, pause/resume', async (c) => {
  const t = await setup(c);
  await t.pair();
  await t.run(120_000);                                                   // +120 counted
  t.browser.win.focused = false; await t.emit('winFocus', -1);            // switch to VS Code
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'window_not_focused');
  await t.run(300_000);                                                   // not counted
  t.browser.win.focused = true; await t.emit('winFocus', 1);
  await t.run(60_000);                                                    // +60
  t.browser.win.state = 'minimized'; await t.emit('winFocus', 1);
  await t.run(300_000);                                                   // minimised: not counted
  t.browser.win.state = 'normal'; await t.emit('winFocus', 1);
  t.browser.win.incognito = true; await t.emit('winFocus', 1);
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'incognito');
  await t.run(300_000);                                                   // incognito: not counted
  t.browser.win.incognito = false; await t.emit('winFocus', 1);
  await t.run(60_000);                                                    // +60
  let s = await t.rpc({ type: 'togglePause' });
  assert.equal(s.paused, true);
  assert.equal(s.reason, 'paused');
  await t.run(300_000);                                                   // paused: not counted
  s = await t.rpc({ type: 'togglePause' });
  assert.equal(s.paused, false);
  await t.run(60_000);                                                    // +60
  await yt(t, 'https://example.org/'); await t.sync();
  assert.equal(t.total(), 120 + 60 + 60 + 60);
  assert.equal((await t.dashStatus?.())?.extensionPaused ?? false, false);
  await t.stop();
});

test('e2e: idle, lock and sleep reported by the desktop app pause counting', async (c) => {
  let idleSeconds = 0;
  const idle = createIdleMonitor({ getIdleSeconds: () => idleSeconds, getThresholdSeconds: () => 60, now: () => Date.now() });
  const t = await setup(c, { idle });
  await t.pair();
  // 12:00-12:03 active; no input 12:03-12:07 (idle from 12:04); active again 12:07-12:10
  for (let s = 0; s < 600; s++) {
    t.at(local(12) + (s + 1) * 1000);
    idleSeconds = s + 1 < 180 ? 0 : s + 1 < 420 ? s + 1 - 180 : 0;
    idle.tick();
    if ((s + 1) % 30 === 0) await t.tick();
  }
  await yt(t, 'https://example.org/'); await t.sync();
  assert.equal(t.total(), 240 + 180);
  const before = t.total();
  await yt(t, 'https://www.youtube.com/');
  await t.run(60_000);
  idle.lock(); await t.run(120_000); idle.unlock();                        // screen locked 2 min
  await t.run(60_000);
  idle.suspend(); await t.run(120_000); idle.resume();                     // asleep 2 min
  await t.run(60_000);
  await yt(t, 'https://example.org/'); await t.sync();
  assert.equal(t.total() - before, 180);
  await t.stop();
});

test('e2e: closing and reopening Chrome never credits the time Chrome was closed', async (c) => {
  const t = await setup(c);
  await t.pair();
  await t.run(300_000);
  // Chrome quits without any event. An hour later it starts again and the service worker runs from scratch.
  t.at(Date.now() + 3600_000);
  t.env = null;
  await t.load();
  await t.emit('startup');
  await t.run(120_000);
  await yt(t, 'https://example.org/'); await t.sync();
  const total = t.total();
  assert.ok(total >= 300 + 120 - 35 && total <= 300 + 120, `total ${total}`); // loses at most one checkpoint interval, never the hour
  assert.equal(t.rows().length, 2);
  await t.stop();
});

test('e2e: a service-worker restart in the middle of a session loses and duplicates nothing', async (c) => {
  const t = await setup(c);
  await t.pair();
  await t.run(300_000);
  t.at(Date.now() + 10_000);
  await t.load();                                  // fresh module state, same chrome.storage
  await t.rpc({ type: 'getStatus' });
  await t.run(300_000);
  await yt(t, 'https://example.org/'); await t.sync();
  const total = t.total();
  assert.ok(total >= 600 - 10 && total <= 610, `total ${total}`); // the 10 s while the worker was dead may be uncounted, never double counted
  await t.stop();
});

test('e2e: desktop offline -> sessions buffered locally -> delivered once when it returns, even if a response is lost', async (c) => {
  const t = await setup(c, { ports: PREFERRED_PORTS });
  await t.pair();
  await t.run(120_000);
  await t.api.close(); t.api = null;               // desktop app quits
  await t.run(300_000);                            // 5 min of YouTube while offline
  await yt(t, 'https://www.instagram.com/');
  await t.run(120_000);
  let s = await t.rpc({ type: 'getStatus' });
  assert.equal(s.desktopOnline, false);
  assert.ok(s.buffered >= 2, `buffered ${s.buffered}`);
  assert.equal(t.total(), 120 - (120 % 30) + (120 % 30 ? 0 : 0) >= 0 ? t.total() : 0);
  const stored = t.total();
  await yt(t, 'https://example.org/');
  await t.run(10_000);
  t.ports = [...PREFERRED_PORTS];                  // the desktop app starts again (possibly on another port)
  t.api = await startServer({ repo: t.repo, allowedOrigins: ['null'], extensionOrigins: [EXT_ORIGIN], token: TOKEN, ports: [PREFERRED_PORTS[3]] });
  t.dropNextResponse = true;                       // the first delivery reaches the server but the reply is lost
  await t.sync();
  s = await t.rpc({ type: 'getStatus' });
  assert.equal(s.buffered > 0, true);              // extension thinks it failed...
  await t.sync();                                  // ...and retries the same ids
  s = await t.rpc({ type: 'getStatus' });
  assert.equal(s.buffered, 0);
  assert.equal(s.desktopOnline, true);
  assert.ok(stored <= 120);
  assert.equal(t.total(), 120 + 300 + 120);        // everything exactly once
  await t.stop();
});

test('e2e: chrome.idle is only a fallback while the desktop app is unreachable', async (c) => {
  const t = await setup(c, { ports: PREFERRED_PORTS });
  await t.pair();
  await t.emit('idle', 'idle');                    // desktop online: chrome.idle must be ignored
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'tracking');
  await t.emit('idle', 'active');
  await t.api.close(); t.api = null;
  await t.sync();                                  // extension notices the desktop is gone
  await t.emit('idle', 'locked');
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'idle');
  await t.emit('idle', 'active');
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'tracking');
  await t.stop();
});

test('e2e: dashboard switch, removed websites and revoked pairing are respected', async (c) => {
  const t = await setup(c);
  await t.pair();
  await t.run(60_000);
  t.repo.updateSettings({ websiteTrackingEnabled: false });
  await t.sync();                                  // config arrives
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'tracking_disabled');
  const before = t.total();
  await t.run(300_000);
  assert.equal(t.total(), before);
  t.repo.updateSettings({ websiteTrackingEnabled: true });
  await t.sync();
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'tracking');
  const yid = t.repo.listWebsites().find((w) => w.domain === 'youtube.com').id;
  t.repo.updateWebsite(yid, { isEnabled: false });
  await t.sync();
  assert.equal((await t.rpc({ type: 'getStatus' })).reason, 'not_tracked');
  await (await fetch(t.api.baseUrl + '/api/extension/pairing', { method: 'DELETE', headers: { Authorization: `Bearer ${TOKEN}` } })).json();
  await t.run(60_000);
  const s = await t.rpc({ type: 'getStatus' });
  assert.equal(s.authOk, false);                   // popup will ask for a new code
  await t.stop();
});

test('privacy: only canonical domains and timestamps leave the browser; no URLs, paths or queries anywhere', async (c) => {
  const t = await setup(c);
  await t.pair();
  await t.run(90_000);
  await yt(t, 'https://music.youtube.com/watch?v=SECRET456&list=PRIVATE');
  await t.run(90_000);
  await yt(t, 'https://example.org/private/page?token=ABC');
  await t.run(60_000);
  await t.sync();
  assert.ok(t.sent.length > 0);
  for (const body of t.sent) {
    const parsed = JSON.parse(body);
    assert.deepEqual(Object.keys(parsed).sort(), ['browser', 'paused', 'sessions', 'version']);
    for (const s of parsed.sessions) { assert.deepEqual(Object.keys(s).sort(), ['clientId', 'endedAt', 'hostname', 'startedAt']); assert.equal(s.hostname, 'youtube.com'); }
    assert.doesNotMatch(body, /SECRET|PRIVATE|token=|example\.org|watch|private/i);
  }
  assert.doesNotMatch(JSON.stringify(t.env.store), /SECRET|PRIVATE|token=|example\.org|watch\?|\/private/i); // nothing sensitive persisted in the browser either
  const dump = JSON.stringify(t.db.prepare('SELECT * FROM usage_sessions').all());
  assert.doesNotMatch(dump, /SECRET|PRIVATE|example\.org|watch/i);
  await t.stop();
});
