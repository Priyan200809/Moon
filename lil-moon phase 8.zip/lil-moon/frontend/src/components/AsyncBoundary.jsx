// One consistent loading / error / empty treatment for anything fetched from the backend.
export default function AsyncBoundary({ query, isEmpty = false, empty, children }) {
  if (query.status === 'error') {
    return (
      <div className="state state-error" role="alert">
        <p>{query.error}</p>
        <button className="btn" onClick={query.reload}>Try again</button>
      </div>
    );
  }
  if (!query.data) return <div className="state" role="status">Loading...</div>;
  if (isEmpty) return <div className="state">{empty}</div>;
  return children;
}
