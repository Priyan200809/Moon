// Block page. Shows why, explains the method, and offers the user's own overrides. All decisions go through the background worker.
const $ = (id) => document.getElementById(id);
const domain = new URLSearchParams(location.search).get('d') || '';
const send = (type, extra = {}) => chrome.runtime.sendMessage({ type, domain, ...extra });
const fmt = (sec) => { const s = Math.max(0, Math.round(sec || 0)); if (s < 60) return `${s} seconds`; const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? `${h} h${m ? ` ${m} min` : ''}` : `${m} min`; };
const say = (text, err = false) => { $('msg').textContent = text; $('msg').className = err ? 'msg err' : 'msg'; };
let tabId = null;

async function load() {
  $('title').textContent = `Daily limit reached: ${domain}`;
  $('dom').textContent = domain;
  const r = await send('blockinfo');
  const info = r?.ok ? r.data : null;
  if (info?.item) {
    $('usage').textContent = `You used ${fmt(info.item.usedSeconds)} of ${fmt(info.item.allowanceSeconds)} today.`;
    $('override').textContent = `Allow ${info.item.extensionMinutes} more minutes`;
  } else {
    $('usage').textContent = 'This limit is no longer being enforced. You can go back to the site.';
    $('override').disabled = true; $('disable').disabled = true;
  }
  $('conn').textContent = info?.connection?.ok ? 'Connected to the Lil Moon app.' : 'The Lil Moon app is not reachable right now. If it stays closed, this block lifts by itself after a few minutes.';
}

async function leave() {
  const r = await send('blockresume', { tabId });
  location.replace(r?.ok && r.data ? r.data : `https://${domain}/`);
}

$('override').addEventListener('click', async () => {
  $('override').disabled = true; say('Asking Lil Moon...');
  const r = await send('override', { tabId });
  if (r?.ok) { say('Extra time approved. It is saved in the restriction history.'); location.replace(r.data); }
  else { say(r?.error === 'offline' ? 'Lil Moon is not running. Open it to continue.' : r?.error === 'not_reached' ? 'The limit is no longer reached.' : 'Could not add time. Try again from the Lil Moon dashboard.', true); $('override').disabled = false; }
});
$('disable').addEventListener('click', async () => {
  $('disable').disabled = true; say('Turning the limit off...');
  const r = await send('disablelimit');
  if (r?.ok) { say('Limit turned off.'); await leave(); } else { say('Could not turn it off. Use the Lil Moon dashboard.', true); $('disable').disabled = false; }
});
$('dash').addEventListener('click', async () => { const r = await send('dashboard'); say(r?.ok ? 'Opening Lil Moon...' : 'Lil Moon is not running.', !r?.ok); });
$('back').addEventListener('click', () => { if (history.length > 1) history.back(); else window.close(); });

chrome.tabs.getCurrent().then((t) => { tabId = t?.id ?? null; });
load();
