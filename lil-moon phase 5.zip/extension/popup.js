// Popup: shows status and sends commands to the background worker. No tracking logic lives here.
const $ = (id) => document.getElementById(id);
const send = (type, extra = {}) => chrome.runtime.sendMessage({ type, ...extra });
const fmt = (sec) => { const s = Math.max(0, Math.round(sec || 0)); if (s < 60) return `${s}s`; const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? `${h}h ${m}m` : `${m}m`; };
const ERR = { offline: 'Lil Moon is not running (or not reachable).', unauthorized: 'That pairing code was not accepted.', bad_code: 'The code should be 48 letters and digits (0-9, a-f).', not_paired: 'Not connected yet.', error: 'Something went wrong.' };
const REASON = { paused: 'Paused', browser_not_focused: 'Browser not in front', minimized: 'Browser minimised', incognito: 'Private window (never tracked)', no_tab: 'No active tab', no_window: 'No window', not_tracked: 'Not a listed site', tracking: '' };
let busy = false;

function pill(text, cls) { const el = $('state'); el.textContent = text; el.className = `pill ${cls}`; }

async function render() {
  const r = await send('status');
  if (!r?.ok) { pill('Error', 'off'); return; }
  const s = r.data;
  $('pair').hidden = s.paired && s.connection.error !== 'unauthorized';
  $('main').hidden = !s.paired;
  $('unpair').hidden = !s.paired;
  if (!s.paired) { pill('Not connected', 'off'); return; }

  $('toggle').textContent = s.paused ? 'Resume tracking' : 'Pause tracking';
  if (s.connection.error === 'unauthorized') pill('Re-pair needed', 'off');
  else if (!s.connection.ok && s.connection.at) pill('App offline', 'off');
  else if (s.paused) pill('Paused', 'paused');
  else pill('Tracking on', 'on');

  $('current').textContent = s.current.domain || REASON[s.current.reason] || '-';
  $('conn').textContent = s.connection.ok ? 'Connected' : s.queued ? `Offline, ${s.queued} waiting` : ERR[s.connection.error] || 'Offline';
  try {
    const sum = await send('summary');
    if (sum?.ok) {
      $('total').textContent = fmt(sum.data.totalSeconds);
      $('siteToday').textContent = s.current.domain ? fmt(sum.data.currentDomainSeconds) : '-';
    } else { $('total').textContent = '-'; $('siteToday').textContent = '-'; }
  } catch { /* worker restarting; next tick */ }
}

$('toggle').addEventListener('click', async () => {
  if (busy) return; busy = true;
  const paused = $('toggle').textContent.startsWith('Resume');
  await send(paused ? 'resume' : 'pause');
  busy = false; render();
});
$('dash').addEventListener('click', async () => {
  const r = await send('dashboard');
  $('msg').className = r?.ok ? 'msg' : 'msg err';
  $('msg').textContent = r?.ok ? '' : (ERR[r?.error] || ERR.error);
});
$('connect').addEventListener('click', async () => {
  $('pairMsg').className = 'msg'; $('pairMsg').textContent = 'Connecting...';
  const r = await send('pair', { code: $('code').value });
  if (r?.ok) { $('code').value = ''; $('pairMsg').textContent = ''; } else { $('pairMsg').className = 'msg err'; $('pairMsg').textContent = ERR[r?.error] || ERR.error; }
  render();
});
$('unpair').addEventListener('click', async () => { await send('unpair'); render(); });

render();
setInterval(render, 2000);
