const { THEMES } = require('./database');

class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}
const bad = (msg) => new HttpError(400, 'validation_error', msg);
const CATEGORIES = ['application', 'website'];
const ISO_UTC = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,3})?Z$/;

function onlyFields(body, allowed) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw bad('Request body must be a JSON object.');
  for (const k of Object.keys(body)) if (!allowed.includes(k)) throw bad(`Unknown field: ${k}`);
}

function realDate(v, name) {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) throw bad(`${name} must be a date like 2026-10-25.`);
  const d = new Date(`${v}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v) throw bad(`${name} is not a real calendar date.`);
  return v;
}

function int(v, name, min, max, fallback) {
  if (v === undefined) return fallback;
  if (typeof v !== 'string' || !/^\d{1,9}$/.test(v) || Number(v) < min || Number(v) > max) throw bad(`${name} must be a whole number from ${min} to ${max}.`);
  return Number(v);
}

function category(v, name = 'category') {
  if (v === undefined) return undefined;
  if (!CATEGORIES.includes(v)) throw bad(`${name} must be "application" or "website".`);
  return v;
}

function timestamp(v, name) {
  if (typeof v !== 'string' || !ISO_UTC.test(v)) throw bad(`${name} must be a UTC ISO-8601 timestamp like 2026-10-25T14:03:09.000Z.`);
  const d = new Date(v);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v.slice(0, 10)) throw bad(`${name} is not a real date and time.`);
  if (d.getUTCFullYear() < 2000) throw bad(`${name} is too far in the past.`);
  return d;
}

const settingsPatch = (body) => {
  onlyFields(body, ['dailyLimitSeconds', 'theme']);
  const out = {};
  if ('dailyLimitSeconds' in body) {
    const n = body.dailyLimitSeconds;
    if (!Number.isInteger(n) || n < 300 || n > 86400) throw bad('dailyLimitSeconds must be a whole number from 300 to 86400.');
    out.dailyLimitSeconds = n;
  }
  if ('theme' in body) {
    if (!THEMES.includes(body.theme)) throw bad(`theme must be one of: ${THEMES.join(', ')}.`);
    out.theme = body.theme;
  }
  if (!Object.keys(out).length) throw bad('Provide dailyLimitSeconds, theme, or both.');
  return out;
};

const sessionBody = (body) => {
  onlyFields(body, ['category', 'itemName', 'startedAt', 'endedAt']);
  if (!CATEGORIES.includes(body.category)) throw bad('category must be "application" or "website".');
  const name = typeof body.itemName === 'string' ? body.itemName.trim() : '';
  if (!name || name.length > 200 || /[\u0000-\u001f\u007f]/.test(name)) throw bad('itemName must be 1 to 200 printable characters.');
  const start = timestamp(body.startedAt, 'startedAt');
  const end = timestamp(body.endedAt, 'endedAt');
  if (start.getTime() > Date.now() + 5 * 60 * 1000) throw bad('startedAt cannot be in the future.');
  if (end < start) throw bad('endedAt must not be before startedAt.');
  const durationSeconds = Math.round((end - start) / 1000);
  if (durationSeconds > 86400) throw bad('A session cannot be longer than 24 hours.');
  return { category: body.category, itemName: name, startedAt: start.toISOString(), endedAt: end.toISOString(), durationSeconds };
};

const historyQuery = (q) => {
  const from = q.from === undefined ? undefined : realDate(q.from, 'from');
  const to = q.to === undefined ? undefined : realDate(q.to, 'to');
  if (from && to && from > to) throw bad('from must not be after to.');
  return { from, to, category: category(q.category), limit: int(q.limit, 'limit', 1, 200, 50), offset: int(q.offset, 'offset', 0, 1000000, 0) };
};

const recordId = (v) => {
  if (!/^[1-9]\d{0,9}$/.test(v)) throw bad('id must be a positive whole number.');
  return Number(v);
};

module.exports = { HttpError, settingsPatch, sessionBody, historyQuery, category, recordId };
