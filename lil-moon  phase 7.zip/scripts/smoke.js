// Automated smoke test, run with `npm run smoke` (two phases: persistence is checked across a restart).
// It drives the real windows and IPC; it cannot judge visuals or true Windows behaviour.
const { app, screen, powerMonitor } = require('electron');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');

const phase = process.env.SMOKE_PHASE || '1';
const dir = process.env.SMOKE_DIR || fs.mkdtempSync(path.join(os.tmpdir(), 'lilmoon-'));
app.setPath('userData', dir);
const main = require('../electron/main.js');
const wm = require('../electron/windowManager');

const results = [];
const check = (name, ok) => { results.push(ok); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}`); };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const errors = [];
const watch = (win, tag) => {
  win.webContents.on('console-message', (e) => { if (e.level === 'error') errors.push(`${tag}: ${e.message}`); });
  win.webContents.on('did-fail-load', (_e, c, d) => errors.push(`${tag}: load failed ${c} ${d}`));
};
const fire = (win, code) => win.webContents.executeJavaScript(code).catch(() => {}); // window may vanish mid-call
const ev = (win, code) => win.webContents.executeJavaScript(code);
const call = (win, method, p, body) => ev(win, `(async()=>{const c=await window.lilMoon.getApiConfig();const r=await fetch(c.baseUrl+${JSON.stringify(p)},{method:${JSON.stringify(method)},headers:{Authorization:'Bearer '+c.token,'Content-Type':'application/json'},body:${body === undefined ? 'undefined' : JSON.stringify(JSON.stringify(body))}});return {status:r.status,json:await r.json()}})()`);

// Plays the browser extension: real HTTP to the real /ext routes with a pairing code and an extension-style Origin.
const EXT_ORIGIN = 'chrome-extension://abcdefghijklmnopabcdefghijklmnop';
const extCall = (port, token, method, p, body) => new Promise((resolve, reject) => {
  const payload = body === undefined ? undefined : JSON.stringify(body);
  const req = http.request({ host: '127.0.0.1', port, path: p, method, headers: { Authorization: `Bearer ${token}`, Origin: EXT_ORIGIN, ...(payload && { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) }) } }, (res) => {
    let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => resolve({ status: res.statusCode, json: JSON.parse(b || 'null') }));
  });
  req.on('error', reject); req.end(payload);
});
let extSeq = 0;
const report = (port, token, domain, o = {}) => extCall(port, token, 'POST', '/ext/activity', { installId: 'smoke-install-1', seq: extSeq++, kind: 'change', domain, paused: false, at: new Date().toISOString(), browser: 'chrome', ...o });
const pointer = (type, x, y) =>
  `document.querySelector('.moon').dispatchEvent(new PointerEvent('${type}',{bubbles:true,button:0,pointerId:1,screenX:${x},screenY:${y}}))`;

app.whenReady().then(async () => {
  try {
    await wait(1500);
    const moon = wm.getMoon();
    watch(moon, 'moon');
    await moon.webContents.reload(); await wait(1000);
    const prefs = moon.webContents.getLastWebPreferences();
    check('moon window created, always on top', !!moon && moon.isAlwaysOnTop());
    check('security: contextIsolation, no nodeIntegration, sandbox',
      prefs.contextIsolation === true && prefs.nodeIntegration === false && prefs.sandbox === true);
    check('renderer sees only the lilMoon bridge (no require/process)',
      await ev(moon, `typeof window.lilMoon==='object' && typeof require==='undefined' && typeof process==='undefined'`));

    const wa = screen.getPrimaryDisplay().workArea;
    if (phase === '2') {
      const saved = JSON.parse(fs.readFileSync(path.join(dir, 'settings.json'), 'utf8')).moon;
      const [x, y] = moon.getPosition();
      check('moon position restored after restart', x === saved.x && y === saved.y);
      const d2 = wm.openDashboard(); watch(d2, 'dashboard'); await wait(2500);
      const st = (await call(d2, 'GET', '/api/settings')).json.data;
      check('settings persisted in SQLite across restart', st.dailyLimitSeconds === 5400 && st.theme === 'lilac');
      check('usage records persisted in SQLite across restart', (await call(d2, 'GET', '/api/usage/history?category=application')).json.data.total === 1);
      const web2 = (await call(d2, 'GET', '/api/usage/history?category=website')).json.data;
      check('website run open at exit was stored, and survived the restart', web2.total === 1 && web2.records[0].itemName === 'youtube.com' && web2.records[0].durationSeconds >= 1);
      check('tracked website list survived the restart (edited list kept)', (await call(d2, 'GET', '/api/websites')).json.data.some((w) => w.domain === 'smoke-example.com'));
      const lim2 = (await call(d2, 'GET', '/api/limits')).json.data;
      check('limit, its settings and the restriction history survived the restart', lim2.items.length === 1 && lim2.items[0].target === 'smoke-example.com' && lim2.items[0].mode === 'confirm' && lim2.restrictionsEnabled === true && (await call(d2, 'GET', '/api/limits/events')).json.data.total >= 6);
      const vs2 = (await call(d2, 'GET', '/api/voice/settings')).json.data;
      check('voice settings and history survived the restart', vs2.speechRate === 1.5 && vs2.muted === true && vs2.wakeWordEnabled === false && (await call(d2, 'GET', '/api/voice/history')).json.data.total >= 6);
      check('idle threshold survived the restart', (await call(d2, 'GET', '/api/settings')).json.data.idleThresholdSeconds === 90);
      check('saved theme applied on launch', (await ev(d2, `document.documentElement.dataset.theme`)) === 'lilac');
    } else {
      const start = moon.getPosition();
      let cur = { x: start[0] + 50, y: start[1] + 50 };
      wm.__setCursor(() => cur);
      await ev(moon, pointer('pointerdown', 500, 500));
      cur = { x: cur.x - 200, y: cur.y - 150 };
      await ev(moon, pointer('pointermove', 300, 350));
      await wait(100);
      const moved = moon.getPosition();
      check('dragging moves the moon', moved[0] !== start[0] && moved[1] !== start[1]);
      await ev(moon, pointer('pointerup', 300, 350));
      await wait(200);
      check('dragging does not open the dashboard', wm.getDashboard() === null);
      const saved = JSON.parse(fs.readFileSync(path.join(dir, 'settings.json'), 'utf8')).moon;
      check('position saved to disk', saved.x === moved[0] && saved.y === moved[1]);

      cur = { x: -9000, y: -9000 };
      await ev(moon, pointer('pointerdown', 300, 350));
      await ev(moon, pointer('pointermove', 100, 100));
      await ev(moon, pointer('pointerup', 100, 100));
      await wait(100);
      const [ex, ey] = moon.getPosition();
      check('dragging off-screen is clamped into the work area',
        ex >= wa.x && ey >= wa.y && ex + wm.MOON <= wa.x + wa.width && ey + wm.MOON <= wa.y + wa.height);
      const [fx, fy] = moon.getPosition();
      const sf = path.join(dir, 'settings.json');
      fs.writeFileSync(sf, JSON.stringify({ ...JSON.parse(fs.readFileSync(sf, 'utf8')), moon: { x: fx, y: fy } }));

      for (let i = 0; i < 3; i++) {
        await ev(moon, pointer('pointerdown', 10, 10));
        await ev(moon, pointer('pointerup', 10, 10));
      }
      await wait(2500);
      const dash = wm.getDashboard();
      check('clicking the moon opens the dashboard', !!dash);
      check('repeated clicks create no duplicate dashboards', require('electron').BrowserWindow.getAllWindows().length === 2);
      watch(dash, 'dashboard');
      await dash.webContents.reload(); await wait(1200);
      const text = (sel) => ev(dash, `document.querySelector(${JSON.stringify(sel)})?.textContent ?? ''`);
      const nav = async (label) => { await ev(dash, `[...document.querySelectorAll('.nav-btn')].find(b=>b.textContent===${JSON.stringify(label)}).click()`); await wait(250); };
      const setInput = (sel, val) => ev(dash, `(()=>{const el=document.querySelector(${JSON.stringify(sel)});Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,${JSON.stringify(String(val))});el.dispatchEvent(new Event('input',{bubbles:true}));})()`);
      const click = (sel) => ev(dash, `document.querySelector(${JSON.stringify(sel)}).click()`);
      const body = () => ev(dash, `document.body.innerText`);
      check('database file created in the user-data folder', fs.existsSync(path.join(dir, 'lil-moon.db')));
      check('dashboard has 6 nav sections (Usage limits added)', (await ev(dash, `document.querySelectorAll('.nav-btn').length`)) === 6);
      await wait(600);
      let b = await body();
      check('home: branding, status, database connected, empty state', b.includes("Hi, I'm Lil Moon.") && b.includes('Assistant status') && b.includes('Connected') && b.includes('nothing recorded yet'));
      check('API health endpoint', (await call(dash, 'GET', '/api/health')).status === 200);
      check('API rejects a request without the token', (await ev(dash, `(async()=>{const c=await window.lilMoon.getApiConfig();return (await fetch(c.baseUrl+'/api/health')).status})()`)) === 401);
      check('moon window cannot obtain the API token', (await ev(moon, `window.lilMoon.getApiConfig().then(()=>'leak',()=>'rejected')`)) === 'rejected');
      check('default daily limit is 3 hours (10800 s)', (await call(dash, 'GET', '/api/settings')).json.data.dailyLimitSeconds === 10800);
      await nav('Settings');
      check('settings page shows the saved limit (180 min)', (await ev(dash, `document.querySelector('.field input').value`)) === '180');
      await setInput('.field input', 90); await click('.btn-strong'); await wait(700);
      check('changing the limit in the UI saves it to SQLite', (await call(dash, 'GET', '/api/settings')).json.data.dailyLimitSeconds === 5400 && (await body()).includes('Settings saved.'));
      check('API rejects an invalid limit with 400', (await call(dash, 'PUT', '/api/settings', { dailyLimitSeconds: 10 })).status === 400);
      await nav('Application usage');
      b = await body();
      check('application page: empty states, no sample data', b.includes('No application usage recorded today') && b.includes('No sessions saved yet') && !b.includes('Sample data'));
      await setInput('.test-form input', 'Test app'); await click('.test-form button'); await wait(900);
      b = await body();
      check('adding a session in the UI shows it in today and history', b.includes('Test app') && b.includes('10m') && (await call(dash, 'GET', '/api/usage/history')).json.data.total === 1);
      const bad = await call(dash, 'POST', '/api/usage/sessions', { category: 'application', itemName: 'x', startedAt: 'nope', endedAt: 'nope' });
      check('API rejects an invalid session with 400', bad.status === 400 && bad.json.ok === false);
      // ---------------- Phase 5: website tracking ----------------
      const svc = main.__services();
      const { port } = svc.api;
      const pairing = (await call(dash, 'GET', '/api/websites/extension')).json.data;
      const clickText = (t) => ev(dash, `[...document.querySelectorAll('button')].find(b=>b.textContent.trim()===${JSON.stringify(t)}).click()`);
      await nav('Website usage'); await wait(900);
      b = await body();
      check('website page: real tracked list, honest empty state, no sample data',
        (await text('h1')) === 'Website usage' && ['YouTube', 'Instagram', 'GitHub', 'Reddit', 'LinkedIn'].every((n) => b.includes(n)) && b.includes('Extension not connected') && b.includes('Nothing has been recorded today yet') && !b.includes('Sample data'));
      check('extension port is in the range the extension scans', pairing.probedPorts.includes(pairing.port));
      check('pairing code opens /ext but the dashboard token does not',
        (await extCall(port, pairing.pairingCode, 'GET', '/ext/ping')).status === 200 && (await extCall(port, svc.api.token, 'GET', '/ext/ping')).status === 401);
      check('pairing code does not open the dashboard API', (await extCall(port, pairing.pairingCode, 'GET', '/api/settings')).status === 403);

      await report(port, pairing.pairingCode, 'youtube.com');            // the extension says YouTube is in front
      await wait(3200);
      await report(port, pairing.pairingCode, 'youtube.com', { kind: 'heartbeat' });
      await clickText('Refresh now'); await wait(700);
      b = await body();
      const yt = (await call(dash, 'GET', '/api/websites/overview')).json.data;
      check('YouTube time is counted from real timestamps (about 3 s)', yt.sites.find((x) => x.domain === 'youtube.com').todaySeconds >= 3 && yt.sites.find((x) => x.domain === 'youtube.com').todaySeconds <= 5);
      check('dashboard shows Tracking on, Counting now, the time, total and most-used', b.includes('Tracking on') && b.includes('Counting now') && b.includes('Total tracked today') && b.includes('Most-used website'));

      powerMonitor.emit('lock-screen');                                    // real wiring: Electron powerMonitor -> idle monitor -> tracker
      await wait(300);
      const lockedAt = (await call(dash, 'GET', '/api/websites/overview')).json.data;
      await wait(2200);
      await report(port, pairing.pairingCode, 'youtube.com', { kind: 'heartbeat' });
      const lockedLater = (await call(dash, 'GET', '/api/websites/overview')).json.data;
      check('locking the screen stops counting', lockedAt.tracking.presence === 'locked' && lockedLater.sites.find((x) => x.domain === 'youtube.com').todaySeconds === lockedAt.sites.find((x) => x.domain === 'youtube.com').todaySeconds);
      powerMonitor.emit('unlock-screen');
      await wait(2300);
      await report(port, pairing.pairingCode, 'youtube.com', { kind: 'heartbeat' });
      const after = (await call(dash, 'GET', '/api/websites/overview')).json.data;
      check('unlocking resumes counting', after.tracking.presence === 'active' && after.sites.find((x) => x.domain === 'youtube.com').todaySeconds > lockedLater.sites.find((x) => x.domain === 'youtube.com').todaySeconds);

      await report(port, pairing.pairingCode, 'youtube.com', { paused: true });
      await clickText('Refresh now'); await wait(700);
      check('pausing in the extension shows Paused in browser', (await body()).includes('Paused in browser'));
      await report(port, pairing.pairingCode, null, { paused: false });
      check('a domain that is not on the list is never stored', (await extCall(port, pairing.pairingCode, 'POST', '/ext/activity', { installId: 'smoke-install-1', seq: extSeq++, kind: 'change', domain: 'unlisted-site.example', paused: false, at: new Date().toISOString() })).status === 200
        && !svc.db.prepare("SELECT 1 FROM usage_sessions WHERE item_name LIKE '%unlisted%'").get());
      check('API rejects URLs and extra fields from the extension', (await extCall(port, pairing.pairingCode, 'POST', '/ext/activity', { installId: 'smoke-install-1', seq: extSeq++, kind: 'change', domain: 'https://youtube.com/watch?v=1', paused: false, at: new Date().toISOString() })).status === 400
        && (await extCall(port, pairing.pairingCode, 'POST', '/ext/activity', { installId: 'smoke-install-1', seq: extSeq++, kind: 'change', domain: null, paused: false, at: new Date().toISOString(), url: 'https://x.test/' })).status === 400);

      await call(dash, 'POST', '/api/websites', { domain: 'smoke-example.com' });
      await call(dash, 'PUT', '/api/settings', { idleThresholdSeconds: 90 });
      check('website list edit and idle threshold are saved', (await call(dash, 'GET', '/api/websites/overview')).json.data.idleThresholdSeconds === 90 && (await call(dash, 'GET', '/api/websites')).json.data.length === 6);

      await clickText('Delete website history'); await wait(200); await clickText('Yes, delete it'); await wait(700);
      check('deleting website history removes website rows only', (await call(dash, 'GET', '/api/usage/history?category=website')).json.data.total === 0 && (await call(dash, 'GET', '/api/usage/history?category=application')).json.data.total === 1 && (await body()).includes('Deleted'));
      // ---------------- Phase 6: usage limits ----------------
      const fill = (sel, v) => ev(dash, `(()=>{const el=document.querySelector(${JSON.stringify(sel)});const set=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el),'value').set;set.call(el,${JSON.stringify(v)});el.dispatchEvent(new Event('input',{bubbles:true}));})()`);
      const limitsApi = async () => (await call(dash, 'GET', '/api/limits')).json.data;
      await nav('Usage limits'); await wait(900);
      b = await body();
      check('limits page: honest empty state, master switch, summary cards', (await text('h1')) === 'Usage limits' && b.includes('No limits yet') && b.includes('Master switch') && b.includes('Limits reached today') && b.includes('Restrictions on'));

      await fill('input[list="limit-targets"]', 'smoke-example.com'); await fill('input[type="number"][max="1440"]', '0'); await wait(100);
      await clickText('Add limit'); await wait(300);
      check('limit form shows a friendly validation message and creates nothing', (await body()).includes('Enter a whole number of minutes') && (await limitsApi()).items.length === 0);
      await fill('input[type="number"][max="1440"]', '1'); await wait(100);
      await clickText('Add limit'); await wait(900);
      let lim = (await limitsApi()).items[0];
      check('limit created from the UI (website, 1 minute, warning only) and shown on its card', lim && lim.target === 'smoke-example.com' && lim.dailyLimitSeconds === 60 && lim.mode === 'warn' && (await body()).includes('Warning only'));
      check('duplicate limit is refused with a friendly 409', (await call(dash, 'POST', '/api/limits', { targetType: 'website', target: 'smoke-example.com', dailyLimitSeconds: 600, mode: 'warn' })).json.error.code === 'duplicate');
      check('applications cannot be set to block (not implemented, so not offered)', (await call(dash, 'POST', '/api/limits', { targetType: 'application', target: 'Notepad', dailyLimitSeconds: 600, mode: 'enforce' })).json.error.code === 'unsupported_mode');

      const addUse = async (sec) => (await call(dash, 'POST', '/api/usage/sessions', { category: 'website', itemName: 'smoke-example.com', startedAt: new Date(Date.now() - sec * 1000).toISOString(), endedAt: new Date().toISOString() })).json.data.id;
      const useIds = [await addUse(50)];                                   // 50 of 60 s = 83%
      svc.tracking.limits.tick(); svc.tracking.limits.tick(); await wait(300);
      check('80% warning toast shown once (real engine, real notifier)', svc.tracking.notifier.shown.filter((t) => /of today's limit/.test(t.title)).length === 1);
      useIds.push(await addUse(15)); svc.tracking.limits.tick(); svc.tracking.limits.tick(); await wait(300);
      check('100% limit-reached toast shown once, and it says nothing is blocked', svc.tracking.notifier.shown.filter((t) => /Daily limit reached/.test(t.title)).length === 1 && /nothing is blocked/i.test(svc.tracking.notifier.shown.find((t) => /Daily limit reached/.test(t.title)).body));
      await wait(5600);   // the page polls every 5 s
      b = await body();
      check('card shows Limit reached with text (not colour alone), used and remaining', b.includes('Limit reached') && b.includes('Used today') && b.includes('Remaining'));
      const evs = (await call(dash, 'GET', '/api/limits/events')).json.data.records.map((e) => e.eventType);
      check('warning and reached events are saved in SQLite exactly once', evs.filter((t) => t === 'limit_warning').length === 1 && evs.filter((t) => t === 'limit_reached').length === 1);

      await call(dash, 'PUT', `/api/limits/${lim.id}`, { mode: 'enforce' });
      const cfgBlocked = (await extCall(port, pairing.pairingCode, 'GET', '/ext/config')).json.data.restrictions.items.map((i) => i.domain);
      check('enforced limit: the extension is told to block only that domain', cfgBlocked.length === 1 && cfgBlocked[0] === 'smoke-example.com');
      await clickText('Turn off all restrictions'); await wait(900);
      check('master switch off: nothing is blocked and the page says so', (await extCall(port, pairing.pairingCode, 'GET', '/ext/config')).json.data.restrictions.items.length === 0 && (await body()).includes('Restrictions OFF'));
      await clickText('Turn restrictions back on'); await wait(900);
      check('master switch on again restores the block list', (await extCall(port, pairing.pairingCode, 'GET', '/ext/config')).json.data.restrictions.items.length === 1);
      await call(dash, 'PUT', `/api/limits/${lim.id}`, { mode: 'confirm' });
      const ext1 = await call(dash, 'POST', `/api/limits/${lim.id}/extensions`, { minutes: 5 });
      check('approving extra time is recorded with its length', ext1.status === 201 && (await call(dash, 'GET', '/api/limits/events')).json.data.records.some((e) => e.eventType === 'extension_granted' && e.extraSeconds === 300));
      await clickText('Turn off'); await wait(800);
      check('disabling a limit keeps its settings', (await limitsApi()).items[0].isEnabled === false && (await limitsApi()).items[0].dailyLimitSeconds === 60);
      await call(dash, 'PUT', `/api/limits/${lim.id}`, { isEnabled: true, mode: 'confirm' });
      for (const id of useIds) await call(dash, 'DELETE', `/api/usage/sessions/${id}`); // remove the manual test usage; the limit stays for the restart check
      check('manual test usage removed, website history untouched by limits', (await call(dash, 'GET', '/api/usage/history?category=website')).json.data.total === 0);

      // leave a run open on purpose: quitting must store it
      await report(port, pairing.pairingCode, 'youtube.com'); await wait(2300);
      await report(port, pairing.pairingCode, 'youtube.com', { kind: 'heartbeat' }); await wait(1200);
      // ---------------- Phase 7: voice assistant ----------------
            const svc_send = (event) => { const w = require('../electron/windowManager').getDashboard(); w.webContents.send('voice:event', event); };
      await nav('Voice assistant'); await wait(1200);
      b = await body();
      check('voice page: microphone off, push-to-talk only, wake word unavailable, local-processing statement',
        (await text('h1')) === 'Voice assistant' && b.includes('Microphone off') && b.includes('Push-to-talk') && b.includes('Wake word') && b.includes('Hands-free listening is not built') && b.includes('Speech recognition is local'));
      check('renderer voice bridge exposes only the fixed operations', JSON.stringify(await ev(dash, `Object.keys(window.lilMoon.voice).sort()`)) === JSON.stringify(['onActivate', 'onEvent', 'openMicrophoneSettings', 'permission', 'start', 'stop', 'takeActivation']));
      check('voice defaults: enabled, push-to-talk, wake word off, history on', await (async () => { const s = (await call(dash, 'GET', '/api/voice/settings')).json.data; return s.enabled && s.pushToTalk && !s.wakeWordEnabled && s.historyEnabled && s.language === 'en-US'; })());

      await ev(dash, `[...document.querySelectorAll('button')].find(b=>b.getAttribute('aria-label')==='Start listening').click()`); await wait(700);
      check('pressing the microphone without Windows shows a friendly message, not a crash', (await body()).includes('Voice input needs Windows') && (await body()).includes('Microphone off'));

      await fill('input[placeholder="for example: open Notepad"]', 'What time is it?'); await wait(100);
      await clickText('Run command'); await wait(900);
      check('typed command is answered from the pipeline and shown as text', /It's \d{1,2}:\d{2} (AM|PM)\./.test(await body()) && (await body()).includes('Lil Moon says'));
      await fill('input[placeholder="for example: open Notepad"]', 'open notepad'); await clickText('Run command'); await wait(900);
      check('opening an app on a non-Windows system says so and launches nothing', (await body()).includes('only works on Windows'));
      await fill('input[placeholder="for example: open Notepad"]', 'turn off all restrictions'); await clickText('Run command'); await wait(900);
      check('a protection-changing request is refused and changes nothing', (await body()).includes('protection setting') && (await call(dash, 'GET', '/api/limits')).json.data.restrictionsEnabled === true);
      await fill('input[placeholder="for example: open Notepad"]', 'run powershell Get-Process'); await clickText('Run command'); await wait(900);
      check('a command-line request is refused', (await body()).includes("can't run commands"));

      // events from the local recogniser, delivered the same way the real engine delivers them
      svc_send({ type: 'state', state: 'listening' }); svc_send({ type: 'partial', text: 'show website' }); await wait(500);
      b = await body();
      check('listening indicator, "Microphone ON" and live transcription appear', b.includes('Microphone ON') && b.includes('● Listening') && b.includes('show website') && b.includes('Live transcription'));
      svc_send({ type: 'final', text: 'show website usage', confidence: 0.92 }); svc_send({ type: 'state', state: 'idle' }); await wait(1500);
      check('a spoken command is shown, run, and navigates the dashboard', (await text('h1')) === 'Website usage');
      await nav('Voice assistant'); await wait(900);
      check('recognised text and response are shown on the voice page after returning', (await body()).includes('Website usage today') || (await body()).includes("haven't recorded any website usage"));
      svc_send({ type: 'error', code: 'permission_denied', message: 'Windows is blocking microphone access. Open Windows Settings > Privacy & security > Microphone and allow desktop apps to use it.' }); await wait(500);
      check('microphone permission denied is explained with what to do', (await body()).includes('Windows is blocking microphone access'));
      svc_send({ type: 'error', code: 'no_microphone', message: 'No microphone was found. Plug one in, or pick your microphone in Windows Sound settings, then try again.' }); await wait(400);
      check('no-microphone error is explained', (await body()).includes('No microphone was found'));
      svc_send({ type: 'final', text: 'open settings', confidence: 0.3 }); await wait(1500);
      check('low-confidence navigation still works (read-only), no app launched', (await text('h1')) === 'Settings' && true);
      await nav('Voice assistant'); await wait(800);
      const vh = (await call(dash, 'GET', '/api/voice/history')).json.data;
      check('voice history is saved as text (spoken and typed), unmatched speech is not kept', vh.total >= 6 && vh.records.some((r) => r.source === 'voice' && r.intent === 'show_usage') && vh.records.every((r) => r.recognizedText.length > 0));
      await call(dash, 'PUT', '/api/voice/settings', { speechRate: 1.5, muted: true });
      check('wake word cannot be switched on', (await call(dash, 'PUT', '/api/voice/settings', { wakeWordEnabled: true })).json.error.code === 'wake_word_unavailable');
      require('./../electron/main.js').__activateVoice();   // the moon menu's "Talk to Lil Moon"
      await wait(1500);
      b = await body();
      check('"Talk to Lil Moon" from the moon opens the Voice page and tries one listening session', (await text('h1')) === 'Voice assistant' && b.includes('Voice input needs Windows'));
      await call(dash, 'PUT', '/api/settings', { theme: 'lilac' });
      await dash.webContents.reload(); await wait(1500);
      check('saved theme is applied after reload', (await ev(dash, `document.documentElement.dataset.theme`)) === 'lilac');
      await ev(dash, `window.lilMoon.dashboard.minimize()`); await wait(400);
      check('dashboard minimize (needs a window manager, may fail under bare Xvfb)', dash.isMinimized());
      await ev(moon, pointer('pointerdown', 10, 10)); await ev(moon, pointer('pointerup', 10, 10)); await wait(400);
      check('clicking the moon restores a minimized dashboard', !dash.isMinimized());
      await fire(dash, `window.lilMoon.dashboard.close()`); await wait(500);
      check('closing dashboard keeps the moon alive', wm.getDashboard() === null && !moon.isDestroyed() && moon.isVisible());
      await ev(moon, pointer('pointerdown', 10, 10)); await ev(moon, pointer('pointerup', 10, 10)); await wait(2000);
      app.on('will-quit', () => {
        check('explicit Exit quits the app', true);
        if (errors.length) console.log('RENDERER ERRORS:', JSON.stringify(errors));
    check('no JavaScript errors in renderers', errors.length === 0);
        process.exit(results.every(Boolean) ? 0 : 1);
      });
      await fire(wm.getDashboard(), `window.lilMoon.dashboard.exitApp()`);
      await wait(3000);
      check('explicit Exit quits the app', false);
    }
    if (errors.length) console.log('RENDERER ERRORS:', JSON.stringify(errors));
    check('no JavaScript errors in renderers', errors.length === 0);
    if (errors.length) console.log(errors);
  } catch (err) {
    console.error(err); check('smoke run completed without exception', false);
  }
  process.exit(results.every(Boolean) ? 0 : 1);
});
