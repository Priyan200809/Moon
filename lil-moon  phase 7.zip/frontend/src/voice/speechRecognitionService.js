// Renderer side of speech-to-text: a thin wrapper over the restricted preload bridge. The microphone is handled by the main process
// (Windows offline recogniser); this side can only ask it to start, stop, and hear its text events.
const bridge = () => window.lilMoon?.voice;

export const available = () => !!bridge();
export const start = (language) => (bridge() ? bridge().start(language) : Promise.resolve({ ok: false, error: { code: 'failed', message: 'Voice input is not available here. You can type commands.' } }));
export const stop = () => bridge()?.stop();
export const onEvent = (cb) => (bridge() ? bridge().onEvent(cb) : () => {});
export const permission = () => (bridge() ? bridge().permission() : Promise.resolve('unknown'));
export const openMicrophoneSettings = () => bridge()?.openMicrophoneSettings();
