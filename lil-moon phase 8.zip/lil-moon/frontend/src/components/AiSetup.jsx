import { useState } from 'react';
import { api } from '../lib/api.js';

const PRESETS = [
  { label: 'OpenAI', provider: 'openai-compatible', baseUrl: 'https://api.openai.com/v1' },
  { label: 'OpenRouter', provider: 'openai-compatible', baseUrl: 'https://openrouter.ai/api/v1' },
  { label: 'Local (Ollama)', provider: 'openai-compatible', baseUrl: 'http://localhost:11434/v1' },
  { label: 'Anthropic', provider: 'anthropic', baseUrl: '' },
];

export default function AiSetup({ status, onChanged }) {
  const [form, setForm] = useState({ provider: status.provider, baseUrl: status.baseUrl, model: status.model, memoryEnabled: status.memoryEnabled, allowFileExcerpts: status.allowFileExcerpts });
  const [key, setKey] = useState('');
  const [msg, setMsg] = useState({ text: '', error: false });
  const set = (patch) => { setForm({ ...form, ...patch }); setMsg({ text: '', error: false }); };
  const run = async (fn, ok) => {
    try { await fn(); setMsg({ text: ok, error: false }); onChanged(); } catch (e) { setMsg({ text: e.message, error: true }); }
  };

  return (
    <section className="card card-cream setup" aria-label="AI setup">
      <header className="card-head"><h2>AI setup</h2><span className="badge">{status.configured ? 'Ready' : 'Not ready'}</span></header>
      {!status.configured && <p className="note">Still needed: {status.missing.join(', ')}. Nothing is sent anywhere until this is complete.</p>}
      <div className="quick">
        {PRESETS.map((p) => <button key={p.label} type="button" className="btn btn-small" onClick={() => set({ provider: p.provider, baseUrl: p.baseUrl })}>{p.label}</button>)}
      </div>
      <label className="field">Provider type
        <select value={form.provider} onChange={(e) => set({ provider: e.target.value })}>
          <option value="openai-compatible">OpenAI-compatible (cloud or local)</option>
          <option value="anthropic">Anthropic</option>
        </select>
      </label>
      <label className="field">Address {form.provider === 'anthropic' && '(leave empty for the default)'}
        <input value={form.baseUrl} onChange={(e) => set({ baseUrl: e.target.value })} placeholder="https://api.openai.com/v1" spellCheck={false} />
      </label>
      <label className="field">Model
        <input value={form.model} onChange={(e) => set({ model: e.target.value })} placeholder="model name from your provider" spellCheck={false} />
      </label>
      <label className="row"><input type="checkbox" checked={form.memoryEnabled} onChange={(e) => set({ memoryEnabled: e.target.checked })} /> Use my saved memories in answers</label>
      <label className="row"><input type="checkbox" checked={form.allowFileExcerpts} onChange={(e) => set({ allowFileExcerpts: e.target.checked })} /> Let the AI see file names and short excerpts from my indexed files</label>
      <p className="note">{form.allowFileExcerpts ? 'Excerpts of matching files are sent to your AI provider when you ask a question about your files.' : 'Off: your files are never sent to the AI. Local file search still works.'}</p>
      <button type="button" className="btn btn-strong" onClick={() => run(() => api('PUT', '/api/ai/settings', form), 'Settings saved.')}>Save settings</button>

      <label className="field">API key {status.keyConfigured && <small>({status.keySource === 'environment' ? 'from the LILMOON_AI_API_KEY environment variable' : 'saved, encrypted on this computer'})</small>}
        <input type="password" value={key} onChange={(e) => setKey(e.target.value)} placeholder={status.keyConfigured ? 'Enter a new key to replace it' : 'Paste your key'} autoComplete="off" spellCheck={false} />
      </label>
      <div className="quick">
        <button type="button" className="btn" disabled={key.length < 8} onClick={() => run(async () => { await api('PUT', '/api/ai/key', { key }); setKey(''); }, 'Key saved. It stays on this computer and is never shown again.')}>Save key</button>
        {status.keySource === 'stored' && <button type="button" className="btn" onClick={() => run(() => api('DELETE', '/api/ai/key'), 'Key removed.')}>Remove key</button>}
      </div>
      <p className="note">The key is stored with Windows secure storage and used only by Lil Moon's background service. It never reaches this page.</p>
      <span role="status" className={msg.error ? 'msg-error' : ''}>{msg.text}</span>
    </section>
  );
}
