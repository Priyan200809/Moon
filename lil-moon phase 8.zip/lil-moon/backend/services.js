const { createAiRepository } = require('./aiRepo');
const { createIndexer } = require('./files/indexer');
const { createFilesService } = require('./files/service');
const { createTools } = require('./ai/tools');
const { createChat } = require('./ai/chat');

// keyStore: { has(), get(), set(key), clear(), source() } provided by the trusted main process.
function createServices({ db, repo, keyStore, actions = {}, userData = null }) {
  const aiRepo = createAiRepository(db);
  const indexer = createIndexer({ aiRepo, userData });
  const files = createFilesService({ db, aiRepo, indexer, actions, userData });
  const tools = createTools({ db, repo, aiRepo, files, actions });
  const chat = createChat({ db, repo, aiRepo, keyStore, tools });
  return { aiRepo, indexer, files, tools, chat, keyStore };
}

module.exports = { createServices };
