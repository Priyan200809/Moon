// Command normalisation: turns whatever the recogniser or the keyboard produced into a clean, lower-case phrase.
// Pure text in, pure text out: nothing here can run anything.
const POLITE_PREFIX = [
  /^(?:hey|hi|ok|okay)\s+(?:lil\s+)?moon\b[\s,]*/, /^lil\s+moon\b[\s,]*/, /^(?:please|kindly)\b[\s,]*/,
  /^(?:can|could|would|will)\s+you\b[\s,]*/, /^(?:i\s+want\s+to|i\s+would\s+like\s+to|i'd\s+like\s+to|i\s+need\s+to)\b[\s,]*/,
  /^(?:go\s+ahead\s+and|just)\b[\s,]*/,
];
const POLITE_SUFFIX = [/[\s,]*\b(?:please|for\s+me|now|thanks|thank\s+you)$/];
const MAX_LEN = 200;

function normalize(raw) {
  if (typeof raw !== 'string') return { ok: false, reason: 'empty' };
  if (raw.length > 600) return { ok: false, reason: 'too_long' };
  let t = raw.normalize('NFKC').toLowerCase().replace(/[\u0000-\u001f\u007f]/g, ' ');
  t = t.replace(/&/g, ' and ').replace(/[“”"‘’`]/g, (c) => (c === '’' || c === '‘' ? "'" : ''));
  t = t.replace(/[^a-z0-9.'+#\-\s]/g, ' ');               // drops ? ! , ; : ( ) / \ and anything shell-like
  t = t.replace(/(\S+)\s+dot\s+([a-z]{2,})\b/g, '$1.$2'); // "example dot com" -> "example.com"
  t = t.replace(/\.(?=\s|$)/g, ' ').replace(/\s+/g, ' ').trim(); // sentence-final full stops
  for (let changed = true; changed;) {
    changed = false;
    for (const re of POLITE_PREFIX) { const n = t.replace(re, ''); if (n !== t) { t = n.trim(); changed = true; } }
    for (const re of POLITE_SUFFIX) { const n = t.replace(re, ''); if (n !== t) { t = n.trim(); changed = true; } }
  }
  if (!t) return { ok: false, reason: 'empty' };
  if (t.length > MAX_LEN) return { ok: false, reason: 'too_long' };
  return { ok: true, text: t };
}

module.exports = { normalize, MAX_LEN };
