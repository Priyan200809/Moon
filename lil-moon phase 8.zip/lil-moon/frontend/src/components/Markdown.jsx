import { useState } from 'react';

// A small, safe Markdown renderer: builds React elements only (no innerHTML), so model or document text can never inject markup.
function Inline({ text }) {
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|(?<![\w*])\*[^*\s][^*]*\*(?![\w*])|(?<![\w_])_[^_\s][^_]*_(?![\w_]))/g);
  return parts.map((p, i) => {
    if (!p) return null;
    if (p.startsWith('`') && p.endsWith('`') && p.length > 2) return <code key={i} className="md-code">{p.slice(1, -1)}</code>;
    if (p.startsWith('**') && p.endsWith('**') && p.length > 4) return <strong key={i}>{p.slice(2, -2)}</strong>;
    const link = /^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/.exec(p);
    if (link) return <span key={i}>{link[1]} <small className="md-url">({link[2]})</small></span>; // shown, never clickable
    if ((p.startsWith('*') && p.endsWith('*') && p.length > 2) || (p.startsWith('_') && p.endsWith('_') && p.length > 2)) return <em key={i}>{p.slice(1, -1)}</em>;
    return p;
  });
}

export function CopyButton({ text, label = 'Copy' }) {
  const [done, setDone] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); setDone(true); setTimeout(() => setDone(false), 1500); } catch { /* clipboard unavailable */ }
  };
  return <button type="button" className="btn btn-small" onClick={copy}>{done ? 'Copied' : label}</button>;
}

function CodeBlock({ lang, code }) {
  return (
    <figure className="md-block">
      <figcaption><span>{lang || 'code'}</span><CopyButton text={code} label="Copy code" /></figcaption>
      <pre><code>{code}</code></pre>
    </figure>
  );
}

function Lines({ text }) {
  const out = [];
  let para = [], list = null;
  const flushPara = () => { if (para.length) { out.push(<p key={out.length}><Inline text={para.join(' ')} /></p>); para = []; } };
  const flushList = () => { if (list) { const Tag = list.ordered ? 'ol' : 'ul'; out.push(<Tag key={out.length}>{list.items.map((t, i) => <li key={i}><Inline text={t} /></li>)}</Tag>); list = null; } };
  for (const line of text.split('\n')) {
    const h = /^(#{1,4})\s+(.*)$/.exec(line), ul = /^\s*[-*]\s+(.*)$/.exec(line), ol = /^\s*\d+[.)]\s+(.*)$/.exec(line), bq = /^>\s?(.*)$/.exec(line);
    if (h) { flushPara(); flushList(); out.push(<p key={out.length} className="md-h"><Inline text={h[2]} /></p>); }
    else if (ul || ol) { flushPara(); const ordered = !!ol; if (!list || list.ordered !== ordered) { flushList(); list = { ordered, items: [] }; } list.items.push((ul ?? ol)[1]); }
    else if (bq) { flushPara(); flushList(); out.push(<blockquote key={out.length}><Inline text={bq[1]} /></blockquote>); }
    else if (!line.trim()) { flushPara(); flushList(); }
    else { flushList(); para.push(line.trim()); }
  }
  flushPara(); flushList();
  return out;
}

export default function Markdown({ text }) {
  const segments = text.split(/(```[^\n]*\n[\s\S]*?(?:```|$))/g);
  return (
    <div className="md">
      {segments.map((seg, i) => {
        const m = /^```([^\n]*)\n([\s\S]*?)(?:```)?$/.exec(seg);
        return m ? <CodeBlock key={i} lang={m[1].trim()} code={m[2].replace(/\n$/, '')} /> : <Lines key={i} text={seg} />;
      })}
    </div>
  );
}
