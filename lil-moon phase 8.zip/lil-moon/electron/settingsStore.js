// settings.json now only holds the moon position. Phase 2 "preferences" are left untouched and
// offered once to the database as a one-time import (see getLegacyPreferences).
const { app } = require('electron');
const fs = require('fs');
const path = require('path');

const file = () => path.join(app.getPath('userData'), 'settings.json');

function read() {
  try {
    const s = JSON.parse(fs.readFileSync(file(), 'utf8'));
    return s && typeof s === 'object' && !Array.isArray(s) ? s : {};
  } catch {
    return {};
  }
}

function write(data) {
  const tmp = file() + '.tmp';
  fs.mkdirSync(path.dirname(tmp), { recursive: true });
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file());
}

module.exports = {
  getMoon: () => read().moon,
  saveMoon: (moon) => write({ ...read(), moon }),
  getLegacyPreferences() {
    const p = read().preferences;
    return p && typeof p === 'object' ? { defaultDailyLimitMin: p.defaultDailyLimitMin, theme: p.theme } : null;
  },
};
