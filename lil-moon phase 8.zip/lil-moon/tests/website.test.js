// Website-tracking backend: real Express server + real SQLite + real idle monitor, on a mocked clock in a non-UTC timezone.
process.env.TZ = 'Asia/Kolkata'; // UTC+5:30: proves local-day logic is not accidentally UTC
const test = require('node:test');
const assert = require('node:assert/strict');
const { mock } = test;
const fs = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { openDatabase, createRepository, MIGRATIONS } = require('../backend/database');
const { startServer } = require('../backend/server');
const { createIdleMonitor } = require('../backend/idleMonitor');
const { splitAtLocalMidnight } = require('../backend/intervals');

const TOKEN = 'dash-token';
const EXT_ORIGIN = 'chrome-extension://abcdefghijklmnopabcdefghijklmnop';
const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'lm-web-')), 'lil-moon.db');
const local = (h, m = 0, s = 0, day = 15) => new Date(2026, 9, day, h, m, s).getTime(); // 15 Oct 2026, local time
const iso = (ms) => new Date(ms).toISOString();
let n = 0;
const seg = (host, from, to) => ({ clientId: `client-${Date.now()}-${++n}`, hostname: host, startedAt: iso(from), endedAt: iso(to) });

async function boot({ file = tmp(), idle = null, now = local(13) } = {}) {
  mock.timers.reset();
  mock.timers.enable({ apis: ['Date'], now });
  const db = openDatabase(file);
  const repo = createRepository(db);
  const api = await startServer({ repo, allowedOrigins: ['null'], extensionOrigins: [EXT_ORIGIN], activity: idle, token: TOKEN, ports: [0] });
  const raw = async (prefix, method, p, body, headers) => {
    const res = await fetch(api.baseUrl + prefix + p, { method, headers: { ...(body !== undefined && { 'Content-Type': 'application/json' }), ...headers }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: res.status, json: await res.json().catch(() => null) };
  };
  const dash = (method, p, body) => raw('/api', method, p, body, { Authorization: `Bearer ${TOKEN}` });
  const t = { db, repo, api, dash, file, code: null };
  t.pair = async () => { t.code = (await dash('POST', '/extension/pairing')).json.data.code; return t.code; };
  t.ext = (method, p, body, headers = {}) => raw('/ext', method, p, body, { Authorization: `Bearer ${t.code}`, ...headers });
  t.sync = (sessions, paused = false) => t.ext('POST', '/sync', { paused, browser: 'chrome', version: '0.1.0', sessions });
  t.rows = () => db.prepare("SELECT item_name, started_at, ended_at, duration_seconds, session_date FROM usage_sessions WHERE category = 'website' ORDER BY started_at").all();
  t.total = () => db.prepare("SELECT COALESCE(SUM(duration_seconds),0) s FROM usage_sessions WHERE category = 'website'").get().s;
  t.stop = async () => { await api.close(); db.close(); mock.timers.reset(); };
  return t;
}

test('pairing: separate credentials for dashboard and extension; code stored only as a hash', async () => {
  const t = await boot();
  assert.equal((await t.ext('GET', '/ping', undefined, { Authorization: '' })).json.data.app, 'lil-moon');
  assert.equal((await t.sync([])).json.error.code, 'not_paired');
  const code = await t.pair();
  assert.match(code, /^([A-Z2-9]{4}-){5}[A-Z2-9]{4}$/);
  assert.equal(t.db.prepare('SELECT COUNT(*) n FROM extension_pairing WHERE token_hash LIKE ?').get(`%${code.replace(/-/g, '')}%`).n, 0);
  assert.equal((await t.sync([])).status, 200);
  assert.equal((await t.sync([], false)).json.ok, true);
  assert.equal((await t.ext('POST', '/sync', { paused: false, browser: 'chrome', version: '1', sessions: [] }, { Authorization: 'Bearer WRONG-CODE-1234' })).status, 401);
  assert.equal((await t.ext('POST', '/sync', { paused: false, browser: 'chrome', version: '1', sessions: [] }, { Authorization: `Bearer ${TOKEN}` })).status, 401); // dashboard token is not an extension credential
  assert.equal((await t.dash('DELETE', '/extension/pairing')).json.data.revoked, true);
  assert.equal((await t.sync([])).status, 401);
  await t.stop();
});

test('origins: /ext accepts only the pinned extension, /api only our own pages; repeated bad codes are throttled', async () => {
  const t = await boot();
  await t.pair();
  const body = { paused: false, browser: 'chrome', version: '1', sessions: [] };
  assert.equal((await t.ext('POST', '/sync', body, { Origin: EXT_ORIGIN })).status, 200);
  assert.equal((await t.ext('POST', '/sync', body, { Origin: 'chrome-extension://evilevilevilevilevilevilevilevil' })).status, 403);
  assert.equal((await t.ext('POST', '/sync', body, { Origin: 'null' })).status, 403);
  assert.equal((await t.ext('POST', '/sync', body, { Origin: 'https://evil.example' })).status, 403);
  const apiRes = await fetch(t.api.baseUrl + '/api/health', { headers: { Authorization: `Bearer ${TOKEN}`, Origin: EXT_ORIGIN } });
  assert.equal(apiRes.status, 403);
  let last;
  for (let i = 0; i < 12; i++) last = await t.ext('POST', '/sync', body, { Authorization: 'Bearer nope-nope-nope-1' });
  assert.equal(last.status, 429);
  await t.stop();
});

test('a segment becomes a website session; hostnames are normalised by whole labels', async () => {
  const t = await boot();
  await t.pair();
  const r = await t.sync([seg('m.youtube.com', local(12), local(12, 10)), seg('WWW.GitHub.com', local(12, 10), local(12, 12))]);
  assert.equal(r.status, 200);
  assert.equal(r.json.data.results.accepted.length, 2);
  assert.deepEqual(t.rows().map((x) => [x.item_name, x.duration_seconds, x.session_date]), [['youtube.com', 600, '2026-10-15'], ['github.com', 120, '2026-10-15']]);
  const bad = await t.sync(['notyoutube.com', 'youtube.com.evil.net', 'evilyoutube.com', 'localhost', '127.0.0.1', 'chrome', 'example.org'].map((h, i) => seg(h, local(11, i), local(11, i, 30))));
  assert.equal(bad.json.data.results.accepted.length, 0);
  assert.ok(bad.json.data.results.rejected.every((x) => x.reason === 'not_tracked'));
  assert.equal(t.rows().length, 2);
  assert.equal(r.json.data.config.domains.length, 5);
  assert.equal(r.json.data.today.websiteSeconds, 720);
  await t.stop();
});

test('retries and overlaps never double count; consecutive segments merge into one row', async () => {
  const t = await boot();
  await t.pair();
  const a = seg('youtube.com', local(12), local(12, 10));
  await t.sync([a]);
  const again = await t.sync([a]);
  assert.deepEqual(again.json.data.results.duplicates, [a.clientId]);
  assert.equal(t.total(), 600);
  await t.sync([seg('youtube.com', local(12), local(12, 10))]); // new id, same time range
  assert.equal(t.total(), 600);
  await t.sync([seg('youtube.com', local(12, 5), local(12, 15))]); // partial overlap adds only the new 5 min
  assert.equal(t.total(), 900);
  assert.equal(t.rows().length, 1);
  for (let i = 0; i < 4; i++) await t.sync([seg('youtube.com', local(12, 15, i * 30), local(12, 15, i * 30 + 30))]);
  assert.equal(t.rows().length, 1);
  assert.equal(t.total(), 1020);
  await t.stop();
});

test('switching sites ends one session and starts the next; other sites are never merged', async () => {
  const t = await boot();
  await t.pair();
  await t.sync([seg('youtube.com', local(12), local(12, 10)), seg('instagram.com', local(12, 10), local(12, 15)), seg('youtube.com', local(12, 15), local(12, 20))]);
  assert.deepEqual(t.rows().map((r) => [r.item_name, r.duration_seconds]), [['youtube.com', 600], ['instagram.com', 300], ['youtube.com', 300]]);
  const today = (await t.dash('GET', '/usage/today?category=website')).json.data;
  assert.deepEqual(today.items.map((i) => [i.itemName, i.totalSeconds]), [['youtube.com', 900], ['instagram.com', 300]]);
  await t.stop();
});

test('idle: time after the threshold is trimmed, time before it and after return is kept', async () => {
  let idleSeconds = 0;
  const idle = createIdleMonitor({ getIdleSeconds: () => idleSeconds, getThresholdSeconds: () => 60, now: () => Date.now() });
  const t = await boot({ idle, now: local(12) });
  await t.pair();
  // user stops at 12:03:00, comes back at 12:07:00; the clock runs second by second to 12:10:00
  for (let s = 0; s <= 600; s++) {
    mock.timers.setTime(local(12) + s * 1000);
    const lastInput = s < 180 ? s : s < 420 ? 180 : s; // input at 3:00 stops, resumes at 7:00
    idleSeconds = s - (s < 180 ? s : s < 420 ? 180 : s);
    void lastInput;
    idle.tick();
  }
  const r = await t.sync([seg('youtube.com', local(12), local(12, 10))]);
  assert.equal(r.json.data.results.accepted.length, 1);
  assert.equal(t.total(), 4 * 60 + 3 * 60); // 12:00-12:04 (threshold crossed) + 12:07-12:10
  await t.stop();
});

test('lock and sleep intervals are excluded too', async () => {
  const idle = createIdleMonitor({ getIdleSeconds: () => 0, getThresholdSeconds: () => 60, now: () => Date.now() });
  const t = await boot({ idle, now: local(12) });
  await t.pair();
  mock.timers.setTime(local(12, 2)); idle.lock();
  assert.deepEqual([idle.state().inactive, idle.state().reason], [true, 'locked']);
  mock.timers.setTime(local(12, 5)); idle.unlock();
  mock.timers.setTime(local(12, 6)); idle.suspend();
  mock.timers.setTime(local(12, 8)); idle.resume();
  mock.timers.setTime(local(12, 10));
  await t.sync([seg('github.com', local(12), local(12, 10))]);
  assert.equal(t.total(), 600 - 180 - 120);
  assert.equal(idle.state().inactive, false);
  await t.stop();
});

test('sessions crossing local midnight are split so each day gets the right total', async () => {
  const t = await boot({ now: local(0, 30, 0, 16) });
  await t.pair();
  await t.sync([seg('reddit.com', local(23, 55, 0, 15), local(0, 5, 0, 16))]);
  assert.deepEqual(t.rows().map((r) => [r.session_date, r.duration_seconds]), [['2026-10-15', 300], ['2026-10-16', 300]]);
  const today = (await t.dash('GET', '/usage/today?category=website')).json.data;
  assert.equal(today.date, '2026-10-16');
  assert.equal(today.totals.website, 300);
  assert.equal((await t.dash('GET', '/usage/history?from=2026-10-15&to=2026-10-15&category=website')).json.data.total, 1);
  await t.stop();
});

test('split at local midnight is DST-safe (23 hour day in New York)', () => {
  const was = process.env.TZ;
  process.env.TZ = 'America/New_York';
  const parts = splitAtLocalMidnight([new Date(2026, 2, 7, 23, 0).getTime(), new Date(2026, 2, 9, 1, 0).getTime()]);
  assert.deepEqual(parts.map(([a, b]) => (b - a) / 3600000), [1, 23, 1]);
  process.env.TZ = was;
});

test('tracking switch, per-site switch, invalid, future and ancient segments', async () => {
  const t = await boot();
  await t.pair();
  await t.dash('PUT', '/settings', { websiteTrackingEnabled: false });
  const off = await t.sync([seg('youtube.com', local(12), local(12, 5))]);
  assert.equal(off.json.data.results.rejected[0].reason, 'tracking_disabled');
  assert.equal(off.json.data.config.trackingEnabled, false);
  assert.equal(t.total(), 0);
  await t.dash('PUT', '/settings', { websiteTrackingEnabled: true });
  const id = t.db.prepare("SELECT id FROM websites WHERE domain = 'reddit.com'").get().id;
  await t.dash('PATCH', `/websites/${id}`, { isEnabled: false });
  const r = await t.sync([seg('reddit.com', local(12), local(12, 5)), seg('youtube.com', local(14), local(14, 5)), seg('youtube.com', new Date(2026, 7, 1, 1).getTime(), new Date(2026, 7, 1, 1, 5).getTime()), { clientId: 'x', hostname: 'youtube.com' }, { clientId: 'client-bad-times', hostname: 'youtube.com', startedAt: 'now', endedAt: 'later' }, { clientId: 'client-extra-key', hostname: 'youtube.com', startedAt: iso(local(12)), endedAt: iso(local(12, 1)), url: 'https://youtube.com/watch?v=1' }]);
  const reasons = r.json.data.results.rejected.map((x) => x.reason).sort();
  assert.deepEqual(reasons, ['invalid', 'invalid', 'invalid', 'in_future', 'not_tracked', 'too_old'].sort());
  assert.equal(t.total(), 0);
  await t.stop();
});

test('malformed sync bodies are rejected with 400', async () => {
  const t = await boot();
  await t.pair();
  const ok = { paused: false, browser: 'chrome', version: '1', sessions: [] };
  for (const bad of [{}, { ...ok, paused: 'no' }, { ...ok, sessions: 'x' }, { ...ok, extra: 1 }, { ...ok, browser: '<script>' }, { ...ok, sessions: Array.from({ length: 101 }, () => ({})) }]) {
    assert.equal((await t.ext('POST', '/sync', bad)).status, 400, JSON.stringify(bad).slice(0, 40));
  }
  await t.stop();
});

test('website list management validates input and keeps data consistent', async () => {
  const t = await boot();
  const add = await t.dash('POST', '/websites', { domain: 'WWW.Example.COM', displayName: 'Example' });
  assert.equal(add.status, 201);
  assert.equal(add.json.data.domain, 'example.com');
  assert.equal((await t.dash('POST', '/websites', { domain: 'example.com' })).status, 409);
  for (const domain of ['https://x.com/path', 'x.com/path', 'x.com:8080', 'localhost', '127.0.0.1', 'co.uk', 'com.au', 'a b.com', '', 5, 'x'.repeat(300) + '.com']) {
    assert.equal((await t.dash('POST', '/websites', { domain })).status, 400, String(domain).slice(0, 20));
  }
  assert.equal((await t.dash('POST', '/websites', { domain: 'ok.com', matchMode: 'wild' })).status, 400);
  const exact = (await t.dash('POST', '/websites', { domain: 'exact.com', matchMode: 'exact' })).json.data;
  await t.pair();
  const r = await t.sync([seg('sub.exact.com', local(12), local(12, 1)), seg('www.exact.com', local(12, 1), local(12, 2)), seg('shop.example.com', local(12, 2), local(12, 3))]);
  assert.deepEqual(r.json.data.results.rejected.map((x) => x.reason), ['not_tracked']);
  assert.deepEqual(t.rows().map((x) => x.item_name), ['exact.com', 'example.com']);
  assert.equal((await t.dash('PATCH', `/websites/${exact.id}`, {})).status, 400);
  assert.equal((await t.dash('PATCH', '/websites/9999', { isEnabled: false })).status, 404);
  assert.equal((await t.dash('DELETE', `/websites/${exact.id}`)).status, 200);
  assert.equal((await t.dash('DELETE', `/websites/${exact.id}`)).status, 404);
  await t.stop();
});

test('deleting website history removes only website sessions', async () => {
  const t = await boot();
  await t.pair();
  await t.sync([seg('youtube.com', local(12), local(12, 10))]);
  await t.dash('POST', '/usage/sessions', { category: 'application', itemName: 'Editor', startedAt: iso(local(11)), endedAt: iso(local(11, 30)) });
  const before = (await t.dash('GET', '/usage/today')).json.data.totals;
  assert.deepEqual(before, { application: 1800, website: 600 }); // categories are reported separately, never summed
  assert.equal((await t.dash('DELETE', '/usage/websites')).json.data.deleted, 1);
  const after = (await t.dash('GET', '/usage/today')).json.data.totals;
  assert.deepEqual(after, { application: 1800, website: 0 });
  const resend = await t.sync([seg('youtube.com', local(12), local(12, 10))]);
  assert.equal(resend.json.data.results.accepted.length, 1); // a brand-new id after deletion is allowed
  await t.stop();
});

test('extension status reflects pairing, last sync, pause flag and desktop idle state', async () => {
  let idleSeconds = 0;
  const idle = createIdleMonitor({ getIdleSeconds: () => idleSeconds, getThresholdSeconds: () => 60, now: () => Date.now() });
  const t = await boot({ idle });
  assert.deepEqual([(await t.dash('GET', '/extension/status')).json.data.paired, (await t.dash('GET', '/extension/status')).json.data.connected], [false, false]);
  await t.pair();
  await t.sync([], true);
  let s = (await t.dash('GET', '/extension/status')).json.data;
  assert.deepEqual([s.paired, s.connected, s.extensionPaused, s.browser, s.activity.inactive], [true, true, true, 'chrome', false]);
  mock.timers.tick(5 * 60 * 1000);
  assert.equal((await t.dash('GET', '/extension/status')).json.data.connected, false);
  idleSeconds = 120; idle.tick();
  assert.equal((await t.dash('GET', '/extension/status')).json.data.activity.reason, 'idle');
  await t.stop();
});

test('open-dashboard action is available to a paired extension only', async () => {
  mock.timers.reset();
  mock.timers.enable({ apis: ['Date'], now: local(13) });
  const db = openDatabase(':memory:');
  let opened = 0;
  const api = await startServer({ repo: createRepository(db), allowedOrigins: ['null'], extensionOrigins: [EXT_ORIGIN], actions: { openDashboard: () => opened++ }, ports: [0], token: TOKEN });
  const dash = await fetch(api.baseUrl + '/api/extension/pairing', { method: 'POST', headers: { Authorization: `Bearer ${TOKEN}` } }).then((r) => r.json());
  const post = (code) => fetch(api.baseUrl + '/ext/open-dashboard', { method: 'POST', headers: { Authorization: `Bearer ${code}`, 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal((await post('wrong-wrong-wrong')).status, 401);
  assert.equal((await post(dash.data.code)).status, 200);
  assert.equal(opened, 1);
  await api.close(); db.close(); mock.timers.reset();
});

test('upgrading a version-1 database keeps all data and adds the Phase 5 and 8 defaults', () => {
  const file = tmp();
  const d = new DatabaseSync(file);
  d.exec(MIGRATIONS[0]); d.exec('PRAGMA user_version = 1');
  d.exec("INSERT INTO user_settings (id, daily_limit_seconds, theme, created_at, updated_at) VALUES (1, 7200, 'cream', 'a', 'b')");
  d.exec("INSERT INTO usage_sessions (category, item_name, started_at, ended_at, duration_seconds, session_date) VALUES ('application','Editor','2026-10-01T10:00:00.000Z','2026-10-01T10:10:00.000Z',600,'2026-10-01')");
  d.exec("INSERT INTO websites (domain, display_name, is_enabled) VALUES ('mine.example','Mine',0)");
  d.close();
  const db = openDatabase(file);
  const repo = createRepository(db);
  assert.equal(repo.schemaVersion(), 3);
  assert.deepEqual([repo.getSettings().dailyLimitSeconds, repo.getSettings().theme, repo.getSettings().idleThresholdSeconds, repo.getSettings().websiteTrackingEnabled], [7200, 'cream', 60, true]);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM usage_sessions').get().n, 1);
  const sites = repo.listWebsites();
  assert.equal(sites.find((s) => s.domain === 'mine.example').isEnabled, false);
  assert.equal(sites.length, 6);
  db.close();
});

test('website sessions and settings survive a restart', async () => {
  const file = tmp();
  let t = await boot({ file });
  await t.pair();
  await t.dash('PUT', '/settings', { idleThresholdSeconds: 90 });
  await t.sync([seg('youtube.com', local(12), local(12, 10))]);
  const code = t.code;
  await t.stop();
  t = await boot({ file });
  t.code = code;
  assert.equal(t.total(), 600);
  assert.equal((await t.dash('GET', '/settings')).json.data.idleThresholdSeconds, 90);
  assert.equal((await t.sync([])).status, 200); // pairing survived too
  await t.stop();
});
